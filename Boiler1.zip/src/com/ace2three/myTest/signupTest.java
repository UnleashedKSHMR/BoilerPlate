package com.ace2three.myTest;
import com.ace2three.base.*;
import com.ace2three.locators.AndroidLocators;

public class signupTest implements AndroidLocators{
	
	
	
	
	


}
