package com.ace2three.web.impl.pages;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.relevantcodes.extentreports.LogStatus;

public class TourneyAdminImplPage  extends BaseTestSuite{
	
	
	WebDriver desktopDriver;
	

	public TourneyAdminImplPage(WebDriver desktopDriver) {
		
		this.desktopDriver = desktopDriver;
		PageFactory.initElements(desktopDriver, this);
	}
	

	@FindBy(css= "input[name='isFirstFinal']")
	private WebElement firstFinalRadioButton;
	
	public WebElement getFirstFinalRadioButton(){
		return firstFinalRadioButton;
	}
	
	@FindBy(css= "select[id='dynamictab']")
	private WebElement clientTargetedTabDropDownList;
	
	public WebElement getClientTargetedTabDropDownList(){
		return clientTargetedTabDropDownList;
	}
	
	@FindBy(css= "input[name='fixedTablesNumber']")
	private WebElement fixedNoOfTables;
	
	public WebElement getFixedNoOfTables(){
		return fixedNoOfTables;
	}
	
	@FindBy(css= "input[name='aceRadio']")
	private WebElement aceLevelRadioButton;
	
	public WebElement getAceLevelRadioButton(){
		return aceLevelRadioButton;
	}
	
	@FindBy(css= "input[id='checkAll']")
	private WebElement allCheckBox;
	
	public WebElement getAllCheckBox(){
		return allCheckBox;
	}
	@FindBy(css= "input[name='startingDate']")
	private WebElement tourneyStartingDate;
	
	public WebElement getTourneyStartingDate(){
		return tourneyStartingDate;
	}
	@FindBy(css= "select[id='starthr']")
	private WebElement tourneyStartHour;
	
	public WebElement getTourneyStartHour(){
		return tourneyStartHour;
	}
	
	@FindBy(css= "select[id='startmin']")
	private WebElement tourneyStartMin;
	
	public WebElement getTourneyStartMin(){
		return tourneyStartMin;
	}
	
	@FindBy(css= "input[id='entrybuyin']")
	private WebElement entryBuyIn;
	
	public WebElement getEntryBuyIn(){
		return entryBuyIn;
	}
	
	@FindBy(css= "select[id='TourneyRake']")
	private WebElement tourneyRake;
	
	public WebElement getTourneyRake(){
		return tourneyRake;
	}
	
	@FindBy(css= "input[id='guaranteedamount']")
	private WebElement guaranteedAmount;
	
	public WebElement getGuaranteedAmount(){
		return guaranteedAmount;
	}
	
	@FindBy(css= "input[id='tourneyprize']")
	private WebElement tourneyPrize;
	
	public WebElement getTourneyPrize(){
		return tourneyPrize;
	}
	@FindBy(css= "input[id='maxplayers']")
	private WebElement maximumPlayers;
	
	public WebElement getMaximumPlayers(){
		return maximumPlayers;
	}
	
	@FindBy(css= "textarea[id='tdesc']")
	private WebElement tourneyDescription;
	
	public WebElement getTourneyDescription(){
		return tourneyDescription;
	}
	
	@FindBy(css= "textarea[id='ldesc']")
	private WebElement lobbyDescription;
	
	public WebElement getLobbyDescription(){
		return lobbyDescription;
	}
	@FindBy(css= "input[id='giftVoucherId']")
	private WebElement useGiftVoucherRadioButton;
	
	public WebElement getUseGiftVoucherRadioButton(){
		return useGiftVoucherRadioButton;
	}
	
	
	@FindBy(css= "select[name='prizeRecID']")
	private WebElement noOfWinnerOrTableDropDownList;
	
	public WebElement getNoOfWinnerOrTableDropDownList(){
		return noOfWinnerOrTableDropDownList;
	}
	
	@FindBy(css= "select[name='URLName']")
	private WebElement urlDropDownList;
	
	public WebElement getUrlDropDownList(){
		return urlDropDownList;
	}
	
	@FindBy(css= "select[id='gameDefValue']")
	private WebElement gameDefinition;
	
	public WebElement getGameDefinition(){
		return gameDefinition;
	}
	
	@FindBy(css= "input[id='rejoinAmount']")
	private WebElement rejoinBetAmount;
	
	public WebElement getRejoinBetAmount(){
		return rejoinBetAmount;
	}
	
	@FindBy(css= "input[id='entryDescription1']")
	private WebElement entryDescriptionLine1;
	
	public WebElement getEntryDescriptionLine1(){
		return entryDescriptionLine1;
	}
	
	@FindBy(css= "input[id='entryDescription2']")
	private WebElement entryDescriptionLine2;
	
	public WebElement getEntryDescriptionLine2(){
		return entryDescriptionLine2;
	}
	
	@FindBy(css= "input[id='AnnouncedToRegTime']")
	private WebElement announcedToReg;
	
	public WebElement getAnnouncedToRegistrationField(){
		return announcedToReg;
	}
	
	
	@FindBy(css= "select[id='announcedToRegTimeHr']")
	private WebElement announcedToRegHour;
	
	public WebElement getAnnouncedToRegHour(){
		return announcedToRegHour;
	}
	
	@FindBy(css= "select[id='announcedToRegTimeMin']")
	private WebElement announcedToRegMin;
	
	public WebElement getAnnouncedToRegMin(){
		return announcedToRegMin;
	}
	
	@FindBy(css= "input[value='Insert']")
	private WebElement insertButton;
	
	public WebElement getInsertButton(){
		return insertButton;
	}
	
	public enum tourneyGiftVoucherType
	{
		
		USEGIFTVOUCHER, GIFTVOUCHERONLY;
		
	}
	
	
	public String createTourneyAndGenerateGiftVoucher(tourneyGiftVoucherType giftVoucherTourney) throws InterruptedException, IOException
	{
		System.setProperty("webdriver.chrome.driver" , System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
		desktopDriver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(desktopDriver, 10);
		AdminImplPage webAdminPage = new AdminImplPage(desktopDriver);
		TourneyAdminImplPage tourneyAdminImplPage = new TourneyAdminImplPage(desktopDriver);
		desktopDriver.get("http://qaweb.headinfotech.local:8080/AceAdmin");
		webAdminPage.getAdminUserName().sendKeys(ReadDataFromProps.props.getProperty("user.name"));
		webAdminPage.getPasswordButton().sendKeys(ReadDataFromProps.props.getProperty("password.input"));

		webAdminPage.getloginSubmitButton().click();
		desktopDriver.manage().window().maximize();
		
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals(ReadDataFromProps.props.getProperty("admin.tab.tourney"))){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href*='poolTourney.do']")).click();
		tourneyAdminImplPage.getFirstFinalRadioButton().click();
		WebElement ele = tourneyAdminImplPage.getClientTargetedTabDropDownList();
		new Select(ele).selectByValue("Cash");
		tourneyAdminImplPage.getFixedNoOfTables().clear();
		tourneyAdminImplPage.getFixedNoOfTables().sendKeys("1");
		tourneyAdminImplPage.getAceLevelRadioButton().click();
		tourneyAdminImplPage.getAllCheckBox().click();
		new Select(desktopDriver.findElement(By.cssSelector("select[name='tname']"))).selectByValue("Premium Buy-in");
		new Select(desktopDriver.findElement(By.cssSelector("select[id='currentlevelstatus']"))).selectByIndex(1);;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		LocalDateTime now = LocalDateTime.now();  
		String date = (now.getDayOfMonth()+1)+"/"+now.getMonth()+"/"+now.getYear();
		   
		tourneyAdminImplPage.getTourneyStartingDate().sendKeys(date);
		new Select(tourneyAdminImplPage.getTourneyStartHour()).selectByValue(ReadDataFromProps.props.getProperty("tourney.start.hour"));
		new Select(tourneyAdminImplPage.getTourneyStartMin()).selectByValue(ReadDataFromProps.props.getProperty("tourney.start.min"));
		tourneyAdminImplPage.getEntryBuyIn().clear();
		tourneyAdminImplPage.getEntryBuyIn().sendKeys("10");
		if(giftVoucherTourney.toString().equals("USEGIFTVOUCHER"))
		tourneyAdminImplPage.getUseGiftVoucherRadioButton().click();
		else if(giftVoucherTourney.toString().equals("GIFTVOUCHERONLY"))
		desktopDriver.findElement(By.cssSelector("input[value='G']")).click();
		new Select(tourneyAdminImplPage.getTourneyRake()).selectByValue("10");
		tourneyAdminImplPage.getGuaranteedAmount().sendKeys("10");
		tourneyAdminImplPage.getMaximumPlayers().sendKeys("5");
		tourneyAdminImplPage.getTourneyDescription().sendKeys("AutoTourney");
		tourneyAdminImplPage.getLobbyDescription().sendKeys("AutoTourney");
		new Select(tourneyAdminImplPage.getNoOfWinnerOrTableDropDownList()).selectByIndex(1);
		new Select(tourneyAdminImplPage.getUrlDropDownList()).selectByIndex(1);
		new Select(tourneyAdminImplPage.getGameDefinition()).selectByIndex(1);
		tourneyAdminImplPage.getRejoinBetAmount().sendKeys("10");
		tourneyAdminImplPage.getEntryDescriptionLine1().sendKeys("AutoTourney");
		tourneyAdminImplPage.getEntryDescriptionLine2().sendKeys("AutoTourney");
		String date1 = (now.getDayOfMonth())+"/"+now.getMonth()+"/"+now.getYear();
		tourneyAdminImplPage.getAnnouncedToRegistrationField().sendKeys(date1);
		tourneyAdminImplPage.getAnnouncedToRegHour().sendKeys(ReadDataFromProps.props.getProperty("tourney.registration.start.hour"));
		tourneyAdminImplPage.getAnnouncedToRegMin().sendKeys(ReadDataFromProps.props.getProperty("tourney.registration.start.min"));
		tourneyAdminImplPage.getInsertButton().click();
		Thread.sleep(3000);
		WebElement eleme=desktopDriver.findElement(By.xpath("//font[contains(text(),'Tourney inserted successfully')]"));
		if(CustomMethods.isElementPresent(eleme))
		{
			logger.log(LogStatus.PASS, "Tourney Successfully Inserted");
		}
		String successText=eleme.getText();
		String arr[]=successText.split(" ");
		System.out.println(successText);
		List<WebElement>  tabsList =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOneTab:tabsList){
			System.out.println(listedOneTab.getText());
				if(listedOneTab.getText().equals(ReadDataFromProps.props.getProperty("admin.tab.admin"))){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOneTab).build().perform();
				}
		}
		webAdminPage.getGiftVouchers().click();
		JavascriptExecutor executor = (JavascriptExecutor) desktopDriver;
	//	executor.executeScript("document.body.style.zoom = '0.9'");
	//	desktopDriver.navigate().refresh();
	//	webAdminPage.getGameVoucherTypeRadio().click();
		executor.executeScript("arguments[0].click();",webAdminPage.getGameVoucherTypeRadio());
		webAdminPage.getNoOfChipsField().sendKeys("10");
		webAdminPage.getNoOfPlayersCount().sendKeys("5");
		
		new Select(webAdminPage.getTourneyTypeGiftVoucher()).selectByIndex(1);;
		
		//webAdminPage.getTourneyButtonGiftVoucher().click();
		executor.executeScript("arguments[0].click();",webAdminPage.getTourneyButtonGiftVoucher());
		
		Thread.sleep(2000);
		int getTourneyList= new Select(webAdminPage.getSelectTourneyDropDown()).getOptions().size();
		System.out.println("list no:"+ getTourneyList);
		for(int i=1;i<getTourneyList;i++){
		new Select(webAdminPage.getSelectTourneyDropDown()).selectByIndex(i);
		//JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
		executor.executeScript("arguments[0].click();", webAdminPage.getCheckTourneyBonusLink());
		
		//webAdminPage.getCheckTourneyBonusLink().click();
			if(webAdminPage.getBonusCodeNewSucessMessage().getText().equals("It's a new bonuscode. You are good to go.")){
				verifyTextPresent(webAdminPage.getBonusCodeNewSucessMessage(),"It's a new bonuscode. You are good to go.");
				break;
			}
		}
		
		//webAdminPage.getDatePickerGiftVoucher().click();
		executor.executeScript("arguments[0].click();", webAdminPage.getDatePickerGiftVoucher());
		//desktopDriver.findElement(By.cssSelector(".ui-datepicker-week-end a")).click();
		executor.executeScript("arguments[0].click();",desktopDriver.findElement(By.cssSelector(".ui-datepicker-week-end a")));
		
		WebElement dateEle = desktopDriver.findElement(By.xpath("//input[contains(@id,'dispdate')]/following-sibling::img"));
		
		
		executor.executeScript("arguments[0].click();", dateEle);
		executor.executeScript("arguments[0].click();",desktopDriver.findElement(By.cssSelector(".ui-datepicker-week-end a")));
		//logger.log(LogStatus.PASS, "Failed screenshot" + logger.addScreenCapture(takeScreenShot("screen")));
		Thread.sleep(3000);
		//webAdminPage.getApplicabilityIdPrimium().click();
		//webAdminPage.getGenerateVouchers().click();
		WebElement musaID = desktopDriver.findElement(By.cssSelector("input[id='musaID']"));
		executor.executeScript("arguments[0].click();", webAdminPage.getApplicabilityIdPrimium());
		executor.executeScript("arguments[0].click();",musaID);
		executor.executeScript("arguments[0].click();",webAdminPage.getGenerateVouchers());
		desktopDriver.switchTo().alert().accept();
		Thread.sleep(3000);
		verifyTextPresent(webAdminPage.getCreateVoucherSucessMessage(), "Voucher code successfully created.");
		
		
		List<WebElement>  tabsList1 =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOneTab:tabsList1){
			System.out.println(listedOneTab.getText());
				if(listedOneTab.getText().equals(ReadDataFromProps.props.getProperty("admin.tab.tourney"))){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOneTab).build().perform();
				}
		}
		//href="TourneyDetails.do?type=updateReg&tourney_id=JB003537";
		String loc = "a[href*='id="+arr[arr.length-1]+"']";
		System.out.println(loc);
		desktopDriver.findElement(By.cssSelector("a[href*='TourneyDetails.do?type=Reg']")).click();
		desktopDriver.findElement(By.cssSelector("a[href='/AceAdmin/TourneyDetails.do?type=Reg&type=Reg&d-49653-p=2']")).click();
		desktopDriver.findElement(By.cssSelector(loc)).click();
		desktopDriver.switchTo().alert().accept();
		desktopDriver.close();
		return arr[arr.length-1];
	}
	
	public static void main(String args[]) 
	{
		System.setProperty("webdriver.chrome.driver" , System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
		WebDriver desktopDriver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(desktopDriver, 10);
		desktopDriver.close();
		
	}
	
}
