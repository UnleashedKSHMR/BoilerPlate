package com.ace2three.web.impl.pages;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ace2three.locators.WebLocators.AdminLoginPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;

public class AdminImplPage implements AdminLoginPage{
	WebDriver desktopDriver;
	ReadDataFromProps ReadProps =new ReadDataFromProps(); 
	
	public AdminImplPage(WebDriver driver){
		this.desktopDriver= driver;
		PageFactory.initElements(driver, this);
		}
	public AdminImplPage(){
		
		}
	
	
	@FindBy(css= ADMIN_USER_NAME)
	private WebElement adminUserName;
	
	public WebElement getAdminUserName(){
		return adminUserName;
	}
	
	@FindBy(css= ADMIN_PASSWORD_FIELD)
	private WebElement passwordButton;
	
	public WebElement getPasswordButton(){
		return passwordButton;
	}
	
	@FindBy(css= ADMIN_SUBMIT_BUTTON)
	private WebElement loginSubmitButton;
	
	public WebElement getloginSubmitButton(){
		return loginSubmitButton;
	}
	
	@FindBy(xpath= TOURNEY_TAB)
	private WebElement tourneyTab;
	
	public WebElement getTourneyTab(){
		return tourneyTab;
	}
	
	@FindBy(css= "li a[href='mtctTourneyInsertNew.jsp']")
	private WebElement insertJumbo;
	
	public WebElement getInsertJumbo(){
		return insertJumbo;
	}
	
	@FindBy(css= ".hdr_title a[href*='GetTourneyTemplates.do']")
	private WebElement viewTemplate;
	
	public WebElement getViewTemplate(){
		return viewTemplate;
	}
	
	@FindBy(css= "select#currentlevelstatus")
	private WebElement levelStatus;
	
	public WebElement getLevelStatus(){
		return levelStatus;
	}

	@FindBy(css= ".vouchers input#giftVoucherOnly")
	private WebElement buyInGiftVoucherOnly;
	
	public WebElement getBuyInGiftVoucherOnly(){
		return buyInGiftVoucherOnly;
	}

	@FindBy(css= "input#FromDate")
	private WebElement tourneyStartDate;
	
	public WebElement getTourneyStartDate(){
		return tourneyStartDate;
	}
	

	@FindBy(css= "input#RegFromDate")
	private WebElement registrationStartDate;
	
	public WebElement getRegistrationStartDate(){
		return registrationStartDate;
	}
	
	@FindBy(css= "textarea#tdesc")
	private WebElement tourneyDiscription;
	
	public WebElement getTourneyDiscription(){
		return tourneyDiscription;
	}
	@FindBy(css= "textarea#ldesc")
	private WebElement lobbyDiscription;
	
	public WebElement getLobbyDiscription(){
		return lobbyDiscription;
	}
	
		
	@FindBy(css= "select#regstarthr")
	private WebElement tourneyRegistrationStartHour;
	
	public WebElement getTourneyRegistrationStartHour(){
		return tourneyRegistrationStartHour;
	}
	
	@FindBy(css= "select#regstartmin")
	private WebElement tourneyRegistrationStartMins;
	
	public WebElement getTourneyRegistrationStartMins(){
		return tourneyRegistrationStartMins;
	}
	
	@FindBy(css= "#sumittd input[type=submit]")
	private WebElement tourneyCreateSubmitButton;
	
	public WebElement getTourneyCreateSubmitButton(){
		return tourneyCreateSubmitButton;
	}
	
	@FindBy(css= "input#initialtourneychips")
	private WebElement tourneyInitialNoOfChips;
	
	public WebElement getTourneyInitialNoOfChips(){
		return tourneyInitialNoOfChips;
	}
	
	@FindBy(css= "input#entrybuyin")
	private WebElement entrybuyin;
	
	public WebElement getEntrybuyin(){
		return entrybuyin;
	}
	
	@FindBy(css= "input#maxtplayers")
	private WebElement tourneyCount;
	
	public WebElement getTourneyCount(){
		return tourneyCount;
	}
	
	@FindBy(css= "input#createcampaign")
	private WebElement generateVouchers;
	
	public WebElement getGenerateVouchers(){
		return generateVouchers;
	}
	
	@FindBy(css= "html>body>p")
	private WebElement tourneySucessMessage;
	
	public WebElement getTourneySucessMessage(){
		return tourneySucessMessage;
	}
	
	@FindBy(css= "li a[href='grouponbonusconfig.do?method=forward']")
	private WebElement giftVouchers;
	
	public WebElement getGiftVouchers(){
		return giftVouchers;
	}
	
	@FindBy(css= "input[id='tourneyVoucher']")
	private WebElement gameVoucherTypeRadio;
	
	public WebElement getGameVoucherTypeRadio(){
		return gameVoucherTypeRadio;
	}
	@FindBy(css= "input#addedChips")
	private WebElement noOfChipsField;
	
	public WebElement getNoOfChipsField(){
		return noOfChipsField;
	}
	
	@FindBy(css= "input#addedCount")
	private WebElement noOfPlayersCount;
	
	public WebElement getNoOfPlayersCount(){
		return noOfPlayersCount;
	}
	
	@FindBy(css= "select#tourneytype")
	private WebElement tourneyTypeGiftVoucher;
	
	public WebElement getTourneyTypeGiftVoucher(){
		return tourneyTypeGiftVoucher;
	}
	
	@FindBy(css= "input[id='getTourney']")
	private WebElement getTourneyButtonGiftVoucher;
	
	public WebElement getTourneyButtonGiftVoucher(){
		return getTourneyButtonGiftVoucher;
	}
	
	@FindBy(css= "a#verifyBonus")
	private WebElement checkTourneyBonusLink;
	
	public WebElement getCheckTourneyBonusLink(){
		return checkTourneyBonusLink;
	}
	
	@FindBy(css= "span#msgID")
	private WebElement bonusCodeNewSucessMessage;
	
	public WebElement getBonusCodeNewSucessMessage(){
		return bonusCodeNewSucessMessage;
	}

	@FindBy(css= "select#selection")
	private WebElement selectTourneyDropDown;
	
	public WebElement getSelectTourneyDropDown(){
		return selectTourneyDropDown;
	}
	
	@FindBy(css= "input.applicabilityID[value='PREMIUM']")
	private WebElement applicabilityIdPrimium;
	
	public WebElement getApplicabilityIdPrimium(){
		return applicabilityIdPrimium;
	}
	
	@FindBy(css= "img.ui-datepicker-trigger")
	private WebElement datePickerGiftVoucher;
	
	public WebElement getDatePickerGiftVoucher(){
		return datePickerGiftVoucher;
	}
	
	@FindBy(css= "html>body>div:nth-of-type(2)")
	private WebElement createVoucherSucessMessage;
	
	public WebElement getCreateVoucherSucessMessage(){
		return createVoucherSucessMessage;
	}
	
	
	@FindBy(css= "input#cmailId")
	private WebElement updateProfileEmailCheckBok;
	
	public WebElement getUpdateProfileEmailCheckBok(){
		return updateProfileEmailCheckBok;
	}
	
	@FindBy(css= "input#mail")
	private WebElement updateProfileEmailField;
	
	public WebElement getUpdateProfileEmailField(){
		return updateProfileEmailField;
	}
	@FindBy(css= "input#cPhoneNum")
	private WebElement updatePhoneNumberCheckBok;
	
	public WebElement getUpdatePhoneNumberCheckBok(){
		return updatePhoneNumberCheckBok;
	}
	
	@FindBy(css= "input#phone")
	private WebElement updatePhoneNumberField;
	
	public WebElement getUpdatePhoneNumberField(){
		return updatePhoneNumberField;
	}
	/*@FindBys(xpath= "//tr[@class,'odd' or 'even'", value = { @FindBy })
	private List<WebElement> templateTableContent;
	
	public WebElement getTemplateTableContent(){
		return templateTableContent;
	}*/
	
	void mouserOver(WebElement element) throws InterruptedException{
		Thread.sleep(2000);
		Actions action = new Actions(desktopDriver);
		action.moveToElement(element).build().perform();
	}
	
	public void navigateToInsertJumbo() throws InterruptedException{
		mouserOver(getTourneyTab());
	
		WebDriverWait wait = new WebDriverWait(desktopDriver, 10);
				wait.until(ExpectedConditions.visibilityOf(desktopDriver.findElement(By.cssSelector("li a[href='mtctTourneyInsertNew.jsp']"))));
				desktopDriver.findElement(By.cssSelector("li a[href='mtctTourneyInsertNew.jsp']")).click();
		
	}
	
	public void updatePhoneNumberInProfile(String userName, String phoneNumber) throws InterruptedException{
		desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		
		JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
		executor.executeScript("document.body.style.zoom = '0.9'");
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
		try{
			desktopDriver.findElement(By.cssSelector("a[href='userProfileDetails.jsp?userid="+userName+"']")).click();
		}catch(Exception e){
			System.out.println("exception 11");
		}
		
		desktopDriver.findElement(By.cssSelector("a[href*='userDetailsUpdate.jsp']")).click();
	
		getUpdatePhoneNumberCheckBok().click();
		getUpdatePhoneNumberField().clear();
		getUpdatePhoneNumberField().sendKeys(phoneNumber);
		
		WebElement update=	desktopDriver.findElement(By.cssSelector("input[value='UPDATE']"));
		((JavascriptExecutor) desktopDriver).executeScript("arguments[0].scrollIntoView(true);", update);
		executor.executeScript("arguments[0].click()",update);
		desktopDriver.switchTo().alert().accept();
		WebElement goToProfile=	desktopDriver.findElement(By.cssSelector("input[value='Go Back to Player Profile']"));
		executor.executeScript("arguments[0].click()",goToProfile);
		Thread.sleep(3000);
	}

	public void  updatePhoneNumberAndEmailInProfile(String userName) throws InterruptedException{
		
		desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
		executor.executeScript("document.body.style.zoom = '0.9'");
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
		try{
			desktopDriver.findElement(By.cssSelector("a[href='userProfileDetails.jsp?userid="+userName+"']")).click();
		}catch(Exception e){
			System.out.println("exception 11");
		}
		desktopDriver.findElement(By.cssSelector("a[href*='userDetailsUpdate.jsp']")).click();
		
		
		
		getUpdateProfileEmailCheckBok().click();
		getUpdateProfileEmailField().clear();
		getUpdateProfileEmailField().sendKeys(CustomMethods.randomStringGenerator(6)+"@abc.com");
		WebElement update=	desktopDriver.findElement(By.cssSelector("input[value='UPDATE']"));
		((JavascriptExecutor) desktopDriver).executeScript("arguments[0].scrollIntoView(true);", update);
		getUpdatePhoneNumberCheckBok().click();
		getUpdatePhoneNumberField().clear();
		getUpdatePhoneNumberField().sendKeys("555"+Integer.toString(CustomMethods.generateRandomNumber(7)));

		
		executor.executeScript("arguments[0].click()",update);
		desktopDriver.switchTo().alert().accept();
		Thread.sleep(2000);
		WebElement goToProfile=	desktopDriver.findElement(By.cssSelector("input[value='Go Back to Player Profile']"));
		executor.executeScript("arguments[0].click()",goToProfile);
		Thread.sleep(2000);

		}

	public static void main(String args[]) throws InterruptedException{
		AdminImplPage adminImplPage = new  AdminImplPage();
		CustomMethods  customMethods=new  CustomMethods();
		AdminImplPage adminImplPage2= new AdminImplPage(customMethods.launchWebBrowser());
		
		
		adminImplPage2.updatePhoneNumberAndEmailInProfile("dinesh5620");
	}
}
