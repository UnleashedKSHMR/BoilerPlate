package com.ace2three.web.impl.pages;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import io.appium.java_client.AppiumDriver;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.base.Beforetest;
import com.ace2three.locators.AndroidLocators;
import com.ace2three.locators.AndroidLocators.LaunchPageLocators;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.StartsActivity;
import io.appium.java_client.remote.MobileCapabilityType;

public class WebProfileEditImplPage implements AndroidLocators , LaunchPageLocators{

	WebDriver driver;
	public WebProfileEditImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver= driver;
		PageFactory.initElements(driver, this);
        		
	}
	
	@FindBy(css= "div.buychips_btn a")
	WebElement editProfileButton;
	
	public WebElement getEditProfileButton(){
		return editProfileButton;
	}
		
	@FindBy(css= "input#firstName")
	WebElement firstNameField;
	
	public WebElement getFirstNameField(){
		return firstNameField;
	}
	
	@FindBy(css= "input#lastName")
	WebElement lastNameField;
	
	public WebElement getLastNameField(){
		return lastNameField;
	}
	
	@FindBy(css= "#gender")
	WebElement genderDropdown;
	
	public WebElement getGenderDropdown(){
		return genderDropdown;
	}
	
	@FindBy(css= "#daydropdown")
	WebElement dobDayDropDown;
	
	public WebElement getDobDayDropDown(){
		return dobDayDropDown;
	}
	
	@FindBy(css= "#monthdropdown")
	WebElement dobMonthDropDown;
	
	public WebElement getDobMonthDropDown(){
		return dobMonthDropDown;
	}
	
	@FindBy(css= "#yeardropdown")
	WebElement dobYearDropDown;
	
	public WebElement getDobYearDropDown(){
		return dobYearDropDown;
	}
	
	@FindBy(css= "#mobile")
	WebElement mobileInputField;
	
	public WebElement getMobileInputField(){
		return mobileInputField;
	}
	
	@FindBy(css= "input#address1")
	WebElement addressInputField;
	
	public WebElement getAddressInputField(){
		return addressInputField;
	}
	
	@FindBy(css= "#state")
	WebElement stateDropdown;
	
	public WebElement getStateDropdown(){
		return stateDropdown;
	}
	
	@FindBy(css= "#city")
	WebElement cityDropdown;
	
	public WebElement getCityDropdown(){
		return cityDropdown;
	}
	
	@FindBy(css= "#pinCode")
	WebElement pincodeInputField;
	
	public WebElement getPincodeInputField(){
		return pincodeInputField;
	}
	
	@FindBy(css= "div#profSuccess .sm_text2")
	WebElement profileSaveSuccessMessage;
	
	public WebElement getProfileSaveSuccessMessage(){
		return profileSaveSuccessMessage;
	}
	
	@FindBy(css= "input#profile_submit")
	WebElement profileSubmitButton;
	
	public WebElement getprofileSubmitButton(){
		return profileSubmitButton;
	}
	
}
