package com.ace2three.web.impl.pages;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import io.appium.java_client.AppiumDriver;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.base.Beforetest;
import com.ace2three.locators.AndroidLocators;
import com.ace2three.locators.AndroidLocators.LaunchPageLocators;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.StartsActivity;
import io.appium.java_client.remote.MobileCapabilityType;

public class WebLaunchImplPage implements LaunchPageLocators{

	WebDriver driver;
	public WebLaunchImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver= driver;
		PageFactory.initElements(driver, this);
        		
	}

	
	@FindBy(css= "input[id='userid']")
	WebElement userIdField;
	
	public WebElement getUserIdField(){
		return userIdField;
	}
	
	@FindBy(css= "input[id='passwordlogindum']")
	WebElement passwordInputField;
	
	public WebElement getPasswordInputField(){
		return passwordInputField;
	}
	
	@FindBy(css= "input[id='pwd']")
	WebElement passwordInputFieldAfterFocus;
	
	public WebElement getPasswordInputFieldAfterFocus(){
		return passwordInputFieldAfterFocus;
	}
	
	
	@FindBy(css= "input[id='signin_submit']")
	WebElement loginButton;
	
	public WebElement getLoginButton(){
		return loginButton;
	}
	
			
}
