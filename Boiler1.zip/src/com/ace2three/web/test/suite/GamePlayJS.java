package com.ace2three.web.test.suite;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class GamePlayJS {
	WebDriver driver = null;
	JavascriptExecutor js = null;
  @Test
  public void f() throws InterruptedException {
	  //get zcanvas
	  //js.executeScript("canvas = document.getElementById('ui.designer');if(canvas!= null){alert('Hello! I am an alert box!!');canvas=zebra.ui.$canvases[1].canvas;canvas}else{alert('Hello! I have failed!!')};");
      //js.executeScript("canvas = zebra.ui.$detectZCanvas('ui.designer');if(canvas!= null){alert('Hello! I am an alert box!!');canvas=zebra.ui.$canvases[1].canvas;canvas}else{alert('Hello! I have failed!!')};");

	  //get zcanvas.root
      //js.executeScript("canvasElement = document.getElementById('ui.designer');if(canvasElement!= null){alert('Hello! I am canvas!!');canvas=zebra.ui.$canvases[1];root = canvas.root;if(root!= null){alert('Hello! I am root!!');}else{alert('I am not root');}}else{alert('I am not canvas')}");
	  //js.executeScript("if(zebra.ui.$detectZCanvas('ui.designer') != null){rooter = zebra.ui.$canvases[1].root};if(rooter!= null){alert('I am root');}else{alert('I am not root');}");
	  
      //js.executeScript("zebra.ui.$detectZCanvas(\"ui.designer\") ;");       
      //js.executeScript("if(document.getElementById('ui.designer'){alert(\"Hello\")}else{alert(\"Fail\")};");
      
      //js.executeScript("canvas = document.getElementById('ui.designer');if(canvas!= null){root2 = zebra.ui.$canvases[1].canvas.root;if(root2!= null){alert('Hello! I am root!!');}else{alert('I am not root');}}");
      //js.executeScript("canvas = zebra.ui.$detectZCanvas('ui.designer');if(canvas!= null){root2 = zebra.ui.$canvases[1].canvas.root;if(root2!= null){alert('Hello! I am root!!');}else{alert('I am not root');}}");
	  //js.executeScript("alert(zebra.ui.$canvases.length);");
	  
	  //js.executeScript("canvasElement = document.getElementById('ui.designer');if(canvasElement!= null){canvas=zebra.ui.$canvases[1];canvas.findAll(\"//*\", function(uiComponent) {if(uiComponent!= null){alert('UI Initialized');}});}");
	  //js.executeScript("canvasElement = document.getElementById('ui.designer');if(canvasElement!= null){canvas=zebra.ui.$canvases[1];canvas.findAll(\"//*\", function(uiComponent) {if(uiComponent!= null){alert(zebra.ui.$canvases.length);}});}");
	  //js.executeScript("canvasElement = document.getElementById('ui.designer');if(canvasElement!= null){canvas=zebra.ui.$canvases[1];buttons = canvas.find(\"*/zebra.ui.designer.Button\");}");
	  //js.executeScript("canvasElement = document.getElementById('ui.mix');if(canvasElement!= null){canvas=zebra.ui.$canvases[1];canvas.findAll(\"zebra.ui.Checkbox\")[0].setValue(false);}");
	  js.executeScript("zebra.ui.$detectZCanvas(\"ui.mix\").findAll(\"zebra.ui.Checkbox\")[0].setValue(false);");
      Thread.sleep(200);
	  js.executeScript("zebra.ui.$detectZCanvas(\"ui.mix\").findAll(\"zebra.ui.Checkbox\")[0].setValue(true);");
	  Thread.sleep(200);
	  js.executeScript("zebra.ui.$detectZCanvas(\"ui.mix\").findAll(\"zebra.ui.Checkbox\")[0].setValue(false);");
      Thread.sleep(200);
	  js.executeScript("zebra.ui.$detectZCanvas(\"ui.mix\").findAll(\"zebra.ui.Checkbox\")[0].setValue(true);");
	  Thread.sleep(200);
	  js.executeScript("zebra.ui.$canvases[1].findAll(\"zebra.ui.Checkbox\")[0].setValue(false);");
	  Thread.sleep(200);
	  js.executeScript("zebra.ui.$canvases[1].findAll(\"zebra.ui.Checkbox\")[0].setValue(true);");
	  Thread.sleep(200);
	  js.executeScript("var buttonList = zebra.ui.$detectZCanvas(\"ui.designer\").findAll(\"zebra.ui.Button\");for(i=0;i<buttonList.length;i++){buttonList[i].setVisible(false);}");
	  Thread.sleep(200);
	  js.executeScript("var buttonList = zebra.ui.$detectZCanvas(\"ui.designer\").findAll(\"zebra.ui.Button\");for(i=0;i<buttonList.length;i++){buttonList[i].setVisible(true);}");
	  Thread.sleep(200);
	  js.executeScript("var buttonList = zebra.ui.$canvases[2].findAll(\"zebra.ui.Button\");for(i=0;i<buttonList.length;i++){buttonList[i].setVisible(false);}");
	  Thread.sleep(200);
	  js.executeScript("var buttonList = zebra.ui.$canvases[2].findAll(\"zebra.ui.Button\");for(i=0;i<buttonList.length;i++){buttonList[i].setVisible(true);}");
	  Thread.sleep(200);
	  js.executeScript("var buttonList = zebra.ui.$detectZCanvas(\"ui.designer\").findAll(\"zebra.ui.Button\");for(i=0;i<buttonList.length;i++){buttonList[i].setVisible(false);}");
	  Thread.sleep(200);
	  js.executeScript("var buttonList = zebra.ui.$detectZCanvas(\"ui.designer\").findAll(\"zebra.ui.Button\");for(i=0;i<buttonList.length;i++){buttonList[i].setVisible(true);}");
	  Thread.sleep(200);
	  js.executeScript("zebra.ui.$detectZCanvas(\"ui.designer\").findAll(\"zebra.ui.Button\")[1].fire();");
	  Thread.sleep(200);
	  //js.executeScript("alert(zebra.ui.$detectZCanvas(\"ui.designer\").findAll(\"zebra.ui.Button\")[1].kids[0].getValue());");
	  //Thread.sleep(2000);
	  js.executeScript("zebra.ui.$detectZCanvas(\"banner.sample1\").findAll(\"zebra.ui.TextField\")[0].setValue(\"Tejender\");");
	  Thread.sleep(200);
	  //js.executeScript("alert(zebra.ui.$detectZCanvas(\"banner.sample1\").findAll(\"zebra.ui.TextField\")[0].getValue());");
	  //Thread.sleep(2000);
	  js.executeScript("zebra.ui.$detectZCanvas(\"banner.sample1\").findAll(\"zebra.ui.Button\")[0].fire();");
	  //Thread.sleep(2000);
	  //js.executeScript("alert(zebra.ui.$detectZCanvas(\"banner.sample2\").findAll(\"zebra.ui.grid.Grid\")[0].getDataToEdit(1,1));");
	  Thread.sleep(2000);
	  System.out.println("OK");
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "D:/Java/software/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://www.zebkit.org/");
		Thread.sleep(5000);
		js = (JavascriptExecutor) driver;
  }

  @AfterClass
  public void afterClass() throws InterruptedException {
	  //Thread.sleep(5000);
	  driver.quit();
  }

}
