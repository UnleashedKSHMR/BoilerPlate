package com.ace2three.web.test.suite;

import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ace2three.utils.CustomMethods;
import com.ace2three.web.impl.pages.WebLaunchImplPage;

import Flash.FlashObjectWebDriver;

public class GamePlay {

	static WebDriver desktopDriver;
	public static void main(String args[]) throws InterruptedException{
		
		CustomMethods customeMe=  new CustomMethods();
		 desktopDriver=customeMe.launchWebBrowser();
		 
		 desktopDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			desktopDriver.get("http://qaweb.headinfotech.local");
			WebLaunchImplPage weblaunchPage= new WebLaunchImplPage(desktopDriver);
			weblaunchPage.getUserIdField().sendKeys("nani2");
			
			weblaunchPage.getPasswordInputField().click();
			weblaunchPage.getPasswordInputFieldAfterFocus().sendKeys("ace2three@");
			weblaunchPage.getLoginButton().click();
			String beforeHandle = desktopDriver.getWindowHandle();
			JavascriptExecutor js = (JavascriptExecutor) desktopDriver;  
			
			WebElement el=desktopDriver.findElement(By.cssSelector("button.playnow_btn_sml"));
			js.executeScript("arguments[0].click();", el);
			Set<String> afterHandles = desktopDriver.getWindowHandles();
			for(String afterHandle:afterHandles){
				if(!beforeHandle.equals(afterHandle));
				desktopDriver.switchTo().window(afterHandle);
			}
		Thread.sleep(40000);
		
		FlashObjectWebDriver flashApp = new FlashObjectWebDriver(desktopDriver, "Preloader_Project");
		
		flashApp.callFlashObject("Join");			
	  	Thread.sleep(5000);		
		flashApp.callFlashObject("Lobby");			
		Thread.sleep(5000);		
		//flashApp.callFlashObject("SetVariable","/:message","Flash testing using selenium Webdriver");
	    System.out.println(flashApp.callFlashObject("GetVariable","/:message"));	
	    
	    
	// js.executeScript("document.getElementsByTagName(\"Button\")[1].fire();");
	 
	/*for(int i=1;i<+pre.size();i++){
		System.out.println(pre.get(i));
		System.out.println(i);
	}*/
		/*System.out.println(pre);*/
/*		js.executeScript("Object.values(pre)");*/
		
		
	}
}
