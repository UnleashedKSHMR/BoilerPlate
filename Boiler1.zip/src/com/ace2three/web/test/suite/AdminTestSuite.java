package com.ace2three.web.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.web.impl.pages.AdminImplPage;
import com.relevantcodes.extentreports.LogStatus;

public class AdminTestSuite extends BaseTestSuite{
	ReadDataFromProps ReadProps;
	
	
	@BeforeMethod
	public void beforeMethos(Method method) {
		
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName());
		System.out.println("Before Method");
		ReadProps= new ReadDataFromProps();
		driver.manage().window().maximize();
	}
	
	
	@Test(description = "Create tourney and generate gift vouchers",priority=1)
	public void createTourney() throws InterruptedException, IOException{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		AdminImplPage webAdminPage = new AdminImplPage(driver);
		driver.get("http://qaweb.headinfotech.local:8080/AceAdmin/");
		webAdminPage.getAdminUserName().sendKeys(ReadProps.props.getProperty("user.name"));
		webAdminPage.getPasswordButton().sendKeys(ReadProps.props.getProperty("password.input"));

		webAdminPage.getloginSubmitButton().click();
		List<WebElement>  list =driver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals(ReadProps.props.getProperty("admin.tab.tourney"))){
					Actions action = new Actions(driver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		webAdminPage.getInsertJumbo().click();
		wait.until(ExpectedConditions.visibilityOf(webAdminPage.getViewTemplate()));
		webAdminPage.getViewTemplate().click();
		
		/*List<WebElement>  templateList =driver.findElements(By.cssSelector("//tr[(@class,'odd') or (@class,'even')]"));
		for(WebElement template:templateList){
			System.out.println(template.getText());
				if(template.getText().equals(ReadProps.props.getProperty("tourney.template"))){
					template.click();
				}
		}*/
		String templateSelector= "a[href='mtctTourneyInsertNew.jsp?tempName=" + ReadProps.props.getProperty("tourney.template")+"']";
		WebElement templateName = driver.findElement(By.cssSelector(templateSelector));
		templateName.click();
		new Select(webAdminPage.getLevelStatus()).selectByValue(ReadProps.props.getProperty("level.status"));
		
		webAdminPage.getTourneyStartDate().sendKeys(ReadProps.props.getProperty("tourney.start.date"));
		webAdminPage.getRegistrationStartDate().sendKeys(ReadProps.props.getProperty("tourney.registration.start.date"));
		
		webAdminPage.getBuyInGiftVoucherOnly().click();
		new Select(webAdminPage.getTourneyRegistrationStartHour()).selectByValue("20");
		new Select(webAdminPage.getTourneyRegistrationStartMins()).selectByValue("20");
		
		
		String IntitialTourneyChips= ReadProps.props.getProperty("tourney.initial.chips");
		String tourneyMaxPlayerCount= ReadProps.props.getProperty("tourney.maximum.count");
		Thread.sleep(5000);
		webAdminPage.getTourneyInitialNoOfChips().clear();
		webAdminPage.getTourneyInitialNoOfChips().sendKeys(IntitialTourneyChips);
		webAdminPage.getTourneyCount().clear();
		webAdminPage.getTourneyCount().sendKeys(tourneyMaxPlayerCount);
		Thread.sleep(10000);
		webAdminPage.getTourneyDiscription().sendKeys("Acetourney1");
		logger.log(LogStatus.PASS, "Failed screenshot" + logger.addScreenCapture(takeScreenShot("screena1")));
		webAdminPage.getTourneyCreateSubmitButton().click();
		System.out.println(tourneyMaxPlayerCount + "     :        "+IntitialTourneyChips);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		verifyTextPresent(webAdminPage.getTourneySucessMessage(), "Tourney Inserted Successfully");
		
		List<WebElement>  tabsList =driver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOneTab:tabsList){
			System.out.println(listedOneTab.getText());
				if(listedOneTab.getText().equals(ReadProps.props.getProperty("admin.tab.admin"))){
					Actions action = new Actions(driver);
					action.moveToElement(listedOneTab).build().perform();
				}
		}
		webAdminPage.getGiftVouchers().click();
		webAdminPage.getGameVoucherTypeRadio().click();
		webAdminPage.getNoOfChipsField().sendKeys(IntitialTourneyChips);
		webAdminPage.getNoOfPlayersCount().sendKeys(tourneyMaxPlayerCount);
		new Select(webAdminPage.getTourneyTypeGiftVoucher()).selectByValue("JUMBOPR");
		
		webAdminPage.getTourneyButtonGiftVoucher().click();
		int getTourneyList= new Select(webAdminPage.getSelectTourneyDropDown()).getOptions().size();
		System.out.println("list no:"+ getTourneyList);
		for(int i=1;i<getTourneyList;i++){
		new Select(webAdminPage.getSelectTourneyDropDown()).selectByIndex(i);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", webAdminPage.getCheckTourneyBonusLink());
		
		//webAdminPage.getCheckTourneyBonusLink().click();
			if(webAdminPage.getBonusCodeNewSucessMessage().getText().equals("It's a new bonuscode. You are good to go.")){
				verifyTextPresent(webAdminPage.getBonusCodeNewSucessMessage(),"It's a new bonuscode. You are good to go.");
				break;
			}
				
		}
		
		webAdminPage.getDatePickerGiftVoucher().click();
		driver.findElement(By.cssSelector(".ui-datepicker-week-end a")).click();
	
		logger.log(LogStatus.PASS, "Failed screenshot" + logger.addScreenCapture(takeScreenShot("screen")));
		Thread.sleep(3000);
		webAdminPage.getApplicabilityIdPrimium().click();
		webAdminPage.getGenerateVouchers().click();
		
		driver.switchTo().alert().accept();
		verifyTextPresent(webAdminPage.getCreateVoucherSucessMessage(), "Voucher code successfully created.");
		
	}
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			logger.log(LogStatus.FAIL, result.getThrowable().getMessage());
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		extent.endTest(logger);
		
	}
	
	
}
