package com.ace2three.component.pages;

import org.openqa.selenium.WebElement;

public interface OtpPopupComponent {

	public WebElement getOtpField();
	
	
}
