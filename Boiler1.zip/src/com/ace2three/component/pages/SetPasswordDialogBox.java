package com.ace2three.component.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.business.BusinessMethods;

public class SetPasswordDialogBox {

	public SetPasswordDialogBox(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@text,'You need to secure your Ace2Three account with a password')]")
	private WebElement setPasswordAlertMessage;
	
	
	public WebElement getSetPasswordAlertMessage(){
		return setPasswordAlertMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_yes_text')]")
	private WebElement setPasswordButton;
	
	
	public WebElement getSetPasswordButton(){
		return setPasswordButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'X')]")
	private WebElement setPasswordCloseIcon;
	
	public WebElement getSetPasswordCloseIcon(){
		return setPasswordCloseIcon;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Please enter OTP that has been sent to your')]")
	private WebElement setPasswordOtpSentMessage;
	
	public WebElement getSetPasswordOtpSentMessage(){
		return setPasswordOtpSentMessage;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'fb_enter_password_et')]")
	private WebElement setNewPasswordField;

	public WebElement getSetNewPasswordField(){
		return setNewPasswordField;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'fb_enter_conf_password_et')]")
	private WebElement setNewPasswordConfirmField;
	
	public WebElement getSetNewPasswordConfirmField(){
		return setNewPasswordConfirmField;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'fb_enter_otp_et')]")
	private WebElement setNewPasswordOtpField;
	
	public WebElement getSetNewPasswordOtpField(){
		return setNewPasswordOtpField;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_enter_otp_resend')]")
	private WebElement setNewPasswordResendOtp;
	
	public WebElement getSetNewPasswordResendOtp(){
		return setNewPasswordResendOtp;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_yes_text')]")
	private WebElement setNewPasswordSubmitButton;
	
	public WebElement getSetNewPasswordSubmitButton(){
		return setNewPasswordSubmitButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Congratulations, your password is successfully set')]")
	private WebElement setNewPasswordSuccessAlert;
	
	public WebElement getSetNewPasswordSuccessAlert(){
		return setNewPasswordSuccessAlert;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_yes_text')]")
	private WebElement setNewPasswordSuccessAlertOkButton;
	
	public WebElement getSetNewPasswordSuccessAlertOkButton(){
		return setNewPasswordSuccessAlertOkButton;
	}
	
}
