package com.ace2three.component.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.business.BusinessMethods;

public class DisconnectionPopUp {

	BusinessMethods businessMethods;
	BaseTestSuite baseTestSuite;
	WebDriver driver;
	
	public DisconnectionPopUp(WebDriver driver) {
		PageFactory.initElements(driver, this);
		businessMethods = new BusinessMethods();
		baseTestSuite= new BaseTestSuite();
		this.driver= driver;
		
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]")
	private WebElement disConnectedMessage;
	
	public WebElement getDisConnectedMessage() {
		return disConnectedMessage;
	}
	
}
