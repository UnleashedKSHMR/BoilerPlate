package com.ace2three.component.pages;

import org.openqa.selenium.WebElement;

public interface FacebookLoginPages {

	WebElement getFacebookLoginPageHeader();
	WebElement getFacebookUserIDField();
	WebElement getFacebookPasswordField();
	WebElement getFacebookLoginButton();
	WebElement getEditPermissionsLink();
	WebElement getContinueWithFacebook();
	WebElement getEditPermissionsPage();
	WebElement getClearPermissionsButton();
	WebElement getPublicProfileCheckBok();
	WebElement getFriendsListCheckBox();
	WebElement getEmailAddressCheckBox();
	public void resetFacebookAppOrBrowser();
	WebElement getCancelButtonInAppLoginPage();
	WebElement getAgeRestrictionMessage();
	WebElement getAgeRestrictionOkayButton();
	
}
