package com.ace2three.component.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.business.BusinessMethods;

public class ReShufleDeckDialogeBox {

	BusinessMethods businessMethods;
	BaseTestSuite baseTestSuite;
	WebDriver driver;
	
	public ReShufleDeckDialogeBox(WebDriver driver) {
		PageFactory.initElements(driver, this);
		businessMethods = new BusinessMethods();
		baseTestSuite= new BaseTestSuite();
		this.driver= driver;
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement deckReshufflingAlertMessage;
	
	public WebElement getDeckReshufflingAlertMessage() {
		return deckReshufflingAlertMessage;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
	private WebElement deckReshufflingAlertOkButton;
	
	public WebElement getDeckReshufflingAlertOkButton() {
		return deckReshufflingAlertOkButton;
	}

	
}
