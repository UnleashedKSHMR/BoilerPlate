package com.ace2three.component.pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.media.jfxmedia.logging.Logger;

import io.appium.java_client.MobileElement;

public class TourneyDialogBox {
	WebDriver driver;
	
	public TourneyDialogBox(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
	}
	
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'cash_tourney_dialog_title_tv')]")
	private WebElement tLobbyHeaderTitle;
	
	public WebElement getTLobbyHeaderTitle(){
		return tLobbyHeaderTitle;
	}
	
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_qaulifier_dialog_close')]")
	private WebElement tLobbyCloseButton;
	
	public WebElement getTLobbyCloseButton(){
		return tLobbyCloseButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'cash_tourney_details_tourney_id')]")
	private WebElement tourneyIdField;
	
	public WebElement getTourneyIdField(){
		return tourneyIdField;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'cash_tourney_main_details_entry_value')]")
	private WebElement tourneyEntryField;
	
	public WebElement getTourneyEntryField(){
		return tourneyEntryField;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@resource-id,'ptsProfile')]/android.widget.TextView[2]")
	private WebElement tourneytypeName;
	
	public WebElement getTourneytypeName(){
		return tourneytypeName;
	}

	@FindBy(xpath= "//android.widget.Button[contains(@text,'Register')]")
	private WebElement tourneyRegisterButton;
	
	public WebElement getTourneyRegisterButton(){
		return tourneyRegisterButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Register using Voucher')]")
	private WebElement registerUsingVoucherLink;
	
	public WebElement getRegisterUsingVoucherLink(){
		return registerUsingVoucherLink;
	}
	
	@FindBys(@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tourney_details_item3_statustext_tv')]"))
	private List<WebElement> tourneyStatusList;
	
	public List<WebElement> getTourneyStatusList(){
		return tourneyStatusList;
	}
	
	/*List<MobileElement> me = driver.findElements(By.xpath("//android.widget.ListView[contains(@resource-id,'levels_listview')]/android.widget.LinearLayout"));*/

	public void getFullTourney(){
		
				getTourneyStatusList();
		
	}

	
	public enum TourneyDetailType{
		FORMAT,STARTDATE,ENTRY,STARTINGSTACK,LEVELS,NOOFPRIZES,REGISTEREDPLAYERS,CASHPRIZE;
	}
	
	public WebElement getTourneyDetails(TourneyDetailType tourneyDetailType){
	
		String detail= null;
		switch(tourneyDetailType){
			case FORMAT:
				detail = "format";
				break;
			case STARTDATE:
				detail = "start";
				break;
			case ENTRY:
				detail = "entry";
				break;
			case STARTINGSTACK:
				detail = "startstack";
				break;
			case LEVELS:
				detail = "levels";
				break;
			case NOOFPRIZES:
				detail = "winners";
				break;
			case REGISTEREDPLAYERS:
				detail = "registered";
				break;
			case CASHPRIZE:
				detail = "cashprize";
				break;
		default:
			break;
		}
		
		MobileElement element = (MobileElement) driver.findElement(By.xpath("//android.widget.LinearLayout[contains(@resource-id,'"+detail+"')]/android.widget.RelativeLayout[2]/android.widget.TextView"));
		BaseTestSuite.logger.log(LogStatus.INFO, "Tourney "+detail+" value is: "+ element.getText());
		return element;	
	}
	public static void main(String args[]){
		HashMap<String, String> f= new HashMap<String , String>();
		
		
	}
	
}

