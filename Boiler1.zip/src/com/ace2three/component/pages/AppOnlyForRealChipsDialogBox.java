package com.ace2three.component.pages;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;

public class AppOnlyForRealChipsDialogBox {

	BaseTestSuite base= new BaseTestSuite();
	WebDriver driver;
	 
	public AppOnlyForRealChipsDialogBox(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver= driver;
		PageFactory.initElements(driver, this);
     		
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Sorry, this app is only for real chip games')]")
	private WebElement appOnlyForRealChipsGames;
	
	public WebElement getAppOnlyForRealChipsGames(){
		return appOnlyForRealChipsGames;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Sorry, this app is only for real chip games')]/following-sibling::android.widget.Button")
	private WebElement appOnlyForRealChipsGamesBuyChips;
	
	public WebElement getAppOnlyForRealChipsGamesBuyChips(){
		return appOnlyForRealChipsGamesBuyChips;
	}
	
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'closeIv')]")
	private WebElement appOnlyForRealChipsGamesClose;
	
	public WebElement getAppOnlyForRealChipsGamesClose(){
		return appOnlyForRealChipsGamesClose;
	}
}
