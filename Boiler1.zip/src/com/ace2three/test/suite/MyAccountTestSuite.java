package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.KycImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.MyProfileImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class MyAccountTestSuite extends BaseTestSuite{
	DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
	Date date = new Date();
	  
	@BeforeClass
	public void beforeClass(){
		
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		String unveriFyMobileQuery1 = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%9000061713'";
		try {
			dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
			dataBaseConnection.updateQuery(unveriFyMobileQuery1, null);
		} catch (InterruptedException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		((AppiumDriver) driver).resetApp();
				Test test = method.getAnnotation(Test.class);
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		System.out.println("Before Method");
		
	}
	
	@Test(description = "Verify that Enter password light box is displayed by tapping on profile option from hamburger menu",priority=1)
	public void TS_Profile_01() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		launchImplPage.getUsernameField().sendKeys("nani2");
		verifyPresent(launchImplPage.getpasswordField(), "Password field");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();

	}
	
	@Test(description = "Verify that error message is displayed when invalid password is provided ",priority=2)
	public void TS_Profile_02() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		launchImplPage.getUsernameField().sendKeys("nani2");
		verifyPresent(launchImplPage.getpasswordField(), "Password field");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("ace2threeasffd");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(myAccountPage.getPasswordPromtPopUpInvalidError(),"password invalid messsage");
		verifyTextPresent(myAccountPage.getPasswordPromtPopUpInvalidError(),"Incorrect Password");
		
		myAccountPage.getPasswordPopUpField().clear();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2threeas&&%.");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		verifyPresent(myAccountPage.getPasswordPromtPopUpInvalidError(),"password invalid messsage");
		verifyTextPresent(myAccountPage.getPasswordPromtPopUpInvalidError(),"Incorrect Password");
		
		
	}
	
	@Test(description = "Verify that profile screen is displayed when valid password is provided ",priority=3)
	public void TS_Profile_03() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		launchImplPage.getUsernameField().sendKeys("nani2");
		verifyPresent(launchImplPage.getpasswordField(), "Password field");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		
	}
	
	@Test(description = "Verify that all the available objects are visible on profile screen", priority=4)
	public void TS_Profile_04() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage myProfile = new MyProfileImplPage(driver);
		verifyPresent(myProfile.getMyProfileFirstNameField(), "First name Field");
		verifyPresent(myProfile.getMyProfileLastNameField(), "Last name Field");
		verifyPresent(myProfile.getMyProfileDOBField(), "Date Of Birth Field");
		verifyPresent(myProfile.getMyProfileGenderField(), "Gender Field");
		verifyPresent(myProfile.getMyProfileStateField(), "State Field");
		verifyPresent(myProfile.getMyProfileCityField(), "City Field");
		
		
	}
	
	@Test(description = "Verify that error message is displayed when all the edit fields are left blank",priority=5)
	public void TS_Profile_05() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("ace123425");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage myProfile = new MyProfileImplPage(driver);
		myProfile.getMyProfileSaveButtonLoc().click();
		verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
		verifyTextPresent(myProfile.getMyProfileErrorMessage(), "First name cannot be empty");
			
				myProfile.getMyProfileFirstNameField().sendKeys("acefirst");
				logger.log(LogStatus.INFO, "Entered data into first name field");
				myProfile.getMyProfileSaveButtonLoc().click();
				verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
				verifyTextPresent(myProfile.getMyProfileErrorMessage(), "Last name cannot be empty");
				
				myProfile.getMyProfileLastNameField().sendKeys("acelast");
				logger.log(LogStatus.INFO, "Entered data into Last name field");
				myProfile.getMyProfileSaveButtonLoc().click();
				verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
				verifyTextPresent(myProfile.getMyProfileErrorMessage(), "Please select your date of birth");
				
				myProfile.getMyProfileDOBField().click();
				myProfile.getMyProfileCalenderOkButton().click();
				logger.log(LogStatus.INFO, "Entered date of birth");
				myProfile.getMyProfileSaveButtonLoc().click();
				verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
				verifyTextPresent(myProfile.getMyProfileErrorMessage(), "Please select your gender");
				
				myProfile.getMyProfileGenderField().click();
				CustomMethods.selectFromDropDownList("Male");
				logger.log(LogStatus.INFO, "Selected gender");
				myProfile.getMyProfileSaveButtonLoc().click();
				verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
				verifyTextPresent(myProfile.getMyProfileErrorMessage(), "Please select your State");
				
				myProfile.getMyProfileStateField().click();
				CustomMethods.selectFromDropDownList("Goa");
				logger.log(LogStatus.INFO, "Selected State from dropdown");
				myProfile.getMyProfileSaveButtonLoc().click();
				verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
				verifyTextPresent(myProfile.getMyProfileErrorMessage(), "Please select your City");
				
				myProfile.getMyProfileCityField().click();
				CustomMethods.selectFromDropDownList("Calangute");
				logger.log(LogStatus.INFO, "Selected city from dropdown");
				myProfile.getMyProfileFirstNameField().clear();
				logger.log(LogStatus.INFO, "clearing first name field");
				myProfile.getMyProfileSaveButtonLoc().click();
				verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
				verifyTextPresent(myProfile.getMyProfileErrorMessage(), "First name cannot be empty");
				
						
	}
	
	@Test(description = "Verify that profile details are getting saved when valid FN , LN , Gender , DOB , State and city provided and clicks on save button",priority=8)
	public void TS_Profile_06() throws InterruptedException, IOException {

		SignupImplPage signupimplpage = new SignupImplPage(driver);
		
		dateFormat.format(date);
		String Username= "ace" + dateFormat.format(date)+"a";
		
		WebDriverWait wait= new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(signupimplpage.getUsernamefield()));
		signupimplpage.getUsernamefield().sendKeys(Username);
		signupimplpage.getEmailidfield().sendKeys("test"+Username +"@ds.com");
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		logger.log(LogStatus.PASS, "Performing signup with username: "+ Username);
		logger.log(LogStatus.PASS, "Performing signup with email: "+ "abctest"+Username +"@ds.com");
		signupimplpage.getSignupbutton().click();
		
			LobbyImplPage lobbyPage = new LobbyImplPage(driver);	
			lobbyPage.verifyLobbyPageDisplayed();
	
			if(CustomMethods.isElementPresent(lobbyPage.getSignUpBannerPopUpClose())){
				verifyPresent(lobbyPage.getThankYouForSignUpMessage(),"Signup success message on banner");
				verifyPresent(lobbyPage.getSignUpSuccessBannerNoThanksButton(),"No Thanks link on signup success banner");
				verifyPresent(lobbyPage.getSignUpSuccessBuyChipsButton(),"Buy chips button on signup success banner");
				lobbyPage.getSignUpSuccessBannerNoThanksButton().click();
			}	
			
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage myProfile = new MyProfileImplPage(driver);
		//Entering details into fields in profile screen
		
		myProfile.getMyProfileFirstNameField().sendKeys("acefirst");
		myProfile.getMyProfileLastNameField().sendKeys("acelast");
		myProfile.getMyProfileDOBField().click();
		myProfile.getMyProfileCalenderOkButton().click();
		myProfile.getMyProfileGenderField().click();
		CustomMethods.selectFromDropDownList("Male");
		myProfile.getMyProfileStateField().click();
		CustomMethods.selectFromDropDownList("Goa");
		myProfile.getMyProfileCityField().click();
		CustomMethods.selectFromDropDownList("Calangute");
		
		myProfile.getMyProfileSaveButtonLoc().click();
		verifyPresent(myProfile.getMyProfileSaveSuccessMessage(), "Profile details saved sucessfully message");
		verifyTextPresent(myProfile.getMyProfileErrorMessage(), "Your profile details have been saved successfully!");

	}
	
	
	@Test(description = "Verify that error message is displayed when valid FN , "
			+ "Gender , DOB , State , City and invalid LN is provided and clicks on save button",priority=6)
	public void TS_Profile_07() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("ace123425");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
			
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
	
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage myProfile = new MyProfileImplPage(driver);
			myProfile.getMyProfileFirstNameField().sendKeys("acetest");
			//myProfile.getMyProfileLastNameField().sendKeys("");
			myProfile.getMyProfileDOBField().click();
			myProfile.getMyProfileCalenderOkButton().click();
			myProfile.getMyProfileGenderField().click();
			CustomMethods.selectFromDropDownList("Male");
			myProfile.getMyProfileStateField().click();
			CustomMethods.selectFromDropDownList("Goa");
			myProfile.getMyProfileCityField().click();
			CustomMethods.selectFromDropDownList("Calangute");
			
		myProfile.getMyProfileSaveButtonLoc().click();
		verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
		verifyTextPresent(myProfile.getMyProfileErrorMessage(), "Last name cannot be empty");
		/*CustomMethods CM= new CustomMethods();
		CM.launchWebBrowser();
		WebLaunchImplPage launchWebImplPage = new WebLaunchImplPage(driver);
		dateFormat.format(date);
		String Username= "ace" + dateFormat.format(date)+"a";
		BaseTestSuite.logger.log(LogStatus.INFO, "username is: " + Username );
		launchWebImplPage.getUsernameField().sendKeys(Username);*/
	
			
	}
	
	@Test(description = "Verify that error message is displayed when invalid FN and valid LN , "
			+ "Gender , DOB , State , City is provided and clicks on save button",priority=7)
	public void TS_Profile_08() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("ace123425");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage myProfile = new MyProfileImplPage(driver);
			myProfile.getMyProfileFirstNameField().clear();
			myProfile.getMyProfileLastNameField().sendKeys("acetest");
			myProfile.getMyProfileDOBField().click();
			myProfile.getMyProfileCalenderOkButton().click();
			myProfile.getMyProfileGenderField().click();
			CustomMethods.selectFromDropDownList("Male");
			myProfile.getMyProfileStateField().click();
			CustomMethods.selectFromDropDownList("Goa");
			myProfile.getMyProfileCityField().click();
			CustomMethods.selectFromDropDownList("Calangute");
			
		myProfile.getMyProfileSaveButtonLoc().click();
		verifyPresent(myProfile.getMyProfileErrorMessage(), "Error message");
		verifyTextPresent(myProfile.getMyProfileErrorMessage(), "First name cannot be empty");
		/*CustomMethods CM= new CustomMethods();
		CM.launchWebBrowser();
		WebLaunchImplPage launchWebImplPage = new WebLaunchImplPage(driver);
		dateFormat.format(date);
		String Username= "ace" + dateFormat.format(date)+"a";
		BaseTestSuite.logger.log(LogStatus.INFO, "username is: " + Username );
		launchWebImplPage.getUsernameField().sendKeys(Username);*/
	
			
	}
	
	@Test(description = "Verify that all the available objects are visible on KYC screen", priority=9)
	public void TS_Profile_09() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
	
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		
		verifyPresent(kycScreen.getKycEmailField(),"Email field");
		verifyPresent(kycScreen.getKycEmailVerifiedIndicator(),"Email verification indicator");
		verifyPresent(kycScreen.getKycEmailVerifyButton(),"Email Verify button");
		
		verifyPresent(kycScreen.getKycPhoneNoField(),"Phone number field");
		verifyPresent(kycScreen.getKycPhoneNoVerifiedIndicator(),"Phone number Verify button");
		verifyPresent(kycScreen.getKycPhoneNoVerifyButton(),"Phone number Verify button");
		
		verifyPresent(kycScreen.getKycIDProofField(),"Id proof field");
		verifyPresent(kycScreen.getKycIdProofVerifiedIndicator(),"Id proof verification button");
		verifyPresent(kycScreen.getKycIdProofUploadButton(),"Id proof upload button");
		
		verifyPresent(kycScreen.getKycPanField(),"Pan field");
		verifyPresent(kycScreen.getKycPanHelpButton(),"Pan help tool tip");
		verifyPresent(kycScreen.getKycPanVerifiedIndicator(),"Pan Verify button");
		verifyPresent(kycScreen.getKycPanUploadButton(),"Pan upload button");
		
		/*CustomMethods CM= new CustomMethods();
		CM.launchWebBrowser();
		WebLaunchImplPage launchWebImplPage = new WebLaunchImplPage(driver);
		dateFormat.format(date);
		String Username= "ace" + dateFormat.format(date)+"a";
		BaseTestSuite.logger.log(LogStatus.INFO, "username is: " + Username );
		launchWebImplPage.getUsernameField().sendKeys(Username);*/
		
	}
	
	@Test(description = "Verify that confirmation message is displayed when valid email id is provided", priority=10)
	public void TS_Profile_10() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		
		verifyPresent(kycScreen.getKycEmailField(),"Email field");
		kycScreen.getKycEmailField().sendKeys("Automation@test.com");
		kycScreen.getKycEmailVerifyButton().click();
		verifyPresent(kycScreen.getKycEmailWarningMessage(), "Email confirmation message");
		verifyTextPresent(kycScreen.getKycEmailWarningMessage(), "An activation link has been sent to your E-Mail");
		
	}
	
	
	
	
	@Test(description = "Verify that error message is displayed when invalid Email id is provided", priority=11)
	public void TS_Profile_11() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		//if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		//lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		kycScreen.getKycEmailField().clear();
		kycScreen.getKycEmailVerifyButton().click();
		verifyPresent(kycScreen.getKycEmailWarningMessage(),"Email Error Message");
		verifyTextPresent(kycScreen.getKycEmailWarningMessage(),"Please enter email ID");
		
		kycScreen.getKycEmailField().clear();
		kycScreen.getKycEmailField().sendKeys("afjnl.com");
		kycScreen.getKycEmailVerifyButton().click();
		verifyPresent(kycScreen.getKycEmailWarningMessage(),"Please enter email ID");
		verifyTextPresent(kycScreen.getKycEmailWarningMessage(),"Please enter valid email ID");
		
	}
	
	@Test(description = "Verify that Green tick is displayed if email id verified ", priority=12)
	public void TS_Profile_12() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if (CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())) {
			lobbyImplPage.getUpdateProfilePopUpClose().click();
			}
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		verifyNotPresent(kycScreen.getKycEmailVerifyButton(), "Email verify button",3);
	
		if(kycScreen.getKycEmailField().isEnabled()){
			logger.log(LogStatus.FAIL, "Email field should not be editable");
		}else{
			logger.log(LogStatus.PASS, "Email field is not editable");
			logger.log(LogStatus.PASS, "Green tick mark is displayed for phone number field");
		}
		
	}
	
	@Test(description = "Verify a mini window with is displayed when valid mobile number is provided ", priority=13)
	public void TS_Profile_13() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if (CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())) {
			lobbyImplPage.getUpdateProfilePopUpClose().click();
			}
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		//if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		//lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		
		kycScreen.getKycPhoneNoField().sendKeys("9000061713");
		kycScreen.getKycPhoneNoVerifyButton().click();
		Thread.sleep(2000);
		verifyPresent(kycScreen.getEnterOtpPopup(),"OTP window");
		verifyPresent(kycScreen.getOtpEntryField(),"Mini window with OTP field");
		
	}
	
	@Test(description = "Verify resend OTP link functionality", priority=14)
	public void TS_Profile_14() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if (CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())) {
			lobbyImplPage.getUpdateProfilePopUpClose().click();
			}
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		//lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		
		kycScreen.getKycPhoneNoField().sendKeys("9000061713");
		kycScreen.getKycPhoneNoVerifyButton().click();
		CustomMethods.waitForElementPresent(kycScreen.getEnterOtpPopup(),10);
		verifyPresent(kycScreen.getEnterOtpPopup(),"OTP window");
		verifyPresent(kycScreen.getOtpEntryField(),"Mini window with OTP field");
		verifyPresent(kycScreen.getOtpResendLink(),"Resend OTP link");
		
		if(kycScreen.getOtpResendLink().getAttribute("clickable").equalsIgnoreCase("false")){
			logger.log(LogStatus.PASS, "Resend OTP link has not yet enabled , waiting for 60 secs to complete");
			
		}else{
			logger.log(LogStatus.FAIL, "Resend OTP link has enabled ,should wait untill 60 secs to complete");
		}
		
		WebDriverWait wait = new WebDriverWait(driver, 70);
		wait.until(ExpectedConditions.attributeContains(kycScreen.getOtpResendLink(), "clickable", "true"));
		kycScreen.getOtpResendLink().click();
		Thread.sleep(5000);
		if(CustomMethods.isElementPresent(kycScreen.getOtpProgressTimeBar())){
			logger.log(LogStatus.PASS, "Resent OTP link is working properly");
		}else{
			logger.log(LogStatus.FAIL, "Resent OTP link is not working");
		}
		
		
	}
	
	@Test(description = "Verify that error message is displayed when invalid OTP is provided", priority=15)
	public void TS_Profile_15() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if (CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())) {
			lobbyImplPage.getUpdateProfilePopUpClose().click();
			}
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		//lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		
		kycScreen.getKycPhoneNoField().sendKeys("9000061713");
		kycScreen.getKycPhoneNoVerifyButton().click();
		CustomMethods.waitForElementPresent(kycScreen.getEnterOtpPopup(),10);
		verifyPresent(kycScreen.getEnterOtpPopup(),"OTP window");
		verifyPresent(kycScreen.getOtpEntryField(),"Mini window with OTP field");
		verifyPresent(kycScreen.getOtpResendLink(),"Resend OTP link");
		kycScreen.getOtpEntryField().sendKeys("");
		kycScreen.getOtpConfirmButton().click();
		verifyPresent(kycScreen.getOtpIncorrectError(), "Incorrect OTP error message");
		verifyTextPresent(kycScreen.getOtpIncorrectError(), "Please enter OTP");

		kycScreen.getOtpEntryField().clear();
		kycScreen.getOtpEntryField().sendKeys("123456");
		kycScreen.getOtpConfirmButton().click();
		verifyPresent(kycScreen.getOtpIncorrectError(), "Incorrect OTP error message");
		verifyTextPresent(kycScreen.getOtpIncorrectError(), "Sorry, the entered OTP is incorrect");
		
		
	}
	
	@Test(description = "Verify that 60 seconds timer is running on OTP screen", priority=16)
	public void TS_Profile_16() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if (CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())) {
			lobbyImplPage.getUpdateProfilePopUpClose().click();
			}
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		//lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		
		kycScreen.getKycPhoneNoField().sendKeys(ReadDataFromProps.props.getProperty("mobile.number"));
		kycScreen.getKycPhoneNoVerifyButton().click();
		
		verifyPresent(kycScreen.getEnterOtpPopup(),"OTP window");
		verifyPresent(kycScreen.getOtpEntryField(),"Mini window with OTP field");
		verifyPresent(kycScreen.getOtpResendLink(),"Resend OTP link");
		verifyPresent(kycScreen.getOtpProgressTimeBar(),"OTP progress time bar");
		verifyPresent(kycScreen.getOtpProgressTime(),"OTP progress timer");
		
		try{
			//boolean flag= false;
			int temp=60;
			while(temp>4){
				
				String timer= kycScreen.getOtpProgressTime().getText();
				int RunningTime= Integer.parseInt(timer); 
				
					if(temp>=RunningTime){
											
						temp=RunningTime;
						
						logger.log(LogStatus.PASS, "Timer is running and , current time is: " + RunningTime);
						Thread.sleep(3000);
					}else{
						logger.log(LogStatus.FAIL, "Timer is not runnning , current time is: " + RunningTime);
					}
			
			}
		}catch(Exception e){
				}
	
	}
	
	@Test(description = "Verify that Green tick mark is displayed if valid OTP is provided", priority=17)
	public void TS_Profile_17() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium27");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
	
		if (CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())) {
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		verifyNotPresent(kycScreen.getKycPhoneNoVerifyButton(), "Phone number verify button",3);
	
		if(kycScreen.getKycPhoneNoField().isEnabled()){
			logger.log(LogStatus.FAIL, "Phone number field should not be editable");
		}else{
			logger.log(LogStatus.PASS, "Phone number field is not editable");
			logger.log(LogStatus.PASS, "Green tick mark is displayed for Phone number field");
		}
		
	}
	
	@Test(description = "Verify that error message is displayed when invalid mobile number is provided", priority=18)
	public void TS_Profile_18() throws InterruptedException, IOException {

		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		//String unveriFyMobileQuery1 = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%9000061713'";
		try {
			dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
			//dataBaseConnection.updateQuery(unveriFyMobileQuery1, null);
		} catch (InterruptedException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		//lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		
		kycScreen.getKycPhoneNoField().sendKeys("3221854168");
		kycScreen.getKycPhoneNoVerifyButton().click();
		CustomMethods.waitForElementPresent(kycScreen.getKycPhoneNoInvalidError());
		verifyPresent(kycScreen.getKycPhoneNoInvalidError(),"Invalid error message");
		verifyTextPresent(kycScreen.getKycPhoneNoInvalidError(),"Please enter valid Mobile number");
		
		kycScreen.getKycPhoneNoField().sendKeys("32218541");
		kycScreen.getKycPhoneNoVerifyButton().click();
		
		verifyPresent(kycScreen.getKycPhoneNoInvalidError(),"Invalid error message");
		verifyTextPresent(kycScreen.getKycPhoneNoInvalidError(),"Please enter valid Mobile number");
		
	}
	
	@Test(description = "Verify the list of id proofs are displayed by tapping on id proof drop down list", priority=19)
	public void TS_Profile_19() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium3");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		kycScreen.getKycIDProofField().click();
		Thread.sleep(3000);
		List<WebElement> idProofList= driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'tvSpinnerItem')]"));
		int i=0;
		for(WebElement idProof:idProofList){
			int noOfIProof = idProofList.size();
			
					switch (i){
						case 0:
							verifyTextPresent(idProof, "Aadhaar Card");
							i=i+1;
							break;
						case 1:
							verifyTextPresent(idProof, "Ration Card");
							i=i+1;
							break;
						case 2:
							verifyTextPresent(idProof, "Voter ID");
							i=i+1;
							break;
						case 3:
							verifyTextPresent(idProof, "Passport");
							i=i+1;
							break;
						case 4:
							verifyTextPresent(idProof, "Driving Licence");
							i=i+1;
							break;
					
					
				}
		}
		
	}
	
	@Test(description = "Verify that guide lines of id proofs are displayed by tapping on upload button with selection of any one of the id proof ", priority=20)
	public void TS_Profile_20() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		kycScreen.getKycIDProofField().click();
		Thread.sleep(4000);
		CustomMethods.selectFromDropDownList("Passport");
		kycScreen.getKycIdProofUploadButton().click();
		
		System.out.println("guideLine text is : "+ kycScreen.getIdProofGuideLinesPopup().getText());
		String guidelines= kycScreen.getIdProofGuideLinesPopup().getText();
		String[] guideLinesEachLines= guidelines.split("\n\n");

		String Expected= "# Any purchase beyond a certain limit requires ID proof, Bank Account and PAN card submissions. # The file should be in PDF, JPEG or PNG format. # Make sure the picture is clear if you are taking a snapshot of the document. # Upload both sides of the document wherever necessary.\n# The file size should not be more than 2 MB. # Submissions are verified and approved by our support team to enable further transactions. # All other standard Ace2Three terms and conditions apply.";
		for(String eachLine:guideLinesEachLines){
			System.out.println("lines :"+ eachLine);
		
			verifyGuideLineTextText(eachLine, Expected);
		}
		
	}
	
	@Test(description = "Verify that Upload id proof window with two options � "
			+ "'Use Camera and Upload' buttons are displayed by tapping on upload button ", priority=21)
	public void TS_Profile_21() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		//if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		//lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		kycScreen.getKycIDProofField().click();
		CustomMethods.selectFromDropDownList("Passport");
		kycScreen.getKycIdProofUploadButton().click();
		kycScreen.getIdProofGuideLinesPopupOkButton().click();
		verifyPresent(kycScreen.getIdProofUploadPopUpHeader(),"ID Proof upload popup");
		verifyPresent(kycScreen.getIdProofUploadPopUpCameraIcon(),"Upload ID proof window camera icon");
		verifyPresent(kycScreen.getIdProofUploadPopUpUploadIcon(),"Upload ID proof window Upload icon");
		
	}
	@Test(description = "Verify that camera app is getting launched by tapping on use Camera button from upload id proof window  ", priority=22)
	public void TS_Profile_22() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("appium2");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		/*//handling update profile web popup 
		((AppiumDriver) driver).context("WEBVIEW");
		System.out.println(driver.getPageSource());
		
		((AppiumDriver) driver).context("NATIVE_APP");*/
		//if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		//lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycScreen = new KycImplPage(driver);
		kycScreen.getKycIDProofField().click();
		CustomMethods.selectFromDropDownList("Passport");
		kycScreen.getKycIdProofUploadButton().click();
		
		kycScreen.getIdProofGuideLinesPopupOkButton().click();
		kycScreen.getIdProofUploadPopUpCameraIcon().click();
		
		//verifyPresent(kycScreen.getCameraShutterButton(), "Camera App");
		verifyPresent(driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]")), "Camera App");
		
		
	}
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			logger.log(LogStatus.FAIL, result.getThrowable());
			logger.log(LogStatus.PASS, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		extent.flush();
		extent.endTest(logger);
		
	}
	
}
