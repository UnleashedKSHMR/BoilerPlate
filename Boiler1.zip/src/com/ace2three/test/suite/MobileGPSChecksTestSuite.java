package com.ace2three.test.suite;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.Connection;

public class MobileGPSChecksTestSuite extends BaseTestSuite{

	WebDriver desktopDriver;
	ReadDataFromProps readprops;
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		
		Test test = method.getAnnotation(Test.class);
		
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		readprops =new ReadDataFromProps();
		String command = "adb shell settings put secure location_providers_allowed -gps";
		Process child = Runtime.getRuntime().exec(command);
		//((AndroidDriver)driver).resetApp();
		//LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		
	}

	@Test(description = "Check application prompts enable GPS alert in log-in screen when user GPS is not enabled  and check GPS status in admin site", priority=4)
	public void TS_Sanity__GPS_Checks_01() throws InterruptedException, IOException {
		
		LaunchImplPage launchPage = new LaunchImplPage(driver);
		verifyText(launchPage.getGpsPopupMessage().getText(),readprops.props.getProperty("gps.popup.alert.message"));
		verifyPresent(launchPage.getGpsPopupMessage(),"gps popup alert message");
		launchPage.getGpsPopupCancelButton().click();
		verifyPresent(launchPage.getAllowAccessLocationPopUp(), "Allow access location pop up");
		verifyText(launchPage.getAllowAccessLocationPopUp().getText(), "Please allow Ace2Three to access your location in order to play.", "Allow access location Text");
		launchPage.getAllowAccessLocationPopUpOkButton().click();
	
		
		((AndroidDriver) driver).setConnection(Connection.NONE);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());
		logger.log(LogStatus.INFO, "Disconnected Wifi by switching off wifi");
		Thread.sleep(5000);
		logger.log(LogStatus.INFO, "Disconnect while giving access permission to location.");
		//WebDriverWait wait = new WebDriverWait(driver, 120);
		//baseTestSuite.verifyNotPresent(
		//		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]")),"you have been disconnected pop up",5);
		((AndroidDriver) driver).setConnection(Connection.ALL);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());
		logger.log(LogStatus.INFO, "connected ti Wifi by switching on wifi");
		Thread.sleep(5000);
		launchPage.getGpsPopupOk().click();
		Thread.sleep(2000);
		String s = null;
		String gpsStatus = "";
		String gpsStatusCommand = "adb shell settings get secure location_providers_allowed";
		Process child = Runtime.getRuntime().exec(gpsStatusCommand);
		BufferedReader stdInput = new BufferedReader(new 
                InputStreamReader(child.getInputStream()));
		 while ((s = stdInput.readLine()) != null) {
             System.out.println(s);
             gpsStatus = gpsStatus+s;
             
         }
		if( verifyText(gpsStatus, "network,gps") || verifyText(gpsStatus, "gps,network") )
		{
			logger.log(LogStatus.INFO, "Gps is ON after clicking on OK button in gps pop up");
		}
		else
		{
			logger.log(LogStatus.FAIL, "GPS is still OFF");
		}
		LaunchImplPage launchImplPage= new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		String userId="nani2";
		logger.log(LogStatus.INFO, "Logging with premium user");
		launchImplPage.getUsernameField().sendKeys(userId);
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		Thread.sleep(15000);
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		CustomMethods custom= new CustomMethods();
		lobbyImplPage.verifyLobbyPageDisplayed();
		launchImplPage.getLoginDetailsFromAdmin(userId, desktopDriver);
		String command = "adb shell settings put secure location_providers_allowed -gps";
		Runtime.getRuntime().exec(command);
		((AndroidDriver)driver).resetApp();
		verifyText(launchPage.getGpsPopupMessage().getText(),readprops.props.getProperty("gps.popup.alert.message"));
		verifyPresent(launchPage.getGpsPopupMessage(),"gps popup alert message");
		launchPage.getGpsPopupCancelButton().click();
		verifyPresent(launchPage.getAllowAccessLocationPopUp(), "Allow access location pop up");
		verifyText(launchPage.getAllowAccessLocationPopUp().getText(), "Please allow Ace2Three to access your location in order to play.", "Allow access location Text");
		launchPage.getAllowAccessLocationPopUpOkButton().click();
		launchImplPage.getGpsPopupOk().click();
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon(),10);
		launchImplPage.getLoginButon().click();
		logger.log(LogStatus.INFO, "Logging with premium user");
		launchImplPage.getUsernameField().sendKeys(userId);
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		Thread.sleep(15000);

		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
	
		lobbyImplPage.verifyLobbyPageDisplayed();
		launchImplPage.getLoginDetailsFromAdmin(userId, desktopDriver);
	}
	
	//@Test(description = "Check application do not prompt enable GPS alert in log in screen if user has GPS already enabled and check GPS status in admin site", priority=4,dataProvider="provideUsername")
	//public void TS_Sanity__GPS_Checks_02(String userName , String password) throws InterruptedException, IOException {
	@Test(description = "Check application do not prompt enable GPS alert in log in screen if user has GPS already enabled and check GPS status in admin site", priority=4)
	public void TS_Sanity__GPS_Checks_02() throws InterruptedException, IOException {
		
		String command = "adb shell settings put secure location_providers_allowed +gps";
		Process child = Runtime.getRuntime().exec(command);
		((AndroidDriver)driver).resetApp();
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon(),10);
		verifyNotPresent(launchImplPage.getGpsPopupMessage(), "GPS alert popup",5);
		
		//LaunchImplPage launchImplPage= new LaunchImplPage(driver);
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		String userId="nani2";
		//String userId=userName;
		
		logger.log(LogStatus.INFO, "Logging with premium user");
		launchImplPage.getUsernameField().sendKeys(userId);
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		Thread.sleep(10000);
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		CustomMethods custom= new CustomMethods();
		lobbyImplPage.verifyLobbyPageDisplayed();
		launchImplPage.getLoginDetailsFromAdmin(userId, desktopDriver);
		launchImplPage.launchApp();
		verifyNotPresent(launchImplPage.getGpsPopupMessage(), "GPS pop up", 10);
		lobbyImplPage.verifyPostLaunchBanners();
		lobbyImplPage.verifyLobbyPageDisplayed();
		launchImplPage.getLoginDetailsFromAdmin(userId, desktopDriver);
		
		
	}
	
	@Test(description = "Check whether user gets GPS popup after resuming back from wifi interrupt by launching the app", priority=3)
	public void TS_Sanity__GPS_Checks_03() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		BaseTestSuite baseTestSuite = new BaseTestSuite();
		((AndroidDriver) driver).setConnection(Connection.NONE);
		System.out.println("connection none: " + ((AndroidDriver) driver).getConnection());
		logger.log(LogStatus.INFO, "Disconnected Wifi by switching off wifi");
		Thread.sleep(5000);
		launchImplPage.getGpsPopupOk().click();
		baseTestSuite.verifyPresent(
				driver.findElement(By
						.xpath("//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]")),
				"you have been disconnected pop up");
		String command = "adb shell settings put secure location_providers_allowed -gps";
		Process child = Runtime.getRuntime().exec(command);
		((AndroidDriver) driver).setConnection(Connection.ALL);
		System.out.println("connection none: " + ((AndroidDriver) driver).getConnection());
		logger.log(LogStatus.INFO, "connected to Wifi by switching on wifi");
		Thread.sleep(5000);
		verifyText(launchImplPage.getGpsPopupMessage().getText(),readprops.props.getProperty("gps.popup.alert.message"));
		verifyPresent(launchImplPage.getGpsPopupMessage(),"gps popup alert message");
		launchImplPage.getGpsPopupOk().click();
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon());
		verifyPresent(launchImplPage.getLoginButon(), "Signup screen");
		
	}
	
	@Test(description = "Check GPS popup during first time launch after installing app", priority=3)
	public void TS_Sanity__GPS_Checks_04() throws InterruptedException, IOException
	{
		CustomMethods.unInstallAce2three();
		Thread.sleep(3000);
		CustomMethods.installAce2three();
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		Activity activity1 = new Activity("air.com.ace2three.mobile.cash", 
				 "com.ace2three.activity.SplashActivity");
			
		((AndroidDriver) driver).startActivity(activity1);
	     Thread.sleep(5000);
	     
		CustomMethods.waitForElementPresent(launchImplPage.getGpsPopupMessage(),10);
		verifyPresent(launchImplPage.getGpsPopupMessage(), "GPS popup");
	}
	
		
	
	
	
	@DataProvider(name = "provideUsername")
	public Object[][] provideData() {

		return new Object[][] { 
			{ "appium2", "ace2three" }, 
			{ "appium3", "ace2three" }, 
			{ "appium4", "ace2three" },
			{ "appium5", "ace2three" },
			{ "appium6", "ace2three" },
			{ "appium7", "ace2three" },
			{ "appium8", "ace2three" },
			{ "appium9", "ace2three" },
			{ "appium10", "ace2three"}, 
			{ "appium11", "ace2three"} ,
			{ "appium12", "ace2three"} ,
		};
	}
	
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			logger.log(LogStatus.FAIL, result.getThrowable());
			
			try{
				if(desktopDriver.toString().contains("null")){
					logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
					}else{
						logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),desktopDriver)));
					}
			}catch(Exception e){
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
				
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver) driver).resetApp();
	}
	
}
