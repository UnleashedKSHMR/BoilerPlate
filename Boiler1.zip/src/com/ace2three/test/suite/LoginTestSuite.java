package com.ace2three.test.suite;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.ForgotPasswordWebViewImplPage;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.ChangePasswordImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.LoginImplPage;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.MyProfileImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.Connection;


public class LoginTestSuite extends BaseTestSuite {

	private File imgDir;

	@BeforeMethod
	public void beforeMethos(Method method) throws InterruptedException {
		
		Test test = method.getAnnotation(Test.class);
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		Thread.sleep(3000);
		
	}
	
	@Test(description = "TS_Login_1 - Verify that all the available objects are visible on Public landing page.",priority=1)
	public void TS_Login_1() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);

		// launchImplPage.launchPage();
		// launchImplPage.getGpgPopupCloseButton().click();

		Thread.sleep(10000);

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		verifyPresent(launchImplPage.getpasswordField(), "Password field");
		verifyPresent(launchImplPage.getLoginClickButton(), "Login button");
		verifyPresent(launchImplPage.getRememberPassword(), "Keep me logged in field");
		verifyPresent(launchImplPage.getForgotPassword(), "Forgot password field");
		verifyPresent(launchImplPage.getDoNotHaveAccount(), "Do not have an account");
		verifyPresent(launchImplPage.getSignUpButton(), " Sign Up Button");
		verifyPresent(launchImplPage.getSecure100PercentageLogo(), "100 % secure logo");
		verifyPresent(launchImplPage.getLegal100PercentageLogo(), "100 % legal logo");

	}

	@Test(description = "TS_Login_2 - Verify that asterisk mark converted to string value by opting show check box in password field",priority=2)
	public void TS_Login_2() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
	//	launchImplPage.launchApp();
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}

		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		launchImplPage.getUsernameField().sendKeys(ReadDataFromProps.props.getProperty("user.name.premium.user"));
		verifyPresent(launchImplPage.getpasswordField(), ReadDataFromProps.props.getProperty("password.premiun.user.nani2"));
		launchImplPage.getpasswordField().sendKeys(ReadDataFromProps.props.getProperty("password.premiun.user.nani2"));
		logger.log(LogStatus.INFO, launchImplPage.getpasswordField().getText());
		launchImplPage.getShowPassword().click();
		verifyTextPresent(launchImplPage.getpasswordField(), ReadDataFromProps.props.getProperty("password.premiun.user.nani2"));
	}

	@Test(description = "Verify successful login of a registered user "
			+ "to the application when a valid username and password is provided & "
			+ "Check whether user able to login or not by entering letters of user id in capital.",priority=3)
	public void TS_Login_3() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		launchImplPage.getUsernameField().sendKeys("nani2");
		verifyPresent(launchImplPage.getpasswordField(), "Password field");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		//Check whether user able to login or not by entering letters of user id in capital.
		
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getLoginClickButton(), 4);
		
		LoginImplPage loginImplPage = new LoginImplPage(driver);
		launchImplPage.launchLobbyPage("NANI2", "ace2three@");
		lobbyImplPage.verifyLobbyPageDisplayed();

	}

	@Test(description = "TS_Login_4 - Verify that error message is displayed when a valid user name and invalid password is provided",priority=4, groups={"non login"})
	public void TS_Login_4() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}

		launchImplPage.getUsernameField().sendKeys("appium");
		// Enter invalid password
		launchImplPage.getpasswordField().sendKeys("afjashiph");
		launchImplPage.getLoginClickButton().click();
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");

		// Enter blank password
		launchImplPage.getpasswordField().clear();
		launchImplPage.getpasswordField().sendKeys("");
		launchImplPage.getLoginClickButton().click();
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Password cannot be empty");

		// SPL char password
		launchImplPage.getpasswordField().clear();
		launchImplPage.getpasswordField().sendKeys("$%^&#edvdf3");
		launchImplPage.getLoginClickButton().click();
		// verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid
		// User Id or Password");
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOf(launchImplPage.getpasswordErrorMessage()));
		logger.log(LogStatus.INFO, launchImplPage.getpasswordErrorMessage().getText());
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(),
				"Password should not contain spaces and characters");
	
		
	}

	@Test(description = "TS_Login_5 -Verify that error message is displayed when a invalid username and valid password provided ",priority=5)
	public void TS_Login_5() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}

		launchImplPage.getUsernameField().sendKeys("appium12345");
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");

		// With blank user name
		launchImplPage.getUsernameField().clear();
		launchImplPage.getLoginClickButton().click();
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "User ID cannot be empty");
	}

	@Test(description = "Verify that auto login of a registered user to the application "
			+ "when a valid username and password is provided by opting Keep me logged In checkbox is opted ",priority=6)
	public void TS_Login_6() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");

		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();

		launchImplPage.launchApp();
		lobbyImplPage.verifyLobbyPageDisplayed();
		logger.log(LogStatus.PASS, "user able to auto login to the application");
		
	}

	@Test(description = "TS_Login_7 -Verify that Forgot password web page is launched by clicking on Forgot user ID/Password link",priority=7, groups={"non login"})
	public void TS_Login_7() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		verifyPresent(launchImplPage.getForgotPassword(), "Forgot Password");
		launchImplPage.getForgotPassword().click();
				
		/*Set<String> contextNames = ((AndroidDriver) driver).getContextHandles();
		for (String contextName : contextNames) {
			System.out.println(contextName); // prints out something like
												// NATIVE_APP \n WEBVIEW_1
			if (contextName.contains("WEBVIEW")) {
				((AndroidDriver) driver).context(contextName);
			}
		}
		((AndroidDriver) driver).context("WEBVIEW_chrome");
		System.out.println(driver.getPageSource());
		CustomMethods.waitForElementPresent(launchImplPage.getForgotPasswordPageHeader());
		verifyPresent(launchImplPage.getForgotPasswordPageHeader(), "Forgot password page header");
		((AndroidDriver) driver).context("NATIVE_APP");*/
		
		ForgotPasswordWebViewImplPage forgotPasswordWebViewImplPage = new ForgotPasswordWebViewImplPage(driver);
		CustomMethods.waitForElementPresent(forgotPasswordWebViewImplPage.getForgotPasswordHeader());
		
	}

	@Test(description = "Verify that sign up button functionality ",priority=8)
	public void TS_Login_8() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}

		verifyPresent(launchImplPage.getSignUpButton(), " Sign Up Button");
		//launchImplPage.getSignUpButton().click();
		LoginImplPage loginImplPage = new LoginImplPage(driver);
		loginImplPage.clickOnSignUpLink();

		SignupImplPage singupImplPage = new SignupImplPage(driver);
		singupImplPage.verifyPageLoaded();
		
	}

	@Test(description = "Verify a popup with an warning message is displayed "
			+ "when a valid username and an invalid password is provided for 5 times",priority=9)
	public void TS_Login_9() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("hello011");

		for (int i = 0; i <= 3; i++) {
			// Enter invalid password
			launchImplPage.getpasswordField().sendKeys("invalid" + i);
			launchImplPage.getLoginClickButton().click();
			if (!(i == 3)) {
				verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
			}
			logger.log(LogStatus.INFO, i + " time invalid password attempts");

		}
		verifyPresent(launchImplPage.getMultipleIncorrectAttemptsAlert(), "multiple incorrect password attempt alert");
		
	}

	@Test(description = "Verify a popup with OTP sent message is displayed "
			+ "when a valid user name and password provided on 6th attempt &"
			+ " Check login with OLD otp by clicking resend OTP link"+
			"Verify resend otp fuctionality in failed login attempts screen.",priority=10, groups={"OTP"})
	public void TS_Login_10() throws InterruptedException, IOException, SQLException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("hello011");

		for (int i = 0; i <= 3; i++) {
			// Enter invalid password
			launchImplPage.getpasswordField().sendKeys("invalid" + i);
			launchImplPage.getLoginClickButton().click();
			if (!(i == 3)) {
				verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
			}
			logger.log(LogStatus.INFO, i + " time invalid password attempts");
		}
		
		verifyPresent(launchImplPage.getMultipleIncorrectAttemptsAlert(), "multiple incorrect password attempt alert");
		launchImplPage.getCloseMultipleIncorrectAttemptsAlert().click();

		launchImplPage.getpasswordField().sendKeys("ace2three@");

		launchImplPage.getLoginClickButton().click();
		verifyPresent(launchImplPage.getOtpSentAlertMessage(), "OTP sent alert message");
		CustomMethods.waitForElementPresent(launchImplPage.getOtpSentAlertMessageOkButton(), 5);
		launchImplPage.getOtpSentAlertMessageOkButton().click();
		
		//Check whether user able to login with valid password and any old OTP which will be generated after clicking on Resend OTP link(User should only login with latest OTP). - old OTP, previous otp
		DataBaseServerConnect dataBaseServerConnect=new DataBaseServerConnect();
		String OTPOld= dataBaseServerConnect.selectQuery(null, "hello011");
		launchImplPage.getOtpReSentLink().click();
		CustomMethods.verifyNotEnabled(launchImplPage.getOtpReSentLink(), "Resend OTP link");
		
		String OTPNew= dataBaseServerConnect.selectQuery(null, "hello011");
		MobileElement OtpField= (MobileElement) driver.findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'otpET')]"));
		OtpField.sendKeys(OTPOld);
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getpasswordErrorMessage(), 5);
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Please enter the correct OTP");
		
		//Verify whether user able to login with invalid OTP and valid password(Should not login) and also verify appropiate alert is displaying or not.
		
		MobileElement OtpField1= (MobileElement) driver.findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'otpET')]"));
		OtpField1.sendKeys("11111");
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getpasswordErrorMessage(), 5);
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Please enter a valid OTP");
		
		//Verify whether user is able to login with valid OTP and Invalid password.
		MobileElement OtpField2= (MobileElement) driver.findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'otpET')]"));
		launchImplPage.getpasswordField().clear();
		launchImplPage.getpasswordField().sendKeys("ace2three");
		OtpField2.sendKeys(OTPNew);
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getpasswordErrorMessage(), 5);
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
		
	
	}
	
	/*Verify successful login of a registered user to the application when a valid username , password and OTP is provided 
	 * Verify uneditable user id is displayed in login screen by entering valid user id and password after 5 failed login attempts.
	 * */

	@Test(description = "Verify successful login of a registered user to the application when a valid username , password and OTP is provided & "
			+ "Verify uneditable user id is displayed in login screen by entering valid user id and password after 5 failed login attempts.& "
			,priority=11)
	public void TS_Login_11() throws InterruptedException, IOException, SQLException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		launchImplPage.launchApp();

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("hello011");
			for (int i = 0; i <= 3; i++) {
				// Enter invalid password
				launchImplPage.getpasswordField().sendKeys("invalid" + i);
				launchImplPage.getLoginClickButton().click();
				if (!(i == 3)) {
					verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
				}
				logger.log(LogStatus.INFO, i + " time invalid password attempts");

			}
			verifyPresent(launchImplPage.getMultipleIncorrectAttemptsAlert(), "multiple incorrect password attempt alert");
			launchImplPage.getCloseMultipleIncorrectAttemptsAlert().click();
			launchImplPage.getpasswordField().sendKeys("invalid");
			launchImplPage.getLoginClickButton().click();
			
			launchImplPage.getpasswordField().sendKeys("ace2three@");
			launchImplPage.getLoginClickButton().click();
			verifyPresent(launchImplPage.getOtpSentAlertMessage(), "OTP sent alert message");
			launchImplPage.getOtpSentAlertMessageOkButton().click();
			//Verify un-editable user id is displayed in login screen by entering valid user id and password after 5 failed login attempts.
			CustomMethods.verifyNotEnabled(launchImplPage.getUsernameField(), "user Id field");
			CustomMethods.VerifyElementNotEditable(launchImplPage.getUsernameField(), "user Id field", "clickable");
			
			DataBaseServerConnect dataBaseServerConnect=new DataBaseServerConnect();
			String OTP= dataBaseServerConnect.selectQuery(null, "hello011");
			
			
		/*((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(3000);
		((AndroidDriver) driver).openNotifications();

		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'AM-ACEACT')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 1");
		}
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'New messages')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 2");
		}

		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();

		List<WebElement> textMessages = driver
				.findElements(By.xpath("//android.widget.TextView[contains(@text,'Hello champion3')]"));
		int noOfMesg = textMessages.size();
		System.out.println(noOfMesg);
		
		String messageText = textMessages.get(noOfMesg - 1).getText();
		String splitMessage[] =messageText.split(",");
		String OTP= splitMessage[1].substring(1, 7);
		System.out.println("Text Message actual:" + textMessages.get(noOfMesg - 1).getText());
		System.out.println("OTP: " + OTP);
		for (WebElement message : textMessages) {
			System.out.println("Text Message :" + message.getText());
		}
		
		 try {((AndroidDriver) driver).runAppInBackground(2);
	        } catch (Exception e) {//ignore} 
	        	
	        }*/
		 
		 Thread.sleep(4000);
		
		 launchImplPage.getpasswordField().sendKeys("ace2three@");
		 //Verify whether OTP field is allowing alphabets or not(Should not allow).
		 MobileElement OtpField= (MobileElement) driver.findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'otpET')]"));
		 OtpField.sendKeys("afaa");
		 
		 if(OtpField.getText().equalsIgnoreCase("afaa")){
			 logger.log(LogStatus.FAIL, "alphabets are accepting in OTP field");
		 }else{
			 logger.log(LogStatus.PASS, "alphabets are not accepting in OTP field");
		 }
		 
		 OtpField.clear();
		 OtpField.sendKeys(OTP);
		
		 launchImplPage.getLoginClickButton().click();
		 LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		 if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			 lobbyImplPage.getUpdateProfilePopUpClose().click();
			 ChangePasswordImplPage changePasswordImplPage =new ChangePasswordImplPage(driver);
			 if(CustomMethods.isElementPresent(changePasswordImplPage.getNotNowButton()))
			 changePasswordImplPage.getNotNowButton().click();
			 lobbyImplPage.verifyLobbyPageDisplayed();
		 
	}
	
	//@Deprecated
	@Test(description = "Verify a popup with OTP sent message is displayed "
			+ "when a valid user name and password provided on 6th attempt ",priority=12,enabled = false)
	public void TS_Login_12() throws InterruptedException, IOException{

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("hello013");

		/*int i;
		for (i=0; i <= 3; i++) {
			// Enter invalid password
			launchImplPage.getpasswordField().sendKeys("invalid" + i);
			launchImplPage.getLoginClickButton().click();
			if ((i < 3)) {
				verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
			} else {
				verifyPresent(launchImplPage.getMultipleIncorrectAttemptsAlert(),
						"multiple incorrect password attempt alert");
				launchImplPage.getCloseMultipleIncorrectAttemptsAlert().click();
			}
			logger.log(LogStatus.INFO, i + " time invalid password attempts");

		}

		launchImplPage.getpasswordField().sendKeys("invalid");
		launchImplPage.getLoginClickButton().click();*/

		launchImplPage.getpasswordField().sendKeys("Ace2three@");

		launchImplPage.getLoginClickButton().click();
		verifyPresent(launchImplPage.getOtpSentAlertMessage(), "OTP sent alert message");
		launchImplPage.getOtpSentAlertMessageOkButton().click();

		launchImplPage.getOtpReSentLink().click();
		
		/*
		File file = new File("C:\\Users\\dineshsoma\\Desktop\\");
		String aa= file+"\\OTP.png";
		OCREngine ocr = new OCREngine((AppiumDriver) driver);
		Settings.OcrTextRead=true;
		Settings.OcrTextSearch=true;
		Finder f = new Finder(ocr.takeScreenshot());
       
        f.find("OTP sent to registered email");
        
		ocr.waitUntilImageExists(aa, 30);
		ocr.clickByImage(aa);
      //  Region region = new Region();
      //  region.find("");
        */
		Thread.sleep(1000);
		
		 WebElement toastView = driver.findElement(By.xpath("//android.widget.Toast[1]"));
		 String text = toastView.getAttribute("name");
		 System.out.println(text + "  :saklgbdsijlgbildasgbjdsla: ");
		 
		 
		WebElement ele = driver.findElement(By.xpath("//*[contains(@text,'OTP sent to registered email id and phone number')]"));
		System.out.println(driver.getPageSource());
		CustomMethods.waitForElementPresent(ele, 5);
		//driver.findElement(By.xpath("//*[contains(text,'OTP sent to registered email id and phone number')]")).getText();
	/*	ReadToastMessage readToastMessage= new  ReadToastMessage();
		readToastMessage.readToastMessage().contains("OTP sent to registered email id and phone number");*/
	}
	
	@Test(description = "Verify that login screen is displayed when user clicks on sign in with different user id"
			+ "Verify whether user able to login with valid OTP and valid password after giving network interrupt at failed login attempts screen(Should login).",priority=12)
	public void TS_Login_13() throws InterruptedException, IOException, SQLException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("champion3");

		int i;
		for (i=0; i <= 3; i++) {
			// Enter invalid password
			launchImplPage.getpasswordField().sendKeys("invalid" + i);
			launchImplPage.getLoginClickButton().click();
			if ((i < 3)) {
				verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
			} else {
				verifyPresent(launchImplPage.getMultipleIncorrectAttemptsAlert(),
						"multiple incorrect password attempt alert");
				launchImplPage.getCloseMultipleIncorrectAttemptsAlert().click();
			}
			logger.log(LogStatus.INFO, i + " time invalid password attempts");

		}

		launchImplPage.getpasswordField().sendKeys("invalid");
		launchImplPage.getLoginClickButton().click();

		launchImplPage.getpasswordField().sendKeys("ace2three");

		launchImplPage.getLoginClickButton().click();
		verifyPresent(launchImplPage.getOtpSentAlertMessage(), "OTP sent alert message");
		CustomMethods.waitForElementPresent(launchImplPage.getOtpSentAlertMessageOkButton(), 6);
		launchImplPage.getOtpSentAlertMessageOkButton().click();
		verifyPresent(launchImplPage.getSigninWithDifferentUserID(),"Sign in with different user ID");
		launchImplPage.getSigninWithDifferentUserID().click();
		if(verifyPresent(launchImplPage.getKeepMeLogged(),"Login Page")){
			logger.log(LogStatus.PASS, "User navigated to login page succesfully after clicking Sign in with different user ID link ");
		}else{
			logger.log(LogStatus.FAIL, "User not navigated to login page after clicking Sign in with different user ID link ");
			//logger.addScreenCapture(takeScreenShot("Sign in with different user ID")
		}
		
		//Verify whether user able to login with valid OTP and valid password after giving network interrupt at failed login attempts screen(Should login).
		launchImplPage.getUsernameField().sendKeys("hello011");
		launchImplPage.getUsernameField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getOtpSentAlertMessageOkButton(), 4);
		launchImplPage.getOtpSentAlertMessageOkButton().click();
		
		((AndroidDriver) driver).setConnection(Connection.NONE);
		logger.log(LogStatus.INFO, "connection status: "+ ((AndroidDriver) driver).getConnection());
		
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(
				"//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"))));

		verifyPresent(
				driver.findElement(By
						.xpath("//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]")),
				"you have been disconnected pop up");
	
		((AndroidDriver) driver).setConnection(Connection.ALL);
		logger.log(LogStatus.INFO, "connection status: "+ ((AndroidDriver) driver).getConnection());
		System.out.println("connection status: "+ ((AndroidDriver) driver).getConnection());
		
		DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
		String OTPNew= dataBaseServerConnect.selectQuery(null, "hello011");
		MobileElement OtpField2= (MobileElement) driver.findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'otpET')]"));
		launchImplPage.getpasswordField().clear();
		launchImplPage.getpasswordField().sendKeys("ace2three");
		OtpField2.sendKeys(OTPNew);
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage= new LobbyImplPage(driver);
		 ChangePasswordImplPage changePasswordImplPage =new ChangePasswordImplPage(driver);
		 if(CustomMethods.isElementPresent(changePasswordImplPage.getNotNowButton()))
		 changePasswordImplPage.getNotNowButton().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
	}
	
	
	@Test(description = "Verify a popup with message � You have been disconnected. "
			+ "trying to reconnect� is displayed when wifi is in OFF mode",priority=13)
	public void TS_Login_14() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		Thread.sleep(15000);
		 launchImplPage.launchApp();

		((AndroidDriver) driver).setConnection(Connection.ALL);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());
		
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		/*((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(3000);
		((AndroidDriver) driver).openNotifications();
		Thread.sleep(3000);
		// ((AndroidDriver) driver).swipe( 300,300,300,900,2000);
		// for micromax
		((AndroidDriver) driver).swipe(200, 200, 200, 700, 2000);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Android')]")).click();
		Thread.sleep(3000);
		// driver.findElement(By.xpath("//android.widget.TextView[contains(@text'Cellular
		// data')]/following-sibling::android.widget.Switch")).click();
		driver.findElement(By.xpath("//android.widget.Switch[contains(@resource-id,'toggle')]")).click();
		Thread.sleep(3000);*/
		
		((AndroidDriver) driver).setConnection(Connection.NONE);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());
		logger.log(LogStatus.INFO, "Disconnected Wifi by switching off wifi");
		/*try {
			((AndroidDriver) driver).runAppInBackground(1);
		} catch (Exception e) {// ignore}

		}*/
		
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(
				"//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"))));

		verifyPresent(
				driver.findElement(By
						.xpath("//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]")),
				"you have been disconnected pop up");
		
		/*Thread.sleep(3000);
		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(3000);
		((AndroidDriver) driver).openNotifications();
		Thread.sleep(3000);
		((AndroidDriver) driver).swipe(300, 300, 300, 900, 2000);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Head')]")).click();
		Thread.sleep(3000);
		// driver.findElement(By.xpath("//android.widget.TextView[contains(@text'Cellular
		// data')]/following-sibling::android.widget.Switch")).click();
		
		driver.findElement(By.xpath("//android.widget.Switch[contains(@resource-id,'toggle')]")).click();
		Thread.sleep(3000);

		try {
			((AndroidDriver) driver).runAppInBackground(1);
		} catch (Exception e) {// ignore}

		}*/
		
		((AndroidDriver) driver).setConnection(Connection.ALL);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());


		
	}
	
	@Test(description = "Check duplicate account message and account locked",priority=14)
	public void TS_Login_1_new() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//Check whether password is case sensitive or not while logging into the app
				if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
					launchImplPage.getLoginButon().click();
				}
				launchImplPage.getUsernameField().sendKeys("nani10");
				launchImplPage.getpasswordField().sendKeys("ACE2THREE@");
				launchImplPage.getLoginClickButton().click();
				verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
				
		//Check user whom fall under RG master log should not be login with appropriate message
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("acetest19");
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		
		verifyTextPresent(launchImplPage.getAccountDisabledVerificationMessage(), 
				ReadDataFromProps.props.getProperty("login.error.disabled.duplicate.rg.actions.message"));
		
		/*if("abc".contains("abc")){
			throw new SkipException("Here");
			}*/
		
		//Check duplicate account message and account locked
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("devuda26");
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		
		verifyPresent(launchImplPage.getAccountDisabledVerificationMessage(), 
				ReadDataFromProps.props.getProperty("login.error.disabled.duplicate.rg.actions.message"));
		
		
		
		//	launchImplPage.launchApp();
		//  system should allow old user which has special char in username - start
			if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
				launchImplPage.getLoginButon().click();
			}
			launchImplPage.getUsernameField().sendKeys("purna_kee");
			launchImplPage.getpasswordField().sendKeys("ace2three");
			launchImplPage.getLoginClickButton().click();
			LobbyImplPage lobbyImplPage= new LobbyImplPage(driver);
			
			lobbyImplPage.verifyLobbyPageDisplayed();
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null);
			
			//system should allow old user which has special char in username - end
		
		//Check whether user able to login or not after selecting state and city to blocked states.- start
		
		((AndroidDriver) driver).resetApp();
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon(), 15);
		SignupImplPage signupImplPage= new SignupImplPage(driver);
		String userName=signupImplPage.doSignUp();
		//LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage myProfile = new MyProfileImplPage(driver);
		myProfile.verifyProfilePageIsDisplayed();
		
			int length = 7;
		    boolean useLetters = true;
		    boolean useNumbers = false;
		    String generatedString = RandomStringUtils.random(length, useLetters, useNumbers);
		    System.out.println(generatedString.toLowerCase());
		    
		    String firstName= "fn"+ generatedString.toLowerCase();
		    String lastName= "ln"+ generatedString.toLowerCase();
			
			myProfile.getMyProfileFirstNameField().sendKeys(firstName);
			myProfile.getMyProfileLastNameField().sendKeys(lastName);
			myProfile.getMyProfileDOBField().click();
			myProfile.getMyProfileCalenderOkButton().click();
			myProfile.getMyProfileGenderField().click();
			CustomMethods.selectFromDropDownList("Male");
			myProfile.getMyProfileStateField().click();
			CustomMethods.selectFromDropDownList("Assam");
			myProfile.getMyProfileCityField().click();
			CustomMethods.selectFromDropDownList("Bijni");
			myProfile.getMyProfileSaveButtonLoc().click();
		
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
			lobbyImplPage.getLogoutAlertPopupYesButton().click();
			CustomMethods.waitForElementPresent(launchImplPage.getUsernameField(),4);
			
			launchImplPage.getUsernameField().sendKeys(userName);
			launchImplPage.getpasswordField().sendKeys("ace2three@");
			launchImplPage.getLoginClickButton().click();
			verifyPresent(launchImplPage.getAccessRestrictedDueToLocationError(), "Signin restricted due to location");
			
			//Check whether user able to login or not after selecting state and city to blocked states.- end
			
		}
	
	@Test(description = "Check user able to login before online count has displayed",priority=15)
	public void TS_Login_2_new() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		LoginImplPage loginImplPage= new LoginImplPage(driver);
		Thread.sleep(2000);
		launchImplPage.getLoginButon().click();
		LobbyImplPage lobbyImplPage;
		
		//Check user able to login before online count has displayed
		if(CustomMethods.isElementPresent(loginImplPage.getTableandPlayerCount())){
				
				launchImplPage.getUsernameField().sendKeys("nani2");
				launchImplPage.getpasswordField().sendKeys("ace2three@");
				launchImplPage.getLoginClickButton().click();
			
				lobbyImplPage= new LobbyImplPage(driver);
				lobbyImplPage.verifyLobbyPageDisplayed();
				
		}else{
			launchImplPage.getUsernameField().sendKeys("nani2");
			launchImplPage.getpasswordField().sendKeys("ace2three@");
			launchImplPage.getLoginClickButton().click();
			
			lobbyImplPage= new LobbyImplPage();
			verifyPresent(loginImplPage.getLoginWithFacebook(), "login page");
			verifyNotPresent(lobbyImplPage.getgamesTabIcon(), "Lobby page", 18);
		}
		
	}
	
	@Test(description = "Copy paste username and password and edit them before login",priority=16, enabled =false)
	public void TS_Login_3_new() throws InterruptedException, IOException, UnsupportedFlavorException {
		
		String str = "String1";
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Clipboard clipboard = toolkit.getSystemClipboard();
		StringSelection strSel = new StringSelection(str);
		clipboard.setContents(strSel, null);
		
		
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		Thread.sleep(2000);
		launchImplPage.getLoginButon().click();
		/*Dictionary keyEvent = new  Hashtable();
		keyEvent.put("keycode", 50);
		keyEvent.put("metastate", 113);*/
		MobileElement element = (MobileElement) driver.findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'nicknameTV')]"));
		 TouchAction action = new TouchAction((PerformsTouchActions) driver);
         action.longPress(element).perform().release();
         action.press(element.getLocation().getX()+ 30, element.getLocation().getY() - 30);
         
         
		Thread.sleep(6000);
	}
	//this test scenario  has been included in TS_Login_14
	@Deprecated
	@Test(description = "Verify a popup with message � You have been disconnected. Trying to reconnect� "
			+ "is gets dissappeared when wifi is in ON mode ",enabled = false)
	public void TS_Login_15() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		Thread.sleep(30000);
		launchImplPage.launchApp();

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}

		verifyPresent(launchImplPage.getSignUpButton(), " Sign Up Button");
		launchImplPage.getSignUpButton().click();

		SignupImplPage singupImplPage = new SignupImplPage(driver);
		singupImplPage.verifyPageLoaded();
	}

	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			logger.log(LogStatus.FAIL, result.getThrowable());
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		
		extent.endTest(logger);
		extent.flush();
		((AppiumDriver) driver).resetApp();
		
	}
	
}
