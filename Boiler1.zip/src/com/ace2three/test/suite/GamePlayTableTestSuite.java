package com.ace2three.test.suite;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.component.pages.JoinAnotherGameDialogBox;
import com.ace2three.component.pages.MeldCardsPopUp;
import com.ace2three.component.pages.ReShufleDeckDialogeBox;
import com.ace2three.component.pages.ResultsWindow;
import com.ace2three.impl.pages.GamePlayPlayer2ImplPage;
import com.ace2three.impl.pages.GamePlayTableImplPage;
import com.ace2three.impl.pages.GamePlayTableImplPage.Game;
import com.ace2three.impl.pages.GamePlayTableImplPage.twoPlayerGameTypes;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class GamePlayTableTestSuite extends BaseTestSuite{

	WebDriver player2Driver;
	CustomMethods cm;
	@BeforeMethod
	public void beforeMethos(Method method) {
	
		Test test = method.getAnnotation(Test.class);
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		cm = new CustomMethods();
		BaseTestSuite baseTestSuite=new BaseTestSuite();
		try{
			baseTestSuite.driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'permission_allow_button')]")).click();
		}catch(Exception e){
			
		}
	}
	
	@Test(description = "Verify insufficient balance alert need to be displayed when user tries to play game if real chips are available")
	public void TS_GamePlay_01() throws InterruptedException, IOException {
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("appium18");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		gamePlayTable.navigateToGameType(Game.BestO2);
				//Player 01 join table
				gamePlayTable.joinGameTable("5");
				verifyPresent(gamePlayTable.getNoSufficientChipsToPlayAlert(),"No sufficient chips to play alert");
				verifyTextPresent(gamePlayTable.getNoSufficientChipsToPlayAlert(),
						ReadDataFromProps.props.getProperty("Lobby.page.no.sufficient.chips.to.play.message"));
				gamePlayTable.getNoSufficientChipsToPlayAlertNoThanks().click();
				verifyPresent(gamePlayTable.getGameTypeRightArrow(),"Game types screen");
				gamePlayTable.joinGameTable("5");
				verifyPresent(gamePlayTable.getNoSufficientChipsToPlayAlert(),"No sufficient chips to play alert");
				verifyTextPresent(gamePlayTable.getNoSufficientChipsToPlayAlert(),
						ReadDataFromProps.props.getProperty("Lobby.page.no.sufficient.chips.to.play.message"));
	}
	
	@SuppressWarnings("static-access")
	@Test(description = "Verify chat option should not be enabled when only one player is on game table"
			+ "and verify chat option is enabled when 2 players are in the game table")
	public void TS_GamePlay_13() throws InterruptedException, IOException {
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		CustomMethods.waitForElementPresent(gamePlayTable.getGameType() , 4);
		gamePlayTable.navigateToGameType(Game.BestO2);
				//Player 01 join table
				gamePlayTable.joinGameTable("5");
				gamePlayTable.getJoinTableYesButton().click();
				CustomMethods.waitForElementPresent(gamePlayTable.getWaitOtherPlayerTojoin(), 5);
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyPresent(gamePlayTable.getChatOption(), "Chat option");
				CustomMethods.verifyNotEnabled(gamePlayTable.getChatOption(), "Chat option"); 
				
		this.player2Driver = cm.launchNewSession();
		LaunchImplPage launchImplPage2  = new LaunchImplPage(player2Driver);
		if(CustomMethods.isElementPresent(launchImplPage2.getGpsPopupOk()))
			launchImplPage2.getGpsPopupOk().click();
		GamePlayPlayer2ImplPage gamePlayTable2 = new GamePlayPlayer2ImplPage(player2Driver);
		gamePlayTable2.navigateToGames();
		CustomMethods.waitForElementPresent(gamePlayTable2.getGameType(), 4);
		gamePlayTable2.navigateToGameType(Game.BestO2);
		//Player 02 join table
		gamePlayTable2.joinGameTable("5");
		gamePlayTable2.getJoinTableYesButton().click();
		
		verifyNotPresent(gamePlayTable2.getWaitOtherPlayerTojoin(),"Please wait while other players join the table",3);
		cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
		CustomMethods.verifyEnabled(gamePlayTable.getChatOption(), "Chat option"); 
		Thread.sleep(10000);
		CustomMethods.verifyEnabled(gamePlayTable.getLeaveTableButton(), "Leave Table Button"); 
		gamePlayTable.getLeaveTableButton().click();
		gamePlayTable.getLeaveTableOption().click();
		gamePlayTable.getLeaveToLobbyAlertOkButton().click();
		
	}
	
	@SuppressWarnings("static-access")
	@Test(description = "Verify Leave table functionality with view lobby and leave table buttons and verify user able to go to game table from active table tab")
	public void TS_GamePlay_02() throws InterruptedException, IOException {
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		gamePlayTable.navigateToGameType(Game.BestO2);
				//Player 01 join table
				gamePlayTable.joinGameTable("5");
				gamePlayTable.getJoinTableYesButton().click();
				CustomMethods.waitForElementPresent(gamePlayTable.getWaitOtherPlayerTojoin(), 5);
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyPresent(gamePlayTable.getChatOption(), "Chat option");
				CustomMethods.verifyNotEnabled(gamePlayTable.getChatOption(), "Chat option"); 
				gamePlayTable.getLeaveTableButton().click();
				verifyPresent(gamePlayTable.getLeaveTableOption(), "leave table options");
				gamePlayTable.getLeaveToLobby().click();
				verifyTextPresent(gamePlayTable.getLeaveToLobbyAlertMessage(),
						ReadDataFromProps.props.getProperty("game.table.leave.to.lobby.alert.message"));
				verifyPresent(gamePlayTable.getleaveToLobbyAlertDontShowThisMessage(), "Dont show this message check box");
				gamePlayTable.getLeaveToLobbyAlertOkButton().click();
				verifyPresent(lobbyImplPage.getgamesTabIcon(),"Lobby Page");
				lobbyImplPage.getActiveTablesTab().click();
				verifyPresent(lobbyImplPage.getActiveTable1(), "Active tables box");
				String betAmount =lobbyImplPage.getActiveTable1BetAmount().getText();
				lobbyImplPage.getActiveTable1().click();
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyText(betAmount, gamePlayTable.getGameBetAmount().getText());
				gamePlayTable.getLeaveTableButton().click();
				verifyPresent(gamePlayTable.getLeaveTableOption(), "leave table options");
				gamePlayTable.getLeaveTableOption().click();
				verifyTextPresent(gamePlayTable.getLeaveTableDialogBoxMessage(), 
						ReadDataFromProps.props.getProperty("game.table.leave.table.dialog.box.message"));
				gamePlayTable.getLeaveToLobbyAlertOkButton().click();
				verifyPresent(lobbyImplPage.getgamesTabIcon(),"Lobby Page");
				
	}
	
	@SuppressWarnings("static-access")
	@Test(description = "Verify switch tables functionality in game table by switch table button")
	public void TS_GamePlay_03() throws InterruptedException, IOException {
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		gamePlayTable.navigateToGameType(Game.BestO2);
				//Player 01 join table
				gamePlayTable.joinGameTable("5");
				gamePlayTable.getJoinTableYesButton().click();
				CustomMethods.waitForElementPresent(gamePlayTable.getWaitOtherPlayerTojoin(), 5);
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyPresent(gamePlayTable.getChatOption(), "Chat option");
				CustomMethods.verifyNotEnabled(gamePlayTable.getChatOption(), "Chat option"); 
				String table1ID= gamePlayTable.getGameTableID().getText();
				gamePlayTable.getSwitchTableButton().click();
				verifyPresent(gamePlayTable.getSelectTablePopuUpHeader(), "Select table dialog box");
				gamePlayTable.getSelectTableTwoPlayersOption().click();
				gamePlayTable.getSelectTablePopupGameType().click();
				gamePlayTable.selectFromGameTypeListView(twoPlayerGameTypes.B02);
				gamePlayTable.getSwitchTableGoToLobby().click();
				verifyPresent(lobbyImplPage.getgamesTabIcon(),"Lobby Page");
				
				lobbyImplPage.getActiveTablesTab().click();
				verifyPresent(lobbyImplPage.getActiveTable1(), "Active tables box");
				String betAmount =lobbyImplPage.getActiveTable1BetAmountValue();
				lobbyImplPage.getActiveTable1().click();
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyText(gamePlayTable.getGameBetAmount().getText(), betAmount);
				gamePlayTable.getSwitchTableButton().click();
				verifyPresent(gamePlayTable.getSelectTablePopuUpHeader(), "Select table dialog box");
				gamePlayTable.getSelectTableTwoPlayersOption().click();
				gamePlayTable.getSelectTablePopupGameType().click();
				gamePlayTable.selectFromGameTypeListView(twoPlayerGameTypes.B02);
				String table2BetAmount = gamePlayTable.getSwitchTableBetAmountValue();
				gamePlayTable.getSwitchTableJoinButton().click();
				
				verifyTextPresent(gamePlayTable.getGameBetAmount(), table2BetAmount);
				String table2ID= gamePlayTable.getGameTableID().getText();
				gamePlayTable.getSwitchTableButton().click();
				
				if(gamePlayTable.getGameTableID().getText().equalsIgnoreCase(table1ID)){
					logger.log(LogStatus.PASS, "Able to switch from table 2 to table 1");
				}else{
					logger.log(LogStatus.FAIL, "Unable to switch from table 2 to table 1"+ logger.addScreenCapture(takeScreenShot("Failure")));
				}
				Thread.sleep(4000);
				gamePlayTable.getSwitchTableButton().click();
				if(gamePlayTable.getGameTableID().getText().equalsIgnoreCase(table2ID)){
					logger.log(LogStatus.PASS, "Able to switch from table 1 to table 2");
				}else{
					logger.log(LogStatus.FAIL, "Unable to switch from table 1 to table 2"+ logger.addScreenCapture(takeScreenShot("Failure")));
				}
				
	}
	
	@SuppressWarnings("static-access")
	@Test(description = "BOX - Next game join popup after game end i.e. Do you want to join another game with yes & no buttons.", priority=4)
	public void TS_GamePlay_04() throws InterruptedException, IOException {
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		gamePlayTable.navigateToGameType(Game.BestO2);
				//Player 01 join table
				gamePlayTable.joinGameTable("5");
				gamePlayTable.getJoinTableYesButton().click();
				CustomMethods.waitForElementPresent(gamePlayTable.getWaitOtherPlayerTojoin(), 5);
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyPresent(gamePlayTable.getChatOption(), "Chat option");
				CustomMethods.verifyNotEnabled(gamePlayTable.getChatOption(), "Chat option"); 
		//Player 2 session start	
		this.player2Driver = cm.launchNewSession();
		LaunchImplPage launchImplPage2  = new LaunchImplPage(player2Driver);
		if(CustomMethods.isElementPresent(launchImplPage2.getGpsPopupOk()))
			launchImplPage2.getGpsPopupOk().click();
		GamePlayPlayer2ImplPage gamePlayTable2 = new GamePlayPlayer2ImplPage(player2Driver);
		gamePlayTable2.navigateToGames();
		CustomMethods.waitForElementPresent(gamePlayTable2.getGameType(), 4);
		gamePlayTable2.navigateToGameType(Game.BestO2);
		//Player 02 join table
		gamePlayTable2.joinGameTable("5");
		gamePlayTable2.getJoinTableYesButton().click();
		
		verifyNotPresent(gamePlayTable2.getWaitOtherPlayerTojoin(),"Please wait while other players join the table",3);
		cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
		CustomMethods.verifyEnabled(gamePlayTable.getChatOption(), "Chat option");
		MeldCardsPopUp meldCardsPopUpPlayer1 = new MeldCardsPopUp(driver);
		MeldCardsPopUp meldCardsPopUpPlayer2 = new MeldCardsPopUp(player2Driver);
		String playerWon;
		Thread.sleep(3000);
		//System.out.println("player1 hand timer: " + gamePlayTable.getHandTimerPulse().getText());
		if(cm.isElementPresent(gamePlayTable.getHandTimerPulse())){
				gamePlayTable.getSortButton().click();
				gamePlayTable.getOpenCard().click();
				//gamePlayTable.tapOnOpenCard();
				//gamePlayTable.countCards();
				Thread.sleep(1000);
				gamePlayTable.getCard("12").click();
				gamePlayTable.getDiscardButton().click();
				gamePlayTable2.getSortButton().click();
				gamePlayTable2.getOpenCard().click();
				//gamePlayTable2.tapOnOpenCard();
				//gamePlayTable2.countCards();
				Thread.sleep(1000);
				gamePlayTable2.getCard("12").click();
				gamePlayTable2.getShowButton().click();
				verifyTextPresent(gamePlayTable2.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable2.getPlaceShowConfirmDialogYesButton().click();
				playerWon = "player1";
			}else{
				gamePlayTable2.getSortButton().click();
				gamePlayTable2.getOpenCard().click();
				//gamePlayTable2.tapOnOpenCard();
				//gamePlayTable2.countCards();
				Thread.sleep(2000);
				gamePlayTable2.getCard("12").click();
				gamePlayTable2.getDiscardButton().click();
				gamePlayTable.getSortButton().click();
				gamePlayTable.getOpenCard().click();
				//gamePlayTable.tapOnOpenCard();
				//gamePlayTable.countCards();
				Thread.sleep(3000);
				gamePlayTable.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable.getShowButton(), 10);
				gamePlayTable.getShowButton().click();
				verifyTextPresent(gamePlayTable.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable.getPlaceShowConfirmDialogYesButton().click();
				playerWon = "player2";
			}
			
			meldCardsPopUpPlayer1.getMeldAll().click();
			meldCardsPopUpPlayer1.getSendCardsButton().click();
			meldCardsPopUpPlayer2.getMeldAll().click();
			meldCardsPopUpPlayer2.getSendCardsButton().click();
			
			/*Thread.sleep(5000);*/
			//make sort to wait
			cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
			if(playerWon.equalsIgnoreCase("player1")){
				gamePlayTable.getSortButton().click();
				gamePlayTable2.getSortButton().click();
				gamePlayTable2.getOpenCard().click();
				Thread.sleep(2000);
				//gamePlayTable2.tapOnOpenCard();
				//gamePlayTable2.countCards();
				gamePlayTable2.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable2.getShowButton(), 10);
				gamePlayTable2.getShowButton().click();
				verifyTextPresent(gamePlayTable2.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable2.getPlaceShowConfirmDialogYesButton().click();
			}else{
				gamePlayTable2.getSortButton().click();
				gamePlayTable.getSortButton().click();
				gamePlayTable.getOpenCard().click();
				//gamePlayTable.tapOnOpenCard();
			/*	gamePlayTable.countCards();*/
				Thread.sleep(3000);
				gamePlayTable.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable.getShowButton(), 10);
				gamePlayTable.getShowButton().click();
				verifyTextPresent(gamePlayTable.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable.getPlaceShowConfirmDialogYesButton().click();
			}
			ResultsWindow resultsWindow1 = new ResultsWindow(driver);
			ResultsWindow resultsWindow2 = new ResultsWindow(player2Driver);
			
			meldCardsPopUpPlayer1.getMeldAll().click();
			meldCardsPopUpPlayer1.getSendCardsButton().click();
			verifyPresent(resultsWindow1.getResultsView(), "Results view");
			meldCardsPopUpPlayer2.getMeldAll().click();
			meldCardsPopUpPlayer2.getSendCardsButton().click();
			verifyPresent(resultsWindow2.getResultsView(), "Results view");
			
			JoinAnotherGameDialogBox joinAnotherGameDialogBox1 = new JoinAnotherGameDialogBox(driver);
			JoinAnotherGameDialogBox joinAnotherGameDialogBox2 = new JoinAnotherGameDialogBox(player2Driver);
			if(playerWon.equalsIgnoreCase("player1")){
				verifyText(joinAnotherGameDialogBox1.getJoinAnotherGameAlertMessage().getText(), "Congratulations. You have won the game", "Congratulations message for P1");
				verifyText(joinAnotherGameDialogBox2.getJoinAnotherGameAlertMessage().getText(), "Sorry. You have been eliminated from the game", "Lost game message for P2");
			}if(playerWon.equalsIgnoreCase("player2")){
				verifyText(joinAnotherGameDialogBox2.getJoinAnotherGameAlertMessage().getText(), "Congratulations. You have won the game", "Congratulations message P2");
				verifyText(joinAnotherGameDialogBox1.getJoinAnotherGameAlertMessage().getText(), "Sorry. You have been eliminated from the game", "Lost game message for P1");
			}
			Thread.sleep(12000);
			verifyText(joinAnotherGameDialogBox2.getJoinAnotherGameAlertMessage().getText(), ReadDataFromProps.props.getProperty("game.table.join.another.game"), "Another game join popup");
			joinAnotherGameDialogBox2.getJoinAnotherGameAlertYes().click();
			verifyPresent(gamePlayTable2.getLeaveTableButton(),"Game table");
			
			verifyText(joinAnotherGameDialogBox1.getJoinAnotherGameAlertMessage().getText(),ReadDataFromProps.props.getProperty("game.table.join.another.game"));
			joinAnotherGameDialogBox1.getJoinAnotherGameAlertNo().click();
			verifyPresent(lobbyImplPage.getgamesTabIcon(),"Lobby Page");
	}
	
	@SuppressWarnings("static-access")
	@Test(description = "Pool - Next game join popup after game end i.e. Do you want to join another game with yes & no buttons.", priority=4)
	public void TS_GamePlay_05() throws InterruptedException, IOException {
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		gamePlayTable.navigateToGameType(Game.Pool101);
				//Player 01 join table
				gamePlayTable.joinGameTable("10");
				CustomMethods.waitForElementPresent(gamePlayTable.getJoinTableYesButton(), 5);
				gamePlayTable.getJoinTableYesButton().click();
				CustomMethods.waitForElementPresent(gamePlayTable.getWaitOtherPlayerTojoin(), 5);
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyPresent(gamePlayTable.getChatOption(), "Chat option");
				CustomMethods.verifyNotEnabled(gamePlayTable.getChatOption(), "Chat option"); 
		//Player 2 session start	
		this.player2Driver = cm.launchNewSession();
		GamePlayPlayer2ImplPage gamePlayTable2 = new GamePlayPlayer2ImplPage(player2Driver);
		gamePlayTable2.navigateToGames();
		CustomMethods.waitForElementPresent(gamePlayTable2.getGameType(), 4);
		gamePlayTable2.navigateToGameType(Game.Pool101);
		//Player 02 join table
		gamePlayTable2.joinGameTable("10");
		gamePlayTable2.getJoinTableYesButton().click();
		
		verifyNotPresent(gamePlayTable2.getWaitOtherPlayerTojoin(),"Please wait while other players join the table",3);
		cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
		CustomMethods.verifyEnabled(gamePlayTable.getChatOption(), "Chat option");
		MeldCardsPopUp meldCardsPopUpPlayer1 = new MeldCardsPopUp(driver);
		MeldCardsPopUp meldCardsPopUpPlayer2 = new MeldCardsPopUp(player2Driver);
		String playerWon;
		Thread.sleep(3000);
		//System.out.println("player1 hand timer: " + gamePlayTable.getHandTimerPulse().getText());
		if(cm.isElementPresent(gamePlayTable.getHandTimerPulse())){
				gamePlayTable.getSortButton().click();
				gamePlayTable.getOpenCard().click();
				//gamePlayTable.tapOnOpenCard();
				//gamePlayTable.countCards();
				Thread.sleep(3000);
				gamePlayTable.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable.getDiscardButton(), 5);
				gamePlayTable.getDiscardButton().click();
				Thread.sleep(3000);
				gamePlayTable2.getSortButton().click();
				gamePlayTable2.getOpenCard().click();
				//gamePlayTable2.tapOnOpenCard();
				//gamePlayTable2.countCards();
				Thread.sleep(3000);
				gamePlayTable2.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable2.getShowButton(), 5);
				gamePlayTable2.getShowButton().click();
				verifyTextPresent(gamePlayTable2.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable2.getPlaceShowConfirmDialogYesButton().click();
				playerWon = "player1";
			}else{
				gamePlayTable2.getSortButton().click();
				gamePlayTable2.getOpenCard().click();
				//gamePlayTable2.tapOnOpenCard();
				//gamePlayTable2.countCards();
				Thread.sleep(3000);
				gamePlayTable2.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable2.getDiscardButton(), 5);
				gamePlayTable2.getDiscardButton().click();
				Thread.sleep(3000);
				gamePlayTable.getSortButton().click();
				gamePlayTable.getOpenCard().click();
				//gamePlayTable.tapOnOpenCard();
				//gamePlayTable.countCards();
				Thread.sleep(3000);
				gamePlayTable.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable.getShowButton(), 5);
				gamePlayTable.getShowButton().click();
				verifyTextPresent(gamePlayTable.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable.getPlaceShowConfirmDialogYesButton().click();
				playerWon = "player2";
			}
			meldCardsPopUpPlayer1.getMeldAll().click();
			meldCardsPopUpPlayer1.getSendCardsButton().click();
			meldCardsPopUpPlayer2.getMeldAll().click();
			meldCardsPopUpPlayer2.getSendCardsButton().click();
			
			/*Thread.sleep(5000);*/
			//make sort to wait
			cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
			if(playerWon.equalsIgnoreCase("player1")){
				gamePlayTable.getSortButton().click();
				gamePlayTable2.getSortButton().click();
				gamePlayTable2.getOpenCard().click();
				//gamePlayTable2.tapOnOpenCard();
				//gamePlayTable2.countCards();
				Thread.sleep(3000);
				gamePlayTable2.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable2.getShowButton(), 5);
				gamePlayTable2.getShowButton().click();
				verifyTextPresent(gamePlayTable2.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable2.getPlaceShowConfirmDialogYesButton().click();
			}else{
				gamePlayTable2.getSortButton().click();
				gamePlayTable.getSortButton().click();
				gamePlayTable.getOpenCard().click();
				//gamePlayTable.tapOnOpenCard();
			/*	gamePlayTable.countCards();*/
				Thread.sleep(3000);
				gamePlayTable.getCard("12").click();
				CustomMethods.waitForElementPresent(gamePlayTable.getDiscardButton(), 5);
				gamePlayTable.getShowButton().click();
				verifyTextPresent(gamePlayTable.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable.getPlaceShowConfirmDialogYesButton().click();
			}
			meldCardsPopUpPlayer1.getMeldAll().click();
			meldCardsPopUpPlayer1.getSendCardsButton().click();
			meldCardsPopUpPlayer2.getMeldAll().click();
			meldCardsPopUpPlayer2.getSendCardsButton().click();
			ResultsWindow resultsWindow1 = new ResultsWindow(driver);
			ResultsWindow resultsWindow2 = new ResultsWindow(player2Driver);
			Thread.sleep(3000);
			//verifyPresent(resultsWindow1.getResultsView(), "Results view");
			//verifyPresent(resultsWindow2.getResultsView(), "Results view");
			if(playerWon.equals("player1")){
				verifyTextPresent(resultsWindow1.getWinLossDialogBoxMessage(),"Congratulations. You have won the game.");
				verifyTextPresent(resultsWindow2.getWinLossDialogBoxMessage(),"Sorry. You have been eliminated from the game.");
				resultsWindow1.getWinLossDialogBoxOkButton().click();
				resultsWindow2.getWinLossDialogBoxOkButton().click();
			}else{
				verifyTextPresent(resultsWindow2.getWinLossDialogBoxMessage(),"Congratulations. You have won the game.");
				verifyTextPresent(resultsWindow1.getWinLossDialogBoxMessage(),"Sorry. You have been eliminated from the game.");
				
			}
			resultsWindow1.getWinLossDialogBoxOkButton().click();
			resultsWindow2.getWinLossDialogBoxOkButton().click();
			JoinAnotherGameDialogBox joinAnotherGameDialogBox1 = new JoinAnotherGameDialogBox(driver);
			JoinAnotherGameDialogBox joinAnotherGameDialogBox2 = new JoinAnotherGameDialogBox(player2Driver);
			Thread.sleep(1000);
			verifyText(joinAnotherGameDialogBox2.getJoinAnotherGameAlertMessage().getText(),
					ReadDataFromProps.props.getProperty("game.table.join.another.real.chip"));
			joinAnotherGameDialogBox2.getJoinAnotherGameAlertYes().click();
			verifyPresent(gamePlayTable2.getLeaveTableButton(),"Game table");
			
			verifyText(joinAnotherGameDialogBox1.getJoinAnotherGameAlertMessage().getText(),
					ReadDataFromProps.props.getProperty("game.table.join.another.real.chip"));
			joinAnotherGameDialogBox1.getJoinAnotherGameAlertNo().click();
			verifyPresent(lobbyImplPage.getgamesTabIcon(),"Lobby Page");
			
	}
	
	@SuppressWarnings("static-access")
	@Test(description = "Re-shuffle", priority=4)
	public void TS_GamePlay_06() throws InterruptedException, IOException {
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		gamePlayTable.navigateToGameType(Game.BestO2);
		
				//Player 01 join table
				gamePlayTable.joinGameTable("5");
				gamePlayTable.getJoinTableYesButton().click();
				CustomMethods.waitForElementPresent(gamePlayTable.getWaitOtherPlayerTojoin(), 5);
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyPresent(gamePlayTable.getChatOption(), "Chat option");
				CustomMethods.verifyNotEnabled(gamePlayTable.getChatOption(), "Chat option"); 
		//Player 2 session start	
		this.player2Driver = cm.launchNewSession();
		GamePlayPlayer2ImplPage gamePlayTable2 = new GamePlayPlayer2ImplPage(player2Driver);
		gamePlayTable2.navigateToGames();
		CustomMethods.waitForElementPresent(gamePlayTable2.getGameType() , 4);
		gamePlayTable2.navigateToGameType(Game.BestO2);
		//Player 02 join table
		gamePlayTable2.joinGameTable("5");
		gamePlayTable2.getJoinTableYesButton().click();
		
		verifyNotPresent(gamePlayTable2.getWaitOtherPlayerTojoin(),"Please wait while other players join the table",3);
		cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
		CustomMethods.verifyEnabled(gamePlayTable.getChatOption(), "Chat option");
		MeldCardsPopUp meldCardsPopUpPlayer1 = new MeldCardsPopUp(driver);
		MeldCardsPopUp meldCardsPopUpPlayer2 = new MeldCardsPopUp(player2Driver);
		ReShufleDeckDialogeBox reShufleDeckDialogeBox1= new ReShufleDeckDialogeBox(driver);
		ReShufleDeckDialogeBox reShufleDeckDialogeBox2= new ReShufleDeckDialogeBox(player2Driver);
		String playerWon = null;
		Thread.sleep(3000);
		//System.out.println("player1 hand timer: " + gamePlayTable.getHandTimerPulse().getText());
		/*if(cm.isElementPresent(gamePlayTable.getHandTimerPulse())){
			gamePlayTable.getSortButton().click();
			gamePlayTable2.getSortButton().click();
			for(int i=1;i<=40;i++){
				Thread.sleep(1000);
				System.out.println(i);
				//gamePlayTable.getDeckCard().click();
				gamePlayTable.tapDeckCardButton();
				//Thread.sleep(1000);
				gamePlayTable.getCard("10").click();
				//gamePlayTable.getDiscardButton().click();
				gamePlayTable.tapDiscardButtton();
				Thread.sleep(1000);
			//	gamePlayTable2.getDeckCard().click();
				gamePlayTable2.tapDeckCardButton();
				Thread.sleep(1000);
				gamePlayTable2.getCard("10").click();
				//gamePlayTable2.getDiscardButton().click();
				gamePlayTable2.tapDiscardButtton();
				if(i>=75 && cm.isElementPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage())){
					verifyPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage(), "loc");
					reShufleDeckDialogeBox1.getDeckReshufflingAlertOkButton().click();
					reShufleDeckDialogeBox2.getDeckReshufflingAlertOkButton().click();
					
				}
				playerWon = "player1";
			}
		}else{
				gamePlayTable2.getSortButton().click();
				gamePlayTable.getSortButton().click();
			for(int i=1;i<=81;i++){
				Thread.sleep(1000);
				System.out.println(i);
				//gamePlayTable2.getDeckCard().click();
				gamePlayTable2.tapDeckCardButton();
				Thread.sleep(1000);
				gamePlayTable2.getCard("10").click();
				//gamePlayTable2.getDiscardButton().click();
				gamePlayTable2.tapDiscardButtton();
				Thread.sleep(1000);
				//gamePlayTable.getDeckCard().click();
				gamePlayTable.tapDeckCardButton();
				Thread.sleep(1000);
				gamePlayTable.getCard("10").click();
				//gamePlayTable.getDiscardButton().click();
				gamePlayTable.tapDiscardButtton();
				 
				if(i>=75 && cm.isElementPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage())){
					verifyPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage(), "loc");
					reShufleDeckDialogeBox1.getDeckReshufflingAlertOkButton().click();
					reShufleDeckDialogeBox2.getDeckReshufflingAlertOkButton().click();
				}
				playerWon = "player2";
			}
		}*/
			
		if(cm.isElementPresent(gamePlayTable.getHandTimerPulse())){
			gamePlayTable.getSortButton().click();
			gamePlayTable2.getSortButton().click();
			for(int i=1;i<=40;i++){
				Thread.sleep(1000);
				System.out.println(i);
				//gamePlayTable.getDeckCard().click();
				gamePlayTable.tapDeckCardButton();
				if(i>=39 && cm.isElementPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage())){
					verifyPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage(), "Re shuffle dialog in player 1");
					verifyPresent(reShufleDeckDialogeBox2.getDeckReshufflingAlertMessage(), "Re shuffle dialog in player 2");
					reShufleDeckDialogeBox1.getDeckReshufflingAlertOkButton().click();
					reShufleDeckDialogeBox2.getDeckReshufflingAlertOkButton().click();
				}
				//Thread.sleep(1000);
				while(!(gamePlayTable.cardsCount()==14)){
					gamePlayTable.tapDeckCardButton();
				}
				gamePlayTable.getCard("10").click();
				//gamePlayTable.getDiscardButton().click();
				gamePlayTable.tapDiscardButtton();
				Thread.sleep(1000);
				//gamePlayTable2.getDeckCard().click();
				gamePlayTable2.tapDeckCardButton();
				Thread.sleep(1000);
				while(!(gamePlayTable2.cardsCount()==14)){
					gamePlayTable2.tapDeckCardButton();
				}
				gamePlayTable2.getCard("10").click();
				//gamePlayTable2.getDiscardButton().click();
				gamePlayTable2.tapDiscardButtton();
				playerWon = "player1";
			}
			
				gamePlayTable.getDeckCard().click();
				while(!(gamePlayTable.cardsCount()==14)){
					gamePlayTable.tapDeckCardButton();
				}
				gamePlayTable.getCard("9").click();
				gamePlayTable.getShowButton().click();
				verifyTextPresent(gamePlayTable.getPlaceShowConfirmationDialogBoxMessage(),
						ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
				gamePlayTable.getPlaceShowConfirmDialogYesButton().click();
			
		}else{
				gamePlayTable2.getSortButton().click();
				gamePlayTable.getSortButton().click();
			for(int i=1;i<=40;i++){
				Thread.sleep(1000);
				System.out.println(i);
				//gamePlayTable2.getDeckCard().click();
				gamePlayTable2.tapDeckCardButton();
				if(i>=39 && cm.isElementPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage())){
					verifyPresent(reShufleDeckDialogeBox2.getDeckReshufflingAlertMessage(), "Re shuffle dialog in player 2");
					verifyPresent(reShufleDeckDialogeBox1.getDeckReshufflingAlertMessage(), "Re shuffle dialog in player 1");
					reShufleDeckDialogeBox1.getDeckReshufflingAlertOkButton().click();
					reShufleDeckDialogeBox2.getDeckReshufflingAlertOkButton().click();
				}
				
			//	Thread.sleep(1000);
				while(!(gamePlayTable2.cardsCount()==14)){
					gamePlayTable2.tapDeckCardButton();
				}
				gamePlayTable2.getCard("10").click();
				//gamePlayTable2.getDiscardButton().click();
				gamePlayTable2.tapDiscardButtton();
				Thread.sleep(1000);
				//gamePlayTable.getDeckCard().click();
				gamePlayTable.tapDeckCardButton();
				Thread.sleep(1000);
				while(!(gamePlayTable.cardsCount()==14)){
					gamePlayTable.tapDeckCardButton();
				}
				gamePlayTable.getCard("10").click();
				//gamePlayTable.getDiscardButton().click();
				gamePlayTable.tapDiscardButtton();
				playerWon = "player2";
			}
			
			gamePlayTable2.getDeckCard().click();
			while(!(gamePlayTable2.cardsCount()==14)){
				gamePlayTable2.tapDeckCardButton();
			}
			gamePlayTable2.getCard("9").click();
			gamePlayTable2.getShowButton().click();
			verifyTextPresent(gamePlayTable2.getPlaceShowConfirmationDialogBoxMessage(),
					ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
			
			gamePlayTable2.getPlaceShowConfirmDialogYesButton().click();
		}
		
		meldCardsPopUpPlayer1.getMeldAll().click();
		meldCardsPopUpPlayer1.getSendCardsButton().click();
		meldCardsPopUpPlayer2.getMeldAll().click();
		meldCardsPopUpPlayer2.getSendCardsButton().click();
		
		cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
		CustomMethods.waitForElementPresent(gamePlayTable.getLeaveTableButton(), 20);
		Thread.sleep(5000);
		
		gamePlayTable.getLeaveTableButton().click();
		gamePlayTable.getLeaveTableOption().click();
		gamePlayTable.getLeaveToLobbyAlertOkButton().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
			
	}
	
	
	@Test(description = "BOX & Pool Games - Checking for Discards, last hand, scoreboard, etc. (only checking whether the window is accessible or not).", priority=7)
	public void TS_GamePlay_07() throws InterruptedException, IOException {
		
	
		System.out.println(System.getProperty("deviceName")+ "asjibahisof");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getgamesTabIcon().click();
		
		GamePlayTableImplPage gamePlayTable = new GamePlayTableImplPage(driver);
		gamePlayTable.navigateToGameType(Game.BestO2);
		
				//Player 01 join table
				gamePlayTable.joinGameTable("5");
				gamePlayTable.getJoinTableYesButton().click();
				CustomMethods.waitForElementPresent(gamePlayTable.getWaitOtherPlayerTojoin(), 5);
				verifyTextPresent(gamePlayTable.getWaitOtherPlayerTojoin(),"Please wait while other players join the table");
				verifyPresent(gamePlayTable.getChatOption(), "Chat option");
				CustomMethods.verifyNotEnabled(gamePlayTable.getChatOption(), "Chat option"); 
		//Player 2 session start	
		this.player2Driver = cm.launchNewSession();
		GamePlayPlayer2ImplPage gamePlayTable2 = new GamePlayPlayer2ImplPage(player2Driver);
		gamePlayTable2.navigateToGames();
		CustomMethods.waitForElementPresent(gamePlayTable2.getGameType() , 4);
		gamePlayTable2.navigateToGameType(Game.BestO2);
		//Player 02 join table
		gamePlayTable2.joinGameTable("5");
		gamePlayTable2.getJoinTableYesButton().click();
		
		verifyNotPresent(gamePlayTable2.getWaitOtherPlayerTojoin(),"Please wait while other players join the table",3);
		cm.waitForElementPresent(gamePlayTable.getSortButton(), 30);
		CustomMethods.verifyEnabled(gamePlayTable.getChatOption(), "Chat option");
		MeldCardsPopUp meldCardsPopUpPlayer1 = new MeldCardsPopUp(driver);
		MeldCardsPopUp meldCardsPopUpPlayer2 = new MeldCardsPopUp(player2Driver);
		ReShufleDeckDialogeBox reShufleDeckDialogeBox1= new ReShufleDeckDialogeBox(driver);
		ReShufleDeckDialogeBox reShufleDeckDialogeBox2= new ReShufleDeckDialogeBox(player2Driver);
		String playerWon = null;
		Thread.sleep(3000);
		
		if(cm.isElementPresent(gamePlayTable.getHandTimerPulse())){
			////First Round//////////
			gamePlayTable.getSortButton().click();
			gamePlayTable2.getSortButton().click();
			gamePlayTable.tapDeckCardButton();
			while(!(gamePlayTable.cardsCount()==14)){
				gamePlayTable.tapDeckCardButton();
			}
			gamePlayTable.getCard("10").click();
			//gamePlayTable.getDiscardButton().click();
			gamePlayTable.tapDiscardButtton();
			Thread.sleep(1000);
			//gamePlayTable2.getDeckCard().click();
			gamePlayTable2.tapDeckCardButton();
			Thread.sleep(1000);
			while(!(gamePlayTable2.cardsCount()==14)){
				gamePlayTable2.tapDeckCardButton();
			}
			gamePlayTable2.getCard("10").click();
			//gamePlayTable2.getDiscardButton().click();
			gamePlayTable2.tapDiscardButtton();
			/////Second Round///////////
			gamePlayTable.tapDeckCardButton();
			while(!(gamePlayTable.cardsCount()==14)){
				gamePlayTable.tapDeckCardButton();
			}
			gamePlayTable.getCard("10").click();
			//gamePlayTable.getDiscardButton().click();
			gamePlayTable.tapDiscardButtton();
			Thread.sleep(1000);
			//gamePlayTable2.getDeckCard().click();
			gamePlayTable2.tapDeckCardButton();
			Thread.sleep(1000);
			while(!(gamePlayTable2.cardsCount()==14)){
				gamePlayTable2.tapDeckCardButton();
			}
			gamePlayTable2.getCard("10").click();
			//gamePlayTable2.getDiscardButton().click();
			gamePlayTable2.tapDiscardButtton();
			/////Third Round///////
			gamePlayTable.tapDeckCardButton();
			while(!(gamePlayTable.cardsCount()==14)){
				gamePlayTable.tapDeckCardButton();
			}
			gamePlayTable.getCard("10").click();
			//gamePlayTable.getDiscardButton().click();
			gamePlayTable.tapDiscardButtton();
			Thread.sleep(1000);
			//gamePlayTable2.getDeckCard().click();
			gamePlayTable2.tapDeckCardButton();
			Thread.sleep(1000);
			while(!(gamePlayTable2.cardsCount()==14)){
				gamePlayTable2.tapDeckCardButton();
			}
			gamePlayTable2.getCard("10").click();
			//gamePlayTable2.getDiscardButton().click();
			gamePlayTable2.tapDiscardButtton();
			
			
		}else{
			//////////First Round/////////////
			gamePlayTable2.getSortButton().click();
			gamePlayTable.getSortButton().click();
			gamePlayTable2.tapDeckCardButton();
			while(!(gamePlayTable2.cardsCount()==14)){
				gamePlayTable2.tapDeckCardButton();
			}
			gamePlayTable2.getCard("10").click();
			//gamePlayTable2.getDiscardButton().click();
			gamePlayTable2.tapDiscardButtton();
			Thread.sleep(1000);
			//gamePlayTable.getDeckCard().click();
			gamePlayTable.tapDeckCardButton();
			Thread.sleep(1000);
			while(!(gamePlayTable.cardsCount()==14)){
				gamePlayTable.tapDeckCardButton();
			}
			gamePlayTable.getCard("10").click();
			//gamePlayTable.getDiscardButton().click();
			gamePlayTable.tapDiscardButtton();
			/////////Second Round/////////////////
			gamePlayTable2.tapDeckCardButton();
			while(!(gamePlayTable2.cardsCount()==14)){
				gamePlayTable2.tapDeckCardButton();
			}
			gamePlayTable2.getCard("10").click();
			//gamePlayTable2.getDiscardButton().click();
			gamePlayTable2.tapDiscardButtton();
			Thread.sleep(1000);
			//gamePlayTable.getDeckCard().click();
			gamePlayTable.tapDeckCardButton();
			Thread.sleep(1000);
			while(!(gamePlayTable.cardsCount()==14)){
				gamePlayTable.tapDeckCardButton();
			}
			gamePlayTable.getCard("10").click();
			//gamePlayTable.getDiscardButton().click();
			gamePlayTable.tapDiscardButtton();
			/////////Third Round/////////////////
				gamePlayTable2.tapDeckCardButton();
				while(!(gamePlayTable2.cardsCount()==14)){
					gamePlayTable2.tapDeckCardButton();
				}
				gamePlayTable2.getCard("10").click();
				//gamePlayTable2.getDiscardButton().click();
				gamePlayTable2.tapDiscardButtton();
				Thread.sleep(1000);
				//gamePlayTable.getDeckCard().click();
				gamePlayTable.tapDeckCardButton();
				Thread.sleep(1000);
				while(!(gamePlayTable.cardsCount()==14)){
					gamePlayTable.tapDeckCardButton();
				}
				gamePlayTable.getCard("10").click();
				//gamePlayTable.getDiscardButton().click();
				gamePlayTable.tapDiscardButtton();
			
		}
		
		Thread.sleep(4000);

		
		gamePlayTable.getDiscardWindowButton().click();
		Thread.sleep(3000);
		for(int i =0;i<=2;i++)
		{
			String xpath = "//android.widget.ImageView[contains(@index,'"+i+"')]";
		WebElement ele = driver.findElement(By.xpath(xpath));
		verifyPresent(ele,(i+1)+" Card");
		}
		
		verifyPresent(gamePlayTable.getDiscardTabButton(), "Discard Tab in discards window");
		verifyPresent(gamePlayTable.getLastHandTabButton(), "Last Hand Tab in discards window");
		verifyPresent(gamePlayTable.getScoreBoardTabButton(), "Score Board Tab in discards window");
		gamePlayTable.getDiscardWindowCloseButton().click();
		if(CustomMethods.isElementPresent(gamePlayTable.getHandTimerPulse())){
		
			gamePlayTable.tapDeckCardButton();
			while(!(gamePlayTable.cardsCount()==14)){
				gamePlayTable.tapDeckCardButton();
			}
			gamePlayTable.getCard("9").click();
			gamePlayTable.getShowButton().click();
			verifyTextPresent(gamePlayTable.getPlaceShowConfirmationDialogBoxMessage(),
					ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
			gamePlayTable.getPlaceShowConfirmDialogYesButton().click();
			playerWon = "player2";
		}
		else 
		{
			gamePlayTable2.tapDeckCardButton();
			while(!(gamePlayTable2.cardsCount()==14)){
				gamePlayTable2.tapDeckCardButton();
			}
			gamePlayTable2.getCard("9").click();
			gamePlayTable2.getShowButton().click();
			verifyTextPresent(gamePlayTable2.getPlaceShowConfirmationDialogBoxMessage(),
					ReadDataFromProps.props.getProperty("game.table.place.show.confirmation.message"));
			
			gamePlayTable2.getPlaceShowConfirmDialogYesButton().click();
			playerWon = "player1";
		}
		Thread.sleep(3000);
		meldCardsPopUpPlayer1.getMeldAll().click();
		meldCardsPopUpPlayer1.getSendCardsButton().click();
		meldCardsPopUpPlayer2.getMeldAll().click();
		meldCardsPopUpPlayer2.getSendCardsButton().click();
		
		CustomMethods.waitForElementPresent(gamePlayTable.getSortButton(), 30);	
		CustomMethods.waitForElementPresent(gamePlayTable.getLeaveTableButton(), 20);
		Thread.sleep(5000);
		gamePlayTable.getDiscardWindowButton().click();
		Thread.sleep(3000);
		gamePlayTable.getLastHandTabButton().click();
		
		List<WebElement> tableElement = driver.findElements(By.xpath("//android.widget.TableLayout[contains(@resource-id,'lasthandTL')]/android.widget.TableRow"));
		System.out.println(tableElement.size());
		
		for(int i =0; i <tableElement.size();i++) {
			
			if(i==0)
			{
				WebElement firstRow = tableElement.get(i);
				List<WebElement> firstRowElements = firstRow.findElements(By.xpath("//android.widget.TextView"));
				int j=1;
				for(WebElement ele : firstRowElements)
				{
					switch(j)
					{
					case 1: verifyText(ele.getText(), "Name");
					break;
					case 2: verifyText(ele.getText(), "Result");
					break;
					case 3: verifyText(ele.getText(), "Cards");
					break;
					case 4: verifyText(ele.getText(), "Game Score");
					break;
					case 5: verifyText(ele.getText(), "Total Score");
					break;
					
					}
					j++;
				}
				
			}
			else
			{
				
				
				
				
			}
			
			
			
			
		}
		
		
		
		gamePlayTable.getDiscardWindowCloseButton().click();
		Thread.sleep(3000);
		
		
		
		
		
		gamePlayTable.getLeaveTableButton().click();
		gamePlayTable.getLeaveTableOption().click();
		gamePlayTable.getLeaveToLobbyAlertOkButton().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
	}
	
	
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {

		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			logger.log(LogStatus.FAIL, result.getThrowable());
			/*System.out.println(Thread.currentThread().getStackTrace());
			boolean abc= Thread.currentThread().getStackTrace().toString().contains("GamePlayPlayer2ImplPage");*/
			//System.out.println("boolean is:" + abc);
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			
			try{
				Thread.sleep(2000);
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),player2Driver)));
				
			}catch(Exception e){
				System.out.println("no 2nd player session");
			}
			
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver)driver).resetApp();
		try{
			player2Driver.quit();
		}catch(Exception e){
			System.out.println("no 2nd player session");
		}
		
		
	}
	
	
	
	
	
}
