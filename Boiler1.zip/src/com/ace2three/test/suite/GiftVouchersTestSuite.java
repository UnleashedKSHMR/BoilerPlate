package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.component.pages.AppOnlyForRealChipsDialogBox;
import com.ace2three.impl.pages.GiftVouchersImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.MyProfileImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class GiftVouchersTestSuite extends BaseTestSuite{
DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
	Date date = new Date();
	ReadDataFromProps ReadProps;
	WebDriver desktopDriver;
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		Test test = method.getAnnotation(Test.class);
		
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		ReadProps= new ReadDataFromProps();
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
	}

	@Test(description = "Check whether gift vouchers option is displayed under wrench menu or not", priority=1)
	public void TS_Sanity__Gift_Vouchers_01() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		GiftVouchersImplPage giftVouchersPage = new GiftVouchersImplPage(driver);
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.getHamburgerMenu().click();
		verifyPresent(lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers"), "Gift Vouchers option under wrench menu");
		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Gift Vouchers')]")).click();
		//////////////////
		//verifyText(giftVouchersPage.getClaimYourGiftText().getText(), "Claim your Gift");
		verifyPresent(giftVouchersPage.getGiftVoucherCodeApplyButton(), "Apply Button");
		giftVouchersPage.getGiftVoucherCodeInputField().sendKeys("asf63819645asdfsd");
		giftVouchersPage.getGiftVoucherCodeApplyButton().click();
		System.out.println(giftVouchersPage.getGiftVoucherErrorMessage().getText());
		verifyText(giftVouchersPage.getGiftVoucherErrorMessage().getText(), "Voucher code incorrect. Please try entering it again. \nIf the problem persists contact us at info@ace2three.com with voucher details.", "Voucher Code Incorrect");
		giftVouchersPage.getGiftVoucherCodeInputField().clear();
		giftVouchersPage.getGiftVoucherCodeApplyButton().click();
		verifyText(giftVouchersPage.getGiftVoucherErrorMessage().getText(), "Please enter valid voucher code");
		giftVouchersPage.getGiftVoucherCodeInputField().sendKeys("!@@#$#%$%$^^^&&*(()|\"?:><}{)");
		giftVouchersPage.getGiftVoucherCodeApplyButton().click();
		verifyText(giftVouchersPage.getGiftVoucherErrorMessage().getText(), "Please enter valid voucher code");
		CustomMethods.disconnectAndReconnect();
		
	}
	
	@Test(description = "Check whether all the user able to access gift vouchers option or not", priority=2)
	public void TS_Sanity__Gift_Vouchers_02() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		/*LobbyImplPage implPage= new LobbyImplPage(); 
		implPage.getHamburgerMenu().click();	
		implPage.getHamburgerMenuItem(hamburgerMenuItems.Logout,null).click();
		verifyPresent(implPage.getLogoutAlertPopupMessage(), "logout alert popup");
		implPage.getLogoutAlertPopupYesButton().click();*/

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		logger.log(LogStatus.INFO, "Logging with premium user");
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.getHamburgerMenu().click();
		//verifyPresent(lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers"), "Gift Vouchers option under wrench menu");
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers").click();
		GiftVouchersImplPage giftVouchersPage =new GiftVouchersImplPage(driver);
		CustomMethods.waitForElementPresent(giftVouchersPage.getEncashVoucherHeader(), 10);
			
				verifyPresent(giftVouchersPage.getEncashVoucherHeader(),"Gift Voucher page");
				verifyTextPresent(giftVouchersPage.getEncashVoucherHeader(), "Encash Voucher");
				
				if(CustomMethods.isElementPresent(giftVouchersPage.getEncashVoucherHeader())){
					logger.log(LogStatus.PASS, "Premium user can able to access Gift Voucher page");
				}else{
					logger.log(LogStatus.FAIL, "Premium user cannot able to access Gift Voucher page"+ logger.addScreenCapture(takeScreenShot("gift voucher")));
				}
			
		lobbyImplPage.getHamburgerMenu().click();	
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout,null).click();
		verifyPresent(lobbyImplPage.getLogoutAlertPopupMessage(), "logout alert popup");
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		
		// Logging in with pseudo account
		logger.log(LogStatus.INFO, "Logging with pseudo user");
		launchImplPage.getUsernameField().sendKeys(ReadDataFromProps.props.getProperty("pseudo.user"));
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		lobbyImplPage.verifyPostLaunchBanners();
	
			AppOnlyForRealChipsDialogBox appOnlyForRealChipsDialogBox= new AppOnlyForRealChipsDialogBox(driver);
		
			if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
			}
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		lobbyImplPage.getHamburgerMenu().click();
		//verifyPresent(lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers"), "Gift Vouchers option under wrench menu");
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers").click();
		CustomMethods.waitForElementPresent(giftVouchersPage.getGiftVoucherHeader(), 10);
				verifyPresent(giftVouchersPage.getGiftVoucherHeader(),"Gift Voucher page");
				verifyTextPresent(giftVouchersPage.getGiftVoucherHeader(), "Gift Voucher");
		
				lobbyImplPage.getHamburgerMenu().click();	
				lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout,null).click();
				verifyPresent(lobbyImplPage.getLogoutAlertPopupMessage(), "logout alert popup");
				lobbyImplPage.getLogoutAlertPopupYesButton().click();
					
		// Logging in with regular user account
		logger.log(LogStatus.INFO, "Logging with regular user");
		launchImplPage.getUsernameField().sendKeys(ReadDataFromProps.props.getProperty("regular.user"));
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
	
		lobbyImplPage.verifyPostLaunchBanners();
	
		//driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]")).click();
		//lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
	
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
		appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
		appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
		}
		
		lobbyImplPage.getHamburgerMenu().click();
		//verifyPresent(lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers"), "Gift Vouchers option under wrench menu");
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers").click();
		CustomMethods.waitForElementPresent(giftVouchersPage.getGiftVoucherHeader(), 10);
				verifyPresent(giftVouchersPage.getGiftVoucherHeader(),"Gift Voucher page");
				verifyTextPresent(giftVouchersPage.getGiftVoucherHeader(), "Gift Voucher");
			
	}
	
	@Test(description = "Check whether user able to see apply voucher code edit field or not ", priority=4)
	public void TS_Sanity__Gift_Vouchers_04() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		logger.log(LogStatus.INFO, "Logging with premium user");
		launchImplPage.getUsernameField().sendKeys(ReadDataFromProps.props.getProperty("gift.voucher.premium.user"));
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers").click();
		GiftVouchersImplPage giftVouchersPage =new GiftVouchersImplPage(driver);
			verifyPresent(giftVouchersPage.getEncashVoucherHeader(),"Gift Voucher page");
			
			String realChipsBefore = lobbyImplPage.getNoOfRealChipsCount().getText().toString();
			System.out.println(realChipsBefore);
			String[] realChipsBefore1 = realChipsBefore.split("\\.");
			System.out.println(realChipsBefore1 + "some");
			int beforeChips= Integer.parseInt(realChipsBefore1[0]);
			System.out.println(beforeChips + "before");
			giftVouchersPage.getGiftVoucherCodeInputField().sendKeys(ReadDataFromProps.props.getProperty("gift.voucher"));
			CustomMethods.disconnectAndReconnect();
			giftVouchersPage.getGiftVoucherCodeApplyButton().click();
			verifyPresent(giftVouchersPage.getGiftVoucherSuccessMessage(), "Gift Voucher Successfully claimed message");
			verifyText(giftVouchersPage.getGiftVoucherSuccessMessage().getText(), "Gift Voucher Successfully claimed.\n50 real chips successfully added to your account.","Gift Voucher Successfully claimed");
			String realChipsAfter = lobbyImplPage.getNoOfRealChipsCount().getText();
			String[] realChipsAfter1 = realChipsAfter.split("\\.");
			int afterChips= Integer.parseInt(realChipsAfter1[0]);
			System.out.println(realChipsAfter+ " : afterchips");
			int addedChips = afterChips-beforeChips;
			System.out.println("added chips"+ addedChips);
			
			if(addedChips==50 && afterChips!=beforeChips){
				logger.log(LogStatus.PASS, "Amount has added into user wallet & Correct amount has added");
			}if(addedChips!=50 && afterChips!=beforeChips){
				logger.log(LogStatus.PASS, "Amount has added into user wallet but InCorrect amount of Real chips has added");
			}if(afterChips==beforeChips){
				logger.log(LogStatus.FAIL, "Amount has not added into user wallet"+ logger.addScreenCapture(takeScreenShot("")));
			}
	}
	
	@Test(description = "Check whether proper alert message is displaying or not on entering invalid mobile number in mobile number field for the user who hasn't verified mobile number.", priority=5)
	public void TS_Sanity__Gift_Vouchers_05() throws IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		String userName = launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Voucher").click();
		GiftVouchersImplPage giftVouchersImplPage = new GiftVouchersImplPage(driver);
		verifyPresent(giftVouchersImplPage.getEmailInputField(),"Email ID Field");
		verifyPresent(giftVouchersImplPage.getPhoneNoinputButton(), "Mobile Number Field");
		verifyPresent(giftVouchersImplPage.getVerifyEmailAndMobileText(), "Verify Email and Mobile Number Text");
		verifyText(giftVouchersImplPage.getVerifyEmailAndMobileText().getText(), "Please verify your Email ID & Mobile number in order to apply voucher code");
		giftVouchersImplPage.getEmailInputField().clear();
		giftVouchersImplPage.getEmailVerifyButton().click();
		verifyText(giftVouchersImplPage.getInvalidEmailErrorMessage().getText(), "Please enter email ID");
		giftVouchersImplPage.getEmailInputField().sendKeys("asfdsa@.com");
		giftVouchersImplPage.getEmailVerifyButton().click();
		verifyText(giftVouchersImplPage.getInvalidEmailErrorMessage().getText(), "Please enter valid email ID");
		giftVouchersImplPage.getPhoneNoVerifyButton().click();
		verifyText(giftVouchersImplPage.getInvalidMobileErrorMessage().getText(), "Please enter mobile number");
		giftVouchersImplPage.getPhoneNoinputButton().sendKeys("16784698527698");
		giftVouchersImplPage.getPhoneNoVerifyButton().click();
		CustomMethods.waitForElementPresent(giftVouchersImplPage.getInvalidMobileErrorMessage(),5);
		verifyText(giftVouchersImplPage.getInvalidMobileErrorMessage().getText(), "Please enter valid mobile number");
		giftVouchersImplPage.getPhoneNoinputButton().clear();
		giftVouchersImplPage.getPhoneNoinputButton().sendKeys("!@@$#^%^(*)&<>:\"");
		giftVouchersImplPage.getPhoneNoVerifyButton().click();
		verifyText(giftVouchersImplPage.getInvalidMobileErrorMessage().getText(), "Please enter mobile number");
		giftVouchersImplPage.getEmailInputField().clear();
		giftVouchersImplPage.getEmailInputField().sendKeys(userName+"df@asfasdf.com");
		giftVouchersImplPage.getEmailVerifyButton().click();
		verifyText(giftVouchersImplPage.getActivationLinkSentMessage().getText(),"An activation link has been sent to your E-Mail");
		CustomMethods.verifyNotEnabled(giftVouchersImplPage.getEmailVerifyButton(), "Email Verify Button");
	}
	
	
	@Test(description = "User specific voucher should be verified - targeted"
			+ "User specific voucher should not be claimed by other user than targeted user"
			+ "check for SUSA kind of gift voucher", priority=6)
	public void TS_Sanity__Gift_Vouchers_06() throws IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.getLoginButon().click();
		logger.log(LogStatus.INFO, "Logging with premium user");
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers").click();
		GiftVouchersImplPage giftVouchersPage =new GiftVouchersImplPage(driver);
		verifyPresent(giftVouchersPage.getEncashVoucherHeader(),"Gift Voucher page");
		giftVouchersPage.getGiftVoucherCodeInputField().sendKeys(ReadDataFromProps.props.getProperty("targeted.gift.voucher"));
		giftVouchersPage.getGiftVoucherCodeApplyButton().click();
		verifyText(giftVouchersPage.getGiftVoucherErrorMessage().getText(),"Sorry, this Gift Voucher is linked to a specific player and can be claimed only through that account.\n If you think this is incorrect please contact us at info@ace2three.com with voucher details." );
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout,null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		verifyPresent(launchImplPage.getUsernameField(), "Login Page has displayed");
		logger.log(LogStatus.INFO, "UnMatched targeted user has logged out");
		launchImplPage.getUsernameField().clear();
		launchImplPage.getUsernameField().sendKeys(ReadDataFromProps.props.getProperty("targeted.gift.voucher.userid"));
		launchImplPage.getpasswordField().sendKeys(ReadDataFromProps.props.getProperty("targeted.gift.voucher.user.password"));
		launchImplPage.getLoginClickButton().click();

		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers").click();
		verifyPresent(giftVouchersPage.getEncashVoucherHeader(),"Gift Voucher page");
		giftVouchersPage.getGiftVoucherCodeInputField().sendKeys(ReadDataFromProps.props.getProperty("targeted.gift.voucher"));
		giftVouchersPage.getGiftVoucherCodeApplyButton().click();
		verifyPresent(giftVouchersPage.getGiftVoucherSuccessMessage(), "Gift Voucher Successfully claimed message");
		verifyText(giftVouchersPage.getGiftVoucherSuccessMessage().getText(), "Gift Voucher Successfully claimed.\n50 real chips successfully added to your account.","Success Message");
	}
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
			logger.log(LogStatus.PASS, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver) driver).resetApp();
	}
	/*public static void main(String args[]){
		
		String abc="130617.95";
		String[] realChipsBefore1 = abc.split("\\.");
		System.out.println(realChipsBefore1 + "some");
		int beforeChips= Integer.parseInt(realChipsBefore1[0]);
		System.out.println(beforeChips);
		
	}*/
}
