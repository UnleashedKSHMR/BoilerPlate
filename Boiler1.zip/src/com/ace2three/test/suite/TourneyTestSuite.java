package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.ListUtils;
import org.apache.tools.ant.types.resources.comparators.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.GetPageSource;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.component.pages.TourneyDialogBox;
import com.ace2three.component.pages.TourneyDialogBox.TourneyDetailType;
import com.ace2three.impl.pages.GiftVouchersImplPage;
import com.ace2three.impl.pages.KycImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.TourneyImplPage;
import com.ace2three.impl.pages.TourneyImplPage.filterType;
import com.ace2three.impl.pages.TourneyImplPage.tourneyType;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.ace2three.utils.business.ReadVouchersFromExcel;
import com.ace2three.web.impl.pages.AdminImplPage;
import com.ace2three.web.impl.pages.TourneyAdminImplPage;
import com.ace2three.web.impl.pages.TourneyAdminImplPage.tourneyGiftVoucherType;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TourneyTestSuite extends BaseTestSuite{
	
	WebDriver desktopDriver;
	String gvTourneyID;
	ArrayList<String> gv;
	
	
	@BeforeMethod
	public void beforeMethos(Method method) {
		Test test = method.getAnnotation(Test.class);
		
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		
	}
	
	@Test(description = "Check whether registration count is updating dynamically or not,"
			+ "Check whether data is properly updated in Tlobby according to the data which is given while inserting tourneys"
			+ "Check if the tlobby is getting opened or not while tapping on the tourney in grid lobby",priority=1)
	public void TS_Tourney_01() throws InterruptedException, IOException{
		
		String cashTourneyName="AutoCHTourney";
		String freeRollTourneyName="AutoFRTourney";
		String specialTourneyName="AutoSPTourney";
		String knockOutTourneyName="AutoKOTourney";
		String acePointsTourneyName="AutoAPTourney";
		String beginnerTourneyName="AutoBGTourney";
		
		TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);

		Hashtable<String,Hashtable<String, String>> cashTourneyLevelDetails =tourneyImplPage.getCashTourneyDetails();
		Hashtable<String,Hashtable<String, String>> freerollTourneyLevelDetails =tourneyImplPage.getFreerollTourneyDetails();
		Hashtable<String,Hashtable<String, String>> specialTourneyLevelDetails =tourneyImplPage.getSpecialTourneyDetails();
		Hashtable<String,Hashtable<String, String>> knockoutTourneyLevelDetails =tourneyImplPage.getKnockoutTourneyDetails();
		Hashtable<String,Hashtable<String, String>> acepointTourneyLevelDetails =tourneyImplPage.getAcePointsTourneyDetails();
		
		tourneyImplPage.createTourney(tourneyType.CASH, cashTourneyName);
		driver.getPageSource();
		tourneyImplPage.createTourney(tourneyType.FREEROLL, freeRollTourneyName);
		driver.getPageSource();
		tourneyImplPage.createTourney(tourneyType.SPECIAL, specialTourneyName);
		driver.getPageSource();
		tourneyImplPage.createTourney(tourneyType.KNOCKOUT, knockOutTourneyName);
		driver.getPageSource();
		tourneyImplPage.createTourney(tourneyType.ACEPOINTS, acePointsTourneyName);
		driver.getPageSource();
		tourneyImplPage.createTourney(tourneyType.BEGINNERTOURNEY, beginnerTourneyName);
		driver.getPageSource();
		TourneyAdminImplPage tourneyAdminImplPage = new TourneyAdminImplPage(desktopDriver);
		gvTourneyID = tourneyAdminImplPage.createTourneyAndGenerateGiftVoucher(tourneyGiftVoucherType.USEGIFTVOUCHER);
		ReadVouchersFromExcel readVouchersFromExcel = new ReadVouchersFromExcel();
		gv= readVouchersFromExcel.getVouchers();
		
		for(String s : gv)
		{
			System.out.println(s);
		}
		
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon(), 10);
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.getTourneyButton().click();
		CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney());
		
		tourneyImplPage.findTourney(acePointsTourneyName);
		tourneyImplPage.verifyAcePointsTourneyDetails(acepointTourneyLevelDetails);
		tourneyImplPage.getTLobbyCloseButton().click();
		tourneyImplPage.findTourney(specialTourneyName);
		tourneyImplPage.verifySpecialTourneyDetails(specialTourneyLevelDetails);
		tourneyImplPage.getTLobbyCloseButton().click();
		tourneyImplPage.findTourney(knockOutTourneyName);
		tourneyImplPage.verifyKnockOutTourneyDetails(knockoutTourneyLevelDetails);
		tourneyImplPage.getTLobbyCloseButton().click();
		tourneyImplPage.findTourney(freeRollTourneyName);
		tourneyImplPage.verifyFreeRollTourneyDetails(freerollTourneyLevelDetails);
		tourneyImplPage.getTLobbyCloseButton().click();
		tourneyImplPage.findTourney(cashTourneyName);
		tourneyImplPage.verifyCashTourneyDetails(cashTourneyLevelDetails);
		tourneyImplPage.getTLobbyCloseButton().click();
			 
		
		
		 tourneyImplPage.goToTourney("Acepoint Tourney");
		 tourneyImplPage.findTourney(acePointsTourneyName);	  
		 tourneyImplPage.verifyAcePointsTourneyDetails(acepointTourneyLevelDetails);
		 
		 tourneyImplPage.getTLobbyCloseButton().click();
		 tourneyImplPage.goToTourney("Special Tourney");
		 tourneyImplPage.findTourney(specialTourneyName);	 
	
		tourneyImplPage.verifySpecialTourneyDetails(specialTourneyLevelDetails);
		
		 tourneyImplPage.getTLobbyCloseButton().click();
		 tourneyImplPage.goToTourney("Knockout Tourney");
		 tourneyImplPage.findTourney(knockOutTourneyName);	 
		 tourneyImplPage.verifyKnockOutTourneyDetails(knockoutTourneyLevelDetails);
		 
		 tourneyImplPage.getTLobbyCloseButton().click();
		 tourneyImplPage.goToTourney("Freeroll Tourney");
		 tourneyImplPage.findTourney(freeRollTourneyName);	
		 tourneyImplPage.verifyFreeRollTourneyDetails(freerollTourneyLevelDetails);
		 
		tourneyImplPage.getTLobbyCloseButton().click();
		tourneyImplPage.goToTourney("Cash Tourney");
		tourneyImplPage.findTourney(cashTourneyName);	
		tourneyImplPage.verifyCashTourneyDetails(cashTourneyLevelDetails);
		 	
	}
	@Test(description = "Check whether filter in Tourney tab is working fine or not",priority=1)
	public void TS_Tourney_02() throws InterruptedException, IOException{
		
		TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon(), 10);
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.getTourneyButton().click();
		CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),5);
		tourneyImplPage.getFilterButton().click();
	
		
		
	
		/*tourneyImplPage.getApplyButton().click();
		CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),5);
		
		 List<WebElement> firstLowSwipeElements = tourneyImplPage.getLobbyEntryFields();
		 List<String> firstLow=tourneyImplPage.parseElements(firstLowSwipeElements);
		//((AndroidDriver)driver).swipe(545,1600 , 545, 630, 3000);
		WebElement ele = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Entry/Prize')]"));
		((AndroidDriver)driver).swipe(tourneyImplPage.getFilterButton().getLocation().getX(),tourneyImplPage.getFilterButton().getLocation().getY()-50,ele.getLocation().getX(),ele.getLocation().getY(),3000);
		
		
		System.out.println("");
		List<WebElement> secondLowSwipeElements = tourneyImplPage.getLobbyEntryFields();
		List<String> secondLow=tourneyImplPage.parseElements(secondLowSwipeElements);
		System.out.println("");
		firstLow.addAll(secondLow);
		tourneyImplPage.verifyFilter(firstLow, filterType.LOW);
		
		tourneyImplPage.getFilterButton().click();
		tourneyImplPage.getLowCheckBox().click();
		tourneyImplPage.getMediumCheckBox().click();
		tourneyImplPage.getApplyButton().click();
		
		 List<WebElement> firstMidSwipeElements = tourneyImplPage.getLobbyEntryFields();
		 List<String> firstMid=tourneyImplPage.parseElements(firstMidSwipeElements);
		//((AndroidDriver)driver).swipe(545,1600 , 545, 630, 3000);
		((AndroidDriver)driver).swipe(tourneyImplPage.getFilterButton().getLocation().getX(),tourneyImplPage.getFilterButton().getLocation().getY()-50,ele.getLocation().getX(),ele.getLocation().getY(),3000);
		
		System.out.println("");
		List<WebElement> secondMidSwipeElements = tourneyImplPage.getLobbyEntryFields();
		List<String> secondMid=tourneyImplPage.parseElements(secondMidSwipeElements);
		System.out.println("");
		firstMid.addAll(secondMid);
		tourneyImplPage.verifyFilter(firstMid, filterType.MEDIUM);
		
		tourneyImplPage.getFilterButton().click();
		tourneyImplPage.getMediumCheckBox().click();
		tourneyImplPage.getHighCheckBox().click();
		tourneyImplPage.getApplyButton().click();
		
		 List<WebElement> firstHighSwipeElements = tourneyImplPage.getLobbyEntryFields();
		 List<String> firstHigh=tourneyImplPage.parseElements(firstHighSwipeElements);
		//((AndroidDriver)driver).swipe(545,1600 , 545, 630, 3000);
		 ((AndroidDriver)driver).swipe(tourneyImplPage.getFilterButton().getLocation().getX(),tourneyImplPage.getFilterButton().getLocation().getY()-50,ele.getLocation().getX(),ele.getLocation().getY(),3000);
			
		System.out.println("");
		List<WebElement> secondHighSwipeElements = tourneyImplPage.getLobbyEntryFields();
		List<String> secondHigh=tourneyImplPage.parseElements(secondHighSwipeElements);
		System.out.println("");
		firstHigh.addAll(secondHigh);
		tourneyImplPage.verifyFilter(firstHigh, filterType.HIGH);
		
		tourneyImplPage.getFilterButton().click();
		tourneyImplPage.getHighCheckBox().click();
		tourneyImplPage.getRegisteredCheckBox().click();
		tourneyImplPage.getApplyButton().click();
		
		List<WebElement> elements = tourneyImplPage.getRegisteringStatusFields();
		List<String> regisStatusElements = tourneyImplPage.parseElements(elements);
		tourneyImplPage.verifyRegisteringStatusField(regisStatusElements);*/
	}
	
	
	
	
	@Test(description = "Verify registered filter is working as expected or not. And Check entry for freeroll tourney's is \"free\" or not. "
			+ "Check whether user gets a pop up saying \"Please verify your emaii id and complete your profile to register to the tourney or not \""
			+ " while trying to register for a free roll tourney",priority=1)
	public void TS_Tourney_03() throws InterruptedException, IOException{
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon(), 10);
		launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		lobbyImplPage.getTourneyButton().click();
		TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
		CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),10);
	
		
		tourneyImplPage.getAnyTourney().click();
		if(!tourneyImplPage.getTLobbyHeaderTitle().getText().equals("Freeroll Tourney"))
		{
			while(!tourneyImplPage.getTLobbyHeaderTitle().getText().equals("Freeroll Tourney"))
			{
			tourneyImplPage.getTLobbyCloseButton().click();
			tourneyImplPage.getTourneyLeftArrow().click();
			//CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),5);
				if(CustomMethods.isElementPresent(tourneyImplPage.getAnyTourney()))
					tourneyImplPage.getAnyTourney().click();
				else{
					tourneyImplPage.getTourneyLeftArrow().click();
					CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),10);
					tourneyImplPage.getAnyTourney().click();
				}
			}
		}
		verifyText(tourneyImplPage.getTourneyEntryField().getText().trim(), "free");
		tourneyImplPage.getTLobbyCloseButton().click();
		List<WebElement> element = tourneyImplPage.getLobbyEntryFields();
		List<String> entryInLobbyElements = tourneyImplPage.parseElements(element);
		tourneyImplPage.verifyFreerollEntryFieldsInLobby(entryInLobbyElements);
		
		tourneyImplPage.getAnyTourney().click();
		verifyPresent(tourneyImplPage.getRegisterButton(),"Touney Lobby");
		tourneyImplPage.getRegisterButton().click();
		verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Register Confirmation Pop Up");
		tourneyImplPage.getRegisterConfirmationNoButton().click();
		logger.log(LogStatus.INFO, "No button clicked");
		verifyPresent(tourneyImplPage.getRegisterButton(),"Touney Lobby");
		tourneyImplPage.getRegisterButton().click();
		tourneyImplPage.getRegisterConfirmationYesButton().click();
		verifyPresent(tourneyImplPage.getVerifyEmailAndProfilePopUp(), "Verify Email Id and Complete Propile pop-up");
		verifyText(tourneyImplPage.getVerifyEmailAndProfilePopUp().getText(), "Please verify your email ID and complete your profile to register to the tourney");
		tourneyImplPage.getverifyEmailAndProfilePopUpOkButton().click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		verifyPresent(myAccountImplPage.getPasswordPromtPopUp(), "Enter Password Popup");
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		KycImplPage kycImplPage = new KycImplPage(driver);
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycEmailField(), "KYC Screen");	
		
	}
	
	
	@Test(description = "Create tourney and generate gift vouchers",priority=1)
	public void TS_Tourney_04() throws  IOException, InterruptedException {
	
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		CustomMethods.waitForElementPresent(launchImplPage.getLoginButon(), 10);
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(lobbyImplPage.getPlpBannerCloseIcon(),15);
		lobbyImplPage.verifyPostLaunchBanners();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions,"Gift Vouchers").click();
		GiftVouchersImplPage giftVouchersImplPage = new GiftVouchersImplPage(driver);
		giftVouchersImplPage.getGiftVoucherCodeInputField().sendKeys(gv.get(0));
		giftVouchersImplPage.getGiftVoucherCodeApplyButton().click();
		CustomMethods.waitForElementPresent(giftVouchersImplPage.getTourneyRegistrationButton(),15);
		verifyText(giftVouchersImplPage.getTourneyRegistrationPopUpText().getText(), gvTourneyID);
		giftVouchersImplPage.getTourneyRegistrationButton().click();
		CustomMethods.waitForElementPresent(giftVouchersImplPage.getSuccessfulRegisteredTourneyPopUp(),15);
		verifyText(giftVouchersImplPage.getSuccessfulRegisteredTourneyPopUp().getText(), "registered");
		giftVouchersImplPage.getSuccessfulRegisteredTourneyPopUpOkButton().click();
		
		
	}
	
		
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
				
			try{
				if(desktopDriver.toString().contains("null")){
					logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
					}else{
						logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),desktopDriver)));
						//desktopDriver.close();
					}
			}catch(Exception e){
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
		}
		((AppiumDriver) driver).resetApp();
		extent.flush();
		extent.endTest(logger);
		
	}
	
	
}
