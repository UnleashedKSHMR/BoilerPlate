package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.app.webview.impl.pages.UpdateProfileWebViewImplPage;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.component.pages.AppOnlyForRealChipsDialogBox;
import com.ace2three.impl.pages.BankAccountsImplPage;
import com.ace2three.impl.pages.BankAccountsImplPage.BankAccountProofAction;
import com.ace2three.impl.pages.KycImplPage;
import com.ace2three.impl.pages.KycImplPage.IdProof;
import com.ace2three.impl.pages.KycImplPage.IdProofAction;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.PurchaseLimitsImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.DateUtils;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.ace2three.utils.RetryAnalyzer;
import com.ace2three.utils.business.BusinessMethods;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class PurchaseLimitsTestSuite extends BaseTestSuite {
	

	DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
	Date date = new Date();
	ReadDataFromProps ReadProps;
	WebDriver desktopDriver;
	String userNameWithOutVerification= null;
	String userNameWithVerification= null;
	DateFormat dateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		Test test = method.getAnnotation(Test.class);
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		ReadProps= new ReadDataFromProps();
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
	}

	@Test(description = "Verify regular player should not able access  “Purchase limits” module", priority=1)
	public void TS_Sanity__PurchaseLimits_01() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		launchImplPage.launchLobbyPage("appium7", "ace2three");
		LobbyImplPage lobbyImplPage= new LobbyImplPage();
		AppOnlyForRealChipsDialogBox appOnlyForRealChipsDialogBox = new AppOnlyForRealChipsDialogBox(driver);
		
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			//AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
		lobbyImplPage.getHomeTabIcon().click();
		//appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
		}	
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchPurchaseLimitsScreen();
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitsRestricetedAlert(),"Purchase limits module restricted alert box");
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitsRestricetedAlertBuyChipsButton(),"buy chips button in Purchase limits module restricted alert box");
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitsRestricetedAlertNoThanksButton(),"No thanks button in Purchase limits module restricted alert box");
		purchaselimitsImplPage.getPurchaseLimitsRestricetedAlertNoThanksButton().click();
		verifyNotPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen", 2);
		
	}
	
	@Test(description = "Verify mobile number alert should be displayed when premium user tries to increase limit from 5000 to 10000 when mobile number is not verified", priority=2
			)
	public void TS_Sanity__PurchaseLimits_02() throws InterruptedException, IOException, SQLException {
		
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		dataBaseConnection.updateQuery(unveriFyMobileQuery, userNameWithOutVerification);
		//LaunchImplPage launchImplPage = new LaunchImplPage(driver);
	
		//launchImplPage.launchLobbyPage("nani2", "ace2three");
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		this.userNameWithOutVerification= signupImplPage.doSignUp();
		LobbyImplPage lobbyImplPage= new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200",paymentMethods.MobiKwik);
		/*verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
				ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));*/
		
		lobbyImplPage.getLevelUpAlertOkButton().click();
		
	//	lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab2().click();
		verifyPresent(purchaselimitsImplPage.getVerifyPhoneNoAlertS1toS2(),"Verify Phone number alert");
		verifyTextPresent(purchaselimitsImplPage.getVerifyPhoneNoAlertS1toS2(),
				ReadDataFromProps.props.getProperty("purchase.limits.verify.phone.number.to.increase"));
		purchaselimitsImplPage.getVerifyAlertToIncreasePlLaterButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab2().click();
		verifyPresent(purchaselimitsImplPage.getVerifyPhoneNoAlertS1toS2(),"Verify Phone number alert");
		purchaselimitsImplPage.getVerifyAlertS1toS2VerifyButton().click();
		verifyPresent(purchaselimitsImplPage.getOtpAlertheader(),"OTP pop up");
		purchaselimitsImplPage.getEnterPhoneNumberField().sendKeys("8463932054");
		purchaselimitsImplPage.getSendOtpButton().click();
		
		//If App auto detected the OTP 
		BusinessMethods bmethods= new BusinessMethods();
		boolean autoDetectedOtp= bmethods.checkAutoDetectedOtp(purchaselimitsImplPage.getMobileVerifiedCongratsMessage());
		//To read and enter passwordss
		
		if(!autoDetectedOtp){
		/*	String OTP =bmethods.getOtpFromMessages();
			purchaselimitsImplPage.getOtpField().sendKeys(OTP);*/
			DataBaseServerConnect dataBaseServerConnect=new DataBaseServerConnect();
			String OTP= dataBaseServerConnect.selectQuery(null, userNameWithOutVerification);
			purchaselimitsImplPage.getOtpField2().sendKeys(OTP);
			purchaselimitsImplPage.getConfirmOtpButton().click();
		}
		
		purchaselimitsImplPage.getPurchaseLimitAlertOkButton().click();
		purchaselimitsImplPage.getPurchaseLimitSlab2().click();
		purchaselimitsImplPage.getSubmitButton().click();
		logger.log(LogStatus.INFO, "clicked on submit button for slab 2 increase");
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), "Purchase limit update success message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), 
				ReadDataFromProps.props.getProperty("purchase.limit.updated.success.message"));
		
		purchaselimitsImplPage.getPurchaseLimitAlertOkButton().click();
		verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "10000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "100000");
		
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("puchase.limit.cool.off.period.message")+" "+ dateFormat1.format(DateUtils.getDate(15));
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		//Remove cool off period
		String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userNameWithOutVerification+"')";
		dataBaseConnection.updateQuery(coolOffQuery, userNameWithOutVerification);
		
	}
	
	@Test(description = "Verify purchase limit increase should be pending and verify ID proof alert should be displayed for premium user when tries to increase limit from 10000 to 25000 if ID proof is not verified", priority=3)
	public void TS_Sanity__PurchaseLimits_03() throws InterruptedException, IOException, SQLException {
		
		
		//stub code that need to be removed after completion of all scenarios
		String userName=userNameWithOutVerification;
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchLobbyPage(userName, "ace2three");
		//Stub code ends here
		
		LobbyImplPage lobbyImplPage= new LobbyImplPage();
		
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);
		
		
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(purchaselimitsImplPage.getPurchaseLimitSlab2(),10);
		
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		
		verifyPresent(purchaselimitsImplPage.getVerifyIdproofAlertS2toS3(),"Verify ID-proof alert");
		verifyTextPresent(purchaselimitsImplPage.getVerifyIdproofAlertS2toS3(),
				ReadDataFromProps.props.getProperty("purchase.limits.verify.id.proof.to.increase.s2.to.s3"));
		purchaselimitsImplPage.getVerifyAlertToIncreasePlLaterButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		
		verifyPresent(purchaselimitsImplPage.getVerifyIdproofAlertS2toS3(),"Verify ID-proof alert");
		purchaselimitsImplPage.getVerifyAlertS1toS2VerifyButton().click();
		
		KycImplPage kycPage = new KycImplPage(driver);
		kycPage.uploadIdProofAadharOneSide(userName);
		kycPage.performActionOnIdProofInAdminSite(userName, IdProofAction.Accept, IdProof.Aadhar);
	
		DataBaseServerConnect dataBaseServerConnect= new DataBaseServerConnect();
		String verifyEmailAndMobileNo="update game_user_master set user_confirmation = 'Y',phone_verified = 'Y' where upper(user_id) = upper('"+userNameWithOutVerification+"')";
		dataBaseServerConnect.updateQuery(verifyEmailAndMobileNo, null);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(purchaselimitsImplPage.getPurchaseLimitSlab2(),10);
				
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		
		verifyPresent(purchaselimitsImplPage.getFivePerOfMonLimitPopup(), "Make 5% purchase popup");
		purchaselimitsImplPage.getFivePerOfMonLimitPopupOkButton().click();
		lobbyImplPage.getAddChipsButton().click();
		UpdateProfileWebViewImplPage updateProfileWebViewImplPage = new UpdateProfileWebViewImplPage(driver);
		updateProfileWebViewImplPage.updateShortProfileWithoutStateAndMobileNo();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		lobbyImplPage.verifyPostLaunchBanners();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(purchaselimitsImplPage.getPurchaseLimitSlab2(),10);
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		verifyPresent(purchaselimitsImplPage.getFivePerOfMonLimitPopup(), "Make 5% purchase popup");
		purchaselimitsImplPage.getFivePerOfMonLimitPopupOkButton().click();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("5000",paymentMethods.MobiKwik);
	//	addCashWebViewImplPage.getAddCashWebViewClose().click();
		
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(purchaselimitsImplPage.getPurchaseLimitSlab2(),10);
		
		
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		purchaselimitsImplPage.getSubmitButton().click();
		
		logger.log(LogStatus.INFO, "clicked on submit button for slab 3 PL increase");
		
		//Approve limit in Admin
		verifyPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),"Purchase limit increase requested alert");
		verifyTextPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.received"));
		purchaselimitsImplPage.getRequestReceivedAlertForPlimitChangeOkButton().click();
		
		verifyPresent(purchaselimitsImplPage.getRequestReceivedForPlimitChangeInProcessing(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.in.processing"));
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "10000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "100000");
		
		purchaselimitsImplPage.updatePurchaseLimitSlabInAdmin(userName, 3);
		//ends here
		
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(purchaselimitsImplPage.getPurchaseLimitSlab2(),10);
		
		verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "25000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "300000");
		
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("puchase.limit.cool.off.period.message")+" "+ dateFormat1.format(DateUtils.getDate(30));
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		//remove cool off period
		
		String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userName+"')";
		dataBaseConnection.updateQuery(coolOffQuery, userName);
		
		
	}
	
	@Test(description = "Verify purchase limit increase should be pending and verify bank account alert should be displayed for premium user "
			+ "when tries to increase limit from 25000 to 50000 if bank account is not verified", priority=4)
	public void TS_Sanity__PurchaseLimits_04() throws InterruptedException, IOException, SQLException {
		
		//stub code that need to be removed after completion of all scenarios
		String userName=userNameWithOutVerification;
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchLobbyPage(userName, "ace2three");
		//Stub code ends here
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab4().click();
		verifyPresent(purchaselimitsImplPage.getProvideBankAccountAlertS3toS4(),"Provide bank account details alert");
		verifyTextPresent(purchaselimitsImplPage.getProvideBankAccountAlertS3toS4(),
				ReadDataFromProps.props.getProperty("purchase.limits.provide.bank.account.details.to.increase.s3.to.s4"));
		purchaselimitsImplPage.getVerifyAlertToIncreasePlLaterButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab4().click();
		
		verifyPresent(purchaselimitsImplPage.getProvideBankAccountAlertS3toS4(),"Provide bank account details alert");
		purchaselimitsImplPage.getVerifyAlertS3toS4VerifyButton().click();
		
		BankAccountsImplPage bankAccountsImplPage = new BankAccountsImplPage(driver);
		bankAccountsImplPage.verifyBankAccountsPageDisplayed();
		
		if(CustomMethods.isElementPresent(bankAccountsImplPage.getClickHereToAddAnotherAccount()))
			bankAccountsImplPage.getClickHereToAddAnotherAccount().click();
		
		String acctNumber =bankAccountsImplPage.addBankAccountWithProof();
		
		bankAccountsImplPage.approveBankAcountInAdmin(userName, acctNumber, BankAccountProofAction.Accept);
		LobbyImplPage lobbyImplPage= new LobbyImplPage();
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		purchaselimitsImplPage.getPurchaseLimitSlab4().click();
		///////////////////////////
		verifyPresent(purchaselimitsImplPage.getFivePerOfMonLimitPopup(), "Make 5% purchase popup");
		purchaselimitsImplPage.getFivePerOfMonLimitPopupOkButton().click();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("10000",paymentMethods.MobiKwik);
	//	addCashWebViewImplPage.getAddCashWebViewClose().click();
		
		
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(purchaselimitsImplPage.getPurchaseLimitSlab2(),10);
	
		
		purchaselimitsImplPage.getPurchaseLimitSlab4().click();
		purchaselimitsImplPage.getSubmitButton().click();
		verifyPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),"Purchase limit increase requested alert");
		verifyTextPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.received"));
		purchaselimitsImplPage.getRequestReceivedAlertForPlimitChangeOkButton().click();
		
		verifyPresent(purchaselimitsImplPage.getRequestReceivedForPlimitChangeInProcessing(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.in.processing"));
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "25000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "300000");
		
		purchaselimitsImplPage.updatePurchaseLimitSlabInAdmin(userName, 4);
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		/*verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");*/
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "50000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "500000");
		
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("purchase.limit.reached.maximum.limit.message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		//remove cool off period
		String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userName+"')";
				dataBaseConnection.updateQuery(coolOffQuery, userName);
	}
	
	@Test(description = "Verify purchase limit should be increased and verify mobile number alert should not be displayed for premium user "
			+ "when tries to increase limit from 5000 to 10000 if mobile number is verified", priority=5)
	public void TS_Sanity__PurchaseLimits_05() throws InterruptedException, IOException, SQLException {
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		dataBaseConnection.updateQuery(unveriFyMobileQuery, userNameWithOutVerification);
		
		/*//stub code that need to be removed after completion of all scenarios
		String userName="test12021155";
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchLobbyPage(userName, "ace2three");
		//Stub code ends here
*/		
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		this.userNameWithVerification= signupImplPage.doSignUp();
		LobbyImplPage lobbyImplPage= new LobbyImplPage(driver);
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200",paymentMethods.MobiKwik);
		/*verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
				ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));*/
		lobbyImplPage.getLevelUpAlertOkButton().click();
		UpdateProfileWebViewImplPage updateProfileWebViewImplPage= new UpdateProfileWebViewImplPage(driver);
		updateProfileWebViewImplPage.verifyPhoneNumberFromShortProfilePage("8463932054", userNameWithVerification);
		
	//	lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);
		purchaselimitsImplPage.getPurchaseLimitSlab2().click();
		verifyNotPresent(purchaselimitsImplPage.getVerifyPhoneNoAlertS1toS2(),"Verify Phone number alert",2);
		verifyText(purchaselimitsImplPage.getSubmitButton().getAttribute("enabled"),"true");
		purchaselimitsImplPage.getSubmitButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), "Purchase limit update success message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), 
				ReadDataFromProps.props.getProperty("purchase.limit.updated.success.message"));
		purchaselimitsImplPage.getPurchaseLimitAlertOkButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "10000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "100000");
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("puchase.limit.cool.off.period.message")+" "+ dateFormat1.format(DateUtils.getDate(15));
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		//remove cool off period
		String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userNameWithVerification+"')";
		dataBaseConnection.updateQuery(coolOffQuery, userNameWithVerification);
	}
	
	@Test(description = "Verify purchase limit increase should be pending and verify ID proof alert should not be displayed for premium user "
			+ "when tries to increase limit from 10000 to 25000 if ID proof is already verified", priority=6)
	public void TS_Sanity__PurchaseLimits_06() throws InterruptedException, IOException, SQLException {
		
		String userName=userNameWithVerification;
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();
		launchImplPage.launchLobbyPage(userName, "ace2three");
		
		LobbyImplPage lobbyImplPage= new LobbyImplPage();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		KycImplPage kycPage = new KycImplPage(driver);
		kycPage.uploadIdProofAadharOneSide(userName);
		kycPage.performActionOnIdProofInAdminSite(userName, IdProofAction.Accept, IdProof.Aadhar);
		//Navigate to purchase limits
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		
		
		verifyPresent(purchaselimitsImplPage.getFivePerOfMonLimitPopup(), "Make 5% purchase popup");
		purchaselimitsImplPage.getFivePerOfMonLimitPopupOkButton().click();
		lobbyImplPage.getAddChipsButton().click();
		UpdateProfileWebViewImplPage updateProfileWebViewImplPage = new UpdateProfileWebViewImplPage(driver);
		updateProfileWebViewImplPage.updateShortProfileWithoutStateAndMobileNo();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		lobbyImplPage.verifyPostLaunchBanners();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(purchaselimitsImplPage.getPurchaseLimitSlab2(),10);
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		verifyPresent(purchaselimitsImplPage.getFivePerOfMonLimitPopup(), "Make 5% purchase popup");
		purchaselimitsImplPage.getFivePerOfMonLimitPopupOkButton().click();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("5000",paymentMethods.MobiKwik);
	//	addCashWebViewImplPage.getAddCashWebViewClose().click();
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		
		verifyNotPresent(purchaselimitsImplPage.getVerifyIdproofAlertS2toS3(),"Verify ID-proof alert",2);
		verifyText(purchaselimitsImplPage.getSubmitButton().getAttribute("enabled"),"true");
		
		purchaselimitsImplPage.getSubmitButton().click();
		
		logger.log(LogStatus.INFO, "clicked on submit button for slab 3 PL increase");
		//Approve limit in Admin
		verifyPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),"Purchase limit increase requested alert");
		verifyTextPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.received"));
		purchaselimitsImplPage.getRequestReceivedAlertForPlimitChangeOkButton().click();
		
		verifyPresent(purchaselimitsImplPage.getRequestReceivedForPlimitChangeInProcessing(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.in.processing"));
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "10000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "100000");
		
		purchaselimitsImplPage.updatePurchaseLimitSlabInAdmin(userName, 3);
		//ends here
		
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		
		verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "25000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "300000");
		
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("puchase.limit.cool.off.period.message")+" "+ dateFormat1.format(DateUtils.getDate(30));
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		//remove cool off period
		String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userName+"')";
		dataBaseConnection.updateQuery(coolOffQuery, userName);
		
	}
	
	@Test(description = "Verify purchase limit increase should be pending and verify bank account alert should not be displayed for premium user"
			+ " when tries to increase limit from 25000 to 50000 if bank account is already verified", priority=7)
	public void TS_Sanity__PurchaseLimits_07() throws InterruptedException, IOException, SQLException {
		
		DataBaseServerConnect dataBaseServerConnect= new DataBaseServerConnect();
		String verifyEmailAndMobileNo="update game_user_master set user_confirmation = 'Y',phone_verified = 'Y' where upper(user_id) = upper('"+userNameWithVerification+"')";
		dataBaseServerConnect.updateQuery(verifyEmailAndMobileNo, null);
		
		String userName=userNameWithVerification;
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();
		launchImplPage.launchLobbyPage(userName, "ace2three");
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.BankAccounts);
		BankAccountsImplPage bankAccountsImplPage = new BankAccountsImplPage(driver);
		bankAccountsImplPage.verifyBankAccountsPageDisplayed();
		String acctNumber =bankAccountsImplPage.addBankAccountWithProof();
		
		bankAccountsImplPage.approveBankAcountInAdmin(userName, acctNumber, BankAccountProofAction.Accept);
		LobbyImplPage lobbyImplPage= new LobbyImplPage();
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab4().click();
		/////////////////////////
		verifyPresent(purchaselimitsImplPage.getFivePerOfMonLimitPopup(), "Make 5% purchase popup");
		purchaselimitsImplPage.getFivePerOfMonLimitPopupOkButton().click();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("10000",paymentMethods.MobiKwik);
		//addCashWebViewImplPage.getAddCashWebViewClose().click();
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		
		purchaselimitsImplPage.getPurchaseLimitSlab4().click();
		
		
		
		
		verifyNotPresent(purchaselimitsImplPage.getProvideBankAccountAlertS3toS4(),"Provide bank account details alert",2);
		verifyText(purchaselimitsImplPage.getSubmitButton().getAttribute("enabled"),"true");
		purchaselimitsImplPage.getSubmitButton().click();
		
		verifyPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),"Purchase limit increase requested alert");
		verifyTextPresent(purchaselimitsImplPage.getRequestReceivedAlertForPlimitChange(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.received"));
		purchaselimitsImplPage.getRequestReceivedAlertForPlimitChangeOkButton().click();
		verifyPresent(purchaselimitsImplPage.getRequestReceivedForPlimitChangeInProcessing(),
				ReadDataFromProps.props.getProperty("purchase.limit.increase.request.in.processing"));
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "25000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "300000");
		//Update limit in admin page
		purchaselimitsImplPage.updatePurchaseLimitSlabInAdmin(userName, 4);
	
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		/*verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");*/
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "50000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "500000");
		
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("purchase.limit.reached.maximum.limit.message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		//remove cool off period
		String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userName+"')";
		dataBaseConnection.updateQuery(coolOffQuery, userName);
		
	}
	
	@Test(description = "Verify purchase limit decrease should be completed and cool off message should be displayed when"
			+ " user tries to decrease limit from 50000 to 25000 if user already has s4 purchase limit", priority=8)
	public void TS_Sanity__PurchaseLimits_08() throws InterruptedException, IOException {
		
		String userName=userNameWithVerification;
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();
		launchImplPage.launchLobbyPage(userName, "ace2three");
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);	
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
	
		purchaselimitsImplPage.navigateToPurchaseLimitPage();
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab3().click();
		verifyNotPresent(purchaselimitsImplPage.getProvideBankAccountAlertS3toS4(),"Alert message",2);
		verifyText(purchaselimitsImplPage.getSubmitButton().getAttribute("enabled"),"true");
		purchaselimitsImplPage.getSubmitButton().click();
		verifyTextPresent(purchaselimitsImplPage.getPeducePurchaseLimitsConfirmationAlert(),
				ReadDataFromProps.props.getProperty("purchase.limits.reduce.confirmation.alert.message"));
		purchaselimitsImplPage.getReducePurchaseLimitsConfirmationYesButton().click();
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), "Purchase limit update success message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), 
				ReadDataFromProps.props.getProperty("purchase.limit.updated.success.message"));
		purchaselimitsImplPage.getPurchaseLimitAlertOkButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "25000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "300000");
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("puchase.limit.cool.off.period.message")+" "+ dateFormat1.format(DateUtils.getDate(30));
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
				
	}
	
	@Test(description = "Verify purchase limit decrease should be completed and cool off message should be displayed  "
			+ "when user tries to decrease limit from 25000 to 10000 if user already has s3 purchase limit", priority=9)
	public void TS_Sanity__PurchaseLimits_09() throws InterruptedException, IOException {
		
		String userName=userNameWithVerification;
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();
		launchImplPage.launchLobbyPage(userName, "ace2three");
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);	
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
	
		purchaselimitsImplPage.navigateToPurchaseLimitPage();
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab2().click();
		verifyNotPresent(purchaselimitsImplPage.getVerifyIdproofAlertS2toS3(),"Alert message",2);
		verifyText(purchaselimitsImplPage.getSubmitButton().getAttribute("enabled"),"true");
		purchaselimitsImplPage.getSubmitButton().click();
		verifyTextPresent(purchaselimitsImplPage.getPeducePurchaseLimitsConfirmationAlert(),
				ReadDataFromProps.props.getProperty("purchase.limits.reduce.confirmation.alert.message"));
		purchaselimitsImplPage.getReducePurchaseLimitsConfirmationYesButton().click();
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), "Purchase limit update success message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), 
				ReadDataFromProps.props.getProperty("purchase.limit.updated.success.message"));
		purchaselimitsImplPage.getPurchaseLimitAlertOkButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "10000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "100000");
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("puchase.limit.cool.off.period.message")+" "+ dateFormat1.format(DateUtils.getDate(15));
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		
	}
	
	@Test(description = "Verify purchase limit decrease should be completed and cool off message should be displayed "
			+ "when user tries to decrease limit from 10000 to 5000 if user already has s2 purchase limit", priority=10)
	public void TS_Sanity__PurchaseLimits_10() throws InterruptedException, IOException {
		
		String userName=userNameWithVerification;
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();
		launchImplPage.launchLobbyPage(userName, "ace2three");
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		PurchaseLimitsImplPage purchaselimitsImplPage =new PurchaseLimitsImplPage(driver);	
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
	
		purchaselimitsImplPage.navigateToPurchaseLimitPage();
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitSlab1(), "Purchase limits screen");
		purchaselimitsImplPage.getPurchaseLimitSlab1().click();
		verifyNotPresent(purchaselimitsImplPage.getVerifyPhoneNoAlertS1toS2(),"Alert message",2);
		verifyText(purchaselimitsImplPage.getSubmitButton().getAttribute("enabled"),"true");
		purchaselimitsImplPage.getSubmitButton().click();
		verifyTextPresent(purchaselimitsImplPage.getPeducePurchaseLimitsConfirmationAlert(),
				ReadDataFromProps.props.getProperty("purchase.limits.reduce.confirmation.alert.message"));
		purchaselimitsImplPage.getReducePurchaseLimitsConfirmationYesButton().click();
		verifyPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), "Purchase limit update success message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseLimitUpdatedMessage(), 
				ReadDataFromProps.props.getProperty("purchase.limit.updated.success.message"));
		purchaselimitsImplPage.getPurchaseLimitAlertOkButton().click();
		
		verifyPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(),"Purchase limit cool off period message");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseDailyLimitValue(), "5000");
		verifyTextPresent(purchaselimitsImplPage.getPurchaseMonthlyLimitValue(), "25000");
		String CoolOffPeriodMessage = ReadDataFromProps.props.getProperty("puchase.limit.cool.off.period.message")+" "+ dateFormat1.format(DateUtils.getDate(7));
		verifyTextPresent(purchaselimitsImplPage.getPurchaselimitIncreaseCoolOffPeriodMessage(), CoolOffPeriodMessage);
		
	}
		
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
			
			try{
				if(desktopDriver.toString().contains("null")){
					logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
					}else{
						logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),desktopDriver)));
						desktopDriver.close();
					}
			}catch(Exception e){
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver) driver).resetApp();
	}
	
	
}
