package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.MyProfileImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.ace2three.web.impl.pages.WebLaunchImplPage;
import com.ace2three.web.impl.pages.WebMyAccountImplPage;
import com.ace2three.web.impl.pages.WebProfileEditImplPage;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.media.jfxmedia.logging.Logger;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.Connection;

public class MyProfileShortDetailsTestSuite extends BaseTestSuite{
	
	
	ReadDataFromProps ReadProps;
	WebDriver desktopDriver;
	
	@BeforeClass
	public void beforeClass(){
		
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		String unveriFyMobileQuery1 = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%9000061713'";
		try {
			dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
			dataBaseConnection.updateQuery(unveriFyMobileQuery1, null);
		} catch (InterruptedException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@BeforeMethod
	public void beforeMethos(Method method) throws InterruptedException {
		Test test = method.getAnnotation(Test.class);
		
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		ReadProps= new ReadDataFromProps();
		Thread.sleep(2000);
	}

	@Test(description = "Check whether user should not be able to edit FN or LN etc fields provided if the users KYC is verified", priority=1)
	public void TS_Sanity__ShortProfile_01() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileFirstNameField(),"First name field", "enabled");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileLastNameField(),"Last name field", "enabled");
		
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileCalenderIcon(), "Date of Birth field");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileGenderDropDown(), "Gender drop down field");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileStateDropDown(), "State drop down field");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileCityDropDown(), "City drop down field");
		
	}
	
	@Test(description = "check if the State and city is editable or not if the user once saves short profile details"
			+ "Check max allowed char for FN & LN - 50", priority=2)
	public void TS_Sanity__ShortProfile_03() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}	
		launchImplPage.getUsernameField().sendKeys(ReadDataFromProps.props.getProperty("pseudo.user"));
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		
		CustomMethods.VerifyElementIsEditable(profilePage.getMyProfileFirstNameField(),"First name field", "enabled");
		CustomMethods.VerifyElementIsEditable(profilePage.getMyProfileLastNameField(),"Last name field", "enabled");
		
		CustomMethods.VerifyElementIsEditable(profilePage.getMyProfileCalenderIcon(), "Date of Birth field");
		CustomMethods.VerifyElementIsEditable(profilePage.getMyProfileGenderDropDown(), "Gender drop down field");
		CustomMethods.VerifyElementIsEditable(profilePage.getMyProfileStateDropDown(), "State drop down field");
		CustomMethods.VerifyElementIsEditable(profilePage.getMyProfileCityDropDown(), "City drop down field");
		
		//Check max allowed char for FN & LN - 50
		logger.log(LogStatus.INFO, "Checkin max allowed char for FN & LN is 50");
		String fname= "qwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmqwertyu";
		String lname= "qwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmasdfghjkl";
		profilePage.getMyProfileFirstNameField().sendKeys(fname);
		profilePage.getMyProfileFirstNameField().sendKeys(lname);
		profilePage.getMyProfileSaveButtonLoc().click();
		if(profilePage.getMyProfileFirstNameField().getText().length()==50){
			logger.log(LogStatus.PASS, "First name field is not accepting more than 50 chars");
		}else{
			logger.log(LogStatus.FAIL, "" + logger.addScreenCapture(takeScreenShot("FN max allowed char")));
		}
		
		if(profilePage.getMyProfileLastNameField().getText().length()==50){
			logger.log(LogStatus.PASS, "Last name field is not accepting more than 50 chars");
		}else{
			logger.log(LogStatus.FAIL, "" + logger.addScreenCapture(takeScreenShot("LN max allowed char")));
		}
		
		
	}
	
	@Test(description = "Check whether a popup is displaying or not when a user tries to upload a profile pic", priority=4)
	public void TS_Sanity__ShortProfile_04() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}	
		launchImplPage.getUsernameField().sendKeys("appium5");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		verifyPresent(profilePage.getMyProfilePicEditButton(), "Profile pic edit button");
		profilePage.getMyProfilePicEditButton().click();
		verifyPresent(profilePage.getMyProfilePicEditAlertPopupMessage(), "Edit profile pic alert pop up");
		verifyTextPresent(profilePage.getMyProfilePicEditAlertPopupMessage(),
				ReadProps.props.getProperty("edit.profile.pic.not.verified.email.phone.pop.message"));
		verifyPresent(profilePage.getMyProfilePicEditAlertPopupVerifyNowButton(), "Edit profile pic alert pop up verify now button");
		verifyPresent(profilePage.getMyProfilePicEditAlertPopupLaterButton(), "Edit profile pic alert pop up later button");
		
	}
	
	@Test(description = "Check whether pending status is displayed on profile pic after uploading a profile pic document& / "
			+ "Check whether edit option is displaying or not in below profile pic after rejecting profile Pic from Admin.", priority=5)
	public void TS_Sanity__ShortProfile_05() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}	
		launchImplPage.getUsernameField().sendKeys("raju11");//champion23/appium13//devuda22
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		verifyPresent(profilePage.getMyProfilePicEditButton(), "Profile pic edit button");
		profilePage.getMyProfilePicEditButton().click();
		verifyPresent(profilePage.getGuideLinesForProfilePicture(), "Guideline for profile picture popup");
		verifyTextPresent(profilePage.getGuideLinesForProfilePicture(), "Guidelines for Profile Picture");
		String guidelines= profilePage.getGuideLinesTextForProfilePicture().getText();
		String[] guideLinesEachLines= guidelines.split("\n\n");

		String Expected= ReadProps.props.getProperty("profile.picture.upload.guidelines.text");
		for(String eachLine:guideLinesEachLines){
			System.out.println("lines :"+ eachLine);
		
			verifyText(eachLine, Expected);
		}
		profilePage.getGuideLinesPopUpForProfilePictureOkButton().click();
		
		verifyPresent(profilePage.getUploadPopUpCloseIcon(), "Upload popup close icon");
		verifyTextPresent(profilePage.getIdProofUploadPopUpInstructionsText(), 
				ReadProps.props.getProperty("upload.profile.pic.popup.instructions.text"));
		profilePage.getUploadPopUpCameraIcon().click();
		verifyPresent(profilePage.getCameraShutterButton(), "Camera app");
		profilePage.getCameraShutterButton().click();
		
		driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'crop_image_menu_crop')]")).click();
		logger.log(LogStatus.INFO, "After " + logger.addScreenCapture(takeScreenShot("post completed")));
		verifyPresent(profilePage.getProfilePicUploadSuccessPopUpMessage(), "Profile pic upload success message");
		verifyTextPresent(profilePage.getProfilePicUploadSuccessPopUpMessage(),ReadProps.props.getProperty("profile.pic.upload.success.message"));
		profilePage.getProfilePicUploadSuccessPopUpMessageOkButton().click();
		
		//Check whether pending status is displayed on profile pic after uploading a profile pic document
		verifyText(profilePage.getProfilePicUploadPendingStatus().getText(), "Pending Approval");
		verifyNotPresent(profilePage.getMyProfilePicEditButton(), "Profile pic edit icon", 3);
		
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
/*		desktopDriver.manage().window().maximize();*/
		desktopDriver.get(ReadProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys("administrator");
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("RM")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']")).click();
		driver.getPageSource();
		desktopDriver.findElement(By.cssSelector("input#searchUserId")).sendKeys("raju11");
		desktopDriver.findElement(By.cssSelector("input[value='Submit']")).click();
		desktopDriver.findElement(By.cssSelector("span#imgraju11")).click();
		Thread.sleep(3000);
		new Select(desktopDriver.findElement(By.cssSelector("select[id*=rejectRes]"))).selectByValue("Picture is Blank");
		desktopDriver.findElement(By.cssSelector("input[value='Reject']")).click();
		desktopDriver.switchTo().alert().accept();
		/*new Select(desktopDriver.findElement(By.cssSelector("select[id*=acceptRes]"))).selectByValue("Of Himself");
		desktopDriver.findElement(By.cssSelector("input[value='Accept']")).click();
		desktopDriver.switchTo().alert().accept();*/
		//verifyNotPresent(desktopDriver.findElement(By.cssSelector("input[value='Accept']")), "accept button", 15);
		//desktopDriver.quit();
		Thread.sleep(10000);
		//(AppiumDriver) driver).resetApp();
		desktopDriver.quit();
		//Check whether edit option is displaying or not in below profile pic after rejecting profile Pic from Admin.
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		verifyPresent(profilePage.getMyProfilePicEditButton(), "Profile pic edit button");
		
	}
	
	@Test(description = "Check whether an already user who has profile pic approved can able to upload profile pic",
			dependsOnMethods = "TS_Sanity__ShortProfile_05" , priority=6)
	public void TS_Sanity__ShortProfile_07() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.launchApp();
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}	
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		verifyPresent(profilePage.getMyProfilePicEditButton(), "Profile pic edit button");
		profilePage.getMyProfilePicEditButton().click();
		verifyPresent(profilePage.getUploadPopUpCloseIcon(),"Profile upload camera icon");
		logger.log(LogStatus.PASS, "user can able to upload profile pic after approval of previous requested profile picture");
		
	}
	
	@Test(description = "Check whether updated profile details being reflected or not in account details if a user updates his profile details from Desktop web"
			+ "Check fields are not editable after saving the profile details.",
			 priority=7)
	public void TS_Sanity__ShortProfile_10() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
		Date date = new Date();
		dateFormat.format(date);
		String Username= "ace" + dateFormat.format(date)+"a";
		
		WebDriverWait wait= new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(signupimplpage.getUsernamefield()));
		signupimplpage.getUsernamefield().sendKeys(Username);
		signupimplpage.getEmailidfield().sendKeys("test"+Username +"@ds.com");
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		logger.log(LogStatus.PASS, "Performing signup with username: "+ Username);
		logger.log(LogStatus.PASS, "Performing signup with email: "+ "abctest"+Username +"@ds.com");
		signupimplpage.getSignupbutton().click();
		
			LobbyImplPage lobbyPage = new LobbyImplPage(driver);
			lobbyPage.verifyLobbyPageDisplayed();
	
			if(CustomMethods.isElementPresent(lobbyPage.getSignUpBannerPopUpClose())){
				verifyPresent(lobbyPage.getThankYouForSignUpMessage(),"Signup success message on banner");
				verifyPresent(lobbyPage.getSignUpSuccessBannerNoThanksButton(),"No Tnanks link on signup success banner");
				verifyPresent(lobbyPage.getSignUpSuccessBuyChipsButton(),"Buy chips button on signup success banner");
				lobbyPage.getSignUpSuccessBannerNoThanksButton().click();
			}	
			
		CustomMethods customeMethods=  new CustomMethods();
		desktopDriver=customeMethods.launchWebBrowser();
/*		desktopDriver.manage().window().maximize();*/
		desktopDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		desktopDriver.get(ReadProps.props.getProperty("ace2three.site.url"));
		WebLaunchImplPage weblaunchPage= new WebLaunchImplPage(desktopDriver);
		weblaunchPage.getUserIdField().sendKeys(Username);
		
		weblaunchPage.getPasswordInputField().click();
		weblaunchPage.getPasswordInputFieldAfterFocus().sendKeys(ReadProps.props.getProperty("password.value"));
		weblaunchPage.getLoginButton().click();
		
		WebMyAccountImplPage webMyAccountPage = new WebMyAccountImplPage(desktopDriver);
		webMyAccountPage.getProfileExpandIcon().click();
		webMyAccountPage.getProfileMenuDetailsTab().click();
		
		int length = 7;
	    boolean useLetters = true;
	    boolean useNumbers = false;
	    String generatedString = RandomStringUtils.random(length, useLetters, useNumbers);
	    System.out.println(generatedString.toLowerCase());
	    
	    String firstName= "fn"+ generatedString.toLowerCase();
	    String lastName= "ln"+ generatedString.toLowerCase();
		WebProfileEditImplPage webProfilePage = new WebProfileEditImplPage(desktopDriver);
		webProfilePage.getFirstNameField().sendKeys(firstName);
		webProfilePage.getLastNameField().sendKeys(lastName);
		
		new Select(webProfilePage.getGenderDropdown()).selectByValue("M");
		new Select(webProfilePage.getDobDayDropDown()).selectByValue("10");
		new Select(webProfilePage.getDobMonthDropDown()).selectByValue("Jul");
		new Select(webProfilePage.getDobYearDropDown()).selectByValue("1990");
		Random random = new Random();
		int value = random.nextInt(100000);
		String phoneNumber ="55555"+ value;
		webProfilePage.getMobileInputField().sendKeys(phoneNumber);
		webProfilePage.getAddressInputField().sendKeys("Address1");
		new Select(webProfilePage.getStateDropdown()).selectByValue("Kerala");
		new Select(webProfilePage.getCityDropdown()).selectByValue(" Kalpatta");
		webProfilePage.getPincodeInputField().sendKeys("852111");
		webProfilePage.getprofileSubmitButton().click();
		verifyPresent(webProfilePage.getProfileSaveSuccessMessage(), "Profile successfully saved message");
		verifyTextPresent(webProfilePage.getProfileSaveSuccessMessage(), ReadProps.props.getProperty("web.profile.saved.success.message"));
		Thread.sleep(3000);
		desktopDriver.quit();
		
		//Now performing actions in mobile app
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		verifyText(profilePage.getMyProfileFirstNameField().getText(), firstName);
		verifyText(profilePage.getMyProfileLastNameField().getText(), lastName);
		verifyText(profilePage.getMyProfileDOBField().getText(), "10-Jul-1990");
		verifyText(profilePage.getMyProfileGenderDropDownField().getText(), "Male");
		verifyText(profilePage.getMyProfileStateDropDownField().getText(), "Kerala");
		verifyText(profilePage.getMyProfileCityDropDownField().getText(), "Kalpatta");
		
		//Check fields are editable or not after saving the profile details.
		
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileFirstNameField(),"First name field", "enabled");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileLastNameField(),"Last name field", "enabled");
		
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileCalenderIcon(), "Date of Birth field");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileGenderDropDown(), "Gender drop down field");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileStateDropDown(), "State drop down field");
		CustomMethods.VerifyElementNotEditable(profilePage.getMyProfileCityDropDown(), "City drop down field");
		
		
		
	}
	
	@Test(description = "Check whether a regular user should be able to update his profile details ", priority=13)
	public void TS_Sanity__ShortProfile_13(){
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}	
		launchImplPage.getUsernameField().sendKeys("appium26");
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		profilePage.verifyProfilePageIsDisplayed();
		logger.log(LogStatus.PASS, "Regular user can able to access profile page");
	}
	
	
	
	@Test(description = "Check if the user gets an alert message saying your account details matches with "
			+ "an existing user id or not if the user gives FN and LN of a premium user account", priority=11)
	public void TS_Sanity__ShortProfile_11() throws IOException, InterruptedException{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		String username = launchImplPage.doSignUpAndConvertToPremium();
	/*	if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}	
		launchImplPage.getUsernameField().sendKeys("appium23");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();*/
	
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.Profile);
		MyProfileImplPage myProfile = new MyProfileImplPage(driver);
		myProfile.verifyProfilePageIsDisplayed();
		
		myProfile.getMyProfileFirstNameField().sendKeys("appium");
		myProfile.getMyProfileLastNameField().sendKeys("studio");
		myProfile.getMyProfileDOBField().click();
		myProfile.getMyProfileCalenderOkButton().click();
		myProfile.getMyProfileGenderField().click();
		CustomMethods.selectFromDropDownList("Male");
		myProfile.getMyProfileStateField().click();
		CustomMethods.selectFromDropDownList("Goa");
		myProfile.getMyProfileCityField().click();
		CustomMethods.selectFromDropDownList("Calangute");
		
		myProfile.getMyProfileSaveButtonLoc().click();
		verifyPresent(myProfile.getMyProfileSaveSuccessMessage(), "First and last name matches existing premium account details message");
		verifyTextPresent(myProfile.getMyProfileErrorMessage(), ReadProps.props.getProperty("profile.edit.first.and.last.name.match.error.message"));
		
	}
	
	@Test(description = "Check whether user able to enter special character and numbers in FN and LN fields."
			+ "Check whether /Please select state/ text is displayed while trying to select city before selecting state. &"
			+ "Verify Wifi interupt behaviour  & Check FB connect button", priority=14)
	public void TS_Sanity__ShortProfile_1_New() throws IOException, InterruptedException{
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.getLoginButon().click();
		LobbyImplPage lobbyImplPage= new LobbyImplPage();
		launchImplPage.launchLobbyPage("noshortpro", "ace2three@");
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Profile").click();
		MyProfileImplPage myProfileImplPage= new MyProfileImplPage(driver);
		MyAccountImplPage myAccountImplPage = new   MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		myProfileImplPage.verifyProfilePageIsDisplayed();
		//Check whether "Connect with Facebook" button is displaying or not.
		logger.log(LogStatus.INFO, "Verifying whether Connect with Facebook button is displaying or not.");
		
		verifyPresent(myProfileImplPage.getConnectWithFacebookButton(), "Connect with facebook button");
		//Check whether user able to enter special character and numbers in FN and LN fields.
		myProfileImplPage.getMyProfileFirstNameField().sendKeys("a@$$*09");
		String fname = myProfileImplPage.getMyProfileFirstNameField().getText();
		if(fname.equalsIgnoreCase("a@$$*09")){
			logger.log(LogStatus.FAIL, "special chars are accepting in FN field"+ logger.addScreenCapture(takeScreenShot("speclChar")));
		}else if(fname.equalsIgnoreCase("a")){
			logger.log(LogStatus.PASS, "special chars are not accepting in FN field");
		}
		
		myProfileImplPage.getMyProfileLastNameField().sendKeys("b.-#78");
		String lname = myProfileImplPage.getMyProfileLastNameField().getText();
		if(lname.equalsIgnoreCase("b.-#78")){
			logger.log(LogStatus.FAIL, "special chars are accepting in FN field"+ logger.addScreenCapture(takeScreenShot("speclChar")));
		}else if(lname.equalsIgnoreCase("b")){
			logger.log(LogStatus.PASS, "special chars are not accepting in FN field");
		}
		//Check whether "Please select state" text is displayed while trying to select city before selecting state.
		
		myProfileImplPage.getMyProfileCityDropDownField().click();
		logger.log(LogStatus.INFO, "Trying to select city fields before state selecting state");
		verifyTextPresent(myProfileImplPage.getMyProfileErrorMessage(), "please select state");
		
		//Check whether whether pop-up with message “ You have been disconnected. Trying to reconnect” is displaying or not on giving network interrupt after entering details but not saved.
		myProfileImplPage.getMyProfileDOBField().click();
		myProfileImplPage.getMyProfileCalenderOkButton().click();
		myProfileImplPage.getMyProfileGenderField().click();
		CustomMethods.selectFromDropDownList("Male");
		myProfileImplPage.getMyProfileStateField().click();
		CustomMethods.selectFromDropDownList("Goa");
		myProfileImplPage.getMyProfileCityField().click();
		CustomMethods.selectFromDropDownList("Calangute");
		
		((AndroidDriver) driver).setConnection(Connection.NONE);
		logger.log(LogStatus.INFO, "Disconnecting to Wifi by switching OFF wifi");
		Thread.sleep(5000);
		try{
			driver.findElement(By.xpath(
					"//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"));
			logger.log(LogStatus.PASS, "you have been disconnected pop up has appeared");
		}catch(Exception e){
			logger.log(LogStatus.FAIL, "you have been disconnected pop up has not appeared" + logger.addBase64ScreenShot("Disconnection"));
		}
		
		((AndroidDriver) driver).setConnection(Connection.ALL);
		logger.log(LogStatus.INFO, "connected to Wifi by switching ON wifi");
		Thread.sleep(5000);
		try{
			driver.findElement(By.xpath(
					"//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"));
			logger.log(LogStatus.FAIL, "you have been disconnected pop up has not disappeared"+ logger.addBase64ScreenShot("Disconnection pop up has appeared"));
		}catch(Exception e){
			logger.log(LogStatus.PASS, "you have been disconnected pop up has been disappeared");
		}
		
		verifyTextPresent(myProfileImplPage.getMyProfileFirstNameField(), fname);
		verifyTextPresent(myProfileImplPage.getMyProfileLastNameField(), lname);
		//Verify footer widgets & header, wrench menu are accessible from profile screen
		logger.log(LogStatus.INFO, "Verifing footer widgets & header, wrench menu are accessible from profile screen");
		verifyPresent(lobbyImplPage.getgamesTabIcon(), "Games tab from short profile");
		verifyPresent(lobbyImplPage.getHomeTabIcon(), "Homes tab from short profile");
		verifyPresent(lobbyImplPage.getAddChipsButton(), "Add chips button from short profile");
		verifyPresent(lobbyImplPage.getHamburgerMenu(), "Hamburger menu from short profile");
		
		
	}
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException, InterruptedException {
		
	
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
				
			try{
				if(desktopDriver.toString().contains("null")){
					logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
					}else{
						logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),desktopDriver)));
						desktopDriver.quit();
					}
			}catch(Exception e){
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
		}
		((AppiumDriver) driver).resetApp();
		extent.endTest(logger);
	}
	
	public static void main(String args[]){
		
		
		Calendar cal = Calendar.getInstance();
	
		Date today = cal.getTime();
		cal.add(Calendar.YEAR, -18); // to get previous year add -1
		Date nextYear = cal.getTime();
		System.out.println(today +" : "+ nextYear);
		System.out.println(today);
		
	}
	
}
