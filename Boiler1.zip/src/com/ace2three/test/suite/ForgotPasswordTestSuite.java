package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.ForgotPasswordImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.ReadDataFromProps;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.StartsActivity;

public class ForgotPasswordTestSuite extends BaseTestSuite {
	
	CustomMethods cm;
	ReadDataFromProps readprops;
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		
		
		Test test = method.getAnnotation(Test.class);
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
	}
	
	
	@Test(description = "check whether FOrgot Nickname or userid link is present or not in forgot password window.", priority=1)
	public void TS_Sanity__ForgotPassword_01() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ForgotPasswordImplPage forgotPasswordImplPage = new ForgotPasswordImplPage(driver);
		
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		verifyPresent(launchImplPage.getKeepMeLogged(), "Login Screen");
		verifyPresent(launchImplPage.getForgotPassword(), "Forgot User Id/ Password?");
		launchImplPage.getForgotPassword().click();
		verifyPresent(forgotPasswordImplPage.getForgotPasswordMwebCloseButton(), "Forgot Password Web View");
		CustomMethods.waitForElementPresent(forgotPasswordImplPage.getForgotPasswordMwebCloseButton(),15);
		forgotPasswordImplPage.getForgotPasswordMwebCloseButton().click();
		launchImplPage.getForgotPassword().click();
		CustomMethods.waitForElementPresent(forgotPasswordImplPage.getForgotUserIdMwebLink(), 10);
		verifyPresent(forgotPasswordImplPage.getForgotUserIdMwebLink(), "Forgot User Id?");
				
	}
	
	
	@Test(description = "check whether the received OTP is of 6 digits or not,"
			+ " check the max allowed OTPs from mapp (should be of 2),"
			+ "check the OTP is same or not for every resend from web (should be same).", priority=2)
	public void TS_Sanity__ForgotPassword_02() throws InterruptedException, IOException, SQLException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ForgotPasswordImplPage forgotPasswordImplPage = new ForgotPasswordImplPage(driver);

		//launchImplPage.verifyUpgradePopup();
		//Thread.sleep(1000);
		verifyPresent(launchImplPage.getLoginButon(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		verifyPresent(launchImplPage.getKeepMeLogged(), "Login Screen");
		verifyPresent(launchImplPage.getForgotPassword(), "Forgot User Id/ Password?");
		launchImplPage.getForgotPassword().click();
		CustomMethods.waitForElementPresent(forgotPasswordImplPage.getForgotUserIdMwebLink(), 10);
		
		forgotPasswordImplPage.getForgotPasswordMwebUserNameField().sendKeys("gpic50");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("9640350711");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		DataBaseServerConnect dataBaseServerConnect=new DataBaseServerConnect();
		String OTP= dataBaseServerConnect.selectQuery(null, "gpic50");
		String oldOTP=OTP;
		if(OTP.length()==6)
		{
			logger.log(LogStatus.PASS, "Length of the OTP is 6 characters, Hence it is valid OTP");
		}
		else
		{
			logger.log(LogStatus.FAIL, "Received Invalid OTP");
		}
		CustomMethods.waitForElementPresent(forgotPasswordImplPage.getForgotPasswordResendOTPLink(),10);
		forgotPasswordImplPage.getForgotPasswordResendOTPLink().click();
		Thread.sleep(1000);
		forgotPasswordImplPage.getForgotPasswordResendOTPLink().click();
		CustomMethods.waitForElementPresent(forgotPasswordImplPage.getForgotPasswordOTPNotReceived(),10);
		verifyText(forgotPasswordImplPage.getForgotPasswordOTPNotReceived().getText(), readprops.props.getProperty("forgot.password.still.did.not.receive.otp.message"));
		OTP= dataBaseServerConnect.selectQuery(null, "gpic50");
		if(CustomMethods.isElementPresent(forgotPasswordImplPage.getForgotPasswordResendOTPLink()))
		{
			logger.log(LogStatus.FAIL, "Resend OTP link is displayed even after two click's on it, Hence user can able to receive more than two resend OTP's");
		}
		else
		{
			logger.log(LogStatus.PASS, "Resend OTP link is disappeared after two click's on it, Hence user cannot receive more than two resend OTP's");
		}
		
		if(oldOTP.equals(OTP))
		{
			logger.log(LogStatus.PASS, "Old OTP and new OTP is matched");
		}
		else
		{
			logger.log(LogStatus.FAIL, "Old OTP and new OTP is not matched");
		}				
	}
	
		@Test(description = "check whether user able to give both email id and mobile no in forgot password fields.(should not allow)"
				+ "check whether all validations for mobile no field is proper or not."
				+ "check whether all the alert messages are proper or not "
				+ "check whether user able to see any alert message on entering a valid email id and invalid username and vice versa."
				+ "check whether user able to give spaces in nickname field.", priority=3)
		public void TS_Sanity__ForgotPassword_03() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ForgotPasswordImplPage forgotPasswordImplPage = new ForgotPasswordImplPage(driver);

		
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getLoginButon(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		verifyPresent(launchImplPage.getKeepMeLogged(), "Login Screen");
		verifyPresent(launchImplPage.getForgotPassword(), "Forgot User Id/ Password?");
		launchImplPage.getForgotPassword().click();
		verifyPresent(forgotPasswordImplPage.getForgotPasswordMwebCloseButton(), "Forgot Password Web View");
		forgotPasswordImplPage.getForgotPasswordMwebCloseButton().click();
		launchImplPage.getForgotPassword().click();
		CustomMethods.waitForElementPresent(forgotPasswordImplPage.getForgotUserIdMwebLink(), 10);
		verifyPresent(forgotPasswordImplPage.getForgotUserIdMwebLink(), "Forgot User Id?");
		forgotPasswordImplPage.getForgotPasswordMwebUserNameField().sendKeys("gpic50");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("9640350711/coorg.sloi@gmail.com");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		Thread.sleep(2000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getForgotPasswordMwebStatusField().getText(), "Please enter valid Email ID / Mobile Number");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("9640350711,coorg.sloi@gmail.com");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(2000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getForgotPasswordMwebStatusField().getText(), "Please enter valid Email ID / Mobile Number");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("9640350711coorg.sloi@gmail.com");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(2000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getFpEnterCrtUserIdAndEmail().getText(), "Please enter the correct Email ID used for the userid");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("5640350711@");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(2000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getForgotPasswordMwebStatusField().getText(), "Please enter valid Email ID / Mobile Number");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("9640350712");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(2000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getFpEnterCrtUserIdAndMobileNo().getText(), "Please enter the correct Mobile Number used for the userid");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("sadfas@gmail.com");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(2000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getFpEnterCrtUserIdAndEmail().getText(), "Please enter the correct Email ID used for the userid");
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys("96403");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(2000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getForgotPasswordMwebStatusField().getText(), "Please enter valid Email ID / Mobile Number");
		
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebUserNameField().sendKeys("gps");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(1000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getFpUserIdShouldBeBtwStatusField().getText(),"User Id should be between 4 to 12 characters long." );
		verifyText(forgotPasswordImplPage.getForgotPasswordEnterEmailId().getText(), "Please enter Email ID / Mobile Number");
		
		forgotPasswordImplPage.getForgotPasswordMwebUserNameField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebUserNameField().sendKeys("  ");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(1000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getFpUserIdCannotBeEmptyStatus().getText(),"User Id cannot be empty." );
		verifyText(forgotPasswordImplPage.getForgotPasswordEnterEmailId().getText(), "Please enter Email ID / Mobile Number");
		
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebUserNameField().sendKeys("gpi@");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(1000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getFpUserIdContainAlphaAndNumberStatus().getText(),"User Id can contain alphabets and numbers only." );
		verifyText(forgotPasswordImplPage.getForgotPasswordEnterEmailId().getText(), "Please enter Email ID / Mobile Number");
		
		forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().clear();
		forgotPasswordImplPage.getForgotPasswordMwebUserNameField().sendKeys("5gpic");
		forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
		
		Thread.sleep(1000);
		driver.getPageSource();
		verifyText(forgotPasswordImplPage.getFpUserIdShouldStartAlpha().getText(),"User Id should start with an alphabet." );
		verifyText(forgotPasswordImplPage.getForgotPasswordEnterEmailId().getText(), "Please enter Email ID / Mobile Number");
		
				
	}
		
		@Test(description = "check whether user able to set new password after entering valid userid and email/Mobile number.", priority=4)
		public void TS_Sanity__ForgotPassword_04() throws InterruptedException, IOException, SQLException {
			
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			
			SignupImplPage signupImplPage = new SignupImplPage(driver);
			String userName=signupImplPage.doSignUpWithPhoneNumber();
			LobbyImplPage lobbyImplPage = new LobbyImplPage();
			if(CustomMethods.isElementPresent(lobbyImplPage.getSignUpSuccessBannerNoThanksButton()))
				lobbyImplPage.getSignUpSuccessBannerNoThanksButton().click();
					
				
			lobbyImplPage.getAddChipsButton().click();
			AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
			addCashWebViewImplPage.addCash("200",paymentMethods.MobiKwik);
			verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
			verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
					ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
			lobbyImplPage.getLevelUpAlertOkButton().click();
			
			lobbyImplPage.getUpdateProfilePopUpClose().click();
			
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
			lobbyImplPage.getLogoutAlertPopupYesButton().click();
			CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
			ForgotPasswordImplPage forgotPasswordImplPage = new ForgotPasswordImplPage(driver);
			//launchImplPage.verifyUpgradePopup();
			verifyPresent(launchImplPage.getKeepMeLogged(), "Login Screen");
			verifyPresent(launchImplPage.getForgotPassword(), "Forgot User Id/ Password?");
			launchImplPage.getForgotPassword().click();
			CustomMethods.waitForElementPresent(forgotPasswordImplPage.getForgotUserIdMwebLink(),10);
			verifyPresent(forgotPasswordImplPage.getForgotPasswordMwebCloseButton(), "Forgot Password Web View");
			verifyPresent(forgotPasswordImplPage.getForgotUserIdMwebLink(), "Forgot User Id link");
			forgotPasswordImplPage.getForgotPasswordMwebUserNameField().sendKeys(userName);
			forgotPasswordImplPage.getForgotPasswordMwebEmailOrMobileNoField().sendKeys(ReadDataFromProps.props.getProperty("mobile.number"));
			forgotPasswordImplPage.getForgotPasswordMwebSubmitButton().click();
			Thread.sleep(3000);
			/*DataBaseServerConnect dataBaseServerConnect=new DataBaseServerConnect();
			String OTP = dataBaseServerConnect.selectQuery(null, userName);
			*/
			((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
			
			try {((AndroidDriver) driver).runAppInBackground(5);
	        } catch (Exception e) {//ignore} 
	        	
	        }
			((AndroidDriver) driver).openNotifications();

			try {
				driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();
			} catch (Exception e) {
				System.out.println("into exception 1");
			}
			try {
				if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
				{
				driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'New messages')]")).click();
				}
				else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
				{
					driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'new messages')]")).click();
				}
				
			} catch (Exception e) {
				System.out.println("into exception 2");
			}
			
			if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
			{
				driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();
			}
			else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
			{
				driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'from')]")).click();
			}
			
			//driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();
			List<WebElement> textMessages=null;
			if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
			{
				textMessages = driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'text_view')]"));		
			}
			else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
			{
				textMessages = driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'body_text_view')]"));	
			}
			//List<WebElement> textMessages = driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'text_view')]"));
			int noOfMesg = textMessages.size();
			String messageText;
			/*if(noOfMesg==1)
				messageText = textMessages.get(0).getText();
				else
				messageText = textMessages.get(noOfMesg - 1).getText();*/
			messageText = textMessages.get(noOfMesg - 1).getText();
			System.out.println("Text Message actual:" + messageText);
			
			 /* for(int i=1;i==noOfMesg;i++){
			  System.out.println("telhasf "+textMessages.get(i).getText()); }*/
			 
			//messageText = textMessages.get(noOfMesg - 1).getText();
			String splitMessage[] =messageText.split(" ");
			String OTP= splitMessage[0].substring(0, 6);
			System.out.println("Text Message actual:" + textMessages.get(noOfMesg - 1).getText());
			System.out.println("OTP: " + OTP);
			for (WebElement message : textMessages) {
				System.out.println("Text Message :" + message.getText());
			}
			
			System.out.println(OTP);
			
			
			
			CustomMethods.waitForElementPresent(forgotPasswordImplPage.getEnterOTPfield(),5);
			
			forgotPasswordImplPage.getEnterOTPfield().sendKeys(OTP);
			forgotPasswordImplPage.getForgotPasswordConfirmButton().click();
			
			verifyPresent(forgotPasswordImplPage.getNewPasswordField(), "Reset Password Page displayed");
			forgotPasswordImplPage.getNewPasswordField().sendKeys("Ace2three@");
			forgotPasswordImplPage.getConfirmPasswordField().sendKeys("Ace2three@");
			forgotPasswordImplPage.getResetPasswordButton().click();
			
			verifyText(forgotPasswordImplPage.getPswdChangedSuccessfullyStatusText().getText(),"Congrats, Your password has been changed successfully.");
			
		}
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {

		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			logger.log(LogStatus.FAIL, result.getThrowable());
			/*System.out.println(Thread.currentThread().getStackTrace());
			boolean abc= Thread.currentThread().getStackTrace().toString().contains("GamePlayPlayer2ImplPage");*/
			//System.out.println("boolean is:" + abc);
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			
			
			
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver)driver).resetApp();
		
		
	}

}
