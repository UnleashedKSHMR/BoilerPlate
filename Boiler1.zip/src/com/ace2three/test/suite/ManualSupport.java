package com.ace2three.test.suite;

import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.OCREngine;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class ManualSupport extends BaseTestSuite {
	
	
	 private File imgDir; 
	
	@BeforeMethod
	public void beforeMethos(Method method) {
		
		Test test = method.getAnnotation(Test.class);
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
	} 
	
	@SuppressWarnings("rawtypes")
	@Test(description = "TS_Login_1 - Verify that all the available objects are visible on Public landing page.",priority=1)
	public void Login_1() throws InterruptedException, IOException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		launchImplPage.getLoginButon().click();
		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		verifyPresent(launchImplPage.getpasswordField(), "Password field");
		
		OCREngine ocr = new OCREngine((AppiumDriver) driver);
		//location of screenshots
        File classpathRoot = new File(System.getProperty("user.dir"));
        imgDir = new File(classpathRoot, "/SourceImages");
		launchImplPage.getUsernameField().sendKeys("gpic50");
		for(int i =0;i<30;i++)
		{
			System.out.println(i);
			
			launchImplPage.getpasswordField().sendKeys("Ace2three@");	
			launchImplPage.getLoginClickButton().click();
			CustomMethods.waitForElementPresent(lobbyImplPage.getPlpBannerCloseIcon(), 15);
			lobbyImplPage.verifyPostLaunchBanners();
			lobbyImplPage.verifyLobbyPageDisplayed();	
			CustomMethods.waitForElementPresent(lobbyImplPage.getHamburgerMenu(), 12);
			lobbyImplPage.getHamburgerMenu().click();
			
			String MyAccount= imgDir + "/MyAccount.png";
			String Logout= imgDir + "/logout.png";
			
			ocr.waitUntilImageExists(Logout, 10);
			ocr.clickByImage(Logout);
			
			lobbyImplPage.getLogoutAlertPopupYesButton().click();
			
		}

		
	}
	
	
	
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			logger.log(LogStatus.FAIL, result.getThrowable());
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		extent.endTest(logger);
		((AppiumDriver) driver).resetApp();
	}

}
