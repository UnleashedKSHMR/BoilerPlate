package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.app.webview.impl.pages.RedeemAcePointsWebImplPage;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.KycImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.MyAccountDetailsImplPage;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.RedeemFromMobileImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MyAccountDetailstestSuite extends BaseTestSuite{
	
		DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
		Date date = new Date();
		ReadDataFromProps ReadProps;
	
		@BeforeMethod
		public void beforeMethos(Method method) throws IOException {
			Test test = method.getAnnotation(Test.class);
			
			System.out.println("system property" + System.getProperty("deviceName"));
			super.logger = extent.startTest(method.getName()+" : " +test.description());
			System.out.println("Before Method");
			ReadProps= new ReadDataFromProps();
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			launchImplPage.verifyUpgradePopup();
		}
	
		@Test(description = "For regular user when click on redeem , it should display \"This feature is available only for premium players.\"", priority=1)
		public void TS_Sanity__AccountDetails_01() throws InterruptedException, IOException {
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			
			
			/*if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
				launchImplPage.getLoginButon().click();
			}*/
			SignupImplPage signupImplPage = new SignupImplPage(driver);
			signupImplPage.doSignUp();
			
			LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		
			myAccountImplPage.launchMyAccountDetailsScreen();
			myAccountImplPage.getPasswordPopUpField().sendKeys("ace2three");
			myAccountImplPage.getPasswordPopUpSubmitButton().click();
			
			myAccountImplPage.verifyMyAccountDetailsScreenDisplayed();
		//	myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
			MyAccountDetailsImplPage myAccountpage = new MyAccountDetailsImplPage(driver);
			verifyText(myAccountpage.getRealChipsRedeemableBalance().getText(), "0");
			verifyText(myAccountpage.getBonusPendingValue().getText(), "0");
			verifyText(myAccountpage.getAcePointsBalance().getText(), "0");
			verifyText(myAccountpage.getAceLevel().getText(), "NA");
			verifyText(myAccountpage.getAceLevelUpgradeValue().getText(), "-");
		
			verifyPresent(myAccountpage.getRedeemButton(),"Redeem Button");
			myAccountpage.getRedeemButton().click();
			verifyText(myAccountpage.getThisFeatureIsOnlyForPremiumPlayer().getText(),ReadProps.props.getProperty("my.account.redeem.ace.points.for.premium.players.message"));
			CustomMethods.disconnectAndReconnect();
			myAccountpage.getRedeemButton().click();
			verifyText(myAccountpage.getThisFeatureIsOnlyForPremiumPlayer().getText(),ReadProps.props.getProperty("my.account.redeem.ace.points.for.premium.players.message"));
			/*verifyTextPresent(MyAccountpage.getredirectAlertForRedeemMessage(),ReadProps.props.getProperty("web.redirect.to.redeem.alert.message"));
			MyAccountpage.getredirectAlertForRedeemYes().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Chrome')]")).click();
			Thread.sleep(5000);
			//System.out.println("Page Souredce" + driver.getPageSource());
			//WebElement we = driver.findElement(By.xpath("//android.view.View[contains(@content-desc,'You must verify')]"));
			WebElement we = driver.findElement(By.xpath("//android.view.View[contains(@text,'You must verify')]"));
			System.out.println("details" + we.getText());
			//verifyText( we.getAttribute("name"), ReadProps.props.getProperty("web.profile.incomplete.message.in.redeem"));
			verifyText( we.getText(), ReadProps.props.getProperty("web.profile.incomplete.message.in.redeem"));
			*/
			
		}
		
		@Test(description = "For Premium user when click on redeem , it should navigate to web browser and user should be allowed to redeem if KYC is verified", priority=2)
		public void TS_Sanity__AccountDetails_02() throws InterruptedException, IOException {
			
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			
			if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
				launchImplPage.getLoginButon().click();
			}
			launchImplPage.getUsernameField().sendKeys("kycverified");
			launchImplPage.getpasswordField().sendKeys("ace2three@");
			launchImplPage.getLoginClickButton().click();
			LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			lobbyImplPage.verifyLobbyPageDisplayed();
			
			MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
			MyAccountDetailsImplPage myAccountDetailsImplPage = new MyAccountDetailsImplPage(driver);
			myAccountPage.launchMyAccountDetailsScreen();
			myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
			myAccountPage.getPasswordPopUpSubmitButton().click();
			
			myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		//	myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
			MyAccountDetailsImplPage MyAccountpage = new MyAccountDetailsImplPage(driver);
			verifyNotPresent(myAccountDetailsImplPage.getEnterReferralCodeField(),"Enter Referral Code Field",3);
			verifyPresent(MyAccountpage.getRedeemButton(),"Redeem Button");
			MyAccountpage.getRedeemButton().click();
			RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
			verifyPresent(redeemFromMobileImplPage.getRedeemTab(), "Redeem");
			myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
			myAccountPage.verifyMyAccountDetailsScreenDisplayed();
			verifyPresent(MyAccountpage.getKycClickHereLink(), "KYC Navigation Link");
			MyAccountpage.getKycClickHereLink().click();
			KycImplPage kycImplPage = new KycImplPage(driver);
			verifyPresent(kycImplPage.getKycEmailField(), "KYC screen");
			
		}
		
		
		@Test(description = "Click on “Buy chips” and verify web pop is displayed to but chips also verify amount has added into user wallet", priority=3)
		public void TS_Sanity__AccountDetails_03() throws InterruptedException, IOException {
	
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			
			if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
				launchImplPage.getLoginButon().click();
			}
			launchImplPage.getUsernameField().sendKeys("nani2");
			launchImplPage.getpasswordField().sendKeys("ace2three@");
			launchImplPage.getLoginClickButton().click();
			LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
			
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			lobbyImplPage.verifyLobbyPageDisplayed();
					
			MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
			myAccountPage.launchMyAccountDetailsScreen();
			myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
			myAccountPage.getPasswordPopUpSubmitButton().click();
			
			myAccountPage.verifyMyAccountDetailsScreenDisplayed();
			myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
			MyAccountDetailsImplPage MyAccountpage = new MyAccountDetailsImplPage(driver);
			
			String realChipsBefore = lobbyImplPage.getNoOfRealChipsCount().getText().toString();
			
			verifyPresent(MyAccountpage.getBuyChipsButton(),"Buy chips Button");
			MyAccountpage.getBuyChipsButton().click();
			Thread.sleep(2000);
			if(CustomMethods.isElementPresent(MyAccountpage.getReCheckButton())){
				if(MyAccountpage.getAcknowledgeCheckBox().getAttribute("checked").equalsIgnoreCase("true")){
					
				}else{
					MyAccountpage.getAcknowledgeCheckBox().click();
				}
				MyAccountpage.getAddCashButton().click();
			}
			
			MyAccountpage.getAddAmountField().clear();
			//MyAccountpage.getAddAmountField().sendKeys("200");
			System.out.println(MyAccountpage.getLastPaymentMethod().getText());
			
			/*if(!MyAccountpage.getLastPaymentMethod().getText().contains("AXIS")){
				System.out.println("into select banking if cond");
				MyAccountpage.getChangePaymentMode().click();
				MyAccountpage.getNetBankingOption().click();
				MyAccountpage.getAxisBankOption().click();
				MyAccountpage.getPayNowButton().click();
				MyAccountpage.getAxisPayButton().click();
				
			}else{
				MyAccountpage.getPayNowButton().click();
				MyAccountpage.getAxisPayButton().click();
				
			}*/
			AddCashWebViewImplPage addCashWebViewImplPage= new  AddCashWebViewImplPage(driver);
			addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
					verifyText(MyAccountpage.getChipsAddedSuccesMessage().getText(),
					ReadDataFromProps.props.getProperty("add.chips.success.message.in.webview"));
			
			MyAccountpage.getCloseBuyChipsWebview().click();
			
			/*//driver.context("WEBVIEW");
			 Set<String> contextNames = ((AndroidDriver) driver).getContextHandles();
			 for (String contextName : contextNames) {
	            System.out.println(contextNames); //prints out something like NATIVE_APP \n WEBVIEW_1
	            	if(contextName.contains("WEBVIEW")){
	            		((AndroidDriver) driver).context(contextName);
	            		System.out.println(driver.getPageSource());
	            	}
	        }*/
			
			String[] realChipsBefore1 = realChipsBefore.split("\\.");
			
			int beforeChips= Integer.parseInt(realChipsBefore1[0]);
			
			String realChipsAfter = lobbyImplPage.getNoOfRealChipsCount().getText().toString();
			String[] realChipsAfter1 = realChipsAfter.split("\\.");
			int afterChips= Integer.parseInt(realChipsAfter1[0]);
			System.out.println(realChipsAfter+ " : afterchips");
			int addedChips = afterChips-beforeChips;
			System.out.println("added chips"+ addedChips);
			
			if(addedChips==200 && afterChips!=beforeChips){
				logger.log(LogStatus.PASS, "Amount has added into user wallet & Correct amount has added");
			}if(addedChips!=200 && afterChips!=beforeChips){
				logger.log(LogStatus.PASS, "Amount has added into user wallet but InCorrect amount of Real chips has added");
			}if(afterChips==beforeChips){
				logger.log(LogStatus.FAIL, "Amount has not added into user wallet");
			}
			
		}
		
		@Test(description = "Click on”Redeem Ace Points” and verify user should navigate to web browser to redeem AcePoints screen", priority=4)
		public void TS_Sanity__AccountDetails_04() throws InterruptedException, IOException {
			
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			
			if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
				launchImplPage.getLoginButon().click();
			}
			launchImplPage.getUsernameField().sendKeys("nani2");
			launchImplPage.getpasswordField().sendKeys("ace2three@");
			launchImplPage.getLoginClickButton().click();
			LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			lobbyImplPage.verifyLobbyPageDisplayed();
			MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
			myAccountPage.launchMyAccountDetailsScreen();
			myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
			myAccountPage.getPasswordPopUpSubmitButton().click();
			
			myAccountPage.verifyMyAccountDetailsScreenDisplayed();
			myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
			MyAccountDetailsImplPage MyAccountpage = new MyAccountDetailsImplPage(driver);
			verifyPresent(MyAccountpage.getRedeemAcePointsButton(),"Redeem ace points Button");
			MyAccountpage.getRedeemAcePointsButton().click();
			verifyPresent(MyAccountpage.getredirectAlertForRedeemYes(),"Redeem ace points web page");
			MyAccountpage.getredirectAlertForRedeemYes().click();
			Thread.sleep(2000);
			if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
			{
				driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Chrome')]")).click();
			}
			else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
			{
				driver.findElement(By.id("button_once")).click();
			}
			
			Thread.sleep(5000);
			//System.out.println("Page Source" + driver.getPageSource());
			RedeemAcePointsWebImplPage acePointsWebImplPage = new RedeemAcePointsWebImplPage(driver);
			verifyPresent(acePointsWebImplPage.getRedeemAcePointsHeader(),"Redeem ace points page");
			verifyPresent(acePointsWebImplPage.getRedeemAcePointsPurchaseButton(),"Redeem with purchase button");
		}
		
		@Test(description = "Click on”Redeem Ace Points” and verify user should navigate to web browser to redeem AcePoints screen - premium user with no balance", priority=5)
		public void TS_Sanity__AccountDetails_05() throws InterruptedException, IOException {
			
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
				launchImplPage.getLoginButon().click();
			}
			launchImplPage.getUsernameField().sendKeys("appium11");
			launchImplPage.getpasswordField().sendKeys("ace2three@");
			launchImplPage.getLoginClickButton().click();
			LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			lobbyImplPage.verifyLobbyPageDisplayed();
			MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
			myAccountPage.launchMyAccountDetailsScreen();
			myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
			myAccountPage.getPasswordPopUpSubmitButton().click();
			
			myAccountPage.verifyMyAccountDetailsScreenDisplayed();
			myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
			MyAccountDetailsImplPage MyAccountpage = new MyAccountDetailsImplPage(driver);
			verifyPresent(MyAccountpage.getRedeemAcePointsButton(),"Redeem ace points Button");
			MyAccountpage.getRedeemAcePointsButton().click();
			verifyPresent(MyAccountpage.getredirectAlertForRedeemYes(),"Redeem ace points web page");
			MyAccountpage.getredirectAlertForRedeemYes().click();
			Thread.sleep(2000);
			if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
			{
				driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Chrome')]")).click();
			}
			else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
			{
				driver.findElement(By.id("button_once")).click();
			}
			Thread.sleep(10000);
			//System.out.println("Page Source" + driver.getPageSource());
			RedeemAcePointsWebImplPage acePointsWebImplPage = new RedeemAcePointsWebImplPage(driver);
			verifyPresent(acePointsWebImplPage.getRedeemAcePointsHeader(),"Redeem ace points page");
			verifyPresent(acePointsWebImplPage.getRedeemAcePointsPurchaseButton(),"Redeem with purchase button");
			/*verifyText(acePointsWebImplPage.getInSufficientMessage().getAttribute("name"), 
					ReadDataFromProps.props.getProperty("redeem.acepoints.insufficient.message"));*/
			verifyText(acePointsWebImplPage.getInSufficientMessage().getText(), 
					ReadDataFromProps.props.getProperty("redeem.acepoints.insufficient.message"));
			
		} 
		@Test(description = "Click on”Redeem Ace Points” and verify dialog box should be displayed saying this feature is only for premium users"
				+ " - Regular user &", priority=6)
		public void TS_Sanity__AccountDetails_06() throws InterruptedException, IOException {
			
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
				launchImplPage.getLoginButon().click();
			}
			launchImplPage.getUsernameField().sendKeys("appium40");
			launchImplPage.getpasswordField().sendKeys("ace2three");
			launchImplPage.getLoginClickButton().click();
			LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			WebElement specialOffer = driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'special_offer_iv')]"));
			if(!CustomMethods.isElementPresent(specialOffer))
			verifyPresent(lobbyImplPage.getRegularPlayerPostLoginBuyChipsPop(),"Sorry, This app is only for real chip games");
			if(CustomMethods.isElementPresent(lobbyImplPage.getRegularPlayerPostLoginBuyChipsPop()))
			{
				lobbyImplPage.getRegularPlayerPostLoginBuyChipsButton().click();
				driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]")).click();
			}
			lobbyImplPage.verifyLobbyPageDisplayed();
			MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
			myAccountPage.launchMyAccountDetailsScreen();
			myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
			myAccountPage.getPasswordPopUpSubmitButton().click();
			
			myAccountPage.verifyMyAccountDetailsScreenDisplayed();
			myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
			MyAccountDetailsImplPage MyAccountpage = new MyAccountDetailsImplPage(driver);
			verifyPresent(MyAccountpage.getRedeemAcePointsButton(),"Reddem ace points Button");
			MyAccountpage.getRedeemAcePointsButton().click();
			verifyPresent(MyAccountpage.getRedeemOnlyForPremiumPlayersDialog(),"Redeem only for premium players");
			verifyTextPresent(MyAccountpage.getRedeemOnlyForPremiumPlayersDialog(), 
					ReadDataFromProps.props.getProperty("my.account.redeem.ace.points.for.premium.players.message"));
			MyAccountpage.getRedeemOnlyForPremiumPlayersDialogNoThanks().click();
			myAccountPage.verifyMyAccountDetailsScreenDisplayed();
			MyAccountpage.getRedeemAcePointsButton().click();
			MyAccountpage.getRedeemOnlyForPremiumPlayersDialogBuyChips().click();
			AddCashWebViewImplPage addCashWebViewImplPage=new AddCashWebViewImplPage(driver);
			verifyPresent(addCashWebViewImplPage.getAddCashPageHeader(), "Add cash web view page");
			
		}
		
		@Test(description="Ace points should be updated with 20 ace points with \"claim now\" link after successfull establishment", priority=7)
		public void TS_Sanity__AccountDetails_07() throws InterruptedException, IOException {
			
			
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);	
			SignupImplPage signupimplpage = new SignupImplPage(driver);
			verifyPresent(launchImplPage.getLoginButon(), "SignUp screen");
			DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
			Date date = new Date();
			dateFormat.format(date);
			String Username= "test" + dateFormat.format(date);
			String Password = "hello"+dateFormat.format(date);
			logger.log(LogStatus.INFO, Username);
			logger.log(LogStatus.INFO, Password);
			signupimplpage.getUsernamefield().sendKeys(Username);
			signupimplpage.getEmailidfield().sendKeys("em"+Username+"@ds.com");
			signupimplpage.getPasswordfield().sendKeys(Password);
			launchImplPage.getHaveAReferralCodeLink().click();
			launchImplPage.getEnterReferralCodeField().sendKeys(ReadDataFromProps.props.getProperty("regular.user.referral.code"));
			launchImplPage.getSignUpButton().click();
			
			LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Account Details").click();
			MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
			verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Enter password popup");
			myAccountImplPage.getPasswordPopUpField().sendKeys(Password);
			myAccountImplPage.getPasswordPopUpSubmitButton().click();
			MyAccountDetailsImplPage myAccountDetailsImplPage = new MyAccountDetailsImplPage(driver);
 			verifyPresent(myAccountDetailsImplPage.getAcePointsBalance(), "Account Details Screen");
 			verifyText(myAccountDetailsImplPage.getAcePointsBalance().getText(), "20");
 			verifyPresent(myAccountDetailsImplPage.getClaimNowLink(), "Claim Now Link");
 			myAccountDetailsImplPage.getClaimNowLink().click();
 			verifyPresent(myAccountDetailsImplPage.getYouNeedToBeAPremiumUserPopUp(), "You need to be a premium user pop up");
 			verifyText(myAccountDetailsImplPage.getYouNeedToBeAPremiumUserPopUp().getText(), "You need to be a premium user to avail this bonus. Make a purchase now to claim your rewards.",  "You need to be a premium user pop up");
 			verifyPresent(myAccountDetailsImplPage.getBuyNowButton(), "Buy Now Button");
 			verifyPresent(myAccountDetailsImplPage.getNotNowButton(), "Not Now Button");
 			myAccountDetailsImplPage.getNotNowButton().click();
 			lobbyImplPage.getHomeTabIcon().click();
			lobbyImplPage.getAddChipsButton().click();
			AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
			addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
			CustomMethods.waitForElementPresent(lobbyImplPage.getLevelUpAlertMessage());
			verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
			verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
					ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
			lobbyImplPage.getLevelUpAlertOkButton().click();
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			lobbyImplPage.verifyLobbyPageDisplayed();
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Account Details").click();
			
			verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Enter password popup");
			myAccountImplPage.getPasswordPopUpField().sendKeys(Password);
			myAccountImplPage.getPasswordPopUpSubmitButton().click();
			
 			verifyPresent(myAccountDetailsImplPage.getAcePointsBalance(), "Account Details Screen");
 			verifyText(myAccountDetailsImplPage.getAcePointsBalance().getText(), "20");
 			verifyNotPresent(myAccountDetailsImplPage.getClaimNowLink(), "Claim Now Link",2);
			
 			
			
		}
		
		@Test(description="Verify enter referral code functionality for Pseudo user", priority=8)
		public void TS_Sanity__AccountDetails_08() throws InterruptedException, IOException, SQLException {
			String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
			try {
				dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
			} catch (InterruptedException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
			String clearDeviceIds = "update game_user_master set phone_verified='N' where user_code in (select bonus_claimed from device_details)";
			String deleteDevicesDetails="delete from device_details";
			dataBaseConnection = new DataBaseServerConnect();
			dataBaseConnection.updateQuery(clearDeviceIds, null);
			dataBaseConnection.updateQuery(deleteDevicesDetails, null);
			
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);	
			SignupImplPage signupimplpage = new SignupImplPage(driver);
			verifyPresent(launchImplPage.getLoginButon(), "SignUp screen");
			DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
			Date date = new Date();
			dateFormat.format(date);
			String Username= "test" + dateFormat.format(date);
			String Password = "hello"+dateFormat.format(date);
			logger.log(LogStatus.INFO, Username);
			logger.log(LogStatus.INFO, Password);
			signupimplpage.getUsernamefield().sendKeys(Username);
			signupimplpage.getEmailidfield().sendKeys("8463932054");
			signupimplpage.getPasswordfield().sendKeys(Password);
			launchImplPage.getSignUpButton().click();
			Thread.sleep(5000);
			LobbyImplPage lobbyImplPage = new LobbyImplPage();
	
			WebElement ele = driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]"));
			CustomMethods.waitForElementPresent(ele,5);
			ele.click();
			lobbyImplPage.getSendOTPButton().click();
			DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
			String OTP =dataBaseServerConnect.selectQuery(null, Username);
			lobbyImplPage.getEnterOTPField().sendKeys(OTP);
			lobbyImplPage.getConfirmOTPButton().click();
			lobbyImplPage.getTakeMeToLobbyButton().click();
			verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
			verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
					ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
			//verifyPresent(lobbyImplPage.getAchievedBroonzeLevelOkButton(), "Achieved Broonze Level PopUp");
			lobbyImplPage.getAchievedBroonzeLevelOkButton().click();
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Account Details").click();
			MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
			verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Enter password popup");
			myAccountImplPage.getPasswordPopUpField().sendKeys(Password);
			myAccountImplPage.getPasswordPopUpSubmitButton().click();
			MyAccountDetailsImplPage myAccountDetailsImplPage = new MyAccountDetailsImplPage(driver);
 			verifyPresent(myAccountDetailsImplPage.getAcePointsBalance(), "Account Details Screen");
 			verifyText(myAccountDetailsImplPage.getAcePointsBalance().getText(), "0");
 			myAccountDetailsImplPage.getEnterReferralCodeField().sendKeys("~!@#$%^&*()_+=-`[]{}:\\|;'<>?,./'");
 			String specialCharacter = myAccountDetailsImplPage.getEnterReferralCodeField().getText();
 			if(!specialCharacter.contains("~!@#$%^&*()_+=-`[]{}:\\\\\\\\|;'<>?,./'"))
 				logger.log(LogStatus.PASS, "Special Characters are not allowing in enter referral code field");
 			else
 				logger.log(LogStatus.FAIL,  "Special Characters are allowing in enter referral code field");
 			myAccountDetailsImplPage.getEnterReferralCodeField().clear();
 			myAccountDetailsImplPage.getEnterReferralCodeField().sendKeys(ReadDataFromProps.props.getProperty("regular.user.referral.code"));
 			myAccountDetailsImplPage.getApplyButton().click();
 			CustomMethods.waitForElementPresent(myAccountDetailsImplPage.getAcePointsBalance(),10);
 			verifyText(myAccountDetailsImplPage.getAcePointsBalance().getText(), "20");
 			verifyNotPresent(myAccountDetailsImplPage.getEnterReferralCodeField(), "Enter Referral Code Field", 3);
 			verifyPresent(myAccountDetailsImplPage.getClaimNowLink(), "Claim Now Link");
 			myAccountDetailsImplPage.getClaimNowLink().click();
 			verifyPresent(myAccountDetailsImplPage.getYouNeedToBeAPremiumUserPopUp(), "You need to be a premium user pop up");
 			verifyText(myAccountDetailsImplPage.getYouNeedToBeAPremiumUserPopUp().getText(), "You need to be a premium user to avail this bonus. Make a purchase now to claim your rewards.",  "You need to be a premium user pop up");
 			verifyPresent(myAccountDetailsImplPage.getBuyNowButton(), "Buy Now Button");
 			verifyPresent(myAccountDetailsImplPage.getNotNowButton(), "Not Now Button");
 			myAccountDetailsImplPage.getNotNowButton().click();
 			lobbyImplPage.getHomeTabIcon().click();
			lobbyImplPage.getAddChipsButton().click();
			AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
			addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			lobbyImplPage.verifyLobbyPageDisplayed();
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Account Details").click();
			
			verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Enter password popup");
			myAccountImplPage.getPasswordPopUpField().sendKeys(Password);
			myAccountImplPage.getPasswordPopUpSubmitButton().click();
			
 			verifyPresent(myAccountDetailsImplPage.getAcePointsBalance(), "Account Details Screen");
 			verifyText(myAccountDetailsImplPage.getAcePointsBalance().getText(), "20");
 			verifyNotPresent(myAccountDetailsImplPage.getClaimNowLink(), "Claim Now Link",2);
			
 			
			
		}
		
		
		
		@AfterMethod
		public void afterMethod(Method method, ITestResult result) throws IOException {
			
			if (!(result.getStatus() == ITestResult.SUCCESS)) {
				RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
				recoveryManagement.handleTextMessageAlert();
				logger.log(LogStatus.FAIL, result.getThrowable());
				logger.log(LogStatus.PASS, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
			extent.flush();
			extent.endTest(logger);
			((AppiumDriver) driver).resetApp();
		}
}
