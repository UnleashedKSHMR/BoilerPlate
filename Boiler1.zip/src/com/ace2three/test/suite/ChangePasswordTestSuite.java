package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.tools.ant.types.resources.selectors.InstanceOf;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.app.webview.impl.pages.UpdateProfileWebViewImplPage;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.ChangePasswordImplPage;
import com.ace2three.impl.pages.ForgotPasswordImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.locators.AndroidLocators.ChangePasswordPageLocators;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import sun.security.jca.GetInstance.Instance;

public class ChangePasswordTestSuite extends BaseTestSuite {
	
	CustomMethods cm;
	ReadDataFromProps ReadProps;
	WebDriver desktopDriver;
	String userName;
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		
		
		Test test = method.getAnnotation(Test.class);
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
	}
	
	
	@Test(description = "Verify whether SMS and Email is sent to the user after successfully changing their password.", priority=1)
	public void TS_Sanity__ChangePassword_01() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		 this.userName=signupImplPage.doSignUpWithPhoneNumber();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
		CustomMethods.waitForElementPresent(lobbyImplPage.getLevelUpAlertMessage(), 10);
		verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
				ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
		lobbyImplPage.getLevelUpAlertOkButton().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		Thread.sleep(5000);
		new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		WebElement changePasswordElement=lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Change Password");
		verifyPresent(changePasswordElement, "Change Password in Hamburger Menu");
		changePasswordElement.click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(changePasswordImplPage.getCurrentPasswordfield(), "Change Password screen");
		changePasswordImplPage.getCurrentPasswordfield().sendKeys("ace2three");
		changePasswordImplPage.getNewPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getSubmitButton().click();
		CustomMethods.waitForElementPresent(changePasswordImplPage.getChangePasswordStatusText(),30);
		verifyText(changePasswordImplPage.getChangePasswordStatusText().getText(),"Congrats, your password has been changed successfully.");
		changePasswordImplPage.getChangePasswordStatusOkButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
		verifyPresent(launchImplPage.getUsernameField(), "Login page displayed");
		verifyText(changePasswordImplPage.getYourPswdHasBeenChangedMsgAtLoginScreen().getText(), "Your password has been changed successfully. Please Login to continue");
		
		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(5000);
		((AndroidDriver) driver).openNotifications();

		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'AM-ACEACT')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 1");
		}
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'New messages')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 2");
		}

		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();

		List<WebElement> textMessages = driver
				.findElements(By.xpath("//android.widget.TextView[contains(@text,'your password on Ace2Three')]"));
		int noOfMesg = textMessages.size();
		System.out.println(noOfMesg);
		String messageText;
		if(noOfMesg==1)
		messageText = textMessages.get(0).getText();
		else
		messageText = textMessages.get(noOfMesg-1).getText();
		/*String splitMessage[] =messageText.split(" ");
		String OTP= splitMessage[0].substring(0, 6);
		*/
		System.out.println("Text Message actual:" + messageText);
		
		/*for (WebElement message : textMessages) {
			System.out.println("Text Message :" + message.getText());
		}*/
		//System.out.println(messageText);
		 try {((AndroidDriver) driver).runAppInBackground(2);
	        } catch (Exception e) {//ignore} 
	        	
	        }
		 
		 String actualMesg="Dear "+this.userName+", your password on Ace2Three has been successfully changed. Please reach out to our customer care at 040-66061234 for any concerns. Thanks Team Ace2Three.";
		 verifyText(messageText, actualMesg);
	}
	
	@Test(description = "Verify whether Current,New Confirm password test fields have Show,Hide buttons"
			+ "Verify whether ‘Password length should be minimum 8 characters’ alert message is displayed", priority=1)
	public void TS_Sanity__ChangePassword_02() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys(this.userName);
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		Thread.sleep(5000);
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Change Password").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(changePasswordImplPage.getCurrentPasswordfield(),10);
		verifyPresent(changePasswordImplPage.getCurrentPasswordfield(), "Change Password screen is displayed");
		changePasswordImplPage.getCurrentPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getNewPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("Ace2three@");
		verifyPresent(changePasswordImplPage.getNewPasswordShowButton(), "New password show button");
		verifyPresent(changePasswordImplPage.getCurrentPasswordShowButton(), "Current password show button");
		verifyPresent(changePasswordImplPage.getConfirmPasswordShowButton(), "Confirm password show button");
		
		/*changePasswordImplPage.getNewPasswordShowButton().click();
		changePasswordImplPage.getConfirmPasswordShowButton().click();*/
		if(changePasswordImplPage.getCurrentPasswordfield().getText().equals(""))
		{
			changePasswordImplPage.getCurrentPasswordShowButton().click();
			if(verifyText(changePasswordImplPage.getCurrentPasswordfield().getText(), "Ace2three@"))
			{
				logger.log(LogStatus.PASS, "Show/Hide button is working as expected");
			}
		}
		else if(changePasswordImplPage.getCurrentPasswordfield().getText().equals("Ace2three@"))
		{
			changePasswordImplPage.getCurrentPasswordShowButton().click();
			if(verifyText(changePasswordImplPage.getCurrentPasswordfield().getText(), ""))
				logger.log(LogStatus.PASS, "Show/Hide button is working as expected");
		}
		if(changePasswordImplPage.getNewPasswordfield().getText().equals(""))
		{
			changePasswordImplPage.getNewPasswordShowButton().click();
			if(verifyText(changePasswordImplPage.getNewPasswordfield().getText(), "Ace2three@"))
			{
				logger.log(LogStatus.PASS, "Show/Hide button is working as expected");
			}
		}
		else if(changePasswordImplPage.getNewPasswordfield().getText().equals("Ace2three@"))
		{
			changePasswordImplPage.getNewPasswordShowButton().click();
			if(verifyText(changePasswordImplPage.getNewPasswordfield().getText(), ""))
				logger.log(LogStatus.PASS, "Show/Hide button is working as expected");
		}
		if(changePasswordImplPage.getConfirmPasswordfield().getText().equals(""))
		{
			changePasswordImplPage.getConfirmPasswordShowButton().click();
			if(verifyText(changePasswordImplPage.getConfirmPasswordfield().getText(), "Ace2three@"))
				logger.log(LogStatus.PASS, "Show/Hide button is working as expected");
		}
		else if(changePasswordImplPage.getConfirmPasswordfield().getText().equals("Ace2three@"))
		{
			changePasswordImplPage.getConfirmPasswordShowButton().click();
			if(verifyText(changePasswordImplPage.getConfirmPasswordfield().getText(), ""))
				logger.log(LogStatus.PASS, "Show/Hide button is working as expected");
		}
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("same current password and new password", 
		ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.current.password.as.new.password"));
		changePasswordImplPage.getNewPasswordfield().sendKeys("sfdd");
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("sfdd");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("Entered password is less than 8 characters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.less.than.minimum.characters.as.password"));
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("Entered empty password as current password", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.empty.current.password"));
		changePasswordImplPage.getCurrentPasswordfield().sendKeys("asdfsadf");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("Entered empty password as new password", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.empty.new.password"));
		changePasswordImplPage.getNewPasswordfield().sendKeys("asdasfasd");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("Entered empty password as confirm password", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.empty.confirm.password"));
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("asdgfasd");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("Entered unmatched current password", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.current.password"));
		changePasswordImplPage.getCurrentPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("Entered unmatched new and confirm password", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"));
		
	}
	@Test(description = "Optional Change password pop-up window checks after successful login", priority=1)
	public void TS_Sanity__ChangePassword_03() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
		desktopDriver.get(ReadProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
		executor.executeScript("document.body.style.zoom = '0.9'");
		
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list)
		{
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(this.userName);
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
			
		JavascriptExecutor execu = (JavascriptExecutor)desktopDriver;
		WebElement searchElement= desktopDriver.findElement(By.cssSelector("input[id='openPopUp']"));
		execu.executeScript("arguments[0].click();", searchElement );
			
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		Select contactMode = new Select(desktopDriver.findElement(By.cssSelector("select[id='contactmode']")));
		contactMode.selectByIndex(1);
		
		Select interactionChannel = new Select(desktopDriver.findElement(By.id("ContactChannel")));
		interactionChannel.selectByIndex(1);
		
		desktopDriver.findElement(By.cssSelector("textarea[id='commentForPasswordChange']")).sendKeys("sdasfdf");
		
		Select enforcementDays = new Select(desktopDriver.findElement(By.id("enforceDays")));
		enforcementDays.selectByIndex(2);
		JavascriptExecutor exec = (JavascriptExecutor)desktopDriver;
		WebElement submitButton= desktopDriver.findElement(By.cssSelector("input[value='Submit']"));
		exec.executeScript("arguments[0].click();", submitButton );
		
		//desktopDriver.close();
		
		launchImplPage.getUsernameField().sendKeys(this.userName);
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		Thread.sleep(2000);
		if(CustomMethods.isElementPresent(lobbyImplPage.getPlpBannerCloseIcon()))
		{
			lobbyImplPage.getPlpBannerCloseIcon().click();
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		
		CustomMethods.waitForElementPresent(changePasswordImplPage.getChangeYourPswdPopUpHeader(),10);
		verifyPresent(changePasswordImplPage.getChangeYourPswdPopUpHeader(), "Change Your Password Pop Up 1st login ");
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date(System.currentTimeMillis() + 86400 * 1000 * 2); 
		String date1 = dateFormat.format(date);
	
		
		verifyText(changePasswordImplPage.getPswdExpireText().getText(),
				ReadDataFromProps.props.getProperty("change.password.pop.up.text.message.for.password.expire")+" "+date1);
		
		verifyPresent(changePasswordImplPage.getChangeYourPswdPopUpCloseButton(), "Change Your Password Close Button");
		verifyPresent(changePasswordImplPage.getNotNowButton(), "No Thanks Button");
		
		changePasswordImplPage.getNotNowButton().click();
		lobbyImplPage.verifyPostLaunchBanners();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
		launchImplPage.getUsernameField().sendKeys(this.userName);
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		lobbyImplPage.verifyPostLaunchBanners();
		CustomMethods.waitForElementPresent(changePasswordImplPage.getChangeYourPswdPopUpHeader(),30);
		verifyPresent(changePasswordImplPage.getChangeYourPswdPopUpHeader(), "Change Your Password Pop Up on 2nd login ");
		changePasswordImplPage.getChangeNowButton().click();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getNewPasswordfield().sendKeys("Ace2three$");
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("Ace2three$");
		changePasswordImplPage.getSubmitButton().click();
		Thread.sleep(2000);
		changePasswordImplPage.getChangePasswordStatusOkButton().click();
		verifyPresent(launchImplPage.getLoginButon(), "Login Screen");
		
		
		
		
	}
	
	@Test(description = "Mandatory Change password pop-up window checks after successful login", priority=1)
	public void TS_Sanity__ChangePassword_04() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		
		/*CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
		desktopDriver.get(ReadProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
		executor.executeScript("document.body.style.zoom = '0.9'");
		
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list)
		{
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(this.userName);
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
		
		JavascriptExecutor execu = (JavascriptExecutor)desktopDriver;
		WebElement searchElement= desktopDriver.findElement(By.cssSelector("input[id='openPopUp']"));
		execu.executeScript("arguments[0].click();", searchElement );
			
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		Select contactMode = new Select(desktopDriver.findElement(By.cssSelector("select[id='contactmode']")));
		contactMode.selectByIndex(1);
		
		Select interactionChannel = new Select(desktopDriver.findElement(By.id("ContactChannel")));
		interactionChannel.selectByIndex(1);
		
		desktopDriver.findElement(By.cssSelector("textarea[id='commentForPasswordChange']")).sendKeys("sdasfdf");
		
		Select enforcementDays = new Select(desktopDriver.findElement(By.id("enforceDays")));
		enforcementDays.selectByIndex(0);
		JavascriptExecutor exec = (JavascriptExecutor)desktopDriver;
		WebElement submitButton= desktopDriver.findElement(By.cssSelector("input[value='Submit']"));
		exec.executeScript("arguments[0].click();", submitButton );
		
		desktopDriver.close();
		*/
		launchImplPage.getUsernameField().sendKeys("qatest100");
		launchImplPage.getpasswordField().sendKeys("Ace2three$");
		launchImplPage.getLoginClickButton().click();
		Thread.sleep(3000);
		lobbyImplPage.verifyPostLaunchBanners();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		{
			
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		CustomMethods.waitForElementPresent(changePasswordImplPage.getChangeYourPswdPopUpHeader(),30);
		verifyPresent(changePasswordImplPage.getChangeYourPswdPopUpHeader(), "Change Your Password Pop Up ");
		
		verifyNotPresent(changePasswordImplPage.getChangeYourPswdPopUpCloseButton(), "Change Your Password Close Button",1);
		verifyNotPresent(changePasswordImplPage.getNotNowButton(), "No Thanks Button",1);
		changePasswordImplPage.getChangeNowButton().click();
		verifyPresent(changePasswordImplPage.getChangePasswordHeader(), "Change Password window in lobby");
		
		MobileElement ele= (MobileElement)driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'tvPasswordGuidelines')]"));
		((AndroidDriver)driver).tap(1, ele.getCenter().getX()-160, ele.getCenter().getY(), 2);
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			((AndroidDriver)driver).tap(1, ele.getCenter().getX()-160, ele.getCenter().getY(), 2);		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			((AndroidDriver)driver).tap(1, ele.getCenter().getX()-250, ele.getCenter().getY(), 2);		}
		
		
		verifyPresent(changePasswordImplPage.getGuideLinesHeader(), "Change Password GuideLines Pop-up");
		String expected= "?In order to ensure your safety, Ace2Three password policy recommends that your password ?? - Should be atleast 8 characters long. ?? - Should be composed of random letters, alphabets and special characters. ?? - Should meet atleast 3 conditions of the following. ?? ?? A small case alphabet (a-z) ? ?? A capital case alphabet (A-Z) ? ?? A number (0-9) ? ?? A special character ?? - Should not contain your first name, last name, email and user id. ?? - Should not be same as your last 3 passwords. ?? - Should not contain common strings, consecutive numbers. ?? - Should not be same as your password with other web accounts. ?? - Permitted special characters are ! $ ( ) * + - . ; = ? @ [ ] ^ _ { | } ~ ??";
		
		String guidelines= driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'In order to ensure')]")).getText();
	
		//verifyGuideLineTextText(guidelines,expected);
		//System.out.println(guidelines);
		
		
		
		String[] guideLinesEachLines= guidelines.split("\n\n");
		for(String eachLine:guideLinesEachLines)
		{	
			System.out.println("lines :"+ eachLine);
			//verifyGuideLineTextText(eachLine, expectedGuideLines);
		}

		/*String Expected= "?In order to ensure your safety, Ace2Three password policy recommends that your password ?? - Should be atleast 8 characters long. ?? - Should be composed of random letters, alphabets and special characters. ?? - Should meet atleast 3 conditions of the following. ?? ?? A small case alphabet (a-z) ? ?? A capital case alphabet (A-Z) ? ?? A number (0-9) ? ?? A special character ?? - Should not contain your first name, last name, email and user id. ?? - Should not be same as your last 3 passwords. ?? - Should not contain common strings, consecutive numbers. ?? - Should not be same as your password with other web accounts. ?? - Permitted special characters are ! $ ( ) * + - . ; = ? @ [ ] ^ _ { | } ~ ??";
		for(String eachLine:guideLinesEachLines){
			System.out.println("lines :"+ eachLine);
		
			verifyGuideLineTextText(eachLine, Expected);
		}
		*/
		verifyPresent(changePasswordImplPage.getGuideLinesOkButton(), "GuideLines Ok button");
		changePasswordImplPage.getGuideLinesOkButton().click();
		verifyPresent(changePasswordImplPage.getChangePasswordHeader(), "Change Password window in lobby");
		
	}
	
	@Test(description = " \"Change Password\" button is displayed after a successful purchase for users whose password is weak in Mweb", priority=1)
	public void TS_Sanity__ChangePassword_05() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		String userName=signupImplPage.doSignUp();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
		verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
				ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
		lobbyImplPage.getLevelUpAlertOkButton().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getPlpBannerCloseIcon()))
		{
			lobbyImplPage.getPlpBannerCloseIcon().click();
			
		}
		
		UpdateProfileWebViewImplPage updateProfileWebViewImplPage = new UpdateProfileWebViewImplPage(driver);
		updateProfileWebViewImplPage.getFirstNameEditText().sendKeys(CustomMethods.randomStringGenerator(5));
		updateProfileWebViewImplPage.getLastNameEditText().sendKeys(CustomMethods.randomStringGenerator(5));
		Random ran = new Random();
		String year=199+""+ran.nextInt(9);
		/*int mob= ran.nextInt(Integer.SIZE - 1) + 123456789;
		System.out.println(8+""+mob);
		*/
		updateProfileWebViewImplPage.getMobileNumberEditText().sendKeys(86523+""+CustomMethods.generateRandomNumber(5));
		
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'yeardropdown')]")).click();
		updateProfileWebViewImplPage.selectFromDropDownListOfShortProfile("199"+(ran.nextInt(9-4)+4));
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'monthdropdown')]")).click();
		updateProfileWebViewImplPage.selectFromDropDownListOfShortProfile("Mar");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'daydropdown')]")).click();
		updateProfileWebViewImplPage.selectFromDropDownListOfShortProfile("05");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'state')]")).click();
		updateProfileWebViewImplPage.selectFromDropDownListOfShortProfile("Andhra Pradesh");
		
		
		updateProfileWebViewImplPage.getShortProfileContinueButton().click();
		Thread.sleep(2000);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getAddChipsButton().click();
		addCashWebViewImplPage.getCustomAmountField().clear();
		addCashWebViewImplPage.getCustomAmountField().sendKeys("500");
		driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'validatePay')]")).click();
		CustomMethods.waitForElementPresent(addCashWebViewImplPage.getMobikwikPayButton(),10);
		addCashWebViewImplPage.getMobikwikPayButton().click();
		Thread.sleep(2000);
		WebElement sorryYourPswdWeak = driver.findElement(By.xpath("//android.view.View[contains(@text,'Sorry, your password is weak')]"));
		verifyPresent(sorryYourPswdWeak," Password weak status");
		verifyText(sorryYourPswdWeak.getText(), "Sorry, your password is weak. We recommend you to update your password now.");
		verifyPresent(addCashWebViewImplPage.getChangePasswordButton(), "Change Password Button");
		((AppiumDriver) driver).swipe(500,1000, 500,700 , 3000);
		addCashWebViewImplPage.getChangePasswordButton().click();
		CustomMethods.waitForElementPresent(addCashWebViewImplPage.getChangePasswordHeader());
		verifyPresent(addCashWebViewImplPage.getChangePasswordHeader(), "Change Password Mweb Header");
		
		addCashWebViewImplPage.getCurrentPasswordfield().sendKeys("ace2three");
		addCashWebViewImplPage.getNewPasswordfield().sendKeys("Ace2three@");
		addCashWebViewImplPage.getConfirmPasswordfield().sendKeys("Ace2three@");
		addCashWebViewImplPage.getSubmitButton().click();
		Thread.sleep(5000);
		WebElement ele = driver.findElement(By.xpath("//android.view.View[contains(@text,'Your password has been changed')]"));
		CustomMethods.waitForElementPresent(ele,10);
		verifyGuideLineTextText(ele.getText(),"Your password has been changed successfully. Please login to continue.");
		
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		WebElement changePasswordElement=lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Change Password");
		verifyPresent(changePasswordElement, "Change Password in Hamburger Menu");
		changePasswordElement.click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(changePasswordImplPage.getCurrentPasswordfield(),10);
		verifyPresent(changePasswordImplPage.getCurrentPasswordfield(), "Change Password screen");
		changePasswordImplPage.getCurrentPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getNewPasswordfield().sendKeys("Ace2three$");
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("Ace2three$");
		changePasswordImplPage.getSubmitButton().click();
		CustomMethods.waitForElementPresent(changePasswordImplPage.getChangePasswordStatusText(),10);
		verifyText(changePasswordImplPage.getChangePasswordStatusText().getText(),"Congrats, your password has been changed successfully.");
		changePasswordImplPage.getChangePasswordStatusOkButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
		verifyPresent(launchImplPage.getUsernameField(), "Login page displayed");
		
	}	
	
	@Test(description = "check whether FOrgot Nickname or userid link is present or not in forgot password window.", priority=1)
	public void TS_Sanity__ChangePassword_06() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		/*SignupImplPage signupImplPage = new SignupImplPage(driver);
		String userName=signupImplPage.doSignUp();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());*/
		String currentPassword= "lastPassword2@";
		launchImplPage.getUsernameField().sendKeys("qatest06");
		launchImplPage.getpasswordField().sendKeys(currentPassword);
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Change Password").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys(currentPassword);
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(changePasswordImplPage.getCurrentPasswordfield(), "Change Password screen is displayed");
		
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().sendKeys("lastPassword2@");
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("lastPassword2@");
		changePasswordImplPage.getSubmitButton().click();
		verifyText(changePasswordImplPage.getChangePasswordErrorMessage().getText(),"Sorry, new password cannot be same as current password");
		
		//TC_ID_16 start
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("123456ab");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("123456ab");
		changePasswordImplPage.getSubmitButton().click();
		
		changePasswordImplPage.verifyErrorMessage("change password with only 2 parameters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.smallcase.parameters"));
		
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("aceeethree@");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("aceeethree@");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with only 2 parameters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.specialchar.and.smallcase.parameters"));
		
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("1234776@");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("1234776@");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with only 2 parameters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.specialchar.parameters"));
		//TC_ID_16 start - end
		//TC_ID_19 start 
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("1234123412");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("1234123412");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with only 1 parameters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.only.numbers"));
		
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("abcdpoiu");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("abcdpoiu");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with only 1 parameters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.only.small.letters"));
		
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("@@@@@$$$");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("@@@@@$$$");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with only 1 parameters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.only.special.characters"));

		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("DINESHQA");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("DINESHQA");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with only 1 parameters", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.only.capital.letters"));
		//TC_ID_19 - End
		
		//TC_ID_22 p- Start
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("fnnn@123");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("fnnn@123");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with registrered first or Last name", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.registered.firstName.or.lastName"));
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("lnnn@123");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("lnnn@123");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with registrered first or last name", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.registered.firstName.or.lastName"));
		//TC_ID_22 p- END	
		
		//TC_ID_23 p- Start
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("Asemail1@co.com");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("Asemail1@co.com");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with registrered email", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.registered.email"));
		//TC_ID_23 p- END		
		//TC_ID_24 -Start
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("5667777777a@");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("5667777777a@");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with Phone number", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.registered.phone.number"));
		//TC_ID_24 -End	
		
		//TC_ID_25 -Start
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("qatest06@");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("qatest06@");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with password containing user ID", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.registered.user.id"));
		//TC_ID_25 -End
		
	
		//TC_ID_26 -Start
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("Ace2three@");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with password containing last 3 passwords", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.last.3.given.passwords"));
		
		changePasswordImplPage.getNewPasswordfield().clear();
		changePasswordImplPage.getNewPasswordfield().sendKeys("lastPassword1@");
		changePasswordImplPage.getConfirmPasswordfield().clear();
		changePasswordImplPage.getConfirmPasswordfield().sendKeys("lastPassword1@");
		changePasswordImplPage.getSubmitButton().click();
		changePasswordImplPage.verifyErrorMessage("change password with password containing last 3 passwords", 
				ReadDataFromProps.props.getProperty("change.password.error.message.giving.last.3.given.passwords"));
		//TC_ID_26 -End
		
		
		//TC_ID_26 -End
		
		//TC_ID_27 -Start
			changePasswordImplPage.getCurrentPasswordfield().clear();
			changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
			changePasswordImplPage.getNewPasswordfield().clear();
			changePasswordImplPage.getNewPasswordfield().sendKeys("ace2three#");
			changePasswordImplPage.getConfirmPasswordfield().clear();
			changePasswordImplPage.getConfirmPasswordfield().sendKeys("ace2three#");
			changePasswordImplPage.getSubmitButton().click();
			changePasswordImplPage.verifyErrorMessage("change password with unsupported special char", 
					ReadDataFromProps.props.getProperty("change.password.error.message.giving.unsupported.spl.chars.spaces"));
		//TC_ID_27 -End
		
		
		//TC_ID_29 - Starts
		//Check -1 
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "abcd", "abcde", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.less.than.minimum.characters.as.password"), 
				"password length check with password mismatch check hierarchy");
		//Check -2
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "abcd##", "abcd##", 
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.less.than.minimum.characters.as.password"), 
				"password length check with special char check hierarchy");
		//Check -3
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "ab1@C", "ab1@C",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.less.than.minimum.characters.as.password"), 
				"password length check with mandatory password check hierarchy");
		//Check -6
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "fnnn", "lnnn",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.less.than.minimum.characters.as.password"), 
				"password length check with Fname and Lname check hierarchy");
		//Check -7
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "dinesh###", "dinesh##",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
				"password mismatch check with spl char check hierarchy");
		//Check -8
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "dinesh###", "dinesh@##",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
				"password mismatch check with mandatory password check hierarchy");
		//Check -10
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "qatest06", "qatest07",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
				"password mismatch check with user-id check hierarchy");
		//Check -11
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "fnnn1234", "lnnn1234",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
				"password mismatch check with user-id check hierarchy");
		//Check -11
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "Asemail1@co.com", "Asemail1@co.co",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
				"password mismatch check with user-id check hierarchy");
		//Check -11
		changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "5667777777a@", "5667777777a$",
				ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
				"password mismatch check with user-id check hierarchy");
				
		//Check -12
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "Asemail1@co.com", "Asemail1@co.co",
						ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
						"password mismatch check with user-id check hierarchy");
				//Check -13
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "5667777777a@", "5667777777a$",
						ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
						"password mismatch check with user-id check hierarchy");
				//Check -14
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "Rummy@123", "Rummy@1234",
						ReadDataFromProps.props.getProperty("change.password.error.message.for.giving.unmatched.new.and.confirm.passwords"), 
						"password mismatch check with user-id check hierarchy");
						
						
				//Check -15
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "Aaa1bcd##", "Aaa1bcd##",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.unsupported.spl.chars.spaces"), 
						"Special character check with old password check hierarchy");
				//Check- 16
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "qatest06#", "qatest06#",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.unsupported.spl.chars.spaces"), 
						"Special character check with user id check hierarchy");
				//check-17
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "fnnn1234&", "fnnn1234&",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.unsupported.spl.chars.spaces"), 
						"Special character check with first name check hierarchy");
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "lnnn1234:", "lnnn1234:",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.unsupported.spl.chars.spaces"), 
						"Special character check with last name check hierarchy");
				//Check-18
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "Asemail1@co.com%", "Asemail1@co.com%",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.unsupported.spl.chars.spaces"), 
						"Special character check with email check hierarchy");	
				//check- 19
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "5667777777>", "5667777777>",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.unsupported.spl.chars.spaces"), 
						"Special character check with mobile number check hierarchy");
				//check- 20
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "qatest06", "qatest06",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.smallcase.parameters"), 
						"mandatory password check with user id check hierarchy");
				//check- 21
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "fnnn1234", "fnnn1234",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.smallcase.parameters"), 
						"mandatory password check with first name check hierarchy");
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "lnnn1234", "lnnn1234",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.smallcase.parameters"), 
						"mandatory password check with last name check hierarchy");
				//Check- 22
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "asemail@co.com", "asemail@co.com",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.specialchar.and.smallcase.parameters"), 
						"mandatory password check with email id check hierarchy");
				//Check-23
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "5667777777a", "5667777777a",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.smallcase.parameters"), 
						"mandatory password check with mobile number check hierarchy");
				//Check-24
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "cricket123", "cricket123",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.smallcase.parameters"), 
						"mandatory password check with common passwords check hierarchy");
				//Check-25
				changePasswordImplPage.errorMessageHierarchyCheck(currentPassword, "cricket123", "cricket123",
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.number.and.smallcase.parameters"), 
						"mandatory password check with common passwords check hierarchy");
				
				//TC_ID_29 - end 
	}
	
	@Test(description = "Verify whether the user is able to change the password with all of the following parameters.(Number, Small Case, Capital Case, Special Character)(Should be able to)"
			+ "Verify whether the user is able to use all the special characters mentioned in the permitted list to change their password. (Permitted special characters are:", priority=1)
	public void TS_Sanity__ChangePassword_07() throws InterruptedException, IOException {
		String currentPassword= "ace2three";
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		Thread.sleep(1000);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		String userName = signupImplPage.doSignUp();
		LobbyImplPage lobbyImplPage= new LobbyImplPage(driver);
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage= new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
		lobbyImplPage.getLevelUpAlertOkButton().click();
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Change Password").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys(currentPassword);
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(changePasswordImplPage.getCurrentPasswordfield(), "Change Password screen is displayed");
		String newPassword=null;
		newPassword = changePasswordImplPage.generatePassword();
		logger.log(LogStatus.INFO, "new password is: " +newPassword);
		changePasswordImplPage.getCurrentPasswordfield().sendKeys(currentPassword);
		changePasswordImplPage.getNewPasswordfield().sendKeys(newPassword);
		changePasswordImplPage.getConfirmPasswordfield().sendKeys(newPassword);
		changePasswordImplPage.getSubmitButton().click();
		CustomMethods.waitForElementPresent(changePasswordImplPage.getChangePasswordStatusText());
		verifyText(changePasswordImplPage.getChangePasswordStatusText().getText(),"Congrats, your password has been changed successfully.");
		changePasswordImplPage.getChangePasswordStatusOkButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
		verifyPresent(launchImplPage.getUsernameField(), "Login page displayed");
		
		String speclChars= "!$()*+-.;=?@[]^_{|}~)";
		int charList = speclChars.length();
		
		for(int j=0; j<charList; j++){
			
			launchImplPage.getUsernameField().sendKeys(userName);
			launchImplPage.getpasswordField().sendKeys(newPassword);
			launchImplPage.getLoginClickButton().click();
			LobbyImplPage lobbyImplPage1 = new LobbyImplPage(driver);
			if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
				lobbyImplPage.getUpdateProfilePopUpClose().click();
			lobbyImplPage1.verifyLobbyPageDisplayed();
			lobbyImplPage1.getHamburgerMenu().click();
			lobbyImplPage1.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Change Password").click();
			myAccountImplPage.getPasswordPopUpField().sendKeys(newPassword);
			myAccountImplPage.getPasswordPopUpSubmitButton().click();
			verifyPresent(changePasswordImplPage.getCurrentPasswordfield(), "Change Password screen is displayed");
			changePasswordImplPage.getCurrentPasswordfield().sendKeys(newPassword);
			newPassword ="Ace2three"+speclChars.charAt(j);
			logger.log(LogStatus.INFO, "new password is:" + newPassword);
			changePasswordImplPage.getNewPasswordfield().sendKeys(newPassword);
			changePasswordImplPage.getConfirmPasswordfield().sendKeys(newPassword);
			changePasswordImplPage.getSubmitButton().click();
			CustomMethods.waitForElementPresent(changePasswordImplPage.getChangePasswordStatusText());
			verifyText(changePasswordImplPage.getChangePasswordStatusText().getText(),"Congrats, your password has been changed successfully.");
			changePasswordImplPage.getChangePasswordStatusOkButton().click();
			CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());
			verifyPresent(launchImplPage.getUsernameField(), "Login page displayed");
		}
		
	}
	
	@Test(description = "Verify whether the user is able to change the password with all of the following parameters.(Number, Small Case, Capital Case, Special Character)(Should be able to)", priority=1)
	public void TS_Sanity__ChangePassword_08() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		//String passwordNew=password;
		Thread.sleep(1000);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		/*SignupImplPage signupImplPage = new SignupImplPage(driver);
		String userName=signupImplPage.doSignUp();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField());*/
		String currentPassword= "ace2three";
		launchImplPage.getUsernameField().sendKeys("commonphrase");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Change Password").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(changePasswordImplPage.getCurrentPasswordfield(), "Change Password screen is displayed");
		
		changePasswordImplPage.getCurrentPasswordfield().clear();
		changePasswordImplPage.getCurrentPasswordfield().sendKeys("Ace2three@");
		
		String[] newPasswords= new String[]{
				"Ace2three",
				"Ace2three123",
				"Ace2three1234",
				"Ace2three12345",
				"Ace2three@123",
				"Ace2three@1234",
				"Ace2three@12345",
				"Rummy@123",
				"Rummy@1234",
				"Rummy@12345",
				"Rummy123",
				"Rummy1234",
				"Rummy12345",
				"Ace12345",
				"Ace@1234",
				"Ace@12345",
				"Passw0rd",
				"Password123",
				"Password1234",
				"Password12345",
				"Qwerty123",
				"Qwerty1234",
				"Qwerty12345",
				"Asdfg123",
				"Asdfg1234",
				"Asdfg12345",
				"Zxcvb123",
				"Zxcvb1234",
				"Zxcvb12345",
				"Login123",
				"Login1234",
				"Login12345",
				"Userid123",
				"Userid1234",
				"Userid12345",
				"Poiuy123",
				"Poiuy1234",
				"Poiuy12345",
				"Lkjhg123",
				"Lkjhg1234",
				"Lkjhg12345",
				"Welc0me1",
				"Welc0me12345",
				"Welcome123",
				"Welcome1234",
				"Welcome12345",
				"F00tball",
				"Footbal123",
				"Football1234",
				"Football12345",
				"Cricket123",
				"Cricket1234",
				"Cricket12345",
		};
		
		for(int i=0;i<newPasswords.length; i++){
			changePasswordImplPage.getNewPasswordfield().clear();
			changePasswordImplPage.getNewPasswordfield().sendKeys(newPasswords[i]);
			changePasswordImplPage.getConfirmPasswordfield().clear();
			changePasswordImplPage.getConfirmPasswordfield().sendKeys(newPasswords[i]);
			changePasswordImplPage.getSubmitButton().click();
			logger.log(LogStatus.INFO, "Trying with password : "+ newPasswords[i]);
			changePasswordImplPage.verifyErrorMessage("change password with common phrases", 
					ReadDataFromProps.props.getProperty("change.password.error.message.giving.common.phrase"));
			
				if(i==5||i==8||i==15){
				System.out.println(newPasswords[i].toLowerCase());
				changePasswordImplPage.getNewPasswordfield().clear();
				changePasswordImplPage.getNewPasswordfield().sendKeys(newPasswords[i].toLowerCase());
				changePasswordImplPage.getConfirmPasswordfield().clear();
				changePasswordImplPage.getConfirmPasswordfield().sendKeys(newPasswords[i].toLowerCase());
				changePasswordImplPage.getSubmitButton().click();
				logger.log(LogStatus.INFO, "Trying with password : "+ newPasswords[i]);
				changePasswordImplPage.verifyErrorMessage("change password with common phrases", 
						ReadDataFromProps.props.getProperty("change.password.error.message.giving.common.phrase"));
				}
			}	
		
		String[] passwords= new String[]{"aCe2thRee","aCe2thRee1234","ruMmy@123","acE@1234","passw0RD","UserID123","f00tBAll"};
		for(int j=0;j<passwords.length; j++){
			changePasswordImplPage.getNewPasswordfield().clear();
			changePasswordImplPage.getNewPasswordfield().sendKeys(newPasswords[j]);
			changePasswordImplPage.getConfirmPasswordfield().clear();
			changePasswordImplPage.getConfirmPasswordfield().sendKeys(newPasswords[j]);
			changePasswordImplPage.getSubmitButton().click();
			logger.log(LogStatus.INFO, "Trying with password : "+ newPasswords[j]);
			changePasswordImplPage.verifyErrorMessage("change password with common phrases", 
					ReadDataFromProps.props.getProperty("change.password.error.message.giving.common.phrase"));
		}
	}
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {

		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			logger.log(LogStatus.FAIL, result.getThrowable());
			/*System.out.println(Thread.currentThread().getStackTrace());
			boolean abc= Thread.currentThread().getStackTrace().toString().contains("GamePlayPlayer2ImplPage");*/
			//System.out.println("boolean is:" + abc);
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			
			
			
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver)driver).resetApp();
		
		
	}
	

	public static void main(String args[])
	{/*
		Random ran = new Random();
		System.out.println(ran.nextInt(9-4)+4);*/
	}

}
