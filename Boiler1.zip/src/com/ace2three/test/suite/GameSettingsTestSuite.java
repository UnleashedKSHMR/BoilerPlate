package com.ace2three.test.suite;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.GameSettingsImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.ace2three.utils.business.BusinessMethods;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class GameSettingsTestSuite extends BaseTestSuite {

	private File imgDir;

	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		
		Test test = method.getAnnotation(Test.class);
	
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		
	}

	@Test(description = "Verify a game settings window is opened when tapping on Game settings option from hamburger Menu")
	public void TS_GM_Settings_01() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);

		Thread.sleep(10000);

		if (launchImplPage.getLoginButon().isDisplayed()) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();

		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();

		GameSettingsImplPage gameSettings = new GameSettingsImplPage(driver);
		gameSettings.openGameSettings();

	}

	@Test(description = "Verify that all the available objects are visible on Game settings window ")
	public void TS_GM_Settings_02() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);

		Thread.sleep(10000);

		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();

		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();

		GameSettingsImplPage gameSettings = new GameSettingsImplPage(driver);
		gameSettings.openGameSettings();
		verifyPresent(gameSettings.getSoundOnOffOption(), "Sound ON/OFF option");
		verifyPresent(gameSettings.getVibrationOnOffOption(), "Vibration ON/OFF option");
		verifyPresent(gameSettings.getProfileOnOffOption(), "Profile ON/OFF option");
		verifyPresent(gameSettings.getGameSettingsPopupHeader(), "Game settings header");
		verifyPresent(gameSettings.getGameSettingsClose(), "Game settings close button");
		verifyPresent(gameSettings.getCurrentThemeButton(),"Current Theme button" );
		verifyPresent(gameSettings.getNextThemeButton(), "Next Theme button");
		verifyPresent(gameSettings.getPreviousThemeButton(), "Previous Theme button");
		gameSettings.getPreviousThemeButton().click();
		verifyPresent(gameSettings.getSelectThemeButton(), "Select Theme button");
		gameSettings.getSelectThemeButton().click();
		verifyPresent(gameSettings.getCurrentThemeButton(), "Current Theme button");
		gameSettings.getNextThemeButton().click();
		gameSettings.getSelectThemeButton().click();
		gameSettings.getGameSettingsClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
	}
	
	@Test(description = "Verify that Sound , Vibration and profile "
			+ "features are getting enabled when turning switches to ON mode", enabled=false)
	public void TS_GM_Settings_03() throws InterruptedException {

		LaunchImplPage launchImplPage = new LaunchImplPage(driver);

		Thread.sleep(10000);

		if (launchImplPage.getLoginButon().isDisplayed()) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("champion3");
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();

		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();

		GameSettingsImplPage gameSettings = new GameSettingsImplPage(driver);
		gameSettings.openGameSettings();
		
		
	}
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {

		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			logger.log(LogStatus.FAIL, result.getThrowable());
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver)driver).resetApp();
	}

}
