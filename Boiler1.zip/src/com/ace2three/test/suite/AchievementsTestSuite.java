package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.impl.pages.AchievementsImplPage;
public class AchievementsTestSuite extends BaseTestSuite {
	
	
	//WebDriver driver;
	String userName;
	
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		
		
		Test test = method.getAnnotation(Test.class);
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
	}
	
	@Test(description = "check whether Stake Master is displayed for premium player in Ongoing tab or not.", priority=1)
	public void TS_Achievements_01() throws InterruptedException, IOException {
		
		//BaseTestSuite baseTestSuite = new BaseTestSuite();
		AchievementsImplPage achievementsImplPage = new AchievementsImplPage(driver);
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		verifyPresent(launchImplPage.getSignUpButton(), "Sign Screen");
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		userName = signupImplPage.doSignUp();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions, "Achievements").click();
		//AchievementsImplPage achievementsImplPage = new AchievementsImplPage(driver);
		verifyPresent(achievementsImplPage.getBuyChipsButton(), "Buy Chips Button");
		verifyText(achievementsImplPage.getMakeYourfirstPurchaseText().getText(),"Make your first purchase");
		achievementsImplPage.getBuyChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		verifyPresent(addCashWebViewImplPage.getAddCashPageHeader(), "Add Cash Web View");
		
		
		
		
	}
	
	@Test(description = "check whether Stake Master is displayed for premium player in Ongoing tab or not.", priority=1)
	public void TS_Achievements_02() throws InterruptedException, IOException {
		
		//BaseTestSuite baseTestSuite = new BaseTestSuite();
		AchievementsImplPage achievementsImplPage = new AchievementsImplPage(driver);
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		verifyPresent(launchImplPage.getSignUpButton(), "Sign Screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys(this.userName);
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
		CustomMethods.waitForElementPresent(lobbyImplPage.getLevelUpAlertMessage());
		verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
				ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
		lobbyImplPage.getLevelUpAlertOkButton().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions, "Achievements").click();
		
		verifyPresent(achievementsImplPage.getAchievementsHeader(), "Achievements Screen");
		
		verifyPresent(achievementsImplPage.getTrickyThreeHeader(), "Tricky Three Header");
		verifyPresent(achievementsImplPage.getRummyProHeader(), "Rummy Pro Header");
		
		((AppiumDriver)driver).swipe(500, 1400, 500, 700, 3000);
		verifyPresent(achievementsImplPage.getFantasticFiveHeader(), "Fantastic Five Header");
		verifyPresent(achievementsImplPage.getPoolMaster101Header(), "101 Master Header");
		verifyPresent(achievementsImplPage.getPoolMaster201Header(), "Pool Master Header");
		verifyPresent(achievementsImplPage.getStakesMasterHeader(), "Stakes Master Header");

		
		
	}
	
	@Test(description = "check whether Stake Master is displayed for premium player in Ongoing tab or not.", priority=1)
	public void TS_Achievements_03() throws InterruptedException, IOException, SQLException {
		
		//BaseTestSuite baseTestSuite = new BaseTestSuite();
		AchievementsImplPage achievementsImplPage = new AchievementsImplPage(driver);
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		verifyPresent(launchImplPage.getSignUpButton(), "Sign Screen");
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		userName = signupImplPage.doSignUpWithPhoneNumber();
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		try {
			dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
		} catch (InterruptedException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		CustomMethods.waitForElementPresent(lobbyImplPage.getPlpBannerCloseIcon());
		lobbyImplPage.getPlpBannerCloseIcon().click();
		lobbyImplPage.getSendOTPButton().click();
		String OTP =dataBaseConnection.selectQuery(null, userName);
		lobbyImplPage.getEnterOTPField().sendKeys(OTP);
		lobbyImplPage.getConfirmOTPButton().click();
		lobbyImplPage.getTakeMeToLobbyButton().click();
		lobbyImplPage.getAchievedBroonzeLevelOkButton().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Promotions, "Achievements").click();
		//AchievementsImplPage achievementsImplPage = new AchievementsImplPage(driver);
		verifyPresent(achievementsImplPage.getBuyChipsButton(), "Buy Chips Button");
		verifyText(achievementsImplPage.getMakeYourfirstPurchaseText().getText(),"Make your first purchase");
		achievementsImplPage.getBuyChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		verifyPresent(addCashWebViewImplPage.getAddCashPageHeader(), "Add Cash Web View");
		
	}
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {

		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			logger.log(LogStatus.FAIL, result.getThrowable());
			/*System.out.println(Thread.currentThread().getStackTrace());
			boolean abc= Thread.currentThread().getStackTrace().toString().contains("GamePlayPlayer2ImplPage");*/
			//System.out.println("boolean is:" + abc);
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			
			
			
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver)driver).resetApp();
		
		
	}
	
	public static void main(String args[]) throws InterruptedException, SQLException
	{
		DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
		/*DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
		String clearDeviceIds = "update game_user_master set phone_verified='N' where user_code in (select bonus_claimed from device_details)";
		String deleteDevicesDetails="delete from device_details";
		dataBaseConnection = new DataBaseServerConnect();
		dataBaseConnection.updateQuery(clearDeviceIds, null);
		dataBaseConnection.updateQuery(deleteDevicesDetails, null);*/
		
		/*String OTP =dataBaseServerConnect.selectQuery(null, "hello011");
		System.out.println(OTP);*/
		
		
		/*Random ran = new Random();
		System.out.println(ran.nextInt(50));*/
		
		/*String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('test17140650')";
		dataBaseServerConnect.updateQuery(coolOffQuery, "test17140650");*/
		
		
		/*String disconnectFBQuery = "update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('raju202')";
		dataBaseServerConnect.updateQuery(disconnectFBQuery, null);*/
		
		/*DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
		String coolOffQuery = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('potter')";
		dataBaseServerConnect.updateQuery(coolOffQuery, "potter");*/
		
		/*String verifyEmailAndMobileNo="update game_user_master set user_confirmation = 'Y',phone_verified = 'N' where upper(user_id) = upper('test17170430')";
		dataBaseServerConnect.updateQuery(verifyEmailAndMobileNo, null);*/
		
		/*String verifyEmailAndMobileNo="update game_user_master set user_confirmation = 'Y',phone_verified = 'Y' where upper(user_id) = upper('gpic40')";
		dataBaseServerConnect.updateQuery(verifyEmailAndMobileNo, null);*/
		
	}
}
