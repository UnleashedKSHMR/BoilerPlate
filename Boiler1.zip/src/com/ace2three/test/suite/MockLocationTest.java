package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;

import org.openqa.selenium.html5.Location;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class MockLocationTest extends BaseTestSuite {
	
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		
		Test test = method.getAnnotation(Test.class);
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		System.out.println("Before Method");
		System.out.println(System.getProperty("deviceName"));
		
	}
	
	@Test(description = "TS_Login_1 - Verify that all the available objects are visible on Public landing page.",priority=1)
	public void TS_Login_1() throws InterruptedException {
		
		Location loc = new Location(26.244156, 92.537842,210);
		((AndroidDriver) driver).setLocation(loc);
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//launchImplPage.launchApp();
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		verifyPresent(launchImplPage.getace2threelogo(), "Ace2Three logo");
		verifyPresent(launchImplPage.getUsernameField(), "user name field");
		launchImplPage.getUsernameField().sendKeys("ucme");
		verifyPresent(launchImplPage.getpasswordField(), "Password field");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		
	}

	
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			logger.log(LogStatus.FAIL, result.getThrowable());
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		extent.flush();
		extent.endTest(logger);
		((AppiumDriver) driver).resetApp();
	}
}
