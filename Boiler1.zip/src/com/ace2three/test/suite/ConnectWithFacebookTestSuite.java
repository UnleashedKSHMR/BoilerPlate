package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.app.webview.impl.pages.FacebookLoginWebimplPage;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.component.pages.AppOnlyForRealChipsDialogBox;
import com.ace2three.component.pages.FacebookLoginPages;
import com.ace2three.component.pages.SetPasswordDialogBox;
import com.ace2three.facebook.web.pages.FacebookWebSiteImplPage;
import com.ace2three.impl.pages.ChangePasswordImplPage;
import com.ace2three.impl.pages.FacebookAppLoginImplPage;
import com.ace2three.impl.pages.FacebookImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.LoginImplPage;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.MyProfileImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.ace2three.web.impl.pages.AdminImplPage;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class ConnectWithFacebookTestSuite extends BaseTestSuite{

	@BeforeClass
	public void beforeClass() throws IOException{
		CustomMethods.clearChromeData();
	}
	
	WebDriver desktopDriver;
	String userName=null;
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException, InterruptedException {
		Test test = method.getAnnotation(Test.class);
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		/*if("TS_FacebookLogin_9".equalsIgnoreCase(method.getName())){
			//facebookLoginWebimplPage.resetFacebookAppOrBrowser();
			CustomMethods.clearChromeData();
			FacebookWebSiteImplPage facebookWebSiteImplPage= new FacebookWebSiteImplPage();
			facebookWebSiteImplPage.removeFbFromSite1();
		}*/
		//Launch the ace2three app
		try{
		driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'upgrade_no')]")).click();
		}catch(Exception e){
			
		}
		
	}
	
	@Test(description = "Sign up with FB user into ace2three when there is no FB app available in device",priority=1)
	public void TS_FacebookLogin_1() throws InterruptedException, IOException, SQLException {
		//Launch the ace2three app
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		//driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'upgrade_no')]")).click();
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		//Signup with facebook
		launchImplPage.getSignupWithFacebook().click();
		FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 30);
		verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
		facebookLoginWebimplPage.getFacebookUserIDField().clear();
		facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		Thread.sleep(2000);
		facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 30);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
		facebookLoginWebimplPage.getEditPermissionsLink().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 30);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
		facebookLoginWebimplPage.getContinueWithFacebook().click();
		Thread.sleep(4000);
		FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
		verifyPresent(facebookImplPage.getNoIamNotButton(), "Yes I am and no I am not alert");
		facebookImplPage.getNoIamNotButton().click();
		Thread.sleep(2000);
		verifyPresent(facebookImplPage.getCreateUserNameMessage(),"username created automatically message");
		userName = facebookImplPage.getCreateUserNameField().getText();
		CustomMethods.VerifyElementIsEditable(facebookImplPage.getCreateUserNameField(), "Auto Generated userID field","enabled");
		String userNameCreatedAutomatically= "Your user name is automatically created as "+userName+". If you want to change, edit the user name below.";
		verifyTextPresent(facebookImplPage.getCreateUserNameMessage(), userNameCreatedAutomatically);
		logger.log(LogStatus.INFO, "User name is: " +userName);
		
		facebookImplPage.getCreateUserSubmitButton().click();
		Thread.sleep(5000);
		LobbyImplPage lobbyImplPage=new  LobbyImplPage();
		lobbyImplPage.getPlpBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
		lobbyImplPage.getPsuedoBannerCloseIcon().click();
		AppOnlyForRealChipsDialogBox  appOnlyForRealChipsDialogBox = new AppOnlyForRealChipsDialogBox(driver);
		/*if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips()))*/
			//AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
		appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
		appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
		}
	
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		
		/*CustomMethods cm= new  CustomMethods();
		
		desktopDriver= cm.launchWebBrowser();
		AdminImplPage adminImplPage= new AdminImplPage(desktopDriver);*/
	/*	adminImplPage.updatePhoneNumberInProfile(userName, ReadDataFromProps.props.getProperty("mobile.number"));
		desktopDriver.close();*/
		
		LoginImplPage loginImplPage= new LoginImplPage(driver);
		CustomMethods.waitForElementPresent(loginImplPage.getLoginWithFacebook(), 5);
		
		verifyPresent(loginImplPage.getLoginWithFacebook(), "Login page has displayed");
		loginImplPage.getLoginWithFacebook().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 7);
		verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook login page");
		facebookLoginWebimplPage.getContinueWithFacebook().click();
		Thread.sleep(5000);
		lobbyImplPage.getPlpBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
			lobbyImplPage.getPsuedoBannerCloseIcon().click();
			//AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
			}
	
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Profile").click();
		SetPasswordDialogBox setPasswordDialogBox= new SetPasswordDialogBox(driver);
		verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
		setPasswordDialogBox.getSetPasswordButton().click();
		/*BusinessMethods businessMethods= new BusinessMethods();
		String OTP= businessMethods.getOtpFromMessagesStartingWithHello();*/
		DataBaseServerConnect dataBaseServerConnect=new DataBaseServerConnect();
		String OTP= dataBaseServerConnect.selectQuery(null, userName);
		verifyPresent(setPasswordDialogBox.getSetPasswordOtpSentMessage(),"set password Otp alert");
		setPasswordDialogBox.getSetNewPasswordField().sendKeys("ace2three");
		setPasswordDialogBox.getSetNewPasswordConfirmField().sendKeys("ace2three");
		
		setPasswordDialogBox.getSetNewPasswordOtpField().sendKeys(OTP);
		setPasswordDialogBox.getSetNewPasswordSubmitButton().click();
		CustomMethods.waitForElementPresent(setPasswordDialogBox.getSetNewPasswordSuccessAlert(),3);
		verifyPresent(setPasswordDialogBox.getSetNewPasswordSuccessAlert(),"Password set successfull messsage");
		setPasswordDialogBox.getSetNewPasswordSuccessAlertOkButton().click();
		//Verify whether the profile details are auto-filled from FB
		logger.log(LogStatus.INFO, "verifying whether profile details has auto filled or not");
		MyProfileImplPage myProfileImplPage= new MyProfileImplPage(driver);
		verifyTextPresent(myProfileImplPage.getMyProfileFirstNameField(),"Gopi");
		verifyTextPresent(myProfileImplPage.getMyProfileLastNameField(),"Dugyala");
		verifyTextPresent(myProfileImplPage.getMyProfileGenderDropDownField(),"Male");
		
		verifyPresent(lobbyImplPage.getHomeTabIcon(),"Home button icon");
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField(),4);
		
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(lobbyImplPage.getPlpBannerCloseIcon(),4);
		
		lobbyImplPage.getPlpBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
			lobbyImplPage.getPsuedoBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
			}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		
		CustomMethods.waitForElementPresent(loginImplPage.getLoginWithFacebook(),4);
		
		/*String disconnectFBQuery = "update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('"+userName+"')";
		dataBaseConnection.updateQuery(disconnectFBQuery, null);
		 String query="update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		dataBaseConnection.updateQuery(query, null);
		
		CustomMethods cm= new  CustomMethods();
		desktopDriver= cm.launchWebBrowser();
		AdminImplPage adminImplPage= new AdminImplPage(desktopDriver);
		
		adminImplPage.updatePhoneNumberAndEmailInProfile(userName);
		facebookLoginWebimplPage.resetFacebookAppOrBrowser();
		FacebookWebSiteImplPage facebookWebSiteImplPage= new FacebookWebSiteImplPage();
		facebookWebSiteImplPage.removeFbFromSite();*/
		
		//cm.resetChromeBrowser();
		//loginImplPage.getLoginWithFacebook().click();
		//verifyPresent(facebookLoginWebimplPage.getFacebookUserIDField(),"facebook login");
	}
	
	@Test(description = "Sign up with FB user into ace2three when there is FB app available in device",priority=2)
	public void TS_FacebookLogin_2() throws InterruptedException, IOException, SQLException {
		//driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'upgrade_no')]")).click();
		
		//((AndroidDriver)driver).installApp("D:/Automation/Ace2Three/apk/com.facebook.katana_v152.0.0.42.136-83110613_Android-4.0.3.apk");
		CustomMethods.installFacebook();
		//Launch the ace2three App
		/*((AppiumDriver)driver).installApp("D:/Automation/Ace2Three/apk/facebook.apk");*/
		int count =1;
		while(!((AndroidDriver)driver).isAppInstalled("com.facebook.katana")){
			Thread.sleep(2000);
			count++;
				if(count>=500)
					break;
		}
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		//Signup with facebook
		launchImplPage.getSignupWithFacebook().click();
		
		FacebookLoginPages facebookLoginWebimplPage =new FacebookAppLoginImplPage(driver);
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 60);
		verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook App Login page");
		facebookLoginWebimplPage.getFacebookUserIDField().clear();
		facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");//change username
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		Thread.sleep(2000);
		facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 120);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
		facebookLoginWebimplPage.getEditPermissionsLink().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 45);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
		facebookLoginWebimplPage.getContinueWithFacebook().click();
		
		FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
		CustomMethods.waitForElementPresent(facebookImplPage.getNoIamNotButton(), 15);
		verifyPresent(facebookImplPage.getNoIamNotButton(), "Yes I am and no I am not alert");
		facebookImplPage.getNoIamNotButton().click();
		Thread.sleep(2000);
		verifyPresent(facebookImplPage.getCreateUserNameMessage(),"username created automatically message");
		this.userName = facebookImplPage.getCreateUserNameField().getText();
		CustomMethods.VerifyElementIsEditable(facebookImplPage.getCreateUserNameField(), "Auto Generated userID field","enabled");
		String userNameCreatedAutomatically= "Your user name is automatically created as "+userName+". If you want to change, edit the user name below.";
		verifyTextPresent(facebookImplPage.getCreateUserNameMessage(), userNameCreatedAutomatically);
		logger.log(LogStatus.INFO, "User name is: " +userName);
		facebookImplPage.getCreateUserSubmitButton().click();
		Thread.sleep(5000);
		LobbyImplPage lobbyImplPage= new  LobbyImplPage();
		lobbyImplPage.getPlpBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
			lobbyImplPage.getPsuedoBannerCloseIcon().click();
		AppOnlyForRealChipsDialogBox  appOnlyForRealChipsDialogBox = new AppOnlyForRealChipsDialogBox(driver);
		/*if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips()))*/
			//AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
			}
	
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		
		CustomMethods cm= new  CustomMethods();
		//desktopDriver= cm.launchWebBrowser();
		AdminImplPage adminImplPage= new AdminImplPage(desktopDriver);
		/*adminImplPage.updatePhoneNumberInProfile(userName, ReadDataFromProps.props.getProperty("mobile.number"));
		desktopDriver.close();*/
		
		LoginImplPage loginImplPage= new LoginImplPage(driver);
		CustomMethods.waitForElementPresent(loginImplPage.getLoginWithFacebook(), 5);
		verifyPresent(loginImplPage.getLoginWithFacebook(), "Login page");
		loginImplPage.getLoginWithFacebook().click();
		/*CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 7);
		verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook App login page");
		facebookLoginWebimplPage.getContinueWithFacebook().click();
		Thread.sleep(5000);*/
		CustomMethods.waitForElementPresent(lobbyImplPage.getPlpBannerCloseIcon(), 20);
		lobbyImplPage.getPlpBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
			lobbyImplPage.getPsuedoBannerCloseIcon().click();
			//AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
			}
	
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Profile").click();;
		SetPasswordDialogBox setPasswordDialogBox= new SetPasswordDialogBox(driver);
		verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
		setPasswordDialogBox.getSetPasswordButton().click();
		/*BusinessMethods businessMethods= new BusinessMethods();
		String OTP= businessMethods.getOtpFromMessagesStartingWithHello();*/
		
		DataBaseServerConnect dataBaseServerConnect=new DataBaseServerConnect();
		String OTP= dataBaseServerConnect.selectQuery(null, userName);
		
		verifyPresent(setPasswordDialogBox.getSetPasswordOtpSentMessage(),"set password Otp alert");
		setPasswordDialogBox.getSetNewPasswordField().sendKeys("ace2three");
		setPasswordDialogBox.getSetNewPasswordConfirmField().sendKeys("ace2three");
		
		setPasswordDialogBox.getSetNewPasswordOtpField().sendKeys(OTP);
		setPasswordDialogBox.getSetNewPasswordSubmitButton().click();
		CustomMethods.waitForElementPresent(setPasswordDialogBox.getSetNewPasswordSuccessAlert(),3);
		verifyPresent(setPasswordDialogBox.getSetNewPasswordSuccessAlert(),"Password set successfull messsage");
		setPasswordDialogBox.getSetNewPasswordSuccessAlertOkButton().click();
		verifyPresent(lobbyImplPage.getHomeTabIcon(),"Home button icon");
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getUsernameField(),4);
		
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(lobbyImplPage.getPlpBannerCloseIcon(),4);
		
		lobbyImplPage.getPlpBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
			lobbyImplPage.getPsuedoBannerCloseIcon().click();
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
			}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage=new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
		verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
				ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
		lobbyImplPage.getLevelUpAlertOkButton().click();
		
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		CustomMethods.waitForElementPresent(loginImplPage.getLoginWithFacebook(),4);
		//Checking for OTP to be sent if user enter invalid password for 5 timrs
		for (int i = 0; i <= 3; i++) {
			// Enter invalid password
			launchImplPage.getpasswordField().sendKeys("invalid" + i);
			launchImplPage.getLoginClickButton().click();
			if (!(i == 3)) {
				CustomMethods.waitForElementPresent(launchImplPage.getpasswordErrorMessage(), 3);
				verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
			}
			logger.log(LogStatus.INFO, i + " time invalid password attempts");
		}
		
		verifyPresent(launchImplPage.getMultipleIncorrectAttemptsAlert(), "multiple incorrect password attempt alert");
		launchImplPage.getCloseMultipleIncorrectAttemptsAlert().click();
		launchImplPage.getpasswordField().sendKeys("ace2three1");
		launchImplPage.getLoginClickButton().click();
		verifyTextPresent(launchImplPage.getpasswordErrorMessage(), "Invalid User Id or Password");
		launchImplPage.getpasswordField().clear();
		launchImplPage.getpasswordField().sendKeys("ace2three");
		launchImplPage.getLoginClickButton().click();
		CustomMethods.waitForElementPresent(launchImplPage.getOtpSentAlertMessage(), 5);
		
		verifyPresent(launchImplPage.getOtpSentAlertMessage(), "OTP sent alert message");
		launchImplPage.getOtpSentAlertMessageOkButton().click();
		
		 launchImplPage.getpasswordField().sendKeys("ace2three");
		 String OTP1= dataBaseServerConnect.selectQuery(null, userName);
		 
		 driver.findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'otpET')]")).sendKeys(OTP1);
		 
		 launchImplPage.getLoginClickButton().click();
		 lobbyImplPage.verifyPostLaunchBanners();
		 if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		 {
			 lobbyImplPage.getUpdateProfilePopUpClose().click();
		 }
		 
		 ChangePasswordImplPage changePasswordImplPage = new ChangePasswordImplPage(driver);
		 changePasswordImplPage.getNotNowButton().click();
		 lobbyImplPage.verifyLobbyPageDisplayed();
		 
		/*adminImplPage.updatePhoneNumberAndEmailInProfile(userName);
		facebookLoginWebimplPage.resetFacebookAppOrBrowser();*/
	}

	@Test(description = "Verify Sign up using Fb account flow with user opt to not share email from facebook preferences ",priority=3)
	public void TS_FacebookLogin_3() throws InterruptedException, IOException {
		//Launch the ace2three app
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		//Signup with facebook
		launchImplPage.getSignupWithFacebook().click();
		
		FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 50);
		verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
		facebookLoginWebimplPage.getFacebookUserIDField().clear();
		facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		Thread.sleep(2000);
		facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 30);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
		facebookLoginWebimplPage.getEditPermissionsLink().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 20);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
		facebookLoginWebimplPage.getEmailAddressCheckBox().click();
		facebookLoginWebimplPage.getContinueWithFacebook().click();
		
		FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
		CustomMethods.waitForElementPresent(facebookImplPage.getEnterEmailOrPhoneAlertFieldWhenEmailNotGiven(),20);
			facebookImplPage.getEnterEmailOrPhoneAlertFieldWhenEmailNotGiven().sendKeys("dineshchakravarthy5@gmail.com");
			facebookImplPage.getEnterEmailOrPhoneAlertSubmitWhenEmailNotGiven().click();
			verifyPresent(facebookImplPage.getCreateUserNameMessage(),"username created automatically message");
			userName = facebookImplPage.getCreateUserNameField().getText();
			String userNameCreatedAutomatically= "Your user name is automatically created as "+userName+". If you want to change, edit the user name below.";
			verifyTextPresent(facebookImplPage.getCreateUserNameMessage(), userNameCreatedAutomatically);
			logger.log(LogStatus.INFO, "User name is: " +userName);
			facebookImplPage.getCreateUserSubmitButton().click();
			Thread.sleep(5000);
			LobbyImplPage lobbyImplPage=new  LobbyImplPage();
			lobbyImplPage.getPlpBannerCloseIcon().click();
			if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
				lobbyImplPage.getPsuedoBannerCloseIcon().click();
			AppOnlyForRealChipsDialogBox  appOnlyForRealChipsDialogBox = new AppOnlyForRealChipsDialogBox(driver);
			if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
				appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
				appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
				}
	}
	
	@Test(description = "Verify Sign up using Fb account flow and user should be linked to facebook in profile when user is an existing account and selects 'Yes I am' from link accounts dialog box",priority=4)
	public void TS_FacebookLogin_4() throws InterruptedException, IOException {
		//Launch the ace2three app
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		//Signup with facebook
		launchImplPage.getSignupWithFacebook().click();
		
		FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 30);
		verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
		facebookLoginWebimplPage.getFacebookUserIDField().clear();
		facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		Thread.sleep(2000);
		facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
		facebookLoginWebimplPage.getFacebookLoginButton().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 30);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
		facebookLoginWebimplPage.getEditPermissionsLink().click();
		CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 30);
		verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
		facebookLoginWebimplPage.getContinueWithFacebook().click();
		
		FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
		CustomMethods.waitForElementPresent(facebookImplPage.getYesIamButton(),30);
		facebookImplPage.getYesIamButton().click();
		verifyPresent(facebookImplPage.getLinkFacebookWithAce2threeAlertMessage(), "Link with facebook dialog box");
		verifyText(facebookImplPage.getLinkFacebookWithAce2threeAlertMessage().getText(),"Enter your Ace2Three credentials to link your facebook and Ace2Three accounts. (This is a one time process)");
		facebookImplPage.getLinkFacebookWithAce2threeAlertUserName().sendKeys("test001");
		facebookImplPage.getLinkFacebookWithAce2threeAlertPassword().sendKeys("Ace2three@");
		facebookImplPage.getLinkFacebookWithAce2threeAlertLoginButton().click();
		LobbyImplPage lobbyImplPage= new LobbyImplPage(driver);
		/*lobbyImplPage.getPlpBannerCloseIcon().click();*/
		if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
			lobbyImplPage.getPsuedoBannerCloseIcon().click();
		AppOnlyForRealChipsDialogBox  appOnlyForRealChipsDialogBox = new AppOnlyForRealChipsDialogBox(driver);
		if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
			appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
			}
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Profile").click();
		SetPasswordDialogBox setPasswordDialogBox= new SetPasswordDialogBox(driver);
		verifyNotPresent(setPasswordDialogBox.getSetNewPasswordSubmitButton(),"Set Password", 2);
		MyAccountImplPage myAccountImplPage= new MyAccountImplPage(driver);
		
		verifyPresent(myAccountImplPage.getPasswordPromtPopUp(), "Password popup");
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		MyProfileImplPage myProfileImplPage= new MyProfileImplPage(driver);
		myProfileImplPage.getDisconnectFromFacebookButton().click();
		verifyPresent(myProfileImplPage.getConfirmDisconnectDialoxBoxMessage(),"Confirm to Disconnect from FB message");
		myProfileImplPage.getConfirmToDisconnectDialoxBoxDisconnectButton().click();
		verifyPresent(myProfileImplPage.getDisconnectedFromFBSuccessMessage(),"Disconnected from fb confirmation message");
		myProfileImplPage.getDisconnectedFromFBSuccessOkButton().click();
		
	}
	
	@Test(description = "Verify whether user is re-directed to login page on clicking “Cancel” button when FB apps is available in device",priority=5)
	public void TS_FacebookLogin_5() throws InterruptedException, IOException {
		//Launch the ace2three app
		CustomMethods.installFacebook();
		//Launch the ace2three App
		/*((AppiumDriver)driver).installApp("D:/Automation/Ace2Three/apk/facebook.apk");*/
		int count =1;
		while(!((AndroidDriver)driver).isAppInstalled("com.facebook.katana")){
			Thread.sleep(2000);
			count++;
				if(count>=500)
					break;
		}
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		//Signup with facebook
		launchImplPage.getSignupWithFacebook().click();
		FacebookLoginPages facebookLoginAppimplPage =new FacebookAppLoginImplPage(driver);
		CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), 60);
		verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
		facebookLoginAppimplPage.getFacebookUserIDField().clear();
		facebookLoginAppimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");
		facebookLoginAppimplPage.getFacebookLoginButton().click();
		Thread.sleep(2000);
		facebookLoginAppimplPage.getFacebookPasswordField().sendKeys("janaiah222");
		facebookLoginAppimplPage.getFacebookLoginButton().click();
		CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsLink(), 110);
		verifyPresent(facebookLoginAppimplPage.getEditPermissionsLink(), "edit permissions link");
		facebookLoginAppimplPage.getEditPermissionsLink().click();
		CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsPage(), 30);
		verifyPresent(facebookLoginAppimplPage.getEditPermissionsPage(),"facebook edit permission page");
		facebookLoginAppimplPage.getCancelButtonInAppLoginPage().click();
		CustomMethods.waitForElementPresent(launchImplPage.getSignupWithFacebook(), 80);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		launchImplPage.getLoginButon().click();
		LoginImplPage loginImplPage= new LoginImplPage(driver);
		Thread.sleep(4000);
		loginImplPage.getLoginWithFacebook().click();
		CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsLink(), 80);
		facebookLoginAppimplPage.getCancelButtonInAppLoginPage().click();
		//verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
		//facebookLoginAppimplPage.getCancelButtonInAppLoginPage().click();
		CustomMethods.waitForElementPresent(loginImplPage.getLoginWithFacebook(), 30);
		verifyPresent(loginImplPage.getLoginWithFacebook(), "Login with facebook button");
	
	}
	
	@Test(description = "Verifiy whether signup is blocked if user age is less than 18 if player allows DOB from FB",priority=6)
	public void TS_FacebookLogin_6() throws InterruptedException, IOException {
		//Launch the ace2three app
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		//Signup with facebook
		launchImplPage.getSignupWithFacebook().click();
		
		FacebookLoginPages facebookLoginAppimplPage =new FacebookAppLoginImplPage(driver);
		CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), 60);
		verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
		facebookLoginAppimplPage.getFacebookUserIDField().clear();
		facebookLoginAppimplPage.getFacebookUserIDField().sendKeys("rajendra.g@headinfotech.com");
		facebookLoginAppimplPage.getFacebookLoginButton().click();
		Thread.sleep(2000);
		facebookLoginAppimplPage.getFacebookPasswordField().sendKeys("Souraj@143");
		facebookLoginAppimplPage.getFacebookLoginButton().click();
		
		CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getAgeRestrictionMessage(), 60);
		verifyText(facebookLoginAppimplPage.getAgeRestrictionMessage().getText(),
				ReadDataFromProps.props.getProperty("facebook.age.restricted.message"));
		facebookLoginAppimplPage.getAgeRestrictionOkayButton().click();
	
	}
	
	@Test(description = "Verify whether Signup is blocked by taking location from FB if player allows location from FB",priority=7, enabled=false)
	public void TS_FacebookLogin_7() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		if(CustomMethods.isElementPresent(launchImplPage.getUpgradeRemaindMeLaterButton()))
			launchImplPage.getUpgradeRemaindMeLaterButton().click();
		verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
		//Signup with facebook
		launchImplPage.getSignupWithFacebook().click();
		
		FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
		if(!((AndroidDriver)driver).isAppInstalled("com.facebook.katana")){
			CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 30);
			verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
			facebookLoginWebimplPage.getFacebookUserIDField().clear();
			facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");
			facebookLoginWebimplPage.getFacebookLoginButton().click();
			Thread.sleep(2000);
			facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
			facebookLoginWebimplPage.getFacebookLoginButton().click();
			CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 30);
			verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
			facebookLoginWebimplPage.getEditPermissionsLink().click();
			CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 30);
			verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
			facebookLoginWebimplPage.getContinueWithFacebook().click();
			Thread.sleep(4000);
			
		}else{
			
			FacebookLoginPages facebookLoginAppimplPage =new FacebookAppLoginImplPage(driver);
			CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), 30);
			verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook App Login page");
			facebookLoginAppimplPage.getFacebookUserIDField().clear();
			facebookLoginAppimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");//change username
			facebookLoginAppimplPage.getFacebookLoginButton().click();
			Thread.sleep(2000);
			facebookLoginAppimplPage.getFacebookPasswordField().sendKeys("janaiah222");
			facebookLoginAppimplPage.getFacebookLoginButton().click();
			CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsLink(), 20);
			verifyPresent(facebookLoginAppimplPage.getEditPermissionsLink(), "edit permissions link");
			CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsPage(), 20);
			verifyPresent(facebookLoginAppimplPage.getEditPermissionsPage(),"facebook edit permission page");
			facebookLoginAppimplPage.getContinueWithFacebook().click();
			Thread.sleep(4000);
			LoginImplPage loginImplPage=new LoginImplPage(driver);
			CustomMethods.waitForElementPresent(loginImplPage.getRestrictedAccessLoginMessage(),20);
			verifyPresent(loginImplPage.getRestrictedAccessLoginMessage(), "Access restricted from you location message");
		}
	
	}

	@Test(description = "verify the signup with mobile number from FB without giving acess to email address from FB",priority=8)
	public void TS_FacebookLogin_8() throws InterruptedException, IOException {
		
		//Launch the ace2three app
		//driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'upgrade_no')]")).click();
				LaunchImplPage launchImplPage = new LaunchImplPage(driver);
				verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
				//Signup with facebook
				launchImplPage.getSignupWithFacebook().click();
				
				FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
				if(!((AndroidDriver)driver).isAppInstalled("com.facebook.katana")){
					CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 40);
					verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
					facebookLoginWebimplPage.getFacebookUserIDField().clear();
					facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");
					facebookLoginWebimplPage.getFacebookLoginButton().click();
					Thread.sleep(2000);
					facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
					facebookLoginWebimplPage.getFacebookLoginButton().click();
					CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 40);
					verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
					facebookLoginWebimplPage.getEditPermissionsLink().click();
					CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 40);
					verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
					facebookLoginWebimplPage.getEmailAddressCheckBox().click();
					facebookLoginWebimplPage.getContinueWithFacebook().click();
					Thread.sleep(4000);
					
				}else{
					
					FacebookLoginPages facebookLoginAppimplPage =new FacebookAppLoginImplPage(driver);
					CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), 30);
					verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook App Login page");
					facebookLoginAppimplPage.getFacebookUserIDField().clear();
					facebookLoginAppimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");//change username
					facebookLoginAppimplPage.getFacebookLoginButton().click();
					Thread.sleep(2000);
					facebookLoginAppimplPage.getFacebookPasswordField().sendKeys("janaiah222");
					facebookLoginAppimplPage.getFacebookLoginButton().click();
					CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsLink(), 20);
					verifyPresent(facebookLoginAppimplPage.getEditPermissionsLink(), "edit permissions link");
					CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsPage(), 20);
					verifyPresent(facebookLoginAppimplPage.getEditPermissionsPage(),"facebook edit permission page");
					facebookLoginAppimplPage.getEmailAddressCheckBox().click();
					facebookLoginAppimplPage.getContinueWithFacebook().click();
					Thread.sleep(4000);
					
				}
				
				FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
				CustomMethods.waitForElementPresent(facebookImplPage.getEnterEmailOrPhoneAlertFieldWhenEmailNotGiven(),30);
				int phone= CustomMethods.generateRandomNumber(5);
				/*System.out.println(phone);
				String phoneNo="55555"+ Integer.toString(phone);*/
					facebookImplPage.getEnterEmailOrPhoneAlertFieldWhenEmailNotGiven().sendKeys("9000061713");
					facebookImplPage.getEnterEmailOrPhoneAlertSubmitWhenEmailNotGiven().click();
					verifyPresent(facebookImplPage.getCreateUserNameMessage(),"username created automatically message");
					String userName = facebookImplPage.getCreateUserNameField().getText();
					this.userName=userName;
					String userNameCreatedAutomatically= "Your user name is automatically created as "+userName+". If you want to change, edit the user name below.";
					verifyTextPresent(facebookImplPage.getCreateUserNameMessage(), userNameCreatedAutomatically);
					logger.log(LogStatus.INFO, "User name is: " +userName);
					facebookImplPage.getCreateUserSubmitButton().click();
					Thread.sleep(5000);
					LobbyImplPage lobbyImplPage=new  LobbyImplPage();
					lobbyImplPage.getPlpBannerCloseIcon().click();
					if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
						lobbyImplPage.getPsuedoBannerCloseIcon().click();
					AppOnlyForRealChipsDialogBox  appOnlyForRealChipsDialogBox = new AppOnlyForRealChipsDialogBox(driver);
					if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
						appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
						appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
						}
					
	}
	
	@Test(description = "If the user gives the email address which is already existing our system, verify whether the user ID is auto populated and cannot be edited",priority=9)
	public void TS_FacebookLogin_9() throws InterruptedException, IOException {
		
		//Launch the ace2three app
		//driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'upgrade_no')]")).click();
			LaunchImplPage launchImplPage = new LaunchImplPage(driver);
			verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
			//Signup with facebook
			launchImplPage.getSignupWithFacebook().click();
			
			FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
			if(!((AndroidDriver)driver).isAppInstalled("com.facebook.katana")){
				CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 30);
				verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
				facebookLoginWebimplPage.getFacebookUserIDField().clear();
				facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("acetest77@gmail.com");
				facebookLoginWebimplPage.getFacebookLoginButton().click();
				Thread.sleep(2000);
				facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("ace2three");
				facebookLoginWebimplPage.getFacebookLoginButton().click();
				CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 20);
				verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
				facebookLoginWebimplPage.getEditPermissionsLink().click();
				CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getContinueWithFacebook(), 20);
				verifyPresent(facebookLoginWebimplPage.getContinueWithFacebook(),"facebook edit permission page");
				facebookLoginWebimplPage.getContinueWithFacebook().click();
				Thread.sleep(4000);
				
			}else{
				
				FacebookLoginPages facebookLoginAppimplPage =new FacebookAppLoginImplPage(driver);
				CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), 30);
				verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook App Login page");
				facebookLoginAppimplPage.getFacebookUserIDField().clear();
				facebookLoginAppimplPage.getFacebookUserIDField().sendKeys("acetest77@gmail.com");//change username
				facebookLoginAppimplPage.getFacebookLoginButton().click();
				Thread.sleep(2000);
				facebookLoginAppimplPage.getFacebookPasswordField().sendKeys("ace2three");
				facebookLoginAppimplPage.getFacebookLoginButton().click();
				CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsLink(), 20);
				verifyPresent(facebookLoginAppimplPage.getEditPermissionsLink(), "edit permissions link");
				CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getContinueWithFacebook(), 20);
				verifyPresent(facebookLoginAppimplPage.getContinueWithFacebook(),"facebook edit permission page");
				facebookLoginAppimplPage.getContinueWithFacebook().click();
				Thread.sleep(4000);
				
			}
			
			FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
			CustomMethods.waitForElementPresent(facebookImplPage.getCreateUserNameField(),30);
			verifyPresent(facebookImplPage.getCreateUserNameField(), "username field");
			CustomMethods.verifyNotEnabled(facebookImplPage.getCreateUserNameField(), "username field");
			
			verifyPresent(facebookImplPage.getLinkFacebookWithAce2threeAlertPassword(), "Password field");
			facebookImplPage.getCloseFbDialogBox().click();
			
	}
	
	@Test(description = "Verify whether user able to connect with FB from profile page.",priority=11)
	public void TS_FacebookLogin_11() throws InterruptedException, IOException {
		//((AndroidDriver)driver).installApp("D:/Automation/Ace2Three/apk/com.facebook.katana_v152.0.0.42.136-83110613_Android-4.0.3.apk");
		//Launch the ace2three App
		SignupImplPage signupImplPage= new SignupImplPage(driver);
		signupImplPage.doSignUp();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage= new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200",paymentMethods.MobiKwik);
		//lobbyImplPage.getSignUpSuccessBuyChipsButton().click();
		verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
				ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
		lobbyImplPage.getLevelUpAlertOkButton().click();
		lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Profile").click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
		MyProfileImplPage  myProfileImplPage= new MyProfileImplPage(driver);
		myProfileImplPage.getConnectWithFacebookButton().click();
		FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
		
		if(!((AndroidDriver)driver).isAppInstalled("com.facebook.katana")){
			
			CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 30);
			verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook App Login page");
			facebookLoginWebimplPage.getFacebookUserIDField().clear();
			facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");//change username
			facebookLoginWebimplPage.getFacebookLoginButton().click();
			Thread.sleep(2000);
			facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
			facebookLoginWebimplPage.getFacebookLoginButton().click();
			CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 20);
			verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
			facebookLoginWebimplPage.getEditPermissionsLink().click();
			CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 20);
			verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
			facebookLoginWebimplPage.getContinueWithFacebook().click();
			
		}else{
			
			FacebookLoginPages facebookLoginAppimplPage =new FacebookAppLoginImplPage(driver);
			CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), 30);
			verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook App Login page");
			facebookLoginAppimplPage.getFacebookUserIDField().clear();
			facebookLoginAppimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");//change username
			facebookLoginAppimplPage.getFacebookLoginButton().click();
			Thread.sleep(2000);
			facebookLoginAppimplPage.getFacebookPasswordField().sendKeys("janaiah222");
			facebookLoginAppimplPage.getFacebookLoginButton().click();
			CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsLink(), 20);
			verifyPresent(facebookLoginAppimplPage.getEditPermissionsLink(), "edit permissions link");
			CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsPage(), 20);
			verifyPresent(facebookLoginAppimplPage.getEditPermissionsPage(),"facebook edit permission page");
			facebookLoginAppimplPage.getContinueWithFacebook().click();
			Thread.sleep(4000);
			
		}
		CustomMethods.waitForElementPresent(myProfileImplPage.getConnectWithFbSuccessMessage(), 20);
		verifyTextPresent(myProfileImplPage.getConnectWithFbSuccessMessage(), ReadDataFromProps.props.getProperty("connect.with.fb.success.message"));
		myProfileImplPage.getconnectFromFBSuccessOkButton().click();
		
		verifyPresent(myProfileImplPage.getDisconnectFromFacebookButton(), "Disconnect from FB button");
		//Verify whether the profile details are auto-filled from FB
				logger.log(LogStatus.INFO, "verifying whether profile details has auto filled or not");
				verifyTextPresent(myProfileImplPage.getMyProfileFirstNameField(),"Gopi");
				verifyTextPresent(myProfileImplPage.getMyProfileLastNameField(),"Dugyala");
				verifyTextPresent(myProfileImplPage.getMyProfileGenderDropDownField(),"Male");
		
	}
	

	@Test(description = "Verifiy whether user able to access my account, profile, KYC, purchase limits pages without setting the password",priority=10)
	public void TS_FacebookLogin_10() throws InterruptedException, IOException {
		
				//Launch the ace2three app
				//driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'upgrade_no')]")).click();
					LaunchImplPage launchImplPage = new LaunchImplPage(driver);
					verifyPresent(launchImplPage.getSignupWithFacebook(), "Signup with facebook button");
					//Signup with facebook
					launchImplPage.getSignupWithFacebook().click();
					FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
					if(!((AndroidDriver)driver).isAppInstalled("com.facebook.katana")){
						CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), 30);
						verifyPresent(facebookLoginWebimplPage.getFacebookLoginPageHeader(), "Facebook web Login page");
						facebookLoginWebimplPage.getFacebookUserIDField().clear();
						facebookLoginWebimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");
						facebookLoginWebimplPage.getFacebookLoginButton().click();
						Thread.sleep(2000);
						facebookLoginWebimplPage.getFacebookPasswordField().sendKeys("janaiah222");
						facebookLoginWebimplPage.getFacebookLoginButton().click();
						CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsLink(), 30);
						verifyPresent(facebookLoginWebimplPage.getEditPermissionsLink(), "edit permissions link");
						facebookLoginWebimplPage.getEditPermissionsLink().click();
						CustomMethods.waitForElementPresent(facebookLoginWebimplPage.getEditPermissionsPage(), 30);
						verifyPresent(facebookLoginWebimplPage.getEditPermissionsPage(),"facebook edit permission page");
			
						facebookLoginWebimplPage.getContinueWithFacebook().click();
						Thread.sleep(4000);
						
					}else{
						
						FacebookLoginPages facebookLoginAppimplPage =new FacebookAppLoginImplPage(driver);
						CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), 30);
						verifyPresent(facebookLoginAppimplPage.getFacebookLoginPageHeader(), "Facebook App Login page");
						facebookLoginAppimplPage.getFacebookUserIDField().clear();
						facebookLoginAppimplPage.getFacebookUserIDField().sendKeys("dineshchakravarthy5@gmail.com");//change username
						facebookLoginAppimplPage.getFacebookLoginButton().click();
						Thread.sleep(2000);
						facebookLoginAppimplPage.getFacebookPasswordField().sendKeys("janaiah222");
						facebookLoginAppimplPage.getFacebookLoginButton().click();
						CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsLink(), 20);
						verifyPresent(facebookLoginAppimplPage.getEditPermissionsLink(), "edit permissions link");
						CustomMethods.waitForElementPresent(facebookLoginAppimplPage.getEditPermissionsPage(), 20);
						verifyPresent(facebookLoginAppimplPage.getEditPermissionsPage(),"facebook edit permission page");
						facebookLoginAppimplPage.getContinueWithFacebook().click();
						Thread.sleep(4000);
						
					}
					
					FacebookImplPage facebookImplPage = new  FacebookImplPage(driver);
					
					verifyPresent(facebookImplPage.getNoIamNotButton(), "Yes I am and no I am not alert");
					facebookImplPage.getNoIamNotButton().click();
					Thread.sleep(2000);
					verifyPresent(facebookImplPage.getCreateUserNameMessage(),"username created automatically message");
					this.userName = facebookImplPage.getCreateUserNameField().getText();
					CustomMethods.VerifyElementIsEditable(facebookImplPage.getCreateUserNameField(), "Auto Generated userID field","enabled");
					String userNameCreatedAutomatically= "Your user name is automatically created as "+userName+". If you want to change, edit the user name below.";
					verifyTextPresent(facebookImplPage.getCreateUserNameMessage(), userNameCreatedAutomatically);
					logger.log(LogStatus.INFO, "User name is: " +userName);
					
					facebookImplPage.getCreateUserSubmitButton().click();
					Thread.sleep(5000);
					LobbyImplPage lobbyImplPage=new  LobbyImplPage();
					lobbyImplPage.getPlpBannerCloseIcon().click();
					if(CustomMethods.isElementPresent(lobbyImplPage.getPsuedoBannerCloseIcon()))
					lobbyImplPage.getPsuedoBannerCloseIcon().click();
					AppOnlyForRealChipsDialogBox  appOnlyForRealChipsDialogBox = new AppOnlyForRealChipsDialogBox(driver);
					/*if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips()))*/
						//AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
					if(CustomMethods.isElementPresent(appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips())){
					appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesBuyChips().click();
					appOnlyForRealChipsDialogBox.getAppOnlyForRealChipsGamesClose().click();
					}
				
					lobbyImplPage.verifyLobbyPageDisplayed();
				
					lobbyImplPage.getHamburgerMenu().click();
					lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Account Details").click();
					SetPasswordDialogBox setPasswordDialogBox= new SetPasswordDialogBox(driver);
					verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
					setPasswordDialogBox.getSetPasswordCloseIcon().click();
					lobbyImplPage.getHamburgerMenu().click();
					lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Profile").click();
					verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
					setPasswordDialogBox.getSetPasswordCloseIcon().click();
				
					/*lobbyImplPage.getAddChipsButton().click();
					AddCashWebViewImplPage addCashWebViewImplPage=new AddCashWebViewImplPage(driver);
					Thread.sleep(2000);
					addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
					verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
					verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
							ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
					lobbyImplPage.getLevelUpAlertOkButton().click();
					lobbyImplPage.getUpdateProfilePopUpClose().click();*/
					
					
					/*lobbyImplPage.getHamburgerMenu().click();
					lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Redeem").click();
					verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
					setPasswordDialogBox.getSetPasswordCloseIcon().click();
					lobbyImplPage.getHamburgerMenu().click();
					lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
					verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
					setPasswordDialogBox.getSetPasswordCloseIcon().click();
					lobbyImplPage.getHamburgerMenu().click();
					lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Bank Accounts").click();
					verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
					setPasswordDialogBox.getSetPasswordCloseIcon().click();
					lobbyImplPage.getHamburgerMenu().click();
					lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Purchase Limits").click();
					verifyPresent(setPasswordDialogBox.getSetPasswordAlertMessage(),"Set password alert");
					setPasswordDialogBox.getSetPasswordCloseIcon().click();
					*/
	}
	
	/*@Test
	public void face() throws IOException{
		FacebookLoginWebimplPage facebookLoginWebimplPage= new FacebookLoginWebimplPage(driver);
		facebookLoginWebimplPage.resetFacebookAppOrBrowser();	
		CustomMethods.unInstallFacebook();
	}*/
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException, InterruptedException, SQLException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
				
			try{
				if(desktopDriver.toString().contains("null")){
					logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
					}else{
						logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),desktopDriver)));
						desktopDriver.close();
					}
			}catch(Exception e){
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
			logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		CustomMethods cm= new  CustomMethods();
		try{
		((AppiumDriver) driver).resetApp();
		FacebookWebSiteImplPage facebookWebSiteImplPage= new FacebookWebSiteImplPage();
		FacebookLoginWebimplPage facebookLoginWebimplPage =new FacebookLoginWebimplPage(driver);
		
		if("TS_FacebookLogin_8".equalsIgnoreCase(method.getName())){
			
			String disconnectFBQuery = "update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('"+userName+"')";
			dataBaseConnection.updateQuery(disconnectFBQuery, null);
			String query="update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%9000061713'";
			dataBaseConnection.updateQuery(query, null);
			
			desktopDriver= cm.launchWebBrowser();
			AdminImplPage adminImplPage= new AdminImplPage(desktopDriver);
			adminImplPage.updatePhoneNumberAndEmailInProfile(userName);
			//facebookLoginWebimplPage.resetFacebookAppOrBrowser();
			cm.clearChromeData();
			facebookWebSiteImplPage.removeFbFromSite();
			
			
		}if("TS_FacebookLogin_9".equalsIgnoreCase(method.getName())){
			//facebookLoginWebimplPage.resetFacebookAppOrBrowser();
			cm.clearChromeData();
			facebookWebSiteImplPage.removeFbFromSite1();
		}if(method.getName().equalsIgnoreCase("TS_FacebookLogin_1") || method.getName().equalsIgnoreCase("TS_FacebookLogin_2") || method.getName().equalsIgnoreCase("TS_FacebookLogin_3")
				|| method.getName().equalsIgnoreCase("TS_FacebookLogin_11") || method.getName().equalsIgnoreCase("TS_FacebookLogin_10")){
			System.out.println("in after method fb_ts_2 or 1");
			String disconnectFBQuery = "update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('"+userName+"')";
			dataBaseConnection.updateQuery(disconnectFBQuery, null);
//			 String query="update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%9000061713'";
//			dataBaseConnection.updateQuery(query, null);
			desktopDriver= cm.launchWebBrowser();
			AdminImplPage adminImplPage= new AdminImplPage(desktopDriver);
			adminImplPage.updatePhoneNumberAndEmailInProfile(userName);
			//facebookLoginWebimplPage.resetFacebookAppOrBrowser();
			facebookWebSiteImplPage.removeFbFromSite();
			if(method.getName().equalsIgnoreCase("TS_FacebookLogin_2"))
			cm.unInstallFacebook();
			
		}if(method.getName().equalsIgnoreCase("TS_FacebookLogin_4")){
			cm.clearChromeData();
			facebookWebSiteImplPage.removeFbFromSite();
			String disconnectFBQuery = "update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('test001')";
			dataBaseConnection.updateQuery(disconnectFBQuery, null);
		}if(method.getName().equalsIgnoreCase("TS_FacebookLogin_6")){
			cm.unInstallFacebook();
		}if(method.getName().equalsIgnoreCase("TS_FacebookLogin_5")){
			cm.clearFBData();
		}
	  }catch(Exception e){
		  logger.log(LogStatus.INFO, e);
	  }
		cm.clearChromeData();
	//	facebookLoginWebimplPage.resetFacebookAppOrBrowser();
		extent.flush();
		extent.endTest(logger);
		
		
	}
	public static void main(String args[]) throws InterruptedException, SQLException
	{
		/*DataBaseServerConnect daBaseServerConnect = new DataBaseServerConnect();
		String disconnectFBQuery = "update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('gopidu6573')";
		daBaseServerConnect.updateQuery(disconnectFBQuery, null);*/
		
	}
	
	
}