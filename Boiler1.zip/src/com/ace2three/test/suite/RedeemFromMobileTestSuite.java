package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.List;

import org.apache.http.impl.cookie.BestMatchSpec;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.BankAccountsImplPage;
import com.ace2three.impl.pages.ChangePasswordImplPage;
import com.ace2three.impl.pages.KycImplPage;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.MyAccountDetailsImplPage;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.RedeemFromMobileImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class RedeemFromMobileTestSuite extends BaseTestSuite {
	
	
	WebDriver desktopDriver;
	ReadDataFromProps ReadProps;
	
	
	@BeforeMethod
	public void beforeMethos(Method method) {
		Test test = method.getAnnotation(Test.class);
		
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		ReadProps= new ReadDataFromProps();
	}
	
	@Test(description = "Check whether premium player is able to place redeem request or not."
			+ "Verify whether redeem request is displayed in reversal tab after successful cancellation in redeem tab.", priority=1)
	public void TS_Sanity__RedeemFromMobile_01() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		verifyPresent(launchImplPage.getLoginButon(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
	
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.RedeemChips);
		
		RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
		verifyPresent(redeemFromMobileImplPage.getRedeemTab(), "Redeem Screen");
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys("200");
		redeemFromMobileImplPage.getRedeemRequestButton().click();
		String expectedConfirmRedeemText="You are placing a redeem request of INR 200.\nDo you want to continue?";
		String actualConfirmRedeemText=redeemFromMobileImplPage.getConfirmRedeemText().getText();
		verifyText(actualConfirmRedeemText, expectedConfirmRedeemText, "Confirmation text");
		verifyPresent(redeemFromMobileImplPage.getConfirmRedeemYes(), "Confirmation Pop-Up");
		redeemFromMobileImplPage.getConfirmRedeemYes().click();
		
		
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemStatus(), 10);
		verifyText(redeemFromMobileImplPage.getRedeemStatus().getText(), "Your redeem request for 200 has been submitted successfully");
		redeemFromMobileImplPage.getReversalTab().click();
		verifyPresent(redeemFromMobileImplPage.getCancelRedeemRequestButton(), "Reversal Tab");
		redeemFromMobileImplPage.getCancelRedeemRequestButton().click();
		verifyPresent(redeemFromMobileImplPage.getCancelRedeemRequestPopUpYesButton(), "Cancel Redeem Request");
		redeemFromMobileImplPage.getCancelRedeemRequestPopUpYesButton().click();
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemReversalSuccessfulButton(), 10);
		redeemFromMobileImplPage.getRedeemReversalSuccessfulButton().click();
		redeemFromMobileImplPage.getRedeemTab().click();
		
		
	}
	
	
	@Test(description = "For regular user when click on redeem , it should navigate to web browser and "
			+ "'please make a real chip purchase to access this feature message should be displayed", priority=1)
	public void TS_Sanity__RedeemFromMobile_02() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("gpic40");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
	
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.RedeemChips);
		
		RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
		
		WebElement ele = redeemFromMobileImplPage.getRedeemableBalance();
		float redeemableAmount = Float.parseFloat(ele.getText());
		redeemFromMobileImplPage.getRedeemRequestButton().click();
		redeemFromMobileImplPage.verifyValidation();
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys("1");
		redeemFromMobileImplPage.setEnteredRedeemAmount("1");
		redeemFromMobileImplPage.getRedeemRequestButton().click();
		redeemFromMobileImplPage.verifyValidation();
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys((redeemableAmount+1)+"");
		redeemFromMobileImplPage.setEnteredRedeemAmount((redeemableAmount+1)+"");
		redeemFromMobileImplPage.getRedeemRequestButton().click();
		redeemFromMobileImplPage.verifyValidation();
		
	}
	@Test(description = "Check balance is updating properly in user wallet after accepting/rejecting redeem request.", priority=1)
	public void TS_Sanity__RedeemFromMobile_03() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		float BRamount =Float.parseFloat( lobbyImplPage.getNoOfRealChipsCount().getText());
		int BRwalletAmount = (int)BRamount;
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Redeem").click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
		System.out.println(redeemFromMobileImplPage.getRedeemableBalance().getText());
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemTab(),10);
		float redBal =Float.parseFloat( redeemFromMobileImplPage.getRedeemableBalance().getText());
		int redeemBalAmount = (int)redBal;
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys("200");
		redeemFromMobileImplPage.getRedeemRequestButton().click();
		redeemFromMobileImplPage.getConfirmRedeemYes().click();
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemStatus(),10);
		verifyText(redeemFromMobileImplPage.getRedeemStatus().getText(), "Your redeem request for 200 has been submitted successfully");
		redeemFromMobileImplPage.getReversalTab().click();
		redeemFromMobileImplPage.getRedeemTab().click();
		float bal = Float.parseFloat(redeemFromMobileImplPage.getRedeemableBalance().getText().toString());
		int redeemBal = (int)bal;
		float ARamount =Float.parseFloat( lobbyImplPage.getNoOfRealChipsCount().getText());
		int ARwalletAmount = (int)ARamount;
		logger.log(LogStatus.INFO, "Redeemable Balance");
		verifyText(""+redeemBal, ""+(redeemBalAmount-200));
		logger.log(LogStatus.INFO, "Wallet Balance");
		verifyText(""+ARwalletAmount, ""+(BRwalletAmount-200));
		
		redeemFromMobileImplPage.getReversalTab().click();
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
		desktopDriver.get(ReadProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list)
		{
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("CASHIER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		desktopDriver.findElement(By.cssSelector("a[href='creditDebitTransactions.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("a[href*='withdrawBankPending']")).click();
	
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		Thread.sleep(2000);
		desktopDriver.findElement(By.xpath("//form[@name='form1']/div[1]/img")).click();
		Thread.sleep(2000);
		desktopDriver.findElement(By.cssSelector("td[class*='ui-datepicker-today']")).click();
		desktopDriver.findElement(By.xpath("//form[@name='form1']/div[2]/img")).click();
		Thread.sleep(2000);
		desktopDriver.findElement(By.cssSelector("td[class*='ui-datepicker-today']")).click();
		
		JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
		WebElement searchElement= desktopDriver.findElement(By.cssSelector("input[value='Search']"));
		executor.executeScript("arguments[0].click();", searchElement );
		
		desktopDriver.findElement(By.cssSelector("input[value*='"+redeemFromMobileImplPage.getRedeemReferalId().getText().toString().trim()+"']")).click();
		
		desktopDriver.findElement(By.cssSelector("textarea[id='comment']")).sendKeys("asdfsadf");
		Thread.sleep(1000);
		desktopDriver.findElement(By.cssSelector("input[value='Approve']")).click();
		desktopDriver.switchTo().alert().accept();
		CustomMethods.waitForElementPresent(desktopDriver.findElement(By.tagName("body")), 10);
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		
		BaseTestSuite baseTestSuite = new BaseTestSuite();
		baseTestSuite.verifyText(desktopDriver.findElement(By.tagName("body")).getText().trim(), 
		"Transaction Approved for RequestID:"+redeemFromMobileImplPage.getRedeemReferalId().getText().toString().trim()); 
		desktopDriver.close();
		
		
		
	}
	
	@Test(description = "For regular user when click on redeem , it should navigate to web browser and "
			+ "'please make a real chip purchase to access this feature message should be displayed", priority=1)
	public void TS_Sanity__RedeemFromMobile_04() throws InterruptedException, IOException {
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		launchImplPage.getUsernameField().sendKeys("gpic50");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		float BRamount =Float.parseFloat( lobbyImplPage.getNoOfRealChipsCount().getText());
		int BRwalletAmount = (int)BRamount;
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
	
		myAccountPage.launchMyAccountDetailsScreen();
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.RedeemChips);
		
		RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getReversalTab(), 10);
		
		float bal = Float.parseFloat(redeemFromMobileImplPage.getRedeemableBalance().getText().toString());
		int BRredeemBal = (int)bal;//BR(Before Redeem) means redeemable balance before placing redeem request
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys("200");
		redeemFromMobileImplPage.getRedeemRequestButton().click();
		redeemFromMobileImplPage.getConfirmRedeemYes().click();
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getReversalTab(),10);
		redeemFromMobileImplPage.getReversalTab().click();
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
		desktopDriver.get(ReadProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		
		JavascriptExecutor js = (JavascriptExecutor) desktopDriver;  
		js.executeScript("document.body.style.zoom = '0.9'");
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list)
		{
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
	
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys("gpic50");
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
		Thread.sleep(1000);
		
		desktopDriver.findElement(By.cssSelector("a[href*='playerCashierSummary.jsp?userid=gpic50']")).click();
		
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		
		desktopDriver.findElement(By.cssSelector("a[href*='playerTodayBankWithdrawalPending.jsp']")).click();
		
		Thread.sleep(1000);

		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		
		desktopDriver.findElement(By.cssSelector("input[value*='"+redeemFromMobileImplPage.getRedeemReferalId().getText().toString().trim()+"']")).click();
		
		desktopDriver.findElement(By.cssSelector("textarea[id='comment']")).sendKeys("asdfsadf");
		Thread.sleep(1000);
		desktopDriver.findElement(By.cssSelector("input[value='Redeem Reject']")).click();
		desktopDriver.switchTo().alert().accept();
		CustomMethods.waitForElementPresent(desktopDriver.findElement(By.tagName("body")), 10);
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		
		BaseTestSuite baseTestSuite = new BaseTestSuite();
		baseTestSuite.verifyText(desktopDriver.findElement(By.tagName("body")).getText().trim(), 
		"Transaction Rejected for RequestID:"+redeemFromMobileImplPage.getRedeemReferalId().getText().toString().trim()); 
		desktopDriver.close();
		
		lobbyImplPage.getHomeTabIcon().click();
		float ARamount =Float.parseFloat( lobbyImplPage.getNoOfRealChipsCount().getText());
		int ARwalletAmount = (int)ARamount;
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Redeem").click();
		//MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemTab(),10);
		float ARbal = Float.parseFloat(redeemFromMobileImplPage.getRedeemableBalance().getText().toString());
		int ARredeemBal = (int)ARbal;//BR(Before Redeem) means redeemable balance before placing redeem request
		
		
		logger.log(LogStatus.INFO, "Redeemable Balance");
		verifyText(""+ARredeemBal, ""+BRredeemBal);
		logger.log(LogStatus.INFO, "Wallet Balance");
		verifyText(""+ARwalletAmount, ""+BRwalletAmount);
		
		
		
	}
	
	@Test(description = "Check whether player able to place only one redeem request after upload KYC document to get verified.", priority=1)
	public void TS_Sanity__RedeemFromMobile_05() throws InterruptedException, IOException, SQLException {
		String userName="qatest103";
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignupWithFacebook(), "SignUp Screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("Billa@123");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Redeem").click();
		verifyPresent(lobbyImplPage.getVerifyEmailPhoneNoPopUp(), "Verify Email and Mobile No pop-up");
		lobbyImplPage.getLaterButton().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		Thread.sleep(1000);
		lobbyImplPage.getHamburgerMenu().click();
		//lobbyImplPage.getHamburgerMenu().click();//////////////////////////////////////////////////////////////////////////////////////////////
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "Redeem").click();
		verifyPresent(lobbyImplPage.getVerifyEmailPhoneNoPopUp(), "Verify Email and Mobile No pop-up");
		verifyText(lobbyImplPage.getVerifyEmailPhoneNoPopUp().getText(), "Please verify your email id and phone number to place a redeem request.");
		lobbyImplPage.getVerifyNowButton().click();
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.getPasswordPopUpField().sendKeys("Billa@123");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		KycImplPage kycImplPage = new KycImplPage(driver);
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(), 10);
		
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.Logout, null).click();
		lobbyImplPage.getLogoutAlertPopupYesButton().click();
		verifyPresent(launchImplPage.getUsernameField(), "Login page");
		
		String verifyEmailAndMobileNo="update game_user_master set user_confirmation = 'Y',phone_verified = 'Y' where upper(user_id) = upper('"+userName+"')";
		dataBaseConnection.updateQuery(verifyEmailAndMobileNo, null);
		
		launchImplPage.getpasswordField().sendKeys("Billa@123");
		launchImplPage.getLoginClickButton().click();
		lobbyImplPage.verifyPostLaunchBanners();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		myAccountPage.getPasswordPopUpField().sendKeys("Billa@123");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(), 10);
		verifyNotPresent(kycImplPage.getKycEmailVerifyButton(), "Email verify button", 10);
		verifyNotPresent(kycImplPage.getKycPhoneNoVerifyButton(), "Phone Number verify button", 10);
		myAccountPage.getMyAccountScreenLeftArrow().click();
		RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getpleaseProvideYourKYCDocumentsText(),10);
		verifyText(redeemFromMobileImplPage.getpleaseProvideYourKYCDocumentsText().getText(), "Please provide your KYC documents in order to place a redeem. Information shared with us is stored securely.");
		redeemFromMobileImplPage.getpleaseProvideYourKYCDocumentsOkButton().click();
		verifyPresent(kycImplPage.getToProceedWithRedeemRequestText(), "To proceed with the redeem request text");
		myAccountPage.getMyAccountScreenLeftArrow().click();
		redeemFromMobileImplPage.getpleaseProvideYourKYCDocumentsCancelButton().click();
		verifyNotPresent(kycImplPage.getToProceedWithRedeemRequestText(), "To proceed with the redeem request", 5);
		kycImplPage.uploadIdProofAadharOneSide(userName);
		myAccountPage.getMyAccountScreenLeftArrow().click();
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemTab(),5);
		verifyPresent(redeemFromMobileImplPage.getRedeemTab(), "Redeem Screen");
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys("200");
		redeemFromMobileImplPage.getRedeemRequestButton().click();
		redeemFromMobileImplPage.getConfirmRedeemYes().click();
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemStatus(),10);
		redeemFromMobileImplPage.getReversalTab().click();
		redeemFromMobileImplPage.getRedeemTab().click();
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys("200");
		redeemFromMobileImplPage.getRedeemRequestButton().click();	
		verifyText(redeemFromMobileImplPage.getKycHasToBeVerifiedText().getText(), "Please note that your KYC has to be verified before placing another redeem request. Click ok to verify your KYC status.");
		redeemFromMobileImplPage.getKycHasToBeVerifiedTextCancelButton().click();
		redeemFromMobileImplPage.getEnterRedeemAmount().sendKeys("200");
		redeemFromMobileImplPage.getRedeemRequestButton().click();	
		redeemFromMobileImplPage.getKycHasToBeVerifiedTextOkButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycPhoneNoField(),5);
		verifyPresent(kycImplPage.getKycPhoneNoField(), "KYC screen");
		myAccountPage.getMyAccountScreenLeftArrow().click();
		redeemFromMobileImplPage.getReversalTab().click();
		redeemFromMobileImplPage.getCancelRedeemRequestButton().click();
		redeemFromMobileImplPage.getCancelRedeemRequestPopUpYesButton().click();
		CustomMethods.waitForElementPresent(redeemFromMobileImplPage.getRedeemReversalSuccessfulButton(),10);
		redeemFromMobileImplPage.getRedeemReversalSuccessfulButton().click();
		String unVerifyEmailAndMobileNo="update game_user_master set user_confirmation = 'N',phone_verified = 'N' where upper(user_id) = upper('qatest103')";
		dataBaseConnection.updateQuery(unVerifyEmailAndMobileNo, null);
	
	}
	
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
				
			try{
				if(desktopDriver.toString().contains("null")){
					logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
					}else{
						logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),desktopDriver)));
						desktopDriver.close();
					}
			}catch(Exception e){
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
		}
		((AppiumDriver) driver).resetApp();
		extent.flush();
		extent.endTest(logger);
		
	}
	


}
