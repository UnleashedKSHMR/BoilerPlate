package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.component.pages.DisconnectionPopUp;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.Connection;

public class SignupTestSuite extends BaseTestSuite {
	
	
	DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
	Date date = new Date();
	@BeforeMethod
	public void beforeMethod(Method method) throws IOException{
		Test test = method.getAnnotation(Test.class);
		super.logger = extent.startTest(method.getName()+" : " + test.description());
		System.out.println("Before Method");
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);	
		launchImplPage.verifyUpgradePopup();
	}
	
	@Test(description="Verify that all the available objects are visible on Sign Up screen")
	public void TS_Signup_1(){
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		
		verifyPresent(signupimplpage.getAce2threelogo(),"Ace2three Logo");
		verifyPresent(signupimplpage.getLobbycountDisplay(),"Lobby Count");
		verifyPresent(signupimplpage.getUsernamefield(),"Username field");
		verifyPresent(signupimplpage.getEmailidfield(),"Emailid and mobileno field ");
		verifyPresent(signupimplpage.getPasswordfield(),"Password field");	
		verifyPresent(signupimplpage.getSignupbutton(),"Signup Button");
		verifyPresent(signupimplpage.getSignupnote(),"signup note");
		verifyPresent(signupimplpage.getLoginlinktext(),"Already have an account");
		verifyPresent(signupimplpage.getLoginlink(),"Login_Link");
			
	}
	
	@Test(description="Verify that auto successful login to a registered user to "
			+ "the application when valid user ID / Email ID and password is provided")
	public void TS_Signup_2(){
		
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		dateFormat.format(date);
		String Username= "test" + dateFormat.format(date);
		logger.log(LogStatus.INFO, "User Name: "+Username);
		WebDriverWait wait= new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(signupimplpage.getUsernamefield()));
		signupimplpage.getUsernamefield().sendKeys(Username);
		signupimplpage.getEmailidfield().sendKeys("use"+Username+"@ds.com");
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		signupimplpage.getSignupbutton().click();
		
		/*try {
			CustomMethods.waitForElementPresent(signupimplpage.getSignupSuccessfulBannerNoThanksButton());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		// Need to add one more step
			LobbyImplPage lobbyPage = new LobbyImplPage(driver);
			lobbyPage.verifyLobbyPageDisplayed();
			//signupimplpage.verifyPostSignUpBanner();
	}
	
	@Test(description="Verify that auto successful login to a registered user to the application when valid user ID / Mobile number and password is provided")
	public void TS_Signup_3(){
		
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		dateFormat.format(date);
		String Username= "test" + dateFormat.format(date);
		logger.log(LogStatus.INFO, "User Name: "+Username);
		signupimplpage.getUsernamefield().sendKeys(Username);
		signupimplpage.getEmailidfield().sendKeys(ReadDataFromProps.props.getProperty("mobile.number"));
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		signupimplpage.getSignupbutton().click();
	
	}
	
	@Test(description="Verify that error message is displayed when a valid user id and password with invalid email id is provided ")
	public void TS_Signup_4(){
		
		SignupImplPage signupimplpage = new SignupImplPage(driver);
	
		// Invalid emailid
		signupimplpage.getUsernamefield().sendKeys("nani1941");
		signupimplpage.getEmailidfield().sendKeys("dfser@sdfds");
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		signupimplpage.getSignupbutton().click();
		verifyPresent(signupimplpage.getErrorMessage(),"Please enter valid email ID");
		
		// Empty emailid
		signupimplpage.getEmailidfield().clear();
		signupimplpage.getSignupbutton().click();
		verifyPresent(signupimplpage.getErrorMessage(),"Please enter Email or Mobile Number.");
		
}
	@Test(description="Verify that error message is displayed when a valid user id and email id with invalid password is provided & "
			+ "Verify password field is allowing more than 20 characters or not.(It should not allow")
	public void TS_Signup_5() throws IOException{
		
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		
		// Invalid - Spl char - password
		signupimplpage.getUsernamefield().sendKeys("nani1941");
		signupimplpage.getEmailidfield().sendKeys("dfser@sdfds.com");
		signupimplpage.getPasswordfield().sendKeys("@#$#$%%$$");
		signupimplpage.getSignupbutton().click();

		// Single quotation error
		//verifyPresent(signupimplpage.getErrorMessage(),"Password should not contain Spaces and characters # : & " ' < > % , \  /");
		
		// Three characters - password
		signupimplpage.getPasswordfield().clear();
		signupimplpage.getPasswordfield().sendKeys("abc");
		signupimplpage.getSignupbutton().click();
		verifyPresent(signupimplpage.getErrorMessage(),"Password should be between 8 to 20 characters long");
		
		// Empty password
		signupimplpage.getPasswordfield().clear();
		signupimplpage.getSignupbutton().click();
		verifyPresent(signupimplpage.getErrorMessage(),"Password cannot be empty");
		
		//More than 20 characters - Password
		signupimplpage.getPasswordfield().clear();
		signupimplpage.getPasswordfield().sendKeys("sadfsasdfas@asd141541asdfssaf");
		signupimplpage.getShowPassword().click();
		if(verifyText(signupimplpage.getPasswordfield().getText(), "sadfsasdfas@asd14154"))
		{
			logger.log(LogStatus.PASS, "Password field is not allowing more than 20 characters.");
		}
		else
			logger.log(LogStatus.FAIL, "Password field is allowing more than 20 characters."+logger.addScreenCapture(""));
			
	}
		
	@Test(description="Verify that error message is displayed when a invalid user id and valid email id valid  password is provided"
			+ "Verify username field is accepting special characters or not ( It should allow only few special characters"
			+ "Verify username field is allowing more than 12 characters or not. (It should not allow")
	public void TS_Signup_6() throws IOException, InterruptedException{
	
		SignupImplPage signupimplpage = new SignupImplPage(driver);
			
		
		signupimplpage.getUsernamefield().sendKeys("1234234");
		signupimplpage.getEmailidfield().sendKeys("dfser@sdfds.com");
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		signupimplpage.getSignupbutton().click();
		
		// username - Start with numeric 
		verifyPresent(signupimplpage.getErrorMessage(),"User Id should should start with an alphabet");
		
		// Empty username
		signupimplpage.getUsernamefield().clear();
		signupimplpage.getSignupbutton().click();
		verifyPresent(signupimplpage.getErrorMessage(),"User ID cannot be empty");
		
		// User id already exist
		signupimplpage.getUsernamefield().clear();
		signupimplpage.getUsernamefield().sendKeys("nani2");
		signupimplpage.getSignupbutton().click();
		verifyPresent(signupimplpage.getErrorMessage(),"User ID already exists. Please enter again.");
		
		//Special Character - User Id
		signupimplpage.getUsernamefield().clear();
		signupimplpage.getUsernamefield().sendKeys("~`!@#$%^&*()_+=-{[}]:;'\"|\\<,>.?/");
		signupimplpage.getSignupbutton().click();
		System.out.println(signupimplpage.getErrorMessage().getText());
		//verifyPresent(signupimplpage.getErrorMessage(), "User ID cannot be empty") ;
		verifyText(signupimplpage.getErrorMessage().getText(), "User ID cannot be empty");
		
		//More than 12 characters in User Id field
		signupimplpage.getUsernamefield().clear();
		signupimplpage.getUsernamefield().sendKeys("nani12345678912345");
		logger.log(LogStatus.INFO, "Entered user id is nani12345678912345");
		if(verifyText(signupimplpage.getUsernamefield().getText(), "nani12345678"))
		{
			logger.log(LogStatus.PASS, "User Id field is not allowing more than 12 characters.");
		}
		else
			logger.log(LogStatus.FAIL, "User Id field is allowing more than 12 characters."+logger.addScreenCapture(""));
				
	}
	
	@Test(description="Verify that error message is displayed when a valid user id and password with invalid mobile number")
	public void TS_Signup_7(){
	
		SignupImplPage signupimplpage = new SignupImplPage(driver);
	
	
		signupimplpage.getUsernamefield().sendKeys("	");
		signupimplpage.getmobileNofiled().sendKeys("123");
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		signupimplpage.getSignupbutton().click();
		
		// invalid mobile number
		verifyPresent(signupimplpage.getErrorMessage(),"Please enter valid Mobile number");
	
		
		// Empty mobile number
		signupimplpage.getmobileNofiled().clear();
		signupimplpage.getSignupbutton().click();
		verifyPresent(signupimplpage.getErrorMessage(),"Please enter Email or Mobile Number.");
	}
	
	@Test(description="Verify that error message is displayed when user id , email / mobile number and password edit fields are left blank and clicks on sign up button")
	public void TS_Signup_8(){
	
		SignupImplPage signupimplpage = new SignupImplPage(driver);
	
		signupimplpage.getUsernamefield().clear();
		signupimplpage.getEmailidfield().clear();
		signupimplpage.getPasswordfield().clear();
		signupimplpage.getSignupbutton().click();
		
		
		verifyPresent(signupimplpage.getErrorMessage(),"User ID cannot be empty");
	}
	

	@Test(description="Verify that login screen is displayed when user clicks on Already have an Account Login link")
	public void TS_Signup_9(){
	
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		
		signupimplpage.getLoginlink().click();
		
		LaunchImplPage launchImplPage= new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getLoginClickButton(), "Login page");
	}
	
	@Test(description="Verify that asterisk mark converted to string value by opting show check box in password field")
	public void TS_Signup_10() throws IOException{
	
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		
		try{
			signupimplpage.getLoginSignupButton().click();
		}
		catch(Exception e){
			
			System.out.println("Signup screen");
		}
		
		signupimplpage.getPasswordfield().clear();
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		logger.log(LogStatus.INFO, signupimplpage.getPasswordfield().getText());
		signupimplpage.getShowPassword().click();
			
		verifyTextPresent(signupimplpage.getPasswordfield(),"ace2three");
			
	}
	
	
	@Test(description="Verify a popup with message “ You have been disconnected. Trying to reconnect” is displayed when wifi is in OFF mode")
	public void TS_Signup_11() throws InterruptedException, IOException{
		
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		Thread.sleep(30000);
		verifyPresent(signupimplpage.getSignupbutton(),"Signup page");
		
		// turn off all (data and wi-fi)
		//((AndroidDriver) driver).setConnection(Connection.AIRPLANE);
		//assertEquals(Connection.NONE, ((AndroidDriver) driver).getConnection());
		//System.out.println("connewction "+ ((AndroidDriver) driver).getConnection());
	
		
		//((AndroidDriver) driver).setConnection(Connection.ALL);
		//System.out.println("connewction 1"+ ((AndroidDriver) driver).getConnection());
		
		//((AndroidDriver) driver).setConnection(Connection.WIFI);
		//System.out.println("connewction 2"+ ((AndroidDriver) driver).getConnection());
		//Turn on data and Wifi
		((AndroidDriver) driver).setConnection(Connection.NONE);
		System.out.println("connewction none: "+ ((AndroidDriver) driver).getConnection());
		DisconnectionPopUp disconnectionPopUp= new DisconnectionPopUp(driver);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(
				"//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"))));

		verifyPresent(
				disconnectionPopUp.getDisConnectedMessage(),
				"you have been disconnected pop up");
		
		((AndroidDriver) driver).setConnection(Connection.ALL);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());
		verifyNotPresent(disconnectionPopUp.getDisConnectedMessage(),"you have been disconnected pop up",10);
		
	}
	
	@Test(description="Verify a popup with message “ You have been disconnected. Trying to reconnect” is gets dissappeared when wifi is in ON mode", enabled=false)
	public void TS_Signup_12() throws InterruptedException{
		
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		Thread.sleep(30000);
		verifyPresent(signupimplpage.getSignupbutton(),"Signup Button");
		
		// turn off all (data and wi-fi)
		//((AndroidDriver) driver).setConnection(Connection.AIRPLANE);
		//assertEquals(Connection.NONE, ((AndroidDriver) driver).getConnection());
		//System.out.println("connewction "+ ((AndroidDriver) driver).getConnection());
	
		
		//((AndroidDriver) driver).setConnection(Connection.ALL);
		//System.out.println("connewction 1"+ ((AndroidDriver) driver).getConnection());
		
		//((AndroidDriver) driver).setConnection(Connection.WIFI);
		//System.out.println("connewction 2"+ ((AndroidDriver) driver).getConnection());
		//Turn on data and Wifi
		((AndroidDriver) driver).setConnection(Connection.ALL);
		System.out.println("connewction none: "+ ((AndroidDriver) driver).getConnection());
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath(
				"//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"))));

		verifyPresent(
				driver.findElement(By
						.xpath("//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]")),
				"you have been disconnected pop up");
		
	}
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {

		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
			logger.log(LogStatus.PASS, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
		}
		((AppiumDriver) driver).resetApp();
		extent.flush();
		extent.endTest(logger);
		
	}
	
	
}
