package com.ace2three.test.suite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.ChooseBrowserPopupImplPage;
import com.ace2three.app.webview.impl.pages.KycVerifyWebviewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.BankAccountsImplPage;
import com.ace2three.impl.pages.KycImplPage;
import com.ace2three.impl.pages.KycImplPage.GuideLinesCheck;
import com.ace2three.impl.pages.KycImplPage.IdProof;
import com.ace2three.impl.pages.KycImplPage.IdProofAction;
import com.ace2three.impl.pages.LaunchImplPage;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.impl.pages.LoginImplPage;
import com.ace2three.impl.pages.MyAccountDetailsImplPage;
import com.ace2three.impl.pages.MyAccountImplPage;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.impl.pages.MyAccountImplPage.Section;
import com.ace2three.impl.pages.PurchaseLimitsImplPage;
import com.ace2three.impl.pages.RedeemFromMobileImplPage;
import com.ace2three.impl.pages.SignupImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.RecoveryManagement;
import com.ace2three.utils.business.BusinessMethods;
import com.ace2three.utils.business.BusinessMethods.IdProofList;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class KycTestSuite extends BaseTestSuite{

	DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
	
	ReadDataFromProps ReadProps;
	BusinessMethods bussinessMethods;
	WebDriver desktopDriver;
	AndroidDriver androidDriver;
	String userName1;
	@BeforeMethod
	public void beforeMethos(Method method) throws IOException {
		Test test = method.getAnnotation(Test.class);
		bussinessMethods = new BusinessMethods();
		System.out.println("system property" + System.getProperty("deviceName"));
		super.logger = extent.startTest(method.getName()+" : " +test.description());
		System.out.println("Before Method");
		ReadProps= new ReadDataFromProps();
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		launchImplPage.verifyUpgradePopup();
	}
	
	@BeforeClass
	public void beforeClass(){
		
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		String unveriFyMobileQuery1 = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%9000061713'";
		try {
			dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
			dataBaseConnection.updateQuery(unveriFyMobileQuery1, null);
		} catch (InterruptedException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Test(description = "login with profile restricted user(Champion25) and click on know more and go to KYC page and verify “add new proof” link and add from there", priority=1)
	public void TS_Sanity__KYC_01() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		String userName=ReadDataFromProps.props.getProperty("user.name.restricted.user.to.verify.kyc");
		
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("ace2three");
		
		launchImplPage.getLoginClickButton().click();
		
		LoginImplPage loginPage = new LoginImplPage(driver);
		verifyPresent(loginPage.getRestrictedAccessLoginMessage(), "Account restrictedto login dur to profile message");
		//loginPage.getRestrictedAccessLoginMessage().click();
		
		MobileElement el= (MobileElement) driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Access to Ace2Three is restricted from the location specified in your profile. Know more')]"));
		
		//TouchAction touch = new TouchAction((PerformsTouchActions) driver);
	
	/*	System.out.println("x cord: "+ el.getCenter().getX()+150);
		System.out.println("y cords: "+ el.getCenter().getY());
		System.out.println("x and y cords: "+el.getCoordinates().toString());
		System.out.println("x and y cords: "+el.getLocation());*/
		// ((AppiumDriver) driver).tap(1, (el.getLocation().getX()+el.getSize().getWidth())*9/10, el.getCenter().getY(),200);
		// touch.tap(el, el.getCenter().getX()+60, el.getCenter().getY()+40).perform().release();
		//((AndroidDriver) driver).tap(497,el,480);
		((AndroidDriver) driver).tap(3, el.getCenter().getX()+60, el.getCenter().getY()+10, 2);
		
		ChooseBrowserPopupImplPage chromeBrowser= new ChooseBrowserPopupImplPage((AndroidDriver) driver);
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
		chromeBrowser.getSelectChrome().click();
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			driver.findElement(By.id("button_once")).click();
		}
		KycVerifyWebviewImplPage kycVerifyWebPage = new KycVerifyWebviewImplPage((AndroidDriver) driver);
		Thread.sleep(10000);
		//CustomMethods.waitForElementPresent(kycVerifyWebPage.getVerifyKyc(), 10);
		kycVerifyWebPage.getVerifyKyc().click();
		Thread.sleep(10000);
		//CustomMethods.waitForElementPresent(kycVerifyWebPage.getLocationAlertOkButton(), 10);
		if(CustomMethods.isElementPresent(kycVerifyWebPage.getLocationAlertOkButton())){
			kycVerifyWebPage.getlocationAlertNotNowButton().click();
		}
		//This line is to close location alert 
		verifyPresent(kycVerifyWebPage.getLoginButton(), "Kyc web page login button");
		kycVerifyWebPage.getLoginButton().click();
		
		if(!CustomMethods.isElementPresent(kycVerifyWebPage.getAddAnotherFile())){
		kycVerifyWebPage.getUserId().sendKeys(userName);
		kycVerifyWebPage.getPasswordField().sendKeys("ace2three");
		verifyPresent(kycVerifyWebPage.getLoginButton(), "login web page");
		kycVerifyWebPage.getLoginButton().click();
		}
		
		//verifyPresent(kycVerifyWebPage.getAddAnotherFile(), "Add KYC web page");
		kycVerifyWebPage.getAddAnotherFile().click();
		kycVerifyWebPage.getSelectIdProofDropDownList().click();
		kycVerifyWebPage.getAadharCardRadioButton().click();
		kycVerifyWebPage.getCameraIcon().click();
		kycVerifyWebPage.getCameraOption().click();
		KycImplPage kycImpl = new KycImplPage(driver);
		//kycImpl.getCameraShutterButton().click();
		
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			kycImpl.getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		
	
		Thread.sleep(4000);
		MobileElement elem= (MobileElement) driver.findElement(By.xpath("//android.widget.Button[contains(@text,'No thanks')]"));
		((AndroidDriver) driver).tap(1, elem.getCenter().getX(), elem.getCenter().getY()+100, 2);
	//	kycVerifyWebPage.getAttachAnotherNoThanksButton().click();
		//verifyPresent(kycVerifyWebPage.getOneFileUploaded(), "1 file uploaded");
		((AndroidDriver) driver).swipe(300, 700, 300, 400, 2000);
		kycVerifyWebPage.getTermsCheckBok().click();
		verifyPresent(kycVerifyWebPage.getSubmitButton(), "Submit button");
		//kycVerifyWebPage.getSubmitButton().click();
		
		
	}
	
	
	@Test(description = "KYC link from account details and verify it is correctly navigated to KYC page", priority=1)
	public void TS_Sanity__KYC_08() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		Thread.sleep(4000);
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		
		launchImplPage.getUsernameField().sendKeys("nani2");
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.AccountDetails);
		MyAccountDetailsImplPage myAccountDetails = new MyAccountDetailsImplPage(driver);
		verifyPresent(myAccountDetails.getKycLink(), "Kyc link");
		myAccountDetails.getKycLink().click();
		
		KycImplPage kycImpl = new KycImplPage(driver);
		verifyPresent(kycImpl.getKycPhoneNoField(), "KYC page");
		
	}
	
	@Test(description = "upload KYC id proof and reject from admin and see “verify” button in account", priority=1)
	public void TS_Sanity__KYC_02() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		String userName = "appium11";
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		
		launchImplPage.getLoginClickButton().click();
		Thread.sleep(1000);
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);

		//MyProfileImplPage profilePage = new MyProfileImplPage(driver);
		KycImplPage kycImpl = new KycImplPage(driver);
		verifyPresent(kycImpl.getKycPhoneNoField(), "KYC page");
		kycImpl.getKycIDProofField().click();
		bussinessMethods.selectIdFromDropDown(IdProofList.AadhaarCard);
		kycImpl.getKycIdProofUploadButton().click();
		
		verifyPresent(kycImpl.getIdProofGuideLinesPopup(),"Id proof guidelines");
		kycImpl.getIdProofGuideLinesPopupOkButton().click();
		kycImpl.getIdProofUploadPopUpCameraIcon().click();
		
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			kycImpl.getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		//driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		//driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'crop_image_menu_crop')]")).click();
		verifyPresent(kycImpl.getAtachOtherSidePopUpMessage(),"Attach Other Side popup");
		verifyTextPresent(kycImpl.getAtachOtherSidePopUpMessage(),
				ReadDataFromProps.props.getProperty("kyc.page.attach.another.side.popup.message"));
		verifyText(kycImpl.getAttachedFileName().getText(),"1. "+userName+"_Aadhaar Card_id_front.jpg");
		kycImpl.getAttachFileNoThansksButton().click();
		
		verifyPresent(kycImpl.getAuthorizationPopUpMessage(),"Id card authorization popup");
		kycImpl.getAuthorizationPopUpMessage().click();
		kycImpl.getAuthorizationPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImpl.getIdUploadSuccessPopUpHeader(), 60);
		verifyPresent(kycImpl.getIdUploadSuccessPopUpHeader(),"ID upload success popup");
		verifyTextPresent(kycImpl.getIdUploadSuccessMessage(),ReadDataFromProps.props.getProperty("kyc.page.id.upload.sucess.message"));
		
		kycImpl.getIdUploadPopupOkButton().click();
		verifyTextPresent(kycImpl.getIdUploadStatus(),"Pending Approval");
		
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
		desktopDriver.get(ReadProps.props.getProperty("admin.site.url"));
		JavascriptExecutor js = (JavascriptExecutor) desktopDriver;  
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		//js.executeScript("document.body.style.zoom = '0.9'");
		Thread.sleep(3000);
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		
		
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("RM")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']")).click();
		
		desktopDriver.findElement(By.cssSelector("input#searchUserId")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[value='Submit']")).click();
		desktopDriver.findElement(By.cssSelector("span#img"+userName)).click();
		Thread.sleep(3000);
		WebElement we =desktopDriver.findElement(By.cssSelector("input[value='Reject']"));
	
		js.executeScript("arguments[0].click();", we);
		desktopDriver.switchTo().alert().accept();
		Thread.sleep(4000);
		desktopDriver.close();
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		
		verifyPresent(kycImpl.getKycIdProofUploadButton(),"Upload Id button");
		
		if(customeMe.isElementPresent(kycImpl.getKycIdProofUploadButton())){
			logger.log(LogStatus.PASS, "Verify button has displayed after id proof has been rejected in admin site");
		}else{
			logger.log(LogStatus.FAIL, "Verify button has displayed after id proof has been rejected in admin site");
		}
		
	}
	
	
	@Test(description = "upload KYC id proof and accept from admin and see “verified” icon in account", priority=1)
	public void TS_Sanity__KYC_03() throws InterruptedException, IOException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if (CustomMethods.isElementPresent(launchImplPage.getLoginButon())) {
			launchImplPage.getLoginButon().click();
		}
		String userName = ReadDataFromProps.props.getProperty("user.name.to.accept.kyc.id.proof");
		launchImplPage.getUsernameField().sendKeys(userName);
		launchImplPage.getpasswordField().sendKeys("Automation@2");
		
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())){
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		
		lobbyImplPage.verifyLobbyPageDisplayed();

		MyAccountImplPage myAccountPage = new MyAccountImplPage(driver);
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("Automation@2");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);

	
		KycImplPage kycImpl = new KycImplPage(driver);
		verifyPresent(kycImpl.getKycPhoneNoField(), "KYC page");
		kycImpl.getKycIDProofField().click();
		bussinessMethods.selectIdFromDropDown(IdProofList.AadhaarCard);
		kycImpl.getKycIdProofUploadButton().click();
		
		verifyPresent(kycImpl.getIdProofGuideLinesPopup(),"Id proof guidelines");
		kycImpl.getIdProofGuideLinesPopupOkButton().click();
		kycImpl.getIdProofUploadPopUpCameraIcon().click();
		
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			kycImpl.getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		//kycImpl.getCameraShutterButton().click();
		//driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
	
		verifyPresent(kycImpl.getAtachOtherSidePopUpMessage(),"Attach Other Side popup");
		verifyTextPresent(kycImpl.getAtachOtherSidePopUpMessage(),
				ReadDataFromProps.props.getProperty("kyc.page.attach.another.side.popup.message"));
		verifyText(kycImpl.getAttachedFileName().getText(),"1. "+userName+"_Aadhaar Card_id_front.jpg");
		kycImpl.getAttachFileNoThansksButton().click();
		
		verifyPresent(kycImpl.getAuthorizationPopUpMessage(),"Id card authorization popup");
		kycImpl.getAuthorizationPopUpMessage().click();
		kycImpl.getAuthorizationPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImpl.getIdUploadSuccessPopUpHeader(), 15);
		verifyPresent(kycImpl.getIdUploadSuccessPopUpHeader(),"ID upload success popup");
		verifyTextPresent(kycImpl.getIdUploadSuccessMessage(),ReadDataFromProps.props.getProperty("kyc.page.id.upload.sucess.message"));
		
		kycImpl.getIdUploadPopupOkButton().click();
		verifyTextPresent(kycImpl.getIdUploadStatus(),"Pending Approval");
		
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
/*		desktopDriver.manage().window().maximize();*/
		desktopDriver.get(ReadProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("RM")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']")).click();
		Thread.sleep(2000);
		desktopDriver.findElement(By.cssSelector("input[value='RefreshDetails']")).click();
		Thread.sleep(1000);
		desktopDriver.findElement(By.cssSelector("input#searchUserId")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[value='Submit']")).click();
		desktopDriver.findElement(By.cssSelector("span#img"+userName)).click();
		Thread.sleep(3000);
		WebElement we =desktopDriver.findElement(By.cssSelector("input[value='Accept']"));
		JavascriptExecutor js = (JavascriptExecutor) desktopDriver;
		js.executeScript("arguments[0].click();", we);
	
		Thread.sleep(3000);
		desktopDriver.findElement(By.cssSelector("input[id='ID']")).click();
		new Select(desktopDriver.findElement(By.cssSelector("select[id='idVal']"))).selectByValue("Aadhaar Card");
		desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys("852147855555");
		desktopDriver.findElement(By.cssSelector("textarea[id='comments']")).sendKeys("QA test");
		WebElement we1=desktopDriver.findElement(By.cssSelector("input[value='Accept']"));
		js.executeScript("arguments[0].click();", we1);
		//desktopDriver.switchTo().alert().accept();
		Thread.sleep(6000);
		desktopDriver.close();
		lobbyImplPage.getHomeTabIcon().click();
		myAccountPage.launchMyAccountDetailsScreen();
		
		myAccountPage.getPasswordPopUpField().sendKeys("Automation@2");
		myAccountPage.getPasswordPopUpSubmitButton().click();
		myAccountPage.verifyMyAccountDetailsScreenDisplayed();
		myAccountPage.navigateToMyAccountsSection(Section.KYC);
		
		verifyNotPresent(kycImpl.getKycIdProofUploadButton(),"Upload Id button", 2);
		
		if(customeMe.isElementPresent(kycImpl.getKycIdProofUploadButton())){
			logger.log(LogStatus.FAIL, "Verify button has displayed after id proof has been accepted in admin site");
		}else{
			logger.log(LogStatus.PASS, "Verify button has not displayed after id proof has been accepted in admin site");
		}
	
	}
	
	@Test(description = "Check whether “Make your first purchase to access this feature is displaying or not when regular user tries to access KYC page.", priority=4)
	public void TS_Sanity__KYC_04() throws InterruptedException, IOException, SQLException {
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		userName1 = signupImplPage.doSignUp();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		KycImplPage kycImplPage = new KycImplPage(driver);
		verifyPresent(kycImplPage.getMakeYourFirstPurchasePopup(), "Make you first purchase pop");
		verifyPresent(kycImplPage.getBuyRealChipsButton(), "Buy Real Chips Button");
		verifyPresent(kycImplPage.getNoThanksButton(), "No Thanks Button");
		kycImplPage.getNoThanksButton().click();
		verifyPresent(lobbyImplPage.getHamburgerMenu(), "Lobby page after clicking on No Thanks button");
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenu().click();/////////////////////////////////
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		kycImplPage.getBuyRealChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		verifyPresent(addCashWebViewImplPage.getAddCashPageHeader(), "Add Cash Web View");
		addCashWebViewImplPage.getAddCashWebViewClose().click();
		lobbyImplPage.getAddChipsButton().click();
		addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
		CustomMethods.waitForElementPresent(lobbyImplPage.getLevelUpAlertMessage());
		verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
		ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
		lobbyImplPage.getLevelUpAlertOkButton().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenu().click();////////////////////////////////////////////
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Password Popup");
		myAccountImplPage.getPasswordPopUpField().sendKeys("ace2three");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycEmailField(), "Kyc Screen");
		kycImplPage.getKycEmailField().clear();
		kycImplPage.getKycEmailField().sendKeys("asdfasf.com");
		kycImplPage.getKycEmailVerifyButton().click();
		kycImplPage.getKycPhoneNoField().clear();
		kycImplPage.getKycPhoneNoField().sendKeys("32335");
		kycImplPage.getKycPhoneNoVerifyButton().click();
		kycImplPage.getKycIdProofUploadButton().click();
		kycImplPage.getKycPanUploadButton().click();
		
		verifyText(kycImplPage.getKycEmailWarningMessage().getText(),"Please enter valid email ID");
		verifyText(kycImplPage.getKycPhoneNoInvalidError().getText(), "Please enter valid Mobile number");
		verifyText(kycImplPage.getPleaseSelectIdProofErrorMsg().getText(), "Please select Id Proof type");
		verifyText(kycImplPage.getPleaseEnterPanNumErrorMsg().getText(), "Please enter valid PAN number");
		 
		kycImplPage.getKycPanField().sendKeys("asdfasfads");
		kycImplPage.getKycPanUploadButton().click();
		verifyText(kycImplPage.getPleaseEnterPanNumErrorMsg().getText(),"Please enter valid PAN number");
		
		kycImplPage.getKycPanField().sendKeys("~!@#$%^&*()_+-={}[]:\"|;'\\<>?,./");
		kycImplPage.getKycPanUploadButton().click();
		verifyText(kycImplPage.getPleaseEnterPanNumErrorMsg().getText(),"Please enter valid PAN number");
		
		kycImplPage.getKycPanField().sendKeys("012345678910");
		kycImplPage.getKycPanUploadButton().click();
		verifyText(kycImplPage.getPleaseEnterPanNumErrorMsg().getText(),"Please enter valid PAN number");
		
		CustomMethods.disconnectAndReconnect();
		kycImplPage.getKycEmailField().clear();
		kycImplPage.getKycEmailField().sendKeys(userName1+"a@aawcx.com");
		kycImplPage.getKycEmailVerifyButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getActivationLinkSentMessage(),5);
		verifyText(kycImplPage.getActivationLinkSentMessage().getText(), "An activation link has been sent to your E-Mail");
		CustomMethods.verifyNotEnabled(kycImplPage.getKycEmailField(), "Email Input Field");
		
		verifyNotPresent(kycImplPage.getKycEmailVerifyButton(),"Verify Email Button", 5);
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		try {
			dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
		} catch (InterruptedException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		kycImplPage.getKycPhoneNoField().clear();
		kycImplPage.getKycPhoneNoField().sendKeys("8463932054");
		kycImplPage.getKycPhoneNoVerifyButton().click();
		DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			verifyPresent(kycImplPage.getOtpEntryField(), "OTP pop up");
			String firstOTP =dataBaseServerConnect.selectQuery(null, userName1);
			logger.log(LogStatus.INFO, "First OTP: "+firstOTP);
			verifyNotPresent(kycImplPage.getKycPhoneNoVerifyButton(), "Verify mobile number button", 3);
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			verifyPresent(kycImplPage.getOtpEntryField(), "OTP pop up");
			kycImplPage.getOtpEntryField().sendKeys("~!@#$%^&*()_+-=}{][|\":);'\\'<>?/.,");
			kycImplPage.getOtpConfirmButton().click();
			verifyText(kycImplPage.getOtpIncorrectError().getText(), "Please enter OTP");
			kycImplPage.getOtpEntryField().sendKeys("025879");
			kycImplPage.getOtpConfirmButton().click();
			verifyText(kycImplPage.getOtpIncorrectError().getText(), "Sorry, the entered OTP is incorrect");
			kycImplPage.getOtpEntryField().clear();
			String firstOTP =dataBaseServerConnect.selectQuery(null, userName1);
			logger.log(LogStatus.INFO, "First OTP: "+firstOTP);
			Thread.sleep(40000);
			kycImplPage.getOtpResendLink().click();
			String secondOTP = dataBaseServerConnect.selectQuery(null, userName1);
			logger.log(LogStatus.INFO, "Second OTP: "+secondOTP);
			kycImplPage.getOtpEntryField().sendKeys(secondOTP);
			kycImplPage.getOtpConfirmButton().click();
			verifyNotPresent(kycImplPage.getKycPhoneNoVerifyButton(), "Verify mobile number button", 3);	
		}
		
		
		
	
		
	}
	
	
	@Test(description = "Check whether user able to upload Aadhaar Cards,Ration Card,Voter ID,Passport,Driving Licence as id proof.", priority=5)
	public void TS_Sanity__KYC_05() throws InterruptedException, IOException {
		String userName1="secureqa";
		String password="Ace2three@";
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		KycImplPage kycImplPage = new KycImplPage(driver);
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys(userName1);
		launchImplPage.getpasswordField().sendKeys(password);
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())){
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Password Popup");
		myAccountImplPage.getPasswordPopUpField().sendKeys(password);
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycEmailField(), "Kyc Screen");
		kycImplPage.uploadIdProofAadharOneSide(userName1);
		kycImplPage.performActionOnIdProofInAdminSite(userName1, IdProofAction.Reject, IdProof.Aadhar);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys(password);
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(kycImplPage.getKycIdProofUploadButton(), "Upload ID proof button after rejecting KYC from admin");
		kycImplPage.uploadIdProof(userName1, IdProof.DrivingLicence,GuideLinesCheck.Ignore);
		kycImplPage.performActionOnIdProofInAdminSite(userName1, IdProofAction.Reject, IdProof.DrivingLicence);
		
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys(password);
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(kycImplPage.getKycIdProofUploadButton(), "Upload ID proof button after rejecting KYC from admin");
		kycImplPage.uploadIdProof(userName1, IdProof.Passport,GuideLinesCheck.Ignore);
		kycImplPage.performActionOnIdProofInAdminSite(userName1, IdProofAction.Reject, IdProof.Passport);
		
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys(password);
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(kycImplPage.getKycIdProofUploadButton(), "Upload ID proof button after rejecting KYC from admin");
		kycImplPage.uploadIdProof(userName1, IdProof.RationCard,GuideLinesCheck.Ignore);
		kycImplPage.performActionOnIdProofInAdminSite(userName1, IdProofAction.Reject, IdProof.RationCard);
		
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys(password);
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(kycImplPage.getKycIdProofUploadButton(), "Upload ID proof button after rejecting KYC from admin");
		kycImplPage.uploadIdProof(userName1, IdProof.VoterID,GuideLinesCheck.Ignore);
		kycImplPage.performActionOnIdProofInAdminSite(userName1, IdProofAction.Reject, IdProof.VoterID);
		
	}
	
	
	@Test(description = "Check whether “Upload PAN Card” popup is displaying or not on clicking on upload button after entering valid PAN number", priority=6)
	public void TS_Sanity__KYC_06() throws InterruptedException, IOException
	{
		String userName1="secureqa";
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		KycImplPage kycImplPage = new KycImplPage(driver);
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys(userName1);
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())){
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Password Popup");
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycEmailField(), "Kyc Screen");
		kycImplPage.uploadPan(userName1);
		kycImplPage.performActionOnIdProofInAdminSite(userName1, IdProofAction.Reject,null);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		verifyPresent(kycImplPage.getKycPanUploadButton(), "Upload Button after rejecting pan from admin");
	}
	
	@Test(description = "Check whether pseudo player is able to access KYC page or not."
			+ "KYC link from purchase limits and verify it is correctly navigated to KYC page."
			+ "Check whether resend OTP functionality in OTP screen is working or not."
			+ "Check whether user able to enter special characters in OTP number field in OTP pop-up.", priority=7)
	public void TS_Sanity__KYC_07() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignUpButton(), "Sign Screen");
		launchImplPage.getLoginButon().click();
		/*System.out.println("asdf");
		launchImplPage.getUsernameField().click();
		System.out.println(launchImplPage.getUsernameField().getText());
*/		//launchImplPage.getUsernameField().sendKeys("ucme");
		launchImplPage.getUsernameField().sendKeys(ReadDataFromProps.props.getProperty("pseudo.user.for.kyc"));
		launchImplPage.getpasswordField().sendKeys("ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())){
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Password Popup");
		myAccountImplPage.getPasswordPopUpField().sendKeys("ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		KycImplPage kycImplPage = new KycImplPage(driver);
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		if(verifyPresent(kycImplPage.getKycEmailField(), "Kyc Screen"))
		{
			logger.log(LogStatus.INFO, "Pseudo player is able to access KYC screen");
		}
		kycImplPage.getKycEmailField().clear();
		verifyText(kycImplPage.getKycEmailField().getText(), "Email");
		kycImplPage.getKycPhoneNoField().click();
		verifyText(kycImplPage.getKycPhoneNoField().getText(), "Mobile Number");
		verifyText(kycImplPage.getKycIDProofField().getText(), "Id Proof");
		verifyText(kycImplPage.getKycPanField().getText(), "Pan");
		
	}
	
	@Test(description = "KYC link from purchase limits and verify it is correctly navigated to KYC page.", priority=9)
	public void TS_Sanity__KYC_09() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignUpButton(), "Sign Screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("ucme");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())){
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		verifyPresent(myAccountImplPage.getPasswordPopUpField(), "Password Popup");
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		KycImplPage kycImplPage = new KycImplPage(driver);
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		kycImplPage.getKycEmailField().clear();
		kycImplPage.getKycEmailField().sendKeys("coorg.sloi@gmail.com");
		//kycImplPage.getKycPhoneNoField().sendKeys("9640350711");
		kycImplPage.getKycPanField().sendKeys("SAFPD8347D");
		BankAccountsImplPage bankAccountsImplPage = new BankAccountsImplPage(driver);
		PurchaseLimitsImplPage purchaseLimitsImplPage = new PurchaseLimitsImplPage(driver);
		
		myAccountImplPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		myAccountImplPage.navigateToMyAccountsSection(Section.KYC);
		
	
	
		logger.log(LogStatus.INFO, "Entered details in kyc field after swipping left and right three times");
		verifyText(kycImplPage.getKycEmailField().getText(), "coorg.sloi@gmail.com");
		verifyText(kycImplPage.getKycPhoneNoField().getText(), "9640350711");
		verifyText(kycImplPage.getKycPanField().getText(), "SAFPD8347D");
		myAccountImplPage.getMyAccountScreenLeftArrow().click();
		RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
		verifyText(redeemFromMobileImplPage.getVerifyEmailAndMobNumPopUp().getText(), "Please verify your email id and phone number to place a redeem request.");
		redeemFromMobileImplPage.getverifyEmailAndMobNumPopUpOkButton().click();
		verifyPresent(kycImplPage.getKycPhoneNoField(), "KYC screen");
		verifyText(kycImplPage.getToProceedWithRedeemRequestText().getText(), "To proceed with the redeem request, Please click here.");
		MobileElement ele= (MobileElement) kycImplPage.getToProceedWithRedeemRequestText();
		((AndroidDriver) driver).tap(1, ele.getCenter().getX()+400, ele.getCenter().getY(), 2);
		verifyPresent(redeemFromMobileImplPage.getVerifyEmailAndMobNumPopUp(), "Verify Email and Mobile Number PopUp");
		redeemFromMobileImplPage.getverifyEmailAndMobNumPopUpOkButton().click();
		
		myAccountImplPage.navigateToMyAccountsSection(Section.PurchaseLimits);
		//PurchaseLimitsImplPage purchaseLimitsImplPage = new PurchaseLimitsImplPage(driver);
		verifyPresent(purchaseLimitsImplPage.getPurchaseLimitsKYCMsg(), "You Can verify KYC to increase PL");
		MobileElement elem= (MobileElement)driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'purchase_limits_kyc_message')]"));
		((AndroidDriver) driver).tap(1, elem.getCenter().getX()+240, elem.getCenter().getY(), 2);
		verifyPresent(kycImplPage.getKycPhoneNoField(), "KYC screen");
		
		kycImplPage.getKycEmailField().clear();
		kycImplPage.getKycEmailField().sendKeys("coorg.sloi@gmail.com");
		kycImplPage.getKycEmailVerifyButton().click();
		kycImplPage.getKycPhoneNoField().sendKeys("9640350711");
		kycImplPage.getKycPhoneNoVerifyButton().click();
		kycImplPage.getKycPanField().sendKeys("SAFPD8347D");
	//	kycImplPage.getKycPanUploadButton().click();
		verifyText(kycImplPage.getKycEmailWarningMessage().getText(), "E-Mail already exists");
		verifyText(kycImplPage.getKycPhoneNoInvalidError().getText(), "Mobile number already exists");
		kycImplPage.getKycPanField().sendKeys("SAFPD8347D");
		kycImplPage.getKycPanUploadButton().click();
		verifyText(kycImplPage.getPleaseEnterPanNumErrorMsg().getText(), "Pan number already exists");
	}
	
	@Test(description="Upload Aadhar and verify from admin",priority=10)
	public void TS_Sanity__KYC_10() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		BusinessMethods businessMethods = new BusinessMethods();
		KycImplPage kycImplPage = new KycImplPage(driver);
		String userName=launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getNoThanksButton()))
			lobbyImplPage.getNoThanksButton().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		
		kycImplPage.getKycIDProofField().click();
		businessMethods.selectIdFromDropDown(IdProofList.AadhaarCard);
		kycImplPage.getKycIdProofUploadButton().click();
		verifyPresent(kycImplPage.getIdProofGuideLinesPopup(),"Id proof guidelines");
		kycImplPage.getIdProofGuideLinesPopupOkButton().click();
		
		kycImplPage.getIdProofUploadPopUpCameraIcon().click();
		
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			kycImplPage.getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		
		//driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'crop_image_menu_crop')]")).click();
		verifyPresent(kycImplPage.getAtachOtherSidePopUpMessage(),"Attach Other Side popup");
		verifyTextPresent(kycImplPage.getAtachOtherSidePopUpMessage(),
				ReadDataFromProps.props.getProperty("kyc.page.attach.another.side.popup.message"));
		verifyText(kycImplPage.getAttachedFileName().getText(),"1. "+userName+"_Aadhaar Card_id_front.jpg");
		verifyPresent(kycImplPage.getAttachAnotherSideButton(), "Attach Another Side Button");
		verifyPresent(kycImplPage.getAttachFileNoThansksButton(), "No Thanks Button");
		kycImplPage.getAttachAnotherSideButton().click();
		verifyPresent(kycImplPage.getIdProofUploadPopUpCameraIcon(), "Upload ID Proof popup to upload second image");
		kycImplPage.getIdProofUploadPopUpCameraIcon().click();
		
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			kycImplPage.getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		
		verifyPresent(kycImplPage.getDeleteAttachedFileIcon(), "Delete Icon of first file");
		verifyPresent(kycImplPage.getDeleteSecondAttachedFileIcon(), "Delete Icon of Second file");
		verifyPresent(kycImplPage.getAuthorizationPopUpMessage(),"Id card authorization popup");
		verifyText(kycImplPage.getAuthorizationPopUpMessage().getText(), "By uploading, I authorize Ace2Three to verify my Aadhaar details");
		kycImplPage.getAuthorizationPopUpMessage().click();
		verifyPresent(kycImplPage.getAuthorizationPopUpSubmitButton(), "ID Proof Autorization Submit Button");
		kycImplPage.getAuthorizationPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getIdUploadSuccessPopUpHeader(),30);
		verifyPresent(kycImplPage.getIdUploadSuccessPopUpHeader(),"ID upload success popup");
		verifyTextPresent(kycImplPage.getIdUploadSuccessMessage(),ReadDataFromProps.props.getProperty("kyc.page.id.upload.sucess.message"));
		
		kycImplPage.getIdUploadPopupOkButton().click();
		verifyTextPresent(kycImplPage.getIdUploadStatus(),"Pending Approval");
		
		
		kycImplPage.performActionOnIdProofInAdminSite(userName, IdProofAction.Accept, IdProof.Aadhar);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycIdProofVerifiedIndicator(), "Id Proof verified Right Mark Symbol");
		verifyNotPresent(kycImplPage.getKycIdProofUploadButton(), "Id Proof Upload Button", 1);
		verifyText(kycImplPage.getKycIDProofField().getText(), "Aadhaar Card");
		
	}
	
	@Test(description="Upload Driving Licence and verify from admin",priority=11)
	public void TS_Sanity__KYC_11() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		BusinessMethods businessMethods = new BusinessMethods();
		KycImplPage kycImplPage = new KycImplPage(driver);
		String userName=launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getNoThanksButton()))
			lobbyImplPage.getNoThanksButton().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		kycImplPage.uploadIdProof(userName, IdProof.DrivingLicence, GuideLinesCheck.Verify);
		kycImplPage.performActionOnIdProofInAdminSite(userName, IdProofAction.Accept, IdProof.DrivingLicence);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycIdProofVerifiedIndicator(), "Id Proof verified Right Mark Symbol");
		verifyNotPresent(kycImplPage.getKycIdProofUploadButton(), "Id Proof Upload Button", 1);
		verifyText(kycImplPage.getKycIDProofField().getText(), "Driver Licence");
	}
	@Test(description="Upload Passport and verify from admin",priority=12)
	public void TS_Sanity__KYC_12() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		BusinessMethods businessMethods = new BusinessMethods();
		KycImplPage kycImplPage = new KycImplPage(driver);
		String userName=launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getNoThanksButton()))
			lobbyImplPage.getNoThanksButton().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		kycImplPage.uploadIdProof(userName, IdProof.Passport, GuideLinesCheck.Verify);
		kycImplPage.performActionOnIdProofInAdminSite(userName, IdProofAction.Accept, IdProof.Passport);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycIdProofVerifiedIndicator(), "Id Proof verified Right Mark Symbol");
		verifyNotPresent(kycImplPage.getKycIdProofUploadButton(), "Id Proof Upload Button", 1);
		verifyText(kycImplPage.getKycIDProofField().getText(), "Passport");
	}
	
	@Test(description="Upload Ration Card and verify from admin",priority=13)
	public void TS_Sanity__KYC_13() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		BusinessMethods businessMethods = new BusinessMethods();
		KycImplPage kycImplPage = new KycImplPage(driver);
		String userName=launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getNoThanksButton()))
			lobbyImplPage.getNoThanksButton().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		kycImplPage.uploadIdProof(userName, IdProof.RationCard, GuideLinesCheck.Verify);
		kycImplPage.performActionOnIdProofInAdminSite(userName, IdProofAction.Accept, IdProof.RationCard);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycIdProofVerifiedIndicator(), "Id Proof verified Right Mark Symbol");
		verifyNotPresent(kycImplPage.getKycIdProofUploadButton(), "Id Proof Upload Button", 1);
		verifyText(kycImplPage.getKycIDProofField().getText(), "Ration Card");
	}
	
	@Test(description="Upload Voter ID and verify from admin",priority=14)
	public void TS_Sanity__KYC_14() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		BusinessMethods businessMethods = new BusinessMethods();
		KycImplPage kycImplPage = new KycImplPage(driver);
		String userName=launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getNoThanksButton()))
			lobbyImplPage.getNoThanksButton().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		kycImplPage.uploadIdProof(userName, IdProof.VoterID, GuideLinesCheck.Verify);
		kycImplPage.performActionOnIdProofInAdminSite(userName, IdProofAction.Accept, IdProof.VoterID);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycIdProofVerifiedIndicator(), "Id Proof verified Right Mark Symbol");
		verifyNotPresent(kycImplPage.getKycIdProofUploadButton(), "Id Proof Upload Button", 1);
		verifyText(kycImplPage.getKycIDProofField().getText(), "Voters Id");
	}
	
	@Test(description="Check whether permission popup to capture photo to upload Kyc is displaying or not",priority=15)
	public void TS_Sanity__KYC_15() throws InterruptedException, IOException
	{
		BusinessMethods businessMethods = new BusinessMethods();
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignUpButton(), "Sign Screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("permcheck");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())){
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		KycImplPage kycImplPage = new KycImplPage(driver);
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		kycImplPage.getKycIDProofField().click();
		businessMethods.selectIdFromDropDown(IdProofList.RationCard);
		kycImplPage.getKycIdProofUploadButton().click();
		verifyPresent(kycImplPage.getIdProofGuideLinesPopup(),"Id proof guidelines");
		kycImplPage.getIdProofGuideLinesPopupOkButton().click();
		kycImplPage.getIdProofUploadPopUpCameraIcon().click();
		verifyPresent(kycImplPage.getPhotoPermissionMessage(), "Pictures and record video permission pop-up");
		verifyText(kycImplPage.getPhotoPermissionMessage().getText(), "Allow Ace2Three Plus to take pictures and record video?", "Permission pop-up");
		kycImplPage.getDenyButton().click();
		
	}
	
	@Test(description="Un verify phone number and verify \"verify\" button should be displayed on kyc screen",priority=16)
	public void TS_Sanity__KYC_16() throws InterruptedException, IOException, SQLException
	{
		String unveriFyMobileQuery = "update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
		try {
			dataBaseConnection.updateQuery(unveriFyMobileQuery, null);
		} catch (InterruptedException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		verifyPresent(launchImplPage.getSignUpButton(), "Sign Screen");
		launchImplPage.getLoginButon().click();
		launchImplPage.getUsernameField().sendKeys("verifycheck");
		launchImplPage.getpasswordField().sendKeys("Ace2three@");
		launchImplPage.getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose())){
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		KycImplPage kycImplPage = new KycImplPage(driver);
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		kycImplPage.getKycPhoneNoField().clear();
		kycImplPage.getKycPhoneNoField().sendKeys("8463932054");
		kycImplPage.getKycPhoneNoVerifyButton().click();
		verifyPresent(kycImplPage.getOtpEntryField(), "OTP pop up");
		String firstOTP =dataBaseConnection.selectQuery(null, "verifycheck");
		logger.log(LogStatus.INFO, "First OTP: "+firstOTP);
		verifyNotPresent(kycImplPage.getKycPhoneNoVerifyButton(), "Verify mobile number button", 3);
		kycImplPage.unverifyMobileNumberFromAdmin("verifycheck");
		Thread.sleep(5000);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycPhoneNoVerifyButton(), "Mobile Number Verify Button");
	}
	
	
	
	/*@Test(description="Upload PAN and verify from admin",priority=15)
	public void TS_Sanity__KYC_15() throws InterruptedException, IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		SignupImplPage signupImplPage = new SignupImplPage(driver);
		BusinessMethods businessMethods = new BusinessMethods();
		KycImplPage kycImplPage = new KycImplPage(driver);
		
		kycImplPage.updatePanCard("test17090520", "adfpd5493d"); 
		
		String userName=launchImplPage.doSignUpAndConvertToPremium();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		MyAccountImplPage myAccountImplPage = new MyAccountImplPage(driver);
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		String pan =kycImplPage.uploadPan(userName);
		kycImplPage.approvePan(userName, IdProofAction.Accept, pan);
		lobbyImplPage.getHomeTabIcon().click();
		lobbyImplPage.getHamburgerMenu().click();
		lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount, "KYC").click();
		myAccountImplPage.getPasswordPopUpField().sendKeys("Ace2three@");
		myAccountImplPage.getPasswordPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(kycImplPage.getKycEmailField(),10);
		verifyPresent(kycImplPage.getKycIdProofVerifiedIndicator(), "Id Proof verified Right Mark Symbol");
		verifyNotPresent(kycImplPage.getKycIdProofUploadButton(), "Id Proof Upload Button", 1);
		verifyText(kycImplPage.getKycIDProofField().getText(), "Voters Id");
	}
	*/
	
	
	@AfterMethod
	public void afterMethod(Method method, ITestResult result) throws IOException {
		
		if (!(result.getStatus() == ITestResult.SUCCESS)) {
			RecoveryManagement recoveryManagement= new RecoveryManagement(driver);
			recoveryManagement.handleTextMessageAlert();
			
			logger.log(LogStatus.FAIL, result.getThrowable());
				
			try{
				if(desktopDriver.toString().contains("null")){
					logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
					}else{
						logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName(),desktopDriver)));
						desktopDriver.close();
					}
			}catch(Exception e){
				logger.log(LogStatus.FAIL, "Failed screenshot" + logger.addScreenCapture(takeScreenShot(method.getName())));
			}
		}
		((AppiumDriver) driver).resetApp();
		extent.flush();
		extent.endTest(logger);
		
	}
	
	
}
