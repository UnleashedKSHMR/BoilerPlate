package com.ace2three.base;

import org.openqa.selenium.WebDriver;

public class Beforesuite {
	static WebDriver driver;
	
	public void beforesuite (){
	
		
	}

	
}
