package com.ace2three.base;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.ReadDataFromProps;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.Connection;

public class BaseTestSuite {
	//private static final ThreadLocal<WebDriver> WEB_DRIVER_THREAD_LOCAL = new InheritableThreadLocal<>();
	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest logger;
	private static DesiredCapabilities capabilities;
	
	ReadDataFromProps ReadProps;
	static String ReportFolder;
	public static DataBaseServerConnect dataBaseConnection;
	static String dateString;
	@Parameters("gps")
	@BeforeSuite
	public void beforeSuite(@Optional String gps) throws IOException, InterruptedException, SQLException {
		
		/*Thread.currentThread().setName("Thread 1");
		//Thread.sleep(2000);
		if(Thread.currentThread().getName().contains("Thread 1")){
			Thread.sleep(2000);
		}*/
		
	/*	for(int i=1;i<=Thread.activeCount();i++){
			for(String thread: )
		}*/
			
		long id = Thread.currentThread().getId();
		System.out.println(id+"a");
		/*if(gps.contains(null)){
			gps="default";
		}*/
		System.out.println("gps nin before "+ gps);
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Date date = new Date();
		dateString =dateFormat.format(date);
		/*ReportFolder = System.getProperty("user.dir") + "/extentReports/" + dateFormat.format(date);
		
		extent = new ExtentReports(
				ReportFolder + "/ExtentReport.html",
				true);*/
		ReportFolder = "extentReports/" + dateFormat.format(date);
		
		extent = new ExtentReports(
				ReportFolder + "/ExtentReport.html",
				true);
		
		extent.loadConfig(new File(System.getProperty("user.dir")+"/resource/Extent-config.xml"));
		
		extent.addSystemInfo("Host Name", "Head Infotech").addSystemInfo("Environment", "Automation Testing")
				.addSystemInfo("User Name", "Dinesh").addSystemInfo("Plaftform", "Dinesh");
		
		/*String clearDeviceIds = "update game_user_master set phone_verified='N' where user_code in (select bonus_claimed from device_details)";
		String deleteDevicesDetails="delete from device_details";
		dataBaseConnection = new DataBaseServerConnect();
		dataBaseConnection.updateQuery(clearDeviceIds, null);
		dataBaseConnection.updateQuery(deleteDevicesDetails, null);*/
		
		
		Beforesuite beforeSuite = new Beforesuite();
		System.out.println("into before suite");
		
	}

	@SuppressWarnings("rawtypes")
	@Parameters({ "deviceName", "resolution", "activityName", "app", "appPackage", "appType", "environment", "platform",
			"platformVersion", "browsername", "udid", "portaddress", "testEnvironment", "appiumUrl" ,"gps","systemPort"})
	@BeforeTest
	public void beforeTest(@Optional String deviceName, @Optional String resolution, @Optional String activityName,
			@Optional String app, @Optional String appPackage, @Optional String appType, @Optional String environment,
			@Optional String platform, @Optional String platformVersion, @Optional String browsername,
			@Optional String udid, @Optional String portaddress, @Optional String testEnvironment,
			@Optional String appiumUrl,@Optional String gps, ITestContext context,@Optional String systemPort) throws InterruptedException, IOException {
		
		System.out.println("count " + Thread.activeCount());
		long id = Thread.currentThread().getId();
		if(id==12){
			Thread.sleep(3000);
		}
		
		if(gps.equalsIgnoreCase("off")){
			String command = "adb -s "+udid+" shell settings put secure location_providers_allowed -gps";
			Process child = Runtime.getRuntime().exec(command);
		}else if(gps.equalsIgnoreCase("on")){
			String command = "adb -s "+udid+" shell settings put secure location_providers_allowed +gps";
			Process child = Runtime.getRuntime().exec(command);
		}else{
			System.out.println("Default gps setting");
		}
		
		System.out.println(id+"a");
			Beforetest beforetest = new Beforetest();
			System.out.println("into before test");
			this.driver =  beforetest.beforeTest(deviceName, resolution, activityName, app, appPackage, appType, environment,
					platform, platformVersion, browsername, udid, portaddress, testEnvironment, appiumUrl,gps, context,systemPort);
			if(context.getName().contains("test1")){
			System.setProperty("deviceName", deviceName);
			System.setProperty("udid", udid);
			System.setProperty("testEnvironment", testEnvironment);
			System.setProperty("takeScreenshot",ReadDataFromProps.props.getProperty("takeScreen.shot.on.pass"));
			System.setProperty("appPackage", appPackage);
			System.setProperty("activityName", activityName);
			System.setProperty("platform", platform);
			System.setProperty("platformVersion", platformVersion);
			}else{
				System.setProperty("deviceName", deviceName);
				System.setProperty("udid", udid);
				System.setProperty("testEnvironment", testEnvironment);
				System.setProperty("takeScreenshot",ReadDataFromProps.props.getProperty("takeScreen.shot.on.pass"));
				System.setProperty("appPackage", appPackage);
				System.setProperty("activityName", activityName);
				System.setProperty("platform", platform);
				System.setProperty("platformVersion", platformVersion);
			}
			ReadProps= new ReadDataFromProps();
			this.dataBaseConnection = new DataBaseServerConnect();
		
	}

	@BeforeClass
	public void beforeClass() throws IOException{
		//((AppiumDriver)driver).resetApp();
		((AndroidDriver) driver).setConnection(Connection.ALL);
	}
	
	@AfterClass
	public void afterClass(){
		extent.flush();
	}
	
	@AfterTest
	public void afterTest() {

		Aftertest afterTest = new Aftertest();
		System.out.println("into after test");
		driver.quit();
		//((AppiumDriver)driver).resetApp();
		//extent.flush();
		/*extent.flush();
		extent.close();
		driver.quit();*/
		//((AndroidDriver)driver).closeApp();
}

	@AfterSuite
	public void afterSuite() throws InterruptedException {
		Aftersuite afterSuite = new Aftersuite();
		System.out.println("into after suite");
		Thread.sleep(3000);
	//	driver.quit();
		extent.close();
		//driver.quit();
	}

	public Boolean verifyPresent(WebElement element, String locatorName) {
		
		try {
			element.isDisplayed();
			if (System.getProperty("takeScreenshot").contains("no")) {
				logger.log(LogStatus.PASS, locatorName + " has displayed");
			} else {
				logger.log(LogStatus.PASS,
						"\"" + locatorName + " has displayed\"" + logger.addScreenCapture(takeScreenShot(locatorName)));
			}

			return true;
		} catch (Exception e) {
			try {
				logger.log(LogStatus.FAIL,
						locatorName + " has not displayed" + logger.addScreenCapture(takeScreenShot(locatorName)));
			} catch (IOException e1) {

				logger.log(LogStatus.FAIL, e1.toString());
			}
			return false;
		}
	}
	
	
/*	
 * 
 * 
	public Boolean verifyNotPresent(WebElement element, String locatorName) {
		try {
			WebDriverWait wait = new WebDriverWait((AppiumDriver)driver, 30);
			wait.until(ExpectedConditions.invisibilityOf(element));
			logger.log(LogStatus.PASS, locatorName + " has not displayed");
			return true;
		} catch (Exception e) {
			try {
				logger.log(LogStatus.FAIL,
						locatorName + " is still displaying after 30 seconds" + logger.addScreenCapture(takeScreenShot(locatorName)));
			} catch (Exception e1) {
				
				logger.log(LogStatus.FAIL, e1.toString());
			}
			return false;
		}
	}
	*/
	
	public void verifyNotPresent(WebElement element, String locatorName,int TimeInSeconds) throws IOException {
		
		try {
			Thread.sleep(TimeInSeconds*1000);
				element.isDisplayed();
				logger.log(LogStatus.FAIL,
						locatorName + " is still displaying after "+ TimeInSeconds +" seconds" + logger.addScreenCapture(takeScreenShot(locatorName)));
			}
		
		catch (Exception e) {
			
			if(System.getProperty("takeScreenshot").contains("no")){
				logger.log(LogStatus.PASS, locatorName + " has not displayed");
			}else{
				logger.log(LogStatus.PASS, locatorName + " has not displayed" + logger.addScreenCapture(takeScreenShot(locatorName)));
			}
		}
	}
	
	public void verifyTextPresent(WebElement element, String Expectedvalue) throws IOException {
		
		if (element.getText().trim().equalsIgnoreCase(Expectedvalue.trim())) {
			if(System.getProperty("takeScreenshot").contains("no")){
				logger.log(LogStatus.PASS,
						"Expected value is " + Expectedvalue + " and actual value is " + element.getText());
				}else{
					logger.log(LogStatus.PASS,
							"Expected value is " + Expectedvalue + " and actual value is " + element.getText() + logger.addScreenCapture(takeScreenShot(Expectedvalue)));
				}
			
		} else {

			try {
				logger.log(LogStatus.FAIL, "Expected value is " + Expectedvalue + " and actual value is "
						+ element.getText() + logger.addScreenCapture(takeScreenShot(Expectedvalue)));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.log(LogStatus.FAIL, e.toString());
			}
		}
	}
	

	public Boolean verifyText(String ActualValue, String Expectedvalue) throws IOException {
		
		if (ActualValue.trim().contains(Expectedvalue.trim())) {
				if(System.getProperty("takeScreenshot").contains("no")){
				logger.log(LogStatus.PASS,
						"Expected value is \"" + Expectedvalue + "\" and actual value is \"" + ActualValue+"\"");
				}else{
						logger.log(LogStatus.PASS,
								"Expected value is " + Expectedvalue + " and actual value is " + ActualValue +logger.addScreenCapture(takeScreenShot(ActualValue)));
					}
				return true;
		} else {

				try {
					logger.log(LogStatus.FAIL, "Expected value is " + Expectedvalue + " and actual value is "
							+ActualValue + logger.addScreenCapture(takeScreenShot(ActualValue)));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.log(LogStatus.FAIL, e.toString());
				}
				return false;
		}
	}
	public boolean verifyText(String ActualValue, String Expectedvalue,String ElementName ) throws IOException {

		if (ActualValue.trim().contains(Expectedvalue.trim())) {
		if(System.getProperty("takeScreenshot").contains("no")){
		logger.log(LogStatus.PASS,
		"Expected value of "+ElementName+" is "+"\"" + Expectedvalue + "\" and actual value is \"" + ActualValue+"\"");
		}else{
		logger.log(LogStatus.PASS,
		"Expected value is " + Expectedvalue + " and actual value is " + ActualValue +logger.addScreenCapture(takeScreenShot(ElementName)));
		}
		return true;
		} else {

		try {
		logger.log(LogStatus.FAIL, "Expected value of "+ElementName+" is "+"\"" + Expectedvalue + "\" and actual value is \"" + ActualValue+"\""
		+ logger.addScreenCapture(takeScreenShot(ElementName)));
		} catch (Exception e) {
		// TODO Auto-generated catch block
		logger.log(LogStatus.FAIL, e.toString());
		}
		return false;
		}
		}
	
	
public void verifyGuideLineTextText(String ActualValue, String Expectedvalue) throws IOException {
		
		if (Expectedvalue.trim().contains(ActualValue.trim())) {
				if(System.getProperty("takeScreenshot").contains("no")){
				logger.log(LogStatus.PASS,
						"Expected value is \"" + Expectedvalue + "\" and actual value is \"" + ActualValue+"\"");
				}else{
						logger.log(LogStatus.PASS,
								"Expected value is " + Expectedvalue + " and actual value is " + ActualValue +logger.addScreenCapture(takeScreenShot(ActualValue)));
					}
		} else {

				try {
					logger.log(LogStatus.FAIL, "Expected value is " + Expectedvalue + " and actual value is "
							+ActualValue + logger.addScreenCapture(takeScreenShot(ActualValue)));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.log(LogStatus.FAIL, e.toString());
				}
		}
	}

	public static String takeScreenShot(String methodName) throws IOException {
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Date date = new Date();
		File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		//String dest = ReportFolder + "\\ErrorScreenshots\\" + methodName +dateFormat.format(date)+ ".png";

		String date1 = dateFormat.format(date);
		String dest ="extentReports/"+dateString+"/ErrorScreenshots/" + methodName +date1+ ".png";
		//String dest = ReportFolder + "\\ErrorScreenshots\\" + methodName +dateValue+ ".png";
		//String relativePath = "\\ErrorScreenshots\\"+ methodName +dateValue+ ".png";
		String path="ErrorScreenshots/"+ methodName +date1+ ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);
		//return dest;
		return path;
	}
	
	
	public String takeScreenShot(String methodName, WebDriver driver1) throws IOException {
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Date date = new Date();
		File source = ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);
		String date1 = dateFormat.format(date);
		String dest ="extentReports/"+dateString+"/ErrorScreenshots/" + methodName +date1+ ".png";
		String path="ErrorScreenshots/"+ methodName +date1+ ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);
		return path;
	}
	
	public WebDriver getDriver(){
		
		return null;
		
	}

	

}
