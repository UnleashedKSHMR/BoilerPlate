package com.ace2three.base;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestContext;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class Beforetest {
	WebDriver driver;
	BaseTestSuite basetestsuite = new BaseTestSuite();
	private static DesiredCapabilities capabilities = new DesiredCapabilities();
	String activity;
	String appPackage;
	
	public WebDriver beforeTest(String deviceName, String resolution, String activityName, 	String app, 
			String appPackage, String appType, String environment,String platform,
			String platformVersion,String browsername,String udid,
			String portaddress, String serveraddress,String appiumUrl,String gps,ITestContext context,String systemPort) throws MalformedURLException {
		
		this.activity=activityName;
		this.appPackage=appPackage;
		if (environment.equals("desktop")) {
			if (browsername.equals("firefox")) {
				this.driver = new FirefoxDriver();
				basetestsuite.extent.addSystemInfo("Execution environment", "executing in firefox");
				
				
			} else if (browsername.equals("chrome")) {
				System.setProperty("webdriver.chrome.driver" , 
						System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
				this.driver = new ChromeDriver();
				basetestsuite.extent.addSystemInfo("Execution environment" ,"Executing on Chrome Driver");
				
			} else if (browsername.equals("ie")) {
				
				DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
				caps.setCapability(
						InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);
				caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				System.setProperty("webdriver.ie.driver",
						System.getProperty("user.dir")
								+ "\\driverservers\\IEDriverServer.exe");
				basetestsuite.extent.addSystemInfo("Execution environment" ,"Executing on IE Driver");
				this.driver = new InternetExplorerDriver(caps);
				
				
			}
			
		} else if (environment.equals("mobile")) {
			if (appType.equals("andweb")) {
				
				capabilities.setCapability(CapabilityType.BROWSER_NAME,
						browsername);
				capabilities.setCapability("deviceName",
						deviceName);
				capabilities.setCapability("platformVersion",
						platformVersion);
				capabilities
						.setCapability("platformName",platform);
				basetestsuite.extent.addSystemInfo("Execution environment" ,"Executing on Android browser");
				try {
					this.driver = new AndroidDriver(new URL(appiumUrl+ "/wd/hub/"), capabilities);
				} catch (MalformedURLException e) {
					basetestsuite.extent.addSystemInfo("fail",
							"Either appium is not running or Server port addresses are not matching, Check appium settings");
					basetestsuite.extent.addSystemInfo("warning", e.toString());
				}
				
				driver.get("http://gmail.com");
				
			}
			if (appType.equals("andapp")) {
							
				capabilities.setCapability("deviceName", deviceName);
		    	capabilities.setCapability("platformName", platform);
				capabilities.setCapability("platformVersion", platformVersion);
				if (app != null) {
					File appFile = new File(app);
					capabilities.setCapability("app", appFile.getAbsolutePath());
				}
				//capabilities.setCapability("recreateChromeDriverSessions", true);
				//capabilities.setCapability("setWebContentsDebuggingEnabled",true);
				capabilities.setCapability("appPackage", appPackage);
				capabilities.setCapability("udid", udid);
				capabilities.setCapability("appActivity", activityName);
				capabilities.setCapability("unicodeKeyboard", true);
				capabilities.setCapability("resetKeyboard", true);
		        capabilities.setCapability("noReset", false);
	            capabilities.setCapability("fullReset", false);
	            capabilities.setCapability("newCommandTimeout", 60 * 3);
	            capabilities.setCapability("dontStopAppOnReset", true);
	           // capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Uiautomator2");
	           // capabilities.setCapability(AndroidMobileCapabilityType.SYSTEM_PORT, systemPort);
	          // capabilities.setCapability("automationName", "UiAutomator2");
	           /*capabilities.android();*/
	          /*capabilities.setCapability("autoWebview", true);*/
	         /* capabilities.setCapability("androidDeviceSocket", appPackage + "_devtools_remote");
	            ChromeOptions chromeOptions = new ChromeOptions();
	            chromeOptions.setExperimentalOption("androidDeviceSocket", appPackage + "_devtools_remote");
	            capabilities.setCapability(ChromeOptions.CAPABILITY,chromeOptions);*/
	          // capabilities.setCapability("chromedriverExecutable", "C:\\Users\\dineshsoma\\AppData\\Local\\Programs\\appium-desktop\\resources\\app\\node_modules\\appium\\node_modules\\appium-chromedriver\\chromedriver\\win\\chromedriver.exe");
		        try {
					this.driver = new AndroidDriver(new URL(appiumUrl+ "/wd/hub/"), capabilities);
				} catch (MalformedURLException e) {
					basetestsuite.extent.addSystemInfo("fail",
							"Either appium is not running or Server port addresses are not matching, Check appium settings");
					basetestsuite.extent.addSystemInfo("warning", e.toString());
				}
				
		        basetestsuite.extent.addSystemInfo("info" ,"Executing on Android native App driver");
		        
			}
			if (appType.equals("iosweb")) {
				// To do stub
				// Need to implement iOS drivers
				basetestsuite.extent.addSystemInfo("info" ,"Executing on iOS web app driver");
				  
			}
			if (appType.equals("iosapp")) {
				// To do stub
				// Need to implement iOS drivers
				basetestsuite.extent.addSystemInfo("info" ,"Executing on iOS native app driver");
			
			}
		}
		 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		 return driver;
		
	}
	public void launchApp(){
		
	}

}
