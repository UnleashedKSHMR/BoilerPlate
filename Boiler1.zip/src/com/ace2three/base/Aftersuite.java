package com.ace2three.base;

public class Aftersuite {
	
	Aftersuite(){
		
		
	}

}
