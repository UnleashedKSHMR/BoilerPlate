package com.ace2three.facebook.web.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.CustomMethods;
import com.relevantcodes.extentreports.LogStatus;

import oracle.security.o5logon.d;

public class FacebookWebSiteImplPage extends BaseTestSuite {
	
	static WebDriver driver;
	public FacebookWebSiteImplPage(){
			/*PageFactory.initElements(driver, this);
			this.driver=driver;*/
	}
	
	public void intiateElement(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="input[id='email']")
	private WebElement userNameField;
	
	public WebElement getUserNameField(){
	return userNameField;
	}
	
	@FindBy(css="input[id='pass']")
	private WebElement passowrdField;
	
	public WebElement getPassowrdField(){
	return passowrdField;
	}
	
	@FindBy(css="label[id='loginbutton']")
	private WebElement loginButton;
	
	public WebElement getLoginButton(){
	return loginButton;
	}
	
	@FindBy(css="a[href='https://www.facebook.com/settings']")
	private WebElement userSettingsButton;
	
	public WebElement getUserSettingsButton(){
	return userSettingsButton;
	}
	
	@FindBy(css="div[id='userNavigationLabel']")
	private WebElement usernavigationlabel;
	
	public WebElement getUsernavigationlabel(){
	return usernavigationlabel;
	}
	
	@FindBy(css="a[href='https://www.facebook.com/settings?tab=applications&ref=settings']")
	
	private WebElement appTab;
	
	public WebElement getAppTab(){
	return appTab;
	}
	
	@FindBy(css="div[id='app-id-1901353993476233']")
	private WebElement ace2threeApp;
	
	public WebElement getAce2threeApp(){
	return ace2threeApp;
	}
	
	@FindBy(css="input[value='Remove'][type='button']")
	private WebElement removeAppButton;
	
	public WebElement getRemoveAppButton(){
	return removeAppButton;
	}
	
	@FindBy(css="a[class*='layerCancel'][role='button']")
	private WebElement notificationsNotNow;
	
	public WebElement getNotificationsNotNow(){
	return notificationsNotNow;
	}
	@FindBy(xpath="//img[contains(@src,'6767554683834728448')]/parent::div/following-sibling::div/button")
	private WebElement ace2threeAppCheckBox;
	
	public WebElement getAce2threeAppCheckBox(){
	return ace2threeAppCheckBox;
	}
	@FindBy(xpath="//form[contains(@ajaxify,'/ajax/settings/apps/delete_app_multi/')]")
	private WebElement removeButton;
	
	public WebElement getRemoveButton(){
	return removeButton;
	}
	@FindBy(xpath="//button[contains(@class,'layerConfirm')]")
	private WebElement removeConfirmButton;
	
	public WebElement getRemoveConfirmButton(){
	return removeConfirmButton;
	}
	
	
	
	public static void removeFbFromSite() throws InterruptedException, IOException{
		try{
		 FirefoxProfile ffprofile = new FirefoxProfile(); 
		 ffprofile.setPreference("dom.webnotifications.enabled", false);
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/drivers/geckodriver.exe");
		driver =new FirefoxDriver(ffprofile);
	//	FacebookWebSiteImplPage facebookWebSiteImplPage= new FacebookWebSiteImplPage(driver);
		
		driver.get("http://facebook.com");
		//Maximizing Chrome App Window.
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("document.body.style.zoom = '0.9'");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("input[id='email']")).sendKeys("dineshchakravarthy5@gmail.com");
		driver.findElement(By.cssSelector("input[id='pass']")).sendKeys("janaiah222");
		driver.findElement(By.cssSelector("label[id='loginbutton']")).click();
		Thread.sleep(10000);
		FacebookWebSiteImplPage  facebookWebImplPage= new FacebookWebSiteImplPage();
		facebookWebImplPage.intiateElement(driver);
	
		facebookWebImplPage.getUsernavigationlabel().click();
		facebookWebImplPage.getUserSettingsButton().click();
		
		Thread.sleep(4000);
		facebookWebImplPage.getAppTab().click();
		Thread.sleep(7000);
		
		facebookWebImplPage.getAce2threeAppCheckBox().click();
		facebookWebImplPage.getRemoveButton().click();
		facebookWebImplPage.getRemoveConfirmButton().click();
		Thread.sleep(4000);
		driver.close();
		/*WebElement ele = driver.findElement(By.xpath("//img[contains(@src,'6767554683834728448')]/parent::div/following-sibling::div/button"));
		ele.click();*/
		
		//driver.findElement(By.xpath("//form[contains(@ajaxify,'/ajax/settings/apps/delete_app_multi/')]")).click();
		//driver.findElement(By.xpath("//button[contains(@class,'layerConfirm')]")).click();
		
		
		
		}
		catch(Exception e)
		{
			
		}
		
		
	}
	
	public static void removeFbFromSite1() throws InterruptedException, IOException{
		try{
			 FirefoxProfile ffprofile = new FirefoxProfile(); 
			 ffprofile.setPreference("dom.webnotifications.enabled", false);
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/drivers/geckodriver.exe");
		driver =new FirefoxDriver(ffprofile);
	//	FacebookWebSiteImplPage facebookWebSiteImplPage= new FacebookWebSiteImplPage(driver);
		
		driver.get("http://facebook.com");
		//Maximizing Chrome App Window.
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("document.body.style.zoom = '0.9'");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("input[id='email']")).sendKeys("acetest77@gmail.com");
		driver.findElement(By.cssSelector("input[id='pass']")).sendKeys("ace2three");
		driver.findElement(By.cssSelector("label[id='loginbutton']")).click();
				
		Thread.sleep(10000);
		FacebookWebSiteImplPage  facebookWebImplPage= new FacebookWebSiteImplPage();
		facebookWebImplPage.intiateElement(driver);
		Thread.sleep(6000);
		if(CustomMethods.isElementPresent(facebookWebImplPage.getNotificationsNotNow()))
		facebookWebImplPage.getNotificationsNotNow().click();
		facebookWebImplPage.getUsernavigationlabel().click();
		facebookWebImplPage.getUserSettingsButton().click();
		
		Thread.sleep(4000);
		facebookWebImplPage.getAppTab().click();
		Thread.sleep(7000);
		facebookWebImplPage.getAce2threeAppCheckBox().click();
		facebookWebImplPage.getRemoveButton().click();
		facebookWebImplPage.getRemoveConfirmButton().click();
		Thread.sleep(4000);
		driver.close();
		}catch(Exception e){
			BaseTestSuite.logger.log(LogStatus.INFO, e.toString()+ BaseTestSuite.logger.addScreenCapture(BaseTestSuite.takeScreenShot("screenshot")));
		}
	}
	
	/*public static void main(String args[]) throws InterruptedException, IOException
	{
		removeFbFromSite();
	}*/
	
}
