package com.ace2three.impl.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.component.pages.OtpPopupComponent;
import com.ace2three.impl.pages.MyAccountImplPage.Section;

import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;

import io.appium.java_client.MobileElement;

public class PurchaseLimitsImplPage implements OtpPopupComponent{
WebDriver desktopDriver;
WebDriver driver;
		public PurchaseLimitsImplPage(WebDriver driver) {
			PageFactory.initElements(driver, this);
			this.driver=driver;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
		private WebElement purchaseLimitsRestricetedAlert;
		
		public WebElement getPurchaseLimitsRestricetedAlert(){
			return purchaseLimitsRestricetedAlert;
		}	
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'otp_message_button')]")
		private WebElement confirmOtpButton;
		
		public WebElement getConfirmOtpButton(){
			return confirmOtpButton;
		}	
		
		@FindBy(xpath= "//android.widget.Button[contains(@text,'Buy Real Chips')]")
		private WebElement purchaseLimitsRestricetedAlertBuyChipsButton;
		
		public WebElement getPurchaseLimitsRestricetedAlertBuyChipsButton(){
			return purchaseLimitsRestricetedAlertBuyChipsButton;
		}	
		
		@FindBy(xpath= "//android.widget.Button[contains(@text,'No Thanks')]")
		private WebElement purchaseLimitsRestricetedAlertNoThanksButton;
		
		public WebElement getPurchaseLimitsRestricetedAlertNoThanksButton(){
			return purchaseLimitsRestricetedAlertNoThanksButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'purchase_limits_slab1_button')]")
		private WebElement purchaselimitSlab1;
		
		public WebElement getPurchaseLimitSlab1(){
			return purchaselimitSlab1;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'purchase_limits_slab2_button')]")
		private WebElement purchaselimitSlab2;
		
		public WebElement getPurchaseLimitSlab2(){
			return purchaselimitSlab2;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'purchase_limits_slab3_button')]")
		private WebElement purchaselimitSlab3;
		
		public WebElement getPurchaseLimitSlab3(){
			return purchaselimitSlab3;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'purchase_limits_slab4_button')]")
		private WebElement purchaselimitSlab4;
		
		public WebElement getPurchaseLimitSlab4(){
			return purchaselimitSlab4;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'pl_statusalert')]")
		private WebElement verifyAlertToIncreaseSlab;
		
		public WebElement getVerifyPhoneNoAlertS1toS2(){
			return verifyAlertToIncreaseSlab;
		}
		//Using above same locator
		public WebElement getVerifyIdproofAlertS2toS3(){
			return verifyAlertToIncreaseSlab;
		}
		//Using above same locator
		public WebElement getProvideBankAccountAlertS3toS4(){
			return verifyAlertToIncreaseSlab;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'pl_verify_kyc')]")
		private WebElement verifyAlertS1toS2VerifyButton;
		
		public WebElement getVerifyAlertS1toS2VerifyButton(){
			return verifyAlertS1toS2VerifyButton;
		}
			//Using above same locator
				public WebElement getVerifyAlertS2toS3VerifyButton(){
					return verifyAlertS1toS2VerifyButton;
				}
			//Using above same locator
			public WebElement getVerifyAlertS3toS4VerifyButton(){
				return verifyAlertS1toS2VerifyButton;
			}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'pl_kyc_later')]")
		private WebElement verifyAlertS1toS2LaterButton;
		
		public WebElement getVerifyAlertToIncreasePlLaterButton(){
			return verifyAlertS1toS2LaterButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'header')]")
		private WebElement otpAlertheader;
		
		public WebElement getOtpAlertheader(){
			return otpAlertheader;
		}
		
		@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'mobilenoET')]")
		private WebElement enterPhoneNumberField;
		
		public WebElement getEnterPhoneNumberField(){
			return enterPhoneNumberField;
		}

		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'positiveBtn')]")
		private WebElement sendOtpButton;
		
		public WebElement getSendOtpButton(){
			return sendOtpButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'pl_statusalert')]")
		private WebElement mobileVerifiedCongratsMessage;
		
		public WebElement getMobileVerifiedCongratsMessage(){
			return mobileVerifiedCongratsMessage;
		}

		@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'otpET')]")
		private WebElement enterOTPField;
		
		@Override
		public WebElement getOtpField() {
			return enterOTPField;
		}
		@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'otp_message_entry')]")
		private WebElement enterOTPField2;
		
		
		public WebElement getOtpField2() {
			return enterOTPField2;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'purchase_limits_submit_button')]")
		private WebElement submitButton;
		
		public WebElement getSubmitButton() {
			return submitButton;
		}

		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'pl_statusalert')]")
		private WebElement purchaseLimitUpdatedMessage;
		
		public WebElement getPurchaseLimitUpdatedMessage() {
			return purchaseLimitUpdatedMessage;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'ok')]")
		private WebElement purchaseLimitAlertOkButton;
		
		public WebElement getPurchaseLimitAlertOkButton() {
			return purchaseLimitAlertOkButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'purchase_limits_set_daily_limits_tablevalue_dialy')]")
		private WebElement purchaseDailyLimitValue;
		
		public WebElement getPurchaseDailyLimitValue() {
			return purchaseDailyLimitValue;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'purchase_limits_set_monthly_limits_tablevalue_dialy')]")
		private WebElement purchaseMonthlyLimitValue;
		
		public WebElement getPurchaseMonthlyLimitValue() {
			return purchaseMonthlyLimitValue;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'purchase_limits_show_daily_limits_message')]")
		private WebElement purchaselimitIncreaseCoolOffPeriodMessage;
		
		public WebElement getPurchaselimitIncreaseCoolOffPeriodMessage() {
			return purchaselimitIncreaseCoolOffPeriodMessage;
		}

		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'pl_statusalert')]")
		private WebElement requestReceivedAlertForPlimitChange;
		
		public WebElement getRequestReceivedAlertForPlimitChange() {
			return requestReceivedAlertForPlimitChange;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'ok')]")
		private WebElement requestReceivedAlertForPlimitChangeOkButton;
		
		public WebElement getRequestReceivedAlertForPlimitChangeOkButton() {
			return requestReceivedAlertForPlimitChangeOkButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'purchase_limits_show_daily_limits_message')]")
		private WebElement requestReceivedForPlimitChangeInProcessing;
		
		public WebElement getRequestReceivedForPlimitChangeInProcessing() {
			return requestReceivedForPlimitChangeInProcessing;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'pl_statusalert')]")
		private WebElement reducePurchaseLimitsConfirmationAlert;
		
		public WebElement getPeducePurchaseLimitsConfirmationAlert() {
			return reducePurchaseLimitsConfirmationAlert;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'purchase_limits_kyc_message')]")
		private WebElement purchaseLimitsKYCMsg;
		
		public WebElement getPurchaseLimitsKYCMsg() {
			return purchaseLimitsKYCMsg;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'pl_statusalert')]")
		private WebElement fivePerOfMonLimitPopup;
		
		public WebElement getFivePerOfMonLimitPopup() {
			return fivePerOfMonLimitPopup;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'ok')]")
		private WebElement fivePerOfMonLimitPopupOkButton;
		
		public WebElement getFivePerOfMonLimitPopupOkButton() {
			return fivePerOfMonLimitPopupOkButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'pl_dec_yes')]")
		private WebElement reducePurchaseLimitsConfirmationYesButton;
		
		public WebElement getReducePurchaseLimitsConfirmationYesButton() {
			return reducePurchaseLimitsConfirmationYesButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'pl_dec_no')]")
		private WebElement reducePurchaseLimitsConfirmationNoButton;
		
		public WebElement getReducePurchaseLimitsConfirmationNoButton() {
			return reducePurchaseLimitsConfirmationNoButton;
		}
		
		public void updatePurchaseLimitSlabInAdmin(String userName,int slabLevel){
			
			CustomMethods customeMe=  new CustomMethods();
			desktopDriver=customeMe.launchWebBrowser();
	
			desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
			
			desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
			desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
			desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
			
			JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
			executor.executeScript("document.body.style.zoom = '0.9'");
			
			List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
			for(WebElement listedOne:list){
				System.out.println(listedOne.getText());
					if(listedOne.getText().equals("PLAYER")){
						Actions action = new Actions(desktopDriver);
						action.moveToElement(listedOne).build().perform();
					}
			}
			desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
			desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(userName);
			desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
			
			try{
				desktopDriver.findElement(By.cssSelector("a[href='userProfileDetails.jsp?userid="+userName+"']")).click();
			}catch(Exception e){
				System.out.println("exception 11");
			}
			WebElement purchaselimit= desktopDriver.findElement(By.cssSelector("a[href*='purchaseLimits.do']"));
			executor.executeScript("arguments[0].click()", purchaselimit);
			desktopDriver.findElement(By.cssSelector("a#updateLimits")).click();
			
			if(slabLevel==3){
				WebElement slab3= desktopDriver.findElement(By.cssSelector("input[id='DV']"));
			executor.executeScript("arguments[0].click()", slab3);
			}else if(slabLevel==4){
				WebElement slab4= desktopDriver.findElement(By.cssSelector("input[id='HV']"));
				executor.executeScript("arguments[0].click()", slab4);
			}
			WebElement comments= 	desktopDriver.findElement(By.cssSelector("textarea[id='comment']"));
			((JavascriptExecutor) desktopDriver).executeScript("arguments[0].scrollIntoView(true);", comments);
			comments.sendKeys("QA test");
			desktopDriver.findElement(By.cssSelector("input[id='updatePurchaseStatus']")).click();
			desktopDriver.close();
		}
		
		public void navigateToPurchaseLimitPage(){
			MyAccountImplPage myAccountPage= new MyAccountImplPage(driver);
			if(System.getProperty("testEnvironment").equalsIgnoreCase("qa")){
				myAccountPage.launchPurchaseLimitsScreen();
				myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
				myAccountPage.getPasswordPopUpSubmitButton().click();
			}else if(System.getProperty("testEnvironment").equalsIgnoreCase("production")){
				myAccountPage.launchMyAccountDetailsScreen();
				myAccountPage.getPasswordPopUpField().sendKeys("ace2three");
				myAccountPage.getPasswordPopUpSubmitButton().click();
				myAccountPage.navigateToMyAccountsSection(Section.PurchaseLimits);
			}
			
		}
}
