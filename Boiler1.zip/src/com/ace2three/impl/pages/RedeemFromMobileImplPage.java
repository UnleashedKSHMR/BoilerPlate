package com.ace2three.impl.pages;

import java.io.IOException;
import java.lang.reflect.Method;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.RecoveryManagement;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class RedeemFromMobileImplPage extends BaseTestSuite {

	WebDriver desktopDriver;
	WebDriver driver;
	float enteredRedeemAmount=0;
			public RedeemFromMobileImplPage(WebDriver driver) {
				PageFactory.initElements(driver, this);
				this.driver=driver;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvRedeem')]")
			private WebElement redeemTab;
			
			public WebElement getRedeemTab(){
				return redeemTab;
			}	
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvReversal')]")
			private WebElement reversalTab;
			
			public WebElement getReversalTab(){
				return reversalTab;
			}	
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvHistory')]")
			private WebElement historyTab;
			
			public WebElement getHistoryTab(){
				return historyTab;
			}	
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvRedeemBalance')]")
			private WebElement redeemableBalance;
			
			public WebElement getRedeemableBalance(){
				return redeemableBalance;
			}	
			public void setEnteredRedeemAmount(String amount)
			{
				System.out.println(amount);
				if(!amount.equals(""))
				enteredRedeemAmount=Float.parseFloat(amount);
			
			/*	else 
					enteredRedeemAmount=(Float) null;*/
			}
			public float getEnteredRedeemAmount()
			{
				return enteredRedeemAmount;
			}
	
			@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'etRedeemAmount')]")
			private WebElement enterRedeemAmount;
			
			public WebElement getEnterRedeemAmount(){
				return enterRedeemAmount;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvRedeemStatus')]")
			private WebElement redeemStatus;
			
			public WebElement getRedeemStatus(){
				return redeemStatus;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'ivSelectBank')]")
			private WebElement selectBank;
			
			public WebElement getSelectBank(){
				return selectBank;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvRedeemSubmit')]")
			private WebElement redeemRequestButton;
			
			public WebElement getRedeemRequestButton(){
				return redeemRequestButton;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvRedeemLimits')]")
			private WebElement redeemLimits;
			
			public WebElement getRedeemLimits(){
				return redeemLimits;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'ivRedeemCall')]")
			private WebElement redeemCall;
			
			public WebElement getRedeemCall(){
				return redeemCall;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnYes')]")
			private WebElement confirmRedeemYes;
			
			public WebElement getConfirmRedeemYes(){
				return confirmRedeemYes;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvMessage')]")
			private WebElement confirmRedeemText;
			
			public WebElement getConfirmRedeemText(){
				return confirmRedeemText;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
			private WebElement verifyEmailAndMobNumPopUp;
			
			public WebElement getVerifyEmailAndMobNumPopUp(){
				return verifyEmailAndMobNumPopUp;
			}
			
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnNo')]")
			private WebElement confirmRedeemNo;
			
			public WebElement getConfirmRedeemNo(){
				return confirmRedeemNo;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@text,'Please provide your KYC documents')]")
			private WebElement pleaseProvideYourKYCDocumentsText;
			
			public WebElement getpleaseProvideYourKYCDocumentsText(){
				return pleaseProvideYourKYCDocumentsText;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnYes')]")
			private WebElement pleaseProvideYourKYCDocumentsOkButton;
			
			public WebElement getpleaseProvideYourKYCDocumentsOkButton(){
				return pleaseProvideYourKYCDocumentsOkButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnNo')]")
			private WebElement pleaseProvideYourKYCDocumentsCancelButton;
			
			public WebElement getpleaseProvideYourKYCDocumentsCancelButton(){
				return pleaseProvideYourKYCDocumentsCancelButton;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvClose')]")
			private WebElement confirmRedeemPopUpClose;
			
			public WebElement getConfirmRedeemPopUpClose(){
				return confirmRedeemPopUpClose;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvRedeemReversalCancel')]")
			private WebElement cancelRedeemRequestButton;
			
			public WebElement getCancelRedeemRequestButton(){
				return cancelRedeemRequestButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnYes')]")
			private WebElement cancelRedeemRequestPopUpYesButton;
			
			public WebElement getCancelRedeemRequestPopUpYesButton(){
				return cancelRedeemRequestPopUpYesButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement redeemReversalSuccessfulButton;
			
			public WebElement getRedeemReversalSuccessfulButton(){
				return redeemReversalSuccessfulButton;
			}
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement verifyEmailAndMobNumPopUpOkButton;
			
			public WebElement getverifyEmailAndMobNumPopUpOkButton(){
				return verifyEmailAndMobNumPopUpOkButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
			private WebElement verifyEmailAndMobNumPopUpNoButton;
			
			public WebElement getverifyEmailAndMobNumPopUpNoButton(){
				return verifyEmailAndMobNumPopUpNoButton;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvReversalBankReferalId')]")
			private WebElement redeemReferalId;
			
			public WebElement getRedeemReferalId(){
				return redeemReferalId;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvMessage')]")
			private WebElement kycHasToBeVerifiedText;
			
			public WebElement getKycHasToBeVerifiedText(){
				return kycHasToBeVerifiedText;
			}
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnYes')]")
			private WebElement kycHasToBeVerifiedTextOkButton;
			
			public WebElement getKycHasToBeVerifiedTextOkButton(){
				return kycHasToBeVerifiedTextOkButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnNo')]")
			private WebElement kycHasToBeVerifiedTextCancelButton;
			
			public WebElement getKycHasToBeVerifiedTextCancelButton(){
				return kycHasToBeVerifiedTextCancelButton;
			}
			
			
			public void verifyValidation( ) throws IOException
			{
				float MIN_REDEEM_AMOUNT= 200, MAX_REDEEM_AMOUNT=10000;
				String MIN_AND_MAX_REDEEM_CHECK_STRING="Redeem Amount should be between 200 and 10000.";
				String PLEASE_ENTER_REDEEM_AMOUNT="Please enter the Redeem Amount";
				String ENTER_LESS_THAN_REDEEM_BAL_STRING="Please enter the amount that is less than or equal to your redeemable balance.";
				//RedeemFromMobileImplPage redeemFromMobileImplPage = new RedeemFromMobileImplPage(driver);
				
				//float redeemable_balance = Float.parseFloat(redeemFromMobileImplPage.getEnterRedeemAmount().toString());
				
			/*	if(Float.parseFloat(redeemFromMobileImplPage.getEnterRedeemAmount().getText().toString().trim())>=MIN_REDEEM_AMOUNT &&
						Float.parseFloat(redeemFromMobileImplPage.getEnterRedeemAmount().getText().toString().trim())<=MAX_REDEEM_AMOUNT)
				{
					
				}*/
				//System.out.println(getEnteredRedeemAmount() + "vaslue is");
				if(getEnteredRedeemAmount()==0)
				{
					
					System.out.println("Entered");
					verifyText(getRedeemStatus().getText().trim(), PLEASE_ENTER_REDEEM_AMOUNT);
			
					
				}
				else if((getEnteredRedeemAmount()< MIN_REDEEM_AMOUNT) || (getEnteredRedeemAmount()> MAX_REDEEM_AMOUNT))
				{
					
					verifyText(getRedeemStatus().getText().trim(), MIN_AND_MAX_REDEEM_CHECK_STRING);
				}
				else if(Float.parseFloat(getRedeemableBalance().getText().toString().trim()) < getEnteredRedeemAmount())
				{
					
					verifyText(getRedeemStatus().getText().trim(), ENTER_LESS_THAN_REDEEM_BAL_STRING);
				}
				
		}
		
}
