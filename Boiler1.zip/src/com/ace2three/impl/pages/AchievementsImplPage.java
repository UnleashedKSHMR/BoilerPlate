package com.ace2three.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.locators.AndroidLocators.AchievementsPageLocators;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

	public class AchievementsImplPage implements AchievementsPageLocators {
	
	
	WebDriver driver;
	
	public AchievementsImplPage(WebDriver driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		this.driver=driver;
	}
	
	@FindBy(xpath=ACHIEVEMENTS_HEADER)
	private WebElement achievementsHeader;
	
	public WebElement getAchievementsHeader(){
		return achievementsHeader;
	}
	
	@FindBy(xpath=MAKE_YOUR_FIRST_PURCHASE)
	private WebElement makeYourfirstPurchaseText;
	
	public WebElement getMakeYourfirstPurchaseText(){
		return makeYourfirstPurchaseText;
	}
	@FindBy(xpath=Buy_CHIPS_BUTTON)
	private WebElement buyChipsButton;
	
	public WebElement getBuyChipsButton(){
		return buyChipsButton;
	}
	@FindBy(xpath=TRICKY_THREE_HEADER)
	private WebElement trickyThreeHeader;
	
	public WebElement getTrickyThreeHeader(){
		return trickyThreeHeader;
	}
	@FindBy(xpath=RUMMY_PRO_HEADER)
	private WebElement rummyProHeader;
	
	public WebElement getRummyProHeader(){
		return rummyProHeader;
	}
	@FindBy(xpath=FANTASTIC_FIVE_HEADER)
	private WebElement fantasticFiveHeader;
	
	public WebElement getFantasticFiveHeader(){
		return fantasticFiveHeader;
	}
	@FindBy(xpath=POOL_101_MASTER_HEADER)
	private WebElement poolMaster101Header;
	
	public WebElement getPoolMaster101Header(){
		return poolMaster101Header;
	}
	@FindBy(xpath=POOL_201_MASTER_HEADER)
	private WebElement poolMaster201Header;
	
	public WebElement getPoolMaster201Header(){
		return poolMaster201Header;
	}
	@FindBy(xpath=STAKES_MASTER_HEADER)
	private WebElement stakesMasterHeader;
	
	public WebElement getStakesMasterHeader(){
		return stakesMasterHeader;
	}
}
