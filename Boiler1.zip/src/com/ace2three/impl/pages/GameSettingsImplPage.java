package com.ace2three.impl.pages;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.locators.AndroidLocators.GameSettingsLocators;
import com.ace2three.utils.OCREngine;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class GameSettingsImplPage implements GameSettingsLocators{

	private File imgDir;

	WebDriver driver;
	public GameSettingsImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver= driver;
		PageFactory.initElements(driver, this);
        
	}
	
	public void openGameSettings(){
		
		if(System.getProperty("testEnvironment").equalsIgnoreCase("production")){
		LobbyImplPage lobbyPage = new  LobbyImplPage(driver);
		lobbyPage.getHamburgerMenu().click();
		
		OCREngine ocr = new OCREngine((AppiumDriver) driver);
		 //location of screenshots
        File classpathRoot = new File(System.getProperty("user.dir"));
        imgDir = new File(classpathRoot, "SourceImages");
        
		String gameSettings= imgDir+ "/gameSettings.png";
		
		ocr.clickByImage(gameSettings);
		
		//Verifing game settings pop up has displayed 
				try{
					getGameSettingsPopupHeader().isDisplayed();
					  
						BaseTestSuite.logger.log(LogStatus.PASS, "Game settings pop up has displayed");    
				}catch(Exception e){
					 
					BaseTestSuite.logger.log(LogStatus.FAIL, "Game settings pop up has not displayed");
				}
		}else if(System.getProperty("testEnvironment").equalsIgnoreCase("qa")){
			
			LobbyImplPage lobbyPage = new  LobbyImplPage();
			lobbyPage.getHamburgerMenu().click();
			lobbyPage.getHamburgerMenuItem(hamburgerMenuItems.GameSettings,null).click();
		
			try{
				getGameSettingsPopupHeader().isDisplayed();
				  BaseTestSuite.logger.log(LogStatus.PASS, "Game settings pop up has displayed");    
			}catch(Exception e){
				 
				BaseTestSuite.logger.log(LogStatus.FAIL, "Game settings pop up has not displayed");
			}
			
		}
	}
	
	@FindBy(xpath= GAMES_SETTINGS_POPUP_HEADER)
	WebElement gameSettingsPopupHeader;
	
	public WebElement getGameSettingsPopupHeader(){
		return gameSettingsPopupHeader;
	}
	
	@FindBy(xpath= SOUND_ON_OFF_OPTION)
	WebElement soundOnOffOption;
	
	public WebElement getSoundOnOffOption(){
		return soundOnOffOption;
	}
	@FindBy(xpath= PROFILE_ON_OFF_OPTION)
	WebElement profileOnOffOption;
	
	public WebElement getProfileOnOffOption(){
		return profileOnOffOption;
	}
	
	@FindBy(xpath= VIBRATION_ON_OFF_OPTION)
	WebElement vibrationOnOffOption;
	
	public WebElement getVibrationOnOffOption(){
		return vibrationOnOffOption;
	}
	
	@FindBy(xpath= GAME_SETTINGS_CLOSE)
	WebElement gameSettingsClose;
	
	public WebElement getGameSettingsClose(){
		return gameSettingsClose;
	}
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'next_theme')]")
	WebElement nextThemeButton;
	
	public WebElement getNextThemeButton(){
		return nextThemeButton;
	}
	
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'prev_theme')]")
	WebElement previousThemeButton;
	
	public WebElement getPreviousThemeButton(){
		return previousThemeButton;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Current Theme')]")
	WebElement currentThemeButton;
	
	public WebElement getCurrentThemeButton(){
		return currentThemeButton;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Select Theme')]")
	WebElement selectThemeButton;
	
	public WebElement getSelectThemeButton(){
		return selectThemeButton;
	}
	
	
}
