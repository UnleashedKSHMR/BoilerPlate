package com.ace2three.impl.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.business.BusinessMethods;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class BankAccountsImplPage {
	BusinessMethods businessMethods;
	BaseTestSuite baseTestSuite;
	WebDriver desktopDriver;

		public BankAccountsImplPage(WebDriver driver) {
			PageFactory.initElements(driver, this);
			businessMethods = new BusinessMethods();
			baseTestSuite= new BaseTestSuite();
		}

		@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'etSelectBank')]")
		private WebElement selectBankName;
		
		public WebElement getSelectBankName(){
			return selectBankName;
		}
		
		@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'nmetAccNumber')]")
		private WebElement enterBankAccountNumberField;
		
		public WebElement getEnterBankAccountNumberField(){
			return enterBankAccountNumberField;
		}
		
		@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'nmetConfirmAccNumber')]")
		private WebElement enterConfirmBankAccountNumberField;
		
		public WebElement getEnterConfirmBankAccountNumberField(){
			return enterConfirmBankAccountNumberField;
		}
		
		@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'etIFSCCode')]")
		private WebElement enterIfscCodeField;
		
		public WebElement getEnterIfscCodeField(){
			return enterIfscCodeField;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvBankDoc')]")
		private WebElement bankAccountProofField;
		
		public WebElement getBankAccountProofField(){
			return bankAccountProofField;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvUpload')]")
		private WebElement uploadBankAccountProofButton;
		
		public WebElement getUploadBankAccountProofButton(){
			return uploadBankAccountProofButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvSaveBankDetails')]")
		private WebElement saveBankDetailsButton;
		
		public WebElement getSaveBankDetailsButton(){
			return saveBankDetailsButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvAddAnotherAccount')]")
		private WebElement clickHereToAddAnotherAccount;
		
		public WebElement getClickHereToAddAnotherAccount(){
			return clickHereToAddAnotherAccount;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvBankAccMask')]")
		private WebElement addedBankAccount;
		
		public WebElement getAddedBankAccount(){
			return addedBankAccount;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvGuidelinesTitle')]")
		private WebElement guideLinesForBankAccontsPopupHeader;
		
		public WebElement getGuideLinesForBankAccontsPopupHeader(){
			return guideLinesForBankAccontsPopupHeader;
		}

		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvGuidelines')]")
		private WebElement guideLinesForBankAccontsText;
		
		public WebElement getGuideLinesForBankAccontsText(){
			return guideLinesForBankAccontsText;
		}

		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvOk')]")
		private WebElement guideLinesForBankAccontsOkButton;
		
		public WebElement getGuideLinesForBankAccontsTextOkButton(){
			return guideLinesForBankAccontsOkButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvUploadFileTitle')]")
		private WebElement uploadBankAccountOptionsPopupheader;
		
		public WebElement getUploadBankAccountOptionsPopupheader(){
			return uploadBankAccountOptionsPopupheader;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvTitle')]")
		private WebElement uploadBankAccountProofDocHeader;
		
		public WebElement getUploadBankAccountProofDocHeader(){
			return uploadBankAccountProofDocHeader;
		}

		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvFileOne')]")
		private WebElement uploadBankAccountProofDocName;
		
		public WebElement getUploadBankAccountProofDocName(){
			return uploadBankAccountProofDocName;
		}
		
		@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'iVDeleteFileOne')]")
		private WebElement uploadBankAccountProofDelecteDocButton;
		
		public WebElement getUploadBankAccountProofDelecteDocButton(){
			return uploadBankAccountProofDelecteDocButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvSubmit')]")
		private WebElement uploadBankAccountProofDocOkButton;
		
		public WebElement getUploadBankAccountProofDocOkButton(){
			return uploadBankAccountProofDocOkButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvSelectedFile')]")
		private WebElement uploadedBankAccountProof;
		
		public WebElement getUploadedBankAccountProof(){
			return uploadedBankAccountProof;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvMessage')]")
		private WebElement bankAccountUploadSuccessAlertMessage;
		
		public WebElement getBankAccountUploadSuccessAlertMessage(){
			return bankAccountUploadSuccessAlertMessage;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvOk')]")
		private WebElement bankAccountUploadSuccessAlertOkButton;
		
		public WebElement getBankAccountUploadSuccessAlertOkButton(){
			return bankAccountUploadSuccessAlertOkButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvPendingApproval')]")
		private WebElement bankAccountUploadApprovalStatus;
		
		public WebElement getBankAccountUploadApprovalStatus(){
			return bankAccountUploadApprovalStatus;
		}
		
		public void verifyBankAccountsPageDisplayed() throws IOException, InterruptedException{
			Thread.sleep(2000);
			if(CustomMethods.isElementPresent(getAddedBankAccount())){
				baseTestSuite.logger.log(LogStatus.PASS, "Bank account page has displayed");
			}else if(CustomMethods.isElementPresent(getClickHereToAddAnotherAccount())){
				baseTestSuite.logger.log(LogStatus.PASS, "Bank account page has displayed");
			}else if(CustomMethods.isElementPresent(getEnterBankAccountNumberField())){
				baseTestSuite.logger.log(LogStatus.PASS, "Bank account page has displayed");
			}else{
				baseTestSuite.logger.log(LogStatus.FAIL, "Bank account page has not displayed" + 
							baseTestSuite.logger.addScreenCapture(baseTestSuite.takeScreenShot("bank account page")));
			}
			
		}
		
		private String addBankAccount(){
			getSelectBankName().click();
			CustomMethods.selectFromDropDownList("Axis bank");
			String accNumber ="0566"+ CustomMethods.generateRandomNumber(8);
			getEnterBankAccountNumberField().sendKeys(accNumber);
			getEnterConfirmBankAccountNumberField().sendKeys(accNumber);
			getEnterIfscCodeField().sendKeys("UTIB0003198");
			return accNumber;
		}
		
		public void verifyBankAccountGuideLines() throws IOException{
			CustomMethods.verifyGuideLinesText(getGuideLinesForBankAccontsText(), 
					ReadDataFromProps.props.getProperty("bank.account.proof.upload.guidelines.text"));
			
		}
		
		public String addBankAccountWithProof() throws InterruptedException, IOException{
			/*if(CustomMethods.isElementPresent(getClickHereToAddAnotherAccount())){
				getClickHereToAddAnotherAccount().click();
			}*/
			String acctNumber =addBankAccount();
			getBankAccountProofField().click();
			CustomMethods.selectFromDropDownList("Bank Passbook");
			getUploadBankAccountProofButton().click();
			baseTestSuite.verifyPresent(getGuideLinesForBankAccontsPopupHeader(),"Guidelines for bank account popup");
			
			getGuideLinesForBankAccontsTextOkButton().click();
			baseTestSuite.verifyPresent(getUploadBankAccountOptionsPopupheader(),"Upload bank account proof options");
			KycImplPage kycPage= new KycImplPage(baseTestSuite.driver);

			kycPage.getIdProofUploadPopUpCameraIcon().click();
			if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
			{
				kycPage.getCameraShutterButton().click();
				Thread.sleep(2000);
				baseTestSuite.driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
			}
			else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
			{
				MobileElement ele= (MobileElement) baseTestSuite.driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
				((AndroidDriver) baseTestSuite.driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
				baseTestSuite.driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
			}
			
			//baseTestSuite.driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'tvSubmit')]")).click();
			//Changed/baseTestSuite.driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
			//driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'crop_image_menu_crop')]")).click();
			//baseTestSuite.verifyPresent(getUploadBankAccountProofDocHeader(),"Upload bank account proof doc preview");
			
			getUploadBankAccountProofDocOkButton().click();
			CustomMethods.waitForElementPresent(getUploadedBankAccountProof(), 15);
			baseTestSuite.verifyPresent(getUploadedBankAccountProof(),"Uploaded bank account proof");
			CustomMethods.waitForElementPresent(getSaveBankDetailsButton(), 15);
			getSaveBankDetailsButton().click();
			CustomMethods.waitForElementPresent(getBankAccountUploadSuccessAlertMessage(), 15);
			baseTestSuite.verifyPresent(getBankAccountUploadSuccessAlertMessage(),"Bank account upload success alert");
			CustomMethods.waitForElementPresent(getBankAccountUploadSuccessAlertOkButton(), 15);
			getBankAccountUploadSuccessAlertOkButton().click();
			return acctNumber;
		}
		
		public enum BankAccountProofAction{
			Accept,Reject;
		}
		
		public void approveBankAcountInAdmin(String userName,String bankAccNo, BankAccountProofAction bankAccountProofAction) throws InterruptedException{
			CustomMethods customeMe=  new CustomMethods();
			desktopDriver=customeMe.launchWebBrowser();
		
			desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
			
			desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
			desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
			desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
			JavascriptExecutor js = (JavascriptExecutor) desktopDriver;
			List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
			for(WebElement listedOne:list){
				System.out.println(listedOne.getText());
					if(listedOne.getText().equals("RM")){
						Actions action = new Actions(desktopDriver);
						action.moveToElement(listedOne).build().perform();
					}
			}
			WebElement kycCue= desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']"));
			js.executeScript("arguments[0].click();", kycCue );
			//desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']")).click();
			desktopDriver.findElement(By.cssSelector("input[value='RefreshDetails']")).click();
			desktopDriver.findElement(By.cssSelector("input#searchUserId")).sendKeys(userName);
			Thread.sleep(2000);
			desktopDriver.findElement(By.cssSelector("input[value='Submit']")).click();
			desktopDriver.findElement(By.cssSelector("span#img"+userName)).click();
			Thread.sleep(3000);
			WebElement we =desktopDriver.findElement(By.cssSelector("input[value='"+bankAccountProofAction+"']"));
			  
			js.executeScript("arguments[0].click();", we);
		
			if(bankAccountProofAction.toString().equalsIgnoreCase("Accept")){
				Thread.sleep(3000);
				desktopDriver.findElement(By.cssSelector("input[id='bankaccount']")).click();
				new Select(desktopDriver.findElement(By.cssSelector("select[id='bnkStVal']"))).selectByValue("Bank Statement");
				
				desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys(bankAccNo);
				desktopDriver.findElement(By.cssSelector("textarea[id='comments']")).sendKeys("QA test");
				
				WebElement accept=desktopDriver.findElement(By.cssSelector("input[value='Accept'][type='submit']"));
				js.executeScript("arguments[0].click();", accept);
				
				Thread.sleep(4000);
				desktopDriver.close();
			}else{
				
				desktopDriver.switchTo().alert().accept();
				Thread.sleep(4000);
				desktopDriver.close();
			}
			
		}
}
