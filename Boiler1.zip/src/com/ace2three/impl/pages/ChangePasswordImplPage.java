package com.ace2three.impl.pages;

import java.io.IOException;
import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.locators.AndroidLocators.ChangePasswordPageLocators;
import com.ace2three.locators.WebLocators.EnforceStrongPassword;
import com.ace2three.utils.CustomMethods;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ChangePasswordImplPage implements ChangePasswordPageLocators, EnforceStrongPassword{
	
	WebDriver driver;
	BaseTestSuite baseTestSuite= new BaseTestSuite();
	public ChangePasswordImplPage(WebDriver driver) {
		
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		this.driver=driver;
	}
	
	@FindBy(xpath=HAMBURGER_MENU_CHANGE_PASSWORD)
	private WebElement changePasswordFromHamburgerMenu;
	
	public WebElement getChangePasswordFromHamburgerMenu(){
		return changePasswordFromHamburgerMenu;
	}
	
	@FindBy(xpath=CURRENT_PASSWORD_FIELD)
	private WebElement currentPasswordfield;
	
	public WebElement getCurrentPasswordfield(){
		return currentPasswordfield;
	}
	@FindBy(xpath=NEW_PASSWORD_FIELD)
	private WebElement newPasswordfield;
	
	public WebElement getNewPasswordfield(){
		return newPasswordfield;
	}
	
	@FindBy(xpath=CONFIRM_PASSWORD_FIELD)
	private WebElement confirmPasswordfield;
	
	public WebElement getConfirmPasswordfield(){
		return confirmPasswordfield;
	}
	
	@FindBy(xpath=CONFIRM_PASSWORD_SHOW_BUTTON)
	private WebElement confirmPasswordShowButton;
	
	public WebElement getConfirmPasswordShowButton(){
		return confirmPasswordShowButton;
	}
	
	@FindBy(xpath=CURRENT_PASSWORD_SHOW_BUTTON)
	private WebElement currentPasswordShowButton;
	
	public WebElement getCurrentPasswordShowButton(){
		return currentPasswordShowButton;
	}
	
	@FindBy(xpath=NEW_PASSWORD_SHOW_BUTTON)
	private WebElement newPasswordShowButton;
	
	public WebElement getNewPasswordShowButton(){
		return newPasswordShowButton;
	}
	
	
	@FindBy(xpath=CHANGE_PASSWORD_SUBMIT_BUTTON)
	private WebElement submitButton;
	
	public WebElement getSubmitButton(){
		return submitButton;
	}
	
	@FindBy(xpath=PASSWORD_GUIDELINES_HEADER)
	private WebElement guideLinesHeader;
	
	public WebElement getGuideLinesHeader(){
		return guideLinesHeader;
	}
	
	@FindBy(xpath=CHANGE_PASSWORD_GUIDELINES_TEXT)
	private WebElement guideLinesText;
	
	public WebElement getGuideLinesText(){
		return guideLinesText;
	}
	
	@FindBy(xpath=PASSWORD_GUIDELINES_OK_BUTTON)
	private WebElement guideLinesOkButton;
	
	public WebElement getGuideLinesOkButton(){
		return guideLinesOkButton;
	}
	
	@FindBy(xpath=PASSWORD_CHANGED_SUCCESSFULLY_TEXT)
	private WebElement changePasswordStatusText;
	
	public WebElement getChangePasswordStatusText(){
		return changePasswordStatusText;
	}
	
	@FindBy(xpath=PASSWORD_CHANGED_SUCCESSFULLY_OK_BUTTON)
	private WebElement changePasswordStatusOkButton;
	
	public WebElement getChangePasswordStatusOkButton(){
		return changePasswordStatusOkButton;
	}
	
	@FindBy(xpath=CHANGE_PASSWORD_ERROR_STATUS_FIELD)
	private WebElement changePasswordErrorMessage;
	
	public WebElement getChangePasswordErrorMessage(){
		return changePasswordErrorMessage;
	}
	@FindBy(xpath=ENFORCE_STRONG_PASSWORD)
	private WebElement enforceStrongPswdButton;
	
	public WebElement getEnforceStrongPswdButton(){
		return enforceStrongPswdButton;
	}
	
	
	@FindBy(xpath=COMMENT)
	private WebElement commentTextArea;
	
	public WebElement getCommentTextArea(){
		return commentTextArea;
	}
	
	@FindBy(xpath=SUBMIT)
	private WebElement enforceStrongPswdsubmitButton;
	
	public WebElement getEnforceStrongPswdsubmitButton(){
		return enforceStrongPswdsubmitButton;
	}
	
	@FindBy(xpath=CHANGE_YOUR_PASSWORD_POP_UP)
	private WebElement changeYourPswdPopUpHeader;
	
	public WebElement getChangeYourPswdPopUpHeader(){
		return changeYourPswdPopUpHeader;
	}
	
	@FindBy(xpath=CHANGE_NOW_BUTTON)
	private WebElement changeNowButton;
	
	public WebElement getChangeNowButton(){
		return changeNowButton;
	}
	@FindBy(xpath=NOT_NOW_BUTTON)
	private WebElement notNowButton;
	
	public WebElement getNotNowButton(){
		return notNowButton;
	}
	
	@FindBy(xpath=CHANGE_YOUR_PASSWORD_POP_TEXT)
	private WebElement pswdExpireText;
	
	public WebElement getPswdExpireText(){
		return pswdExpireText;
	}
	
	@FindBy(xpath=CHANGE_YOUR_PASSWORD_POP_UP_CLOSE_BUTTON)
	private WebElement changeYourPswdPopUpCloseButton;
	
	public WebElement getChangeYourPswdPopUpCloseButton(){
		return changeYourPswdPopUpCloseButton;
	}
	@FindBy(xpath=CHANGE_PASSWORD_WINDOW_HEADER)
	private WebElement changePasswordHeader;
	
	public WebElement getChangePasswordHeader(){
		return changePasswordHeader;
	}
	@FindBy(xpath=YOUR_PSWD_HAS_BEEN_CHANGED_MSG_AT_LOGIN_SCREEN)
	private WebElement yourPswdHasBeenChangedMsgAtLoginScreen;
	
	public WebElement getYourPswdHasBeenChangedMsgAtLoginScreen(){
		return yourPswdHasBeenChangedMsgAtLoginScreen;
	}
	
	
	 public void verifyErrorMessage(String elementName, String errorMessage) throws IOException{
			BaseTestSuite baseTestSuite= new BaseTestSuite();
			baseTestSuite.verifyPresent(getChangePasswordErrorMessage(), elementName);
			CustomMethods.waitForElementPresent(getChangePasswordErrorMessage(),2);
			baseTestSuite.verifyTextPresent(getChangePasswordErrorMessage(), errorMessage);
			}
	 public void errorMessageHierarchyCheck(String currentPassword, String newPassword, String confirmCurrentPassword, String Expectedvalue, String loggerMessage){
			
			getCurrentPasswordfield().clear();
			getCurrentPasswordfield().sendKeys(currentPassword);
			getNewPasswordfield().clear();
			getNewPasswordfield().sendKeys(newPassword);
			getConfirmPasswordfield().clear();
			getConfirmPasswordfield().sendKeys(confirmCurrentPassword);
			getSubmitButton().click();
			
			try{
				if (getChangePasswordErrorMessage().getText().trim().equalsIgnoreCase(Expectedvalue.trim())) {
					if(System.getProperty("takeScreenshot").contains("no")){
						baseTestSuite.logger.log(LogStatus.PASS,
								"Expected value is " + Expectedvalue + " and actual value is " + getChangePasswordErrorMessage().getText());
						}else{
							baseTestSuite.logger.log(LogStatus.PASS,
									"Expected value is " + Expectedvalue + " and actual value is " + getChangePasswordErrorMessage().getText() + 
									baseTestSuite.logger.addScreenCapture(baseTestSuite.takeScreenShot(Expectedvalue)));
						}
						baseTestSuite.logger.log(LogStatus.PASS, loggerMessage + " has passed");
					
				} else {
					baseTestSuite.logger.log(LogStatus.FAIL, loggerMessage + " has not passed");
					baseTestSuite.logger.log(LogStatus.FAIL, "Expected value is " + Expectedvalue + " and actual value is "
								+ getChangePasswordErrorMessage().getText() + baseTestSuite.logger.addScreenCapture(baseTestSuite.takeScreenShot(Expectedvalue)));
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					baseTestSuite.logger.log(LogStatus.FAIL, e.toString());
				}
		}
		
		private static int getRandomNumber(int index) {
	        int randomInt = 0;
	        Random randomGenerator = new Random();
	        randomInt = randomGenerator.nextInt(index-1);
	        return randomInt;
	    }
		
		public String generatePassword(){
			char ch;
			//String CHAR_S="!@#$%^&*()_=+";
			String CHAR_S="!$()+-.;=?@[]^_{|}~)";
			
			 ch = CHAR_S.charAt(getRandomNumber(CHAR_S.length()));
			String password= RandomStringUtils.randomAlphanumeric(9)+ch;
			System.out.println(password);
			return password;
		}
		

}
