package com.ace2three.impl.pages;



import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.component.pages.TourneyDialogBox;
import com.ace2three.component.pages.TourneyDialogBox.TourneyDetailType;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.web.impl.pages.AdminImplPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import sun.launcher.resources.launcher;


public class TourneyImplPage extends BaseTestSuite{
	
	static WebDriver desktopDriver;
	WebDriver driver;
	
	
			public TourneyImplPage(WebDriver driver) {
				PageFactory.initElements(driver, this);
				this.driver=driver;
			}
	
			@FindBy(xpath= "//android.widget.LinearLayout[contains(@resource-id,'tourney_details_list_item')]")
			private WebElement anyTourney;
			
			public WebElement getAnyTourney(){
				return anyTourney;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'dialog_title_tv')]")
			private WebElement tLobbyHeaderTitle;
			
			public WebElement getTLobbyHeaderTitle(){
				return tLobbyHeaderTitle;
			}
			
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'dialog_close')]")
			private WebElement tLobbyCloseButton;
			
			public WebElement getTLobbyCloseButton(){
				return tLobbyCloseButton;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'leftarrowIV')]")
			private WebElement tourneyLeftArrow;
			
			public WebElement getTourneyLeftArrow(){
				return tourneyLeftArrow;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'details_tourney_id')]")
			private WebElement tourneyIdField;
			
			public WebElement getTourneyIdField(){
				return tourneyIdField;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'main_details_entry_value')]")
			private WebElement tourneyEntryField;
			
			public WebElement getTourneyEntryField(){
				return tourneyEntryField;
			}
			
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'filter_icon')]")
			private WebElement filterButton;
			
			public WebElement getFilterButton(){
				return filterButton;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_closebg')]")
			private WebElement filterPopUpCloseButton;
			
			public WebElement getFilterPopUpCloseButton(){
				return filterPopUpCloseButton;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tourney_filtersLobbyRow1Tv')]")
			private WebElement cashTextInFilter;
			
			public WebElement getCashTextInFilter(){
				return cashTextInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow1ImageCheckBox')]")
			private WebElement announcedCheckBoxInFilter;
			
			public WebElement getAnnouncedCheckBoxInFilter(){
				return announcedCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow2ImageCheckBox')]")
			private WebElement registeringCheckBoxInFilter;
			
			public WebElement getRegisteringCheckBoxInFilter(){
				return registeringCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow3ImageCheckBox')]")
			private WebElement runningCheckBoxInFilter;
			
			public WebElement getRunningCheckBoxInFilter(){
				return runningCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow4ImageCheckBox')]")
			private WebElement completedCheckBoxInFilter;
			
			public WebElement getCompletedCheckBoxInFilter(){
				return completedCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow5ImageCheckBox')]")
			private WebElement fullCheckBoxInFilter;
			
			public WebElement getFullCheckBoxInFilter(){
				return fullCheckBoxInFilter;
			}
			
			
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow1ImageCheckBox')]")
			private WebElement cashCheckBoxInFilter;
			
			public WebElement getCashCheckBoxInFilter(){
				return cashCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow2ImageCheckBox')]")
			private WebElement freerollCheckBoxInFilter;
			
			public WebElement getFreerollCheckBoxInFilter(){
				return freerollCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow3ImageCheckBox')]")
			private WebElement knockoutCheckBoxInFilter;
			
			public WebElement getKnockoutCheckBoxInFilter(){
				return knockoutCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow4ImageCheckBox')]")
			private WebElement specialCheckBoxInFilter;
			
			public WebElement getSpecialCheckBoxInFilter(){
				return specialCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRow5ImageCheckBox')]")
			private WebElement acepointsCheckBoxInFilter;
			
			public WebElement getAcepointsCheckBoxInFilter(){
				return acepointsCheckBoxInFilter;
			}
			@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'tourney_filtersLobbyRowRegisteredImageCheckBox')]")
			private WebElement registeredCheckBox;
			
			public WebElement getRegisteredCheckBox(){
				return registeredCheckBox;
			}
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'tourney_applybtn')]")
			private WebElement applyButton;
			
			public WebElement getApplyButton(){
				return applyButton;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'item3_statusnum_tv')]")
			private WebElement registrationCount;
			
			public WebElement getRegistrationCount(){
				return registrationCount;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'details_status_button')]")
			private WebElement registerButton;
			
			public WebElement getRegisterButton(){
				return registerButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@text,'Cancel Registration')]")
			private WebElement cancelRegistrationButton;
			
			public WebElement getCancelRegistrationButton(){
				return cancelRegistrationButton;
			}
			
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
			private WebElement registerConfirmationPopUp;
			
			public WebElement getRegisterConfirmationPopUp(){
				return registerConfirmationPopUp;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
			private WebElement unRegisterConfirmationPopUp;
			
			public WebElement getUnRegisterConfirmationPopUp(){
				return unRegisterConfirmationPopUp;
			}
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement registerConfirmationYesButton;
			
			public WebElement getRegisterConfirmationYesButton(){
				return registerConfirmationYesButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement unRegisterConfirmationYesButton;
			
			public WebElement getUnRegisterConfirmationYesButton(){
				return unRegisterConfirmationYesButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
			private WebElement registerConfirmationNoButton;
			
			public WebElement getRegisterConfirmationNoButton(){
				return registerConfirmationNoButton;
			}
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
			private WebElement unRegisterConfirmationNoButton;
			
			public WebElement getUnRegisterConfirmationNoButton(){
				return unRegisterConfirmationNoButton;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
			private WebElement registerSuccessPopUp;
			
			public WebElement getRegisterSuccessPopUp(){
				return registerSuccessPopUp;
			}
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
			private WebElement unRegisterSuccessPopUp;
			
			public WebElement getUnRegisterSuccessPopUp(){
				return unRegisterSuccessPopUp;
			}
			
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
			private WebElement verifyEmailAndProfilePopUp;
			
			public WebElement getVerifyEmailAndProfilePopUp(){
				return verifyEmailAndProfilePopUp;
			}
			

			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement registerSuccessOkButton;
			
			public WebElement getRegisterSuccessOkButton(){
				return registerSuccessOkButton;
			}
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement verifyEmailAndProfilePopUpOkButton;
			
			public WebElement getverifyEmailAndProfilePopUpOkButton(){
				return verifyEmailAndProfilePopUpOkButton;
			}
			
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement unRegisterSuccessOkButton;
			
			public WebElement getUnRegisterSuccessOkButton(){
				return unRegisterSuccessOkButton;
			}
			@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
			private WebElement verifyEmailAndProfilePopUpCancelButton;
			
			public WebElement getVerifyEmailAndProfilePopUpCancelButton(){
				return verifyEmailAndProfilePopUpCancelButton;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'details_startstack_value')]")
			private WebElement startingStackValue;
			
			public WebElement getStartingStackValue(){
				return startingStackValue;
			}
			
			@FindBy(xpath= "//android.widget.ListView[contains(@resource-id,'tourneydetails_lv')]")
			 private WebElement tourneyList;

			 public WebElement getTourneyList(){
			 return tourneyList;
			 }
			
			
			@FindBys(@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'details_item2_entry_tv')]"))
			private List<WebElement> lobbyEntryField;
			
			public List<WebElement> getLobbyEntryFields(){
				return lobbyEntryField;
			}
			
			@FindBys(@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'_statustext_tv')]"))
			private List<WebElement> registeringStatusFields;
			
			public List<WebElement> getRegisteringStatusFields(){
				return registeringStatusFields;
			}
			
			@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'_statustext_tv')]")
			private WebElement registeredStatusField;
			
			public WebElement getRegisteredStatusField(){
				return registeredStatusField;
			}
			
			
			public enum tourneyType {
				CASH, FREEROLL, BEGINNERTOURNEY, MYTOURNEY, ACEPOINTS, SPECIAL, KNOCKOUT;
				}
		
			public String createTourney(tourneyType tourneyInsertionType, String tourneyName) throws InterruptedException, IOException
			
			{
				
				System.setProperty("webdriver.chrome.driver" , System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
				desktopDriver = new ChromeDriver();
				WebDriverWait wait = new WebDriverWait(desktopDriver, 10);
				AdminImplPage webAdminPage = new AdminImplPage(desktopDriver);
				desktopDriver.get("http://qaweb.headinfotech.local:8080/AceAdmin/");
				webAdminPage.getAdminUserName().sendKeys(ReadDataFromProps.props.getProperty("user.name"));
				webAdminPage.getPasswordButton().sendKeys(ReadDataFromProps.props.getProperty("password.input"));

				webAdminPage.getloginSubmitButton().click();
				List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
				for(WebElement listedOne:list){
					System.out.println(listedOne.getText());
						if(listedOne.getText().equals(ReadDataFromProps.props.getProperty("admin.tab.tourney"))){
							Actions action = new Actions(desktopDriver);
							action.moveToElement(listedOne).build().perform();
						}
				}
				webAdminPage.getInsertJumbo().click();
				wait.until(ExpectedConditions.visibilityOf(webAdminPage.getViewTemplate()));
				webAdminPage.getViewTemplate().click();
				Thread.sleep(2000);
				JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
				desktopDriver.manage().window().maximize();
				if(tourneyInsertionType.toString().equals("CASH"))
				{
				/*tourneyDetails.put("format", "Points Rummy");
				tourneyDetails.put("entry", "10");*/
				String templateSelector= "a[href='mtctTourneyInsertNew.jsp?tempName=" + ReadDataFromProps.props.getProperty("cash.tourney.template")+"']";
				WebElement templateName = desktopDriver.findElement(By.cssSelector(templateSelector));
				executor.executeScript("arguments[0].click();", templateName);
				}
				else if(tourneyInsertionType.toString().equals("FREEROLL"))
				{
					//tourneyDetails.put("format", "Points Rummy");
					String templateSelector= "a[href='mtctTourneyInsertNew.jsp?tempName=" + ReadDataFromProps.props.getProperty("freeroll.tourney.template")+"']";
					WebElement templateName = desktopDriver.findElement(By.cssSelector(templateSelector));
					executor.executeScript("arguments[0].click();", templateName);
				}
				else if(tourneyInsertionType.toString().equals("SPECIAL"))
				{
					//tourneyDetails.put("format", "Points Rummy");
					String templateSelector= "a[href='mtctTourneyInsertNew.jsp?tempName=" + ReadDataFromProps.props.getProperty("special.tourney.template")+"']";
					WebElement templateName = desktopDriver.findElement(By.cssSelector(templateSelector));
					executor.executeScript("arguments[0].click();", templateName);
				}
				else if(tourneyInsertionType.toString().equals("KNOCKOUT"))
				{
					//tourneyDetails.put("format", "Points Rummy");
					WebElement nextButton = desktopDriver.findElement(By.linkText("Next"));
					executor.executeScript("arguments[0].click();", nextButton);
					String templateSelector= "a[href='mtctTourneyInsertNew.jsp?tempName=" + ReadDataFromProps.props.getProperty("knockout.tourney.template")+"']";
					WebElement templateName = desktopDriver.findElement(By.cssSelector(templateSelector));
					executor.executeScript("arguments[0].click();", templateName);
				}
				else if(tourneyInsertionType.toString().equals("ACEPOINTS"))
				{
					//tourneyDetails.put("format", "Points Rummy");
					WebElement nextButton = desktopDriver.findElement(By.linkText("Next"));
					executor.executeScript("arguments[0].click();", nextButton);
					String templateSelector= "a[href='mtctTourneyInsertNew.jsp?tempName=" + ReadDataFromProps.props.getProperty("acepoints.tourney.template")+"']";
					WebElement templateName = desktopDriver.findElement(By.cssSelector(templateSelector));
					executor.executeScript("arguments[0].click();", templateName);
				}
				else if(tourneyInsertionType.toString().equals("BEGINNERTOURNEY"))
				{
					//tourneyDetails.put("format", "Points Rummy");
					String templateSelector= "a[href='mtctTourneyInsertNew.jsp?tempName=" + ReadDataFromProps.props.getProperty("begineer.tourney.template")+"']";
					WebElement templateName = desktopDriver.findElement(By.cssSelector(templateSelector));
					executor.executeScript("arguments[0].click();", templateName);
				}
				//templateName.click();
				new Select(webAdminPage.getLevelStatus()).selectByValue(ReadDataFromProps.props.getProperty("level.status"));
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
				   LocalDateTime now = LocalDateTime.now();  
				   String date = now.getDayOfMonth()+"/"+now.getMonth()+"/"+now.getYear();
				   
				webAdminPage.getTourneyStartDate().sendKeys(date);
				//tourneyDetails.put("startDate", ReadDataFromProps.props.getProperty("tourney.start.date"));
				//webAdminPage.getRegistrationStartDate().sendKeys(ReadDataFromProps.props.getProperty("tourney.registration.start.date"));
				
				//webAdminPage.getBuyInGiftVoucherOnly().click();
				if(now.getHour()==23)
				{	
					new Select(desktopDriver.findElement(By.cssSelector("select[id='tstarthr']"))).selectByValue(0+"");
					
				}
				else
				new Select(desktopDriver.findElement(By.cssSelector("select[id='tstarthr']"))).selectByValue((now.getHour()+1)+"");
				//new Select(webAdminPage.getTourneyRegistrationStartMins()).selectByValue("20");
				
				
				String IntitialTourneyChips= ReadDataFromProps.props.getProperty("tourney.initial.chips");
				String tourneyMaxPlayerCount= ReadDataFromProps.props.getProperty("tourney.maximum.count");
				Thread.sleep(5000);
				webAdminPage.getTourneyInitialNoOfChips().clear();
				webAdminPage.getTourneyInitialNoOfChips().sendKeys(IntitialTourneyChips);
				webAdminPage.getTourneyCount().clear();
				webAdminPage.getTourneyCount().sendKeys(tourneyMaxPlayerCount);
				Thread.sleep(10000);
				webAdminPage.getLobbyDiscription().clear();
				
				if(tourneyInsertionType.toString().equals("CASH")){
					webAdminPage.getTourneyDiscription().clear();
					webAdminPage.getTourneyDiscription().sendKeys(tourneyName);
					webAdminPage.getLobbyDiscription().sendKeys(tourneyName);}
				else if(tourneyInsertionType.toString().equals("FREEROLL")){
					webAdminPage.getTourneyDiscription().clear();
					webAdminPage.getTourneyDiscription().sendKeys(tourneyName);
					webAdminPage.getLobbyDiscription().sendKeys(tourneyName);	}
				else if(tourneyInsertionType.toString().equals("SPECIAL")){
					webAdminPage.getTourneyDiscription().clear();
					webAdminPage.getTourneyDiscription().sendKeys(tourneyName);
					webAdminPage.getLobbyDiscription().sendKeys(tourneyName);}
				else if(tourneyInsertionType.toString().equals("KNOCKOUT")){
					webAdminPage.getTourneyDiscription().clear();
					webAdminPage.getTourneyDiscription().sendKeys(tourneyName);
					webAdminPage.getLobbyDiscription().sendKeys(tourneyName);}
				else if(tourneyInsertionType.toString().equals("ACEPOINTS")){
					webAdminPage.getTourneyDiscription().clear();
					webAdminPage.getTourneyDiscription().sendKeys(tourneyName);
					webAdminPage.getLobbyDiscription().sendKeys(tourneyName);}
				else if(tourneyInsertionType.toString().equals("BEGINNERTOURNEY")){
					webAdminPage.getTourneyDiscription().clear();
					webAdminPage.getTourneyDiscription().sendKeys(tourneyName);
					webAdminPage.getLobbyDiscription().sendKeys(tourneyName);}
				
				JavascriptExecutor execu = (JavascriptExecutor)desktopDriver;
				WebElement submmitButton= webAdminPage.getTourneyCreateSubmitButton();
				execu.executeScript("arguments[0].click();", submmitButton );
				
				System.out.println(tourneyMaxPlayerCount + "     :        "+IntitialTourneyChips);
				desktopDriver.switchTo().alert().accept();
				Thread.sleep(2000);
				verifyTextPresent(webAdminPage.getTourneySucessMessage(), "Tourney Inserted Successfully");
				
				String id = webAdminPage.getTourneySucessMessage().getText();
				String arr[] = id.split(" ");
				desktopDriver.close();
				return arr[arr.length-1];
				
			}
			public enum filterType{
				LOW, MEDIUM, HIGH;
			}
			public void verifyFilter(List<String> values, filterType filter) throws IOException
			{
				Boolean flag = true;
				int MIN=0,MAX=0;
				String entryType="";
				WebElement ele = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Entry/Prize')]"));
				
				if(filter.toString().equals("LOW"))
				{
					MIN=0;MAX=50;
					entryType="Low";
				}
				else if(filter.toString().equals("MEDIUM"))
				{
					MIN=50;MAX=200;
					entryType="Medium";
				}
				else if(filter.toString().equals("HIGH"))
				{
					MIN=200;MAX=10000;
					entryType="High";
				}
				for(int i=0;i<values.size();i++)
				{
					int value=0;
					try
					{
					value = Integer.parseInt(values.get(i));
					}
					catch(Exception e)
					{
						((AndroidDriver)driver).swipe(getFilterButton().getLocation().getX(),getFilterButton().getLocation().getY()-50,ele.getLocation().getX(),ele.getLocation().getY(),3000);

						logger.log(LogStatus.FAIL, "Entry for this tourney is invalid"+logger.addScreenCapture(takeScreenShot("Entry")));
						//((AndroidDriver)driver).swipe(545,1600 , 545, 630, 3000);
						//System.out.println(ele.getText());
						((AndroidDriver)driver).swipe(ele.getLocation().getX(),ele.getLocation().getY(),getFilterButton().getLocation().getX(),getFilterButton().getLocation().getY()-50,3000);

						logger.log(LogStatus.INFO,logger.addScreenCapture(takeScreenShot("")) );
					}
					
					if(value>=MIN && value <=MAX)
					{
						
					}
					else
					{
						logger.log(LogStatus.FAIL, "Entry chips for low bet tourneys is not matched"+logger.addScreenCapture(takeScreenShot("Entry")));
						flag=false;
					}
				}
				if(flag==false){
					logger.log(LogStatus.FAIL, entryType+" filter is failed"+logger.addScreenCapture(takeScreenShot("Entry")));}
				else{
					logger.log(LogStatus.PASS, entryType+" filter is working as expected");}
			}
			
			public List<String> parseElements( List<WebElement> we)
			{
				
				 List<String> values= new ArrayList<>();
					for(WebElement e:we)
					{
						System.out.println(e.getText());
						values.add(e.getText());
					}
					return values;
			}
			
			public void verifyRegisteringStatusField(List<String> Elements) throws IOException
			{
				for(String s:Elements)
				{
					System.out.println(s);
					if(s.trim().equals("Registered") || s.trim().equals("Join") || s.trim().equals("Completed") || s.trim().equals("Cancelled"))
					{
						logger.log(LogStatus.PASS, "Register Filter is working as expected");
					}
					else
						logger.log(LogStatus.FAIL, "Register filter is not working properly"+logger.addScreenCapture(takeScreenShot("Filter")));
				}
				
				
				
			}
			public void verifyFreerollEntryFieldsInLobby(List<String> Elements) throws IOException
			{
				for(String s:Elements)
				{
					System.out.println(s);
					if(s.trim().equals("Free"))
					{
						logger.log(LogStatus.PASS, "Entry for all freeroll tourney is \"Free\".");
					}
					else
						logger.log(LogStatus.FAIL, "Entry for all freeroll tourney is not \"Free\"."+logger.addScreenCapture(takeScreenShot("Entry")));
				}
				
				
				
			}
			
			public void findTourney(String tourneyName)
			{
				int count=0;
				String a = tourneyName; /// last element in the list
				Boolean found_result = false;
				String old,New;
				WebElement fil = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Entry/Prize')]"));
				
				while (!found_result){
					driver.getPageSource();
				    List<WebElement> ele = driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'item1_descrip_tv')]"));
				    int size=0;
				     size = size+ele.size();
				     old = ele.get(size-1).getText();
				    
				    for (int i = 0; i < size; i++) {

				        String s = ele.get(i).getText();
				        if (s.equals(a)) {

				        	found_result =true;

				             System.out.println(size);
				            break;
				        }

				    }
				    if(!found_result){
				    //find startx,starty, and Endy
				  //  ((AndroidDriver)driver).swipe(545,1600 , 545, 630, 3000);
				    ((AndroidDriver)driver).swipe(getFilterButton().getLocation().getX(),getFilterButton().getLocation().getY()-50,fil.getLocation().getX(),fil.getLocation().getY(),3000);

				    driver.getPageSource();
				    List<WebElement> elem = driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'item1_descrip_tv')]"));
				    New = elem.get(elem.size()-1).getText();
				    System.out.println(old);
				    System.out.println(New);
				    System.out.println(" ");
				    if(old.equals(New))
				    {
				    	count++;
				    }
				    else
				    	count=0;  	
				 }
				    if(count ==3)
				    break;

				}
				WebElement ele = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'"+tourneyName+"')]"));
				verifyPresent(ele, tourneyName+" Displayed");
				ele.click();
				
			}
			
			public void verifyLevels(Hashtable<String,Hashtable<String, String>> tourneyLevelDetails)
			{
				
				 
				 
				 List<WebElement> me = driver.findElements(By.xpath("//android.widget.ListView[contains(@resource-id,'levels_listview')]/android.widget.LinearLayout"));
				 System.out.println(me.size());
				
				 int i=1;
		Hashtable<String, String> levelDetailsHashMap = new Hashtable<String, String>();
		Hashtable<String, Hashtable<String, String>> levelHashMap = new Hashtable<>();
		
	
		for (WebElement mew : me) {
			System.out.println();
			List<WebElement> me1 = mew.findElements(By.xpath("//android.widget.RelativeLayout"));
			int j = 1;
			for (WebElement mew1 : me1) {
				String value = mew1.findElement(By.xpath("//android.widget.TextView")).getText();
				switch (j) {
				case 1:
					//levelDetailsHashMap.put("level", value);
					if(tourneyLevelDetails.get("level"+i).get("level").equalsIgnoreCase(value)){
						logger.log(LogStatus.PASS, "Expected Level is:"+tourneyLevelDetails.get("level"+i).get("level")+".Actual Level is:"+value);
					}
					else
						logger.log(LogStatus.FAIL, "Expected Level is:"+tourneyLevelDetails.get("level"+i).get("level")+".Actual Level is:"+value);
						
					break;
				case 2:
					//levelDetailsHashMap.put("time", value);
					if(tourneyLevelDetails.get("level"+i).get("time").equalsIgnoreCase(value)){
						logger.log(LogStatus.PASS, "Expected Time is:"+tourneyLevelDetails.get("level"+i).get("time")+".Actual Time is:"+value);
					}
					else
						logger.log(LogStatus.FAIL, "Expected Time is:"+tourneyLevelDetails.get("level"+i).get("time")+".Actual Time is:"+value);
					
					break;
				case 3:
					//levelDetailsHashMap.put("bet", value);
					if(tourneyLevelDetails.get("level"+i).get("bet").equalsIgnoreCase(value)){
						logger.log(LogStatus.PASS, "Expected Bet is:"+tourneyLevelDetails.get("level"+i).get("bet")+".Actual Bet is:"+value);
					}
					else
						logger.log(LogStatus.FAIL, "Expected Bet is:"+tourneyLevelDetails.get("level"+i).get("bet")+".Actual Bet is:"+value);
					
					break;
				case 4:
					//levelDetailsHashMap.put("qualify", value);
					if(tourneyLevelDetails.get("level"+i).get("qualify").equalsIgnoreCase(value)){
						
						logger.log(LogStatus.PASS, "Expected Qualify is:"+tourneyLevelDetails.get("level"+i).get("qualify")+".Actual Qualify is:"+value);
					}
					else
						logger.log(LogStatus.FAIL, "Expected Qualify is:"+tourneyLevelDetails.get("level"+i).get("qualify")+".Actual Qualify is:"+value);
					
					break;
				case 5:
					levelDetailsHashMap.put("rebuy", value);
					if(tourneyLevelDetails.get("level"+i).get("rebuy").equalsIgnoreCase(value)){
						logger.log(LogStatus.PASS, "Expected Rebuy is:"+tourneyLevelDetails.get("level"+i).get("rebuy")+".Actual Rebuy is:"+value);
					}
					else
						logger.log(LogStatus.FAIL, "Expected Rebuy is:"+tourneyLevelDetails.get("level"+i).get("rebuy")+".Actual Rebuy is:"+value);
					
					break;
				case 6:
					levelDetailsHashMap.put("reload", value);
					if(tourneyLevelDetails.get("level"+i).get("reload").equalsIgnoreCase(value)){
						logger.log(LogStatus.PASS, "Expected Reload is:"+tourneyLevelDetails.get("level"+i).get("reload")+".Actual Reload is:"+value);
					}
					else
						logger.log(LogStatus.FAIL, "Expected Reload is:"+tourneyLevelDetails.get("level"+i).get("reload")+".Actual Reload is:"+value);
					
					break;
				}
				System.out.println(value);
				j++;
			}
			/*System.out.println();
			System.out.println(levelDetailsHashMap);
			levelHashMap.put("level" + i, levelDetailsHashMap);
			levelDetailsHashMap.clear();
			System.out.println("here main hash: " + levelHashMap.toString());*/
			i++;
		}
		//System.out.println("here: " + levelHashMap.toString());
		
	}
			public void goToTourney(String tourney) throws IOException, InterruptedException
			{
				
				
				TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
				//tourneyImplPage.getFilterButton().click();
				
				while(true)
				{
					if(CustomMethods.isElementPresent(getFilterButton()))
					{
						tourneyImplPage.getFilterButton().click();
					}
					else
					{
						getTourneyLeftArrow().click();
						CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),10);
						
					}
					//if(CustomMethods.isElementPresent(getCashTextInFilter()))
					if(getCashTextInFilter().getText().equals("Cash"))
					{
						getFilterPopUpCloseButton().click();
						getTourneyLeftArrow().click();
						CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),10);
						
					}
					else 
					{
						getFilterPopUpCloseButton().click();
						tourneyImplPage.getAnyTourney().click();
						CustomMethods.waitForElementPresent(tourneyImplPage.getTLobbyHeaderTitle(), 15);
						if (tourneyImplPage.getTLobbyHeaderTitle().getText().equals(tourney))
						{
							getTLobbyCloseButton().click();
							break;
						} else 
						{
							getTLobbyCloseButton().click();
							getTourneyLeftArrow().click();
							CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(), 10);
						}
					}
				}
				
				/*tourneyImplPage.getAnyTourney().click();
				CustomMethods.waitForElementPresent(tourneyImplPage.getTLobbyHeaderTitle(),15);
				if(!tourneyImplPage.getTLobbyHeaderTitle().getText().equals(tourney))
				{
					while(!tourneyImplPage.getTLobbyHeaderTitle().getText().equals(tourney))
					{
					//Thread.sleep(2000);
					tourneyImplPage.getTLobbyCloseButton().click();
					Thread.sleep(1000);
					driver.getPageSource();
					tourneyImplPage.getTourneyLeftArrow().click();
					//CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),5);
						if(CustomMethods.isElementPresent(tourneyImplPage.getAnyTourney()))
							tourneyImplPage.getAnyTourney().click();
						else{
							tourneyImplPage.getTourneyLeftArrow().click();
							CustomMethods.waitForElementPresent(tourneyImplPage.getAnyTourney(),10);
							tourneyImplPage.getAnyTourney().click();
							
						}
					}
				}
				verifyPresent(tourneyImplPage.getTLobbyHeaderTitle(), tourney);
				tourneyImplPage.getTLobbyCloseButton().click();*/
				
			}
			 public static class getTourney{

				 static WebElement tourneyElement;
				 getTourney(WebElement tourneyElement){
				 this.tourneyElement= tourneyElement;
				 }
				 public WebElement getTourneyName(){
				 return tourneyElement.findElement(By.xpath("//*[contains(@resource-id,'tourney_details_item1_descrip_tv')]"));
				 }

				 public WebElement getTourneyDate(){
				 return tourneyElement.findElement(By.xpath("//*[contains(@resource-id,'tourney_details_item1_date_tv')]"));
				 }

				 public WebElement getTourneyEntryPrice(){
				 return tourneyElement.findElement(By.xpath("//*[contains(@resource-id,'tourney_details_item2_entry_tv')]"));
				 }

				 public WebElement getTourneyPrize(){
				 return tourneyElement.findElement(By.xpath("//*[contains(@resource-id,'tourney_details_item2_prize_tv')]"));
				 }

				 public WebElement getTourneyPlayerCount(){
				 return tourneyElement.findElement(By.xpath("//*[contains(@resource-id,'statusnum')]"));
				 }

				 public WebElement getTourneyStatus(){
				 return tourneyElement.findElement(By.xpath("//*[contains(@resource-id,'statustext')]"));
				 }

				 }
			 public List<WebElement> getTourneySections(){	
				 List<WebElement> tourneys= getTourneyList().
				 findElements(By.xpath("//android.widget.LinearLayout[contains(@resource-id,'tourney_details_list_item')]"));
				 return tourneys;
				 }
			 
			 
			
			public getTourney getTourneySection(String TourneyName){
			/*WebElement TourneyElement = null;
			for(WebElement we:getTourneySections()){
			WebElement TourneyElementDes= we.findElement(By.xpath("//*[contains(@resource-id,'tourney_details_item1_descrip_tv')]"));
			System.out.println("here1:" + TourneyElementDes.getText());
			if(TourneyElementDes.getText().equals(TourneyName)){
			System.out.println(TourneyElementDes.getText() + ":tourney name");
			TourneyElement=we;
			break;
			}
			}*/


			int count=0;
			String a = TourneyName; /// last element in the list
			Boolean found_result = false;
			String old,New;
			WebElement tourneyElement=null;
			while (!found_result){
			driver.getPageSource();
			  List<WebElement> ele = driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'item1_descrip_tv')]"));
			  int size=0;
			   size = size+ele.size();
			   old = ele.get(size-1).getText();
			  
			  for (int i = 0; i < size; i++) {

			      String s = ele.get(i).getText();
			      if (s.equals(a)) {
			      found_result =true;
			           System.out.println(size);
			           System.out.println(getTourneySections().size()+ "list");
			         int s1=1;
			           for(WebElement we:getTourneySections()){
			             System.out.println(we.getText()+"list details");
			           	 WebElement TourneyElementDes = null;
			           	 if(s1==1){
			           	 try{
			           	 TourneyElementDes= we.findElement(By.xpath("//*[contains(@resource-id,'tourney_details_item1_descrip_tv')]"));
			           	 }catch(Exception e){
			           	 System.out.println("in exception");
			           	 }
			           	 s1++;
			           	 }else{
			           	 TourneyElementDes= we.findElement(By.xpath("//*[contains(@resource-id,'tourney_details_item1_descrip_tv')]"));
			             System.out.println("here1:" + TourneyElementDes.getText());
			if(TourneyElementDes.getText().equals(TourneyName)){
			System.out.println(TourneyElementDes.getText() + ":tourney name");
			tourneyElement=we;
			break;
			}
			 }
			           }
			          break;
			      }

			  }
			  if(!found_result){
			  //find startx,starty, and Endy
			 // ((AppiumDriver)driver).swipe(545,1600 , 545, 630, 3000);
			  ((AndroidDriver) driver).swipe(347, 1090, 347, 390, 3000);
			  driver.getPageSource();
			  List<WebElement> elem = driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'item1_descrip_tv')]"));
			  New = elem.get(elem.size()-1).getText();
			  System.out.println(old);
			  System.out.println(New);
			  System.out.println(" ");
			  if(old.equals(New))
			  {
			  count++;
			  }
			  else
			  count=0;
			  
			}
			  if(count ==3)
			  break;

			}
			return new getTourney(tourneyElement);
			}
			  
			
		public Hashtable<String,Hashtable<String, String>> getCashTourneyDetails()
		{
		
			Hashtable<String, String> tourneyDetails1 = new Hashtable<>();
			Hashtable<String, String> tourneyDetails2 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails3 = new Hashtable<>(); 
			Hashtable<String,Hashtable<String, String>> tourneyLevelDetails= new Hashtable<>();
			tourneyDetails1.put("level", "level1");
			tourneyDetails1.put("bet", "5");
			tourneyDetails1.put("rebuy", "15");
			tourneyDetails1.put("reload", "800");
			tourneyDetails1.put("time", "3 Min");
			tourneyDetails1.put("qualify", "400");
			
			tourneyLevelDetails.put("level1", tourneyDetails1);
			//tourneyDetails.clear();
			
			tourneyDetails2.put("level", "level2");
			tourneyDetails2.put("bet", "10");
			tourneyDetails2.put("rebuy", "20");
			tourneyDetails2.put("reload", "1600");
			tourneyDetails2.put("time", "2 Min");
			tourneyDetails2.put("qualify", "800");
			
			tourneyLevelDetails.put("level2", tourneyDetails2);
			//tourneyDetails.clear();
			
			tourneyDetails3.put("level", "level3");
			tourneyDetails3.put("bet", "20");
			tourneyDetails3.put("rebuy", "NA");
			tourneyDetails3.put("reload", "NA");
			tourneyDetails3.put("time", "3 Min");
			tourneyDetails3.put("qualify", "1600");
			
			tourneyLevelDetails.put("level3", tourneyDetails3);
		
			return tourneyLevelDetails;
		}
		
		
		public Hashtable<String,Hashtable<String, String>> getFreerollTourneyDetails()
		{
		
			Hashtable<String, String> tourneyDetails1 = new Hashtable<>();
			Hashtable<String, String> tourneyDetails2 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails3 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails4 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails5 = new Hashtable<>(); 
			Hashtable<String,Hashtable<String, String>> tourneyLevelDetails= new Hashtable<>();
			tourneyDetails1.put("level", "level1");
			tourneyDetails1.put("bet", "5");
			tourneyDetails1.put("rebuy", "0");
			tourneyDetails1.put("reload", "NA");
			tourneyDetails1.put("time", "20 Min");
			tourneyDetails1.put("qualify", "400");
			
			tourneyLevelDetails.put("level1", tourneyDetails1);
			//tourneyDetails.clear();
			
			tourneyDetails2.put("level", "level2");
			tourneyDetails2.put("bet", "10");
			tourneyDetails2.put("rebuy", "0");
			tourneyDetails2.put("reload", "NA");
			tourneyDetails2.put("time", "20 Min");
			tourneyDetails2.put("qualify", "800");
			
			tourneyLevelDetails.put("level2", tourneyDetails2);
			//tourneyDetails.clear();
			
			tourneyDetails3.put("level", "level3");
			tourneyDetails3.put("bet", "15");
			tourneyDetails3.put("rebuy", "0");
			tourneyDetails3.put("reload", "NA");
			tourneyDetails3.put("time", "20 Min");
			tourneyDetails3.put("qualify", "1200");
			
			tourneyLevelDetails.put("level3", tourneyDetails3);
			
			tourneyDetails4.put("level", "level4");
			tourneyDetails4.put("bet", "20");
			tourneyDetails4.put("rebuy", "0");
			tourneyDetails4.put("reload", "NA");
			tourneyDetails4.put("time", "20 Min");
			tourneyDetails4.put("qualify", "1600");
			
			tourneyLevelDetails.put("level4", tourneyDetails4);
			
			tourneyDetails5.put("level", "level5");
			tourneyDetails5.put("bet", "25");
			tourneyDetails5.put("rebuy", "NA");
			tourneyDetails5.put("reload", "NA");
			tourneyDetails5.put("time", "20 Min");
			tourneyDetails5.put("qualify", "2000");
			
			tourneyLevelDetails.put("level5", tourneyDetails5);
		
			return tourneyLevelDetails;
		}
		
		public Hashtable<String,Hashtable<String, String>> getSpecialTourneyDetails()
		{
		
			Hashtable<String, String> tourneyDetails1 = new Hashtable<>();
			Hashtable<String, String> tourneyDetails2 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails3 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails4 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails5 = new Hashtable<>(); 
			Hashtable<String,Hashtable<String, String>> tourneyLevelDetails= new Hashtable<>();
			tourneyDetails1.put("level", "level1");
			tourneyDetails1.put("bet", "5");
			tourneyDetails1.put("rebuy", "0");
			tourneyDetails1.put("reload", "800");
			tourneyDetails1.put("time", "20 Min");
			tourneyDetails1.put("qualify", "400");
			
			tourneyLevelDetails.put("level1", tourneyDetails1);
			//tourneyDetails.clear();
			
			tourneyDetails2.put("level", "level2");
			tourneyDetails2.put("bet", "10");
			tourneyDetails2.put("rebuy", "0");
			tourneyDetails2.put("reload", "1200");
			tourneyDetails2.put("time", "20 Min");
			tourneyDetails2.put("qualify", "800");
			
			tourneyLevelDetails.put("level2", tourneyDetails2);
			//tourneyDetails.clear();
			
			tourneyDetails3.put("level", "level3");
			tourneyDetails3.put("bet", "15");
			tourneyDetails3.put("rebuy", "0");
			tourneyDetails3.put("reload", "1600");
			tourneyDetails3.put("time", "20 Min");
			tourneyDetails3.put("qualify", "1200");
			
			tourneyLevelDetails.put("level3", tourneyDetails3);
			
			tourneyDetails4.put("level", "level4");
			tourneyDetails4.put("bet", "20");
			tourneyDetails4.put("rebuy", "0");
			tourneyDetails4.put("reload", "2000");
			tourneyDetails4.put("time", "20 Min");
			tourneyDetails4.put("qualify", "1600");
			
			tourneyLevelDetails.put("level4", tourneyDetails4);
			
			tourneyDetails5.put("level", "level5");
			tourneyDetails5.put("bet", "25");
			tourneyDetails5.put("rebuy", "NA");
			tourneyDetails5.put("reload", "NA");
			tourneyDetails5.put("time", "20 Min");
			tourneyDetails5.put("qualify", "2000");
			
			tourneyLevelDetails.put("level5", tourneyDetails5);
		
			return tourneyLevelDetails;
		}
		
		public Hashtable<String,Hashtable<String, String>> getKnockoutTourneyDetails()
		{
		
			Hashtable<String, String> tourneyDetails1 = new Hashtable<>();
			Hashtable<String, String> tourneyDetails2 = new Hashtable<>(); 
		
			Hashtable<String,Hashtable<String, String>> tourneyLevelDetails= new Hashtable<>();
			tourneyDetails1.put("level", "level1");
			tourneyDetails1.put("bet", "5");
			tourneyDetails1.put("rebuy", "10");
			tourneyDetails1.put("reload", "800");
			tourneyDetails1.put("time", "20 Min");
			tourneyDetails1.put("qualify", "400");
			
			tourneyLevelDetails.put("level1", tourneyDetails1);
			//tourneyDetails.clear();
			
			tourneyDetails2.put("level", "level2");
			tourneyDetails2.put("bet", "10");
			tourneyDetails2.put("rebuy", "NA");
			tourneyDetails2.put("reload", "NA");
			tourneyDetails2.put("time", "20 Min");
			tourneyDetails2.put("qualify", "800");
			
			tourneyLevelDetails.put("level2", tourneyDetails2);
			//tourneyDetails.clear();
			
			
		
			return tourneyLevelDetails;
		}
		
		
		public Hashtable<String,Hashtable<String, String>> getAcePointsTourneyDetails()
		{
		
			Hashtable<String, String> tourneyDetails1 = new Hashtable<>();
			Hashtable<String, String> tourneyDetails2 = new Hashtable<>(); 
			Hashtable<String, String> tourneyDetails3 = new Hashtable<>(); 
			Hashtable<String,Hashtable<String, String>> tourneyLevelDetails= new Hashtable<>();
			tourneyDetails1.put("level", "level1");
			tourneyDetails1.put("bet", "5");
			tourneyDetails1.put("rebuy", "0 AP");
			tourneyDetails1.put("reload", "800");
			tourneyDetails1.put("time", "3 Min");
			tourneyDetails1.put("qualify", "400");
			
			tourneyLevelDetails.put("level1", tourneyDetails1);
			//tourneyDetails.clear();
			
			tourneyDetails2.put("level", "level2");
			tourneyDetails2.put("bet", "10");
			tourneyDetails2.put("rebuy", "0 AP");
			tourneyDetails2.put("reload", "1600");
			tourneyDetails2.put("time", "3 Min");
			tourneyDetails2.put("qualify", "800");
			
			tourneyLevelDetails.put("level2", tourneyDetails2);
			//tourneyDetails.clear();
			
			tourneyDetails3.put("level", "level3");
			tourneyDetails3.put("bet", "20");
			tourneyDetails3.put("rebuy", "NA");
			tourneyDetails3.put("reload", "NA");
			tourneyDetails3.put("time", "2 Min");
			tourneyDetails3.put("qualify", "1600");
			
			tourneyLevelDetails.put("level3", tourneyDetails3);
		
			return tourneyLevelDetails;
		}
		
		
		public void verifyCashTourneyDetails(Hashtable<String,Hashtable<String, String>> cashTourneyLevelDetails) throws IOException, InterruptedException
		{
			 TourneyDialogBox tourneyDialogBox= new TourneyDialogBox(driver);
			 TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
				String s = tourneyDialogBox.getTourneyDetails(TourneyDetailType.REGISTEREDPLAYERS).getText();
				int regisCountBeforeRegis = Character.getNumericValue(s.charAt(0));
				tourneyImplPage.getRegisterButton().click();
				verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Tourney registration confirmation pop up");
				tourneyImplPage.getRegisterConfirmationYesButton().click();
				verifyPresent(tourneyImplPage.getRegisterSuccessPopUp(), "Successfully Registered");
				if (CustomMethods.isElementPresent(tourneyImplPage.getRegisterSuccessPopUp()))
					logger.log(LogStatus.PASS, "Successfully Registered");
				tourneyImplPage.getRegisterSuccessOkButton().click();
				Thread.sleep(10000);	
				String str = 	 tourneyDialogBox.getTourneyDetails(TourneyDetailType.REGISTEREDPLAYERS).getText();
				int regisCountAfterRegis = Character.getNumericValue(str.charAt(0));
				System.out.println(regisCountBeforeRegis);
				System.out.println(regisCountAfterRegis);
				if(regisCountAfterRegis>regisCountBeforeRegis)
					logger.log(LogStatus.PASS, "Registration count before registering "+regisCountBeforeRegis+",Registration count after registering "+regisCountAfterRegis);
				else
					logger.log(LogStatus.FAIL, "Registration count before registering "+regisCountBeforeRegis+",Registration count after registering "+regisCountAfterRegis+logger.addScreenCapture(takeScreenShot("")));
				 
				tourneyImplPage.getCancelRegistrationButton().click();
				verifyPresent(tourneyImplPage.getUnRegisterConfirmationPopUp(), "Tourney cancel registration confirmation pop up");
				tourneyImplPage.getUnRegisterConfirmationYesButton().click();
				verifyPresent(tourneyImplPage.getUnRegisterSuccessPopUp(), "Successfully Unregistered");
				if(CustomMethods.isElementPresent(tourneyImplPage.getUnRegisterSuccessPopUp()))
					logger.log(LogStatus.PASS,"Successfully Unregistered");
				tourneyImplPage.getUnRegisterSuccessOkButton().click();
				Thread.sleep(10000);
				
				String s1=tourneyDialogBox.getTourneyDetails(TourneyDetailType.REGISTEREDPLAYERS).getText();
				
				int regisCountAfterUnRegis = Character.getNumericValue(s1.charAt(0));
				if(regisCountAfterUnRegis<regisCountAfterRegis)
				{
					logger.log(LogStatus.PASS, "Registration count before Unregistering "+regisCountAfterRegis+",Registration count after Unregistering "+regisCountAfterUnRegis);
				}
				else
					logger.log(LogStatus.FAIL, "Registration count before Unregistering "+regisCountAfterRegis+",Registration count after Unregistering "+regisCountAfterUnRegis+logger.addScreenCapture(takeScreenShot("")));
				
				
				
				 
				 verifyPresent(tourneyImplPage.getTourneyIdField(), "Tourney Id Field");
				 String tID=tourneyImplPage.getTourneyIdField().getText();
				 String arr[] = tID.split(" ");
				 String tEntry = tourneyDialogBox.getTourneyDetails(TourneyDetailType.ENTRY).getText();
				 tourneyImplPage.getRegisterButton().click();
				 verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Tourney registration confirmation pop up");
				 
				 String tConfirmText = "Do you want to register for "+arr[arr.length-1]+"? "+tEntry+" real chips will be deducted from your account.";
				 
				 verifyText(tourneyImplPage.getRegisterConfirmationPopUp().getText(), tConfirmText, "Tourney Registration Confirmation Text");
				 tourneyImplPage.getRegisterConfirmationNoButton().click();
				 
				 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.FORMAT).getText(),"Points Rummy");
				 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.ENTRY).getText(), "10");
				 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.STARTINGSTACK).getText(), "10 chips");
				 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.NOOFPRIZES).getText(), "3");
				 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
				 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
				 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
				 tourneyImplPage.verifyLevels(cashTourneyLevelDetails);
				 
				 
				 tourneyImplPage.getRegisterButton().click();
				 verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Tourney registration confirmation pop up");
				 tourneyImplPage.getRegisterConfirmationYesButton().click();
				 verifyPresent(tourneyImplPage.getRegisterSuccessPopUp(), "Successfully Registered");
				 if(CustomMethods.isElementPresent(tourneyImplPage.getRegisterSuccessPopUp()))
					logger.log(LogStatus.PASS,"Successfully Registered");
				 tourneyImplPage.getRegisterSuccessOkButton().click();
				
				 tourneyImplPage.getCancelRegistrationButton().click();
				 verifyPresent(tourneyImplPage.getUnRegisterConfirmationPopUp(), "Tourney cancel registration confirmation pop up");
				 tourneyImplPage.getUnRegisterConfirmationYesButton().click();
				 verifyPresent(tourneyImplPage.getUnRegisterSuccessPopUp(), "Successfully Unregistered");
				 if(CustomMethods.isElementPresent(tourneyImplPage.getUnRegisterSuccessPopUp()))
					logger.log(LogStatus.PASS,"Successfully Unregistered");
				 tourneyImplPage.getUnRegisterSuccessOkButton().click();
				
		}
			
		public void verifyFreeRollTourneyDetails(Hashtable<String,Hashtable<String, String>> freerollTourneyLevelDetails) throws IOException, InterruptedException
		{
			TourneyDialogBox tourneyDialogBox= new TourneyDialogBox(driver);
			 TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
			verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.FORMAT).getText(),"Points Rummy");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.ENTRY).getText(), "free");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.STARTINGSTACK).getText(), "10 chips");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.NOOFPRIZES).getText(), "6");
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyImplPage.verifyLevels(freerollTourneyLevelDetails);
			 
			 
			 
			 tourneyImplPage.getRegisterButton().click();
			 verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Tourney registration confirmation pop up");
			 tourneyImplPage.getRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getRegisterSuccessPopUp(), "Successfully Registered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Registered");
			 tourneyImplPage.getRegisterSuccessOkButton().click();
			
			 tourneyImplPage.getCancelRegistrationButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterConfirmationPopUp(), "Tourney cancel registration confirmation pop up");
			 tourneyImplPage.getUnRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterSuccessPopUp(), "Successfully Unregistered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getUnRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Unregistered");
			 tourneyImplPage.getUnRegisterSuccessOkButton().click();
		}
		
		public void verifySpecialTourneyDetails(Hashtable<String,Hashtable<String, String>> specialTourneyLevelDetails) throws IOException, InterruptedException
		{
			TourneyDialogBox tourneyDialogBox= new TourneyDialogBox(driver);
			 TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.FORMAT).getText(),"Points Rummy");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.ENTRY).getText(), "10");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.STARTINGSTACK).getText(), "10 chips");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.NOOFPRIZES).getText(), "6");
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyImplPage.verifyLevels(specialTourneyLevelDetails);
		}
		
		public void verifyKnockOutTourneyDetails(Hashtable<String,Hashtable<String, String>> knockoutTourneyLevelDetails) throws IOException, InterruptedException
		{
			TourneyDialogBox tourneyDialogBox= new TourneyDialogBox(driver);
			 TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
			 
			 tourneyImplPage.getRegisterButton().click();
			 verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Tourney registration confirmation pop up");
			 tourneyImplPage.getRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getRegisterSuccessPopUp(), "Successfully Registered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Registered");
			 tourneyImplPage.getRegisterSuccessOkButton().click();
			
			 tourneyImplPage.getCancelRegistrationButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterConfirmationPopUp(), "Tourney cancel registration confirmation pop up");
			 tourneyImplPage.getUnRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterSuccessPopUp(), "Successfully Unregistered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getUnRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Unregistered");
			 tourneyImplPage.getUnRegisterSuccessOkButton().click();
		
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.FORMAT).getText(),"Points Rummy");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.ENTRY).getText(), "10");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.STARTINGSTACK).getText(), "10 chips");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.NOOFPRIZES).getText(), "6");
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyImplPage.verifyLevels(knockoutTourneyLevelDetails);
			 
			 
			 
			 tourneyImplPage.getRegisterButton().click();
			 verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Tourney registration confirmation pop up");
			 tourneyImplPage.getRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getRegisterSuccessPopUp(), "Successfully Registered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Registered");
			 tourneyImplPage.getRegisterSuccessOkButton().click();
			
			 tourneyImplPage.getCancelRegistrationButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterConfirmationPopUp(), "Tourney cancel registration confirmation pop up");
			 tourneyImplPage.getUnRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterSuccessPopUp(), "Successfully Unregistered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getUnRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Unregistered");
			 tourneyImplPage.getUnRegisterSuccessOkButton().click();
			
		}
		
		public void verifyAcePointsTourneyDetails(Hashtable<String,Hashtable<String, String>> acepointTourneyLevelDetails) throws IOException, InterruptedException
		{
			TourneyDialogBox tourneyDialogBox= new TourneyDialogBox(driver);
			 TourneyImplPage tourneyImplPage = new TourneyImplPage(driver);
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.FORMAT).getText(),"Points Rummy");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.ENTRY).getText(), "10 AP");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.STARTINGSTACK).getText(), "10 chips");
			 verifyText(tourneyDialogBox.getTourneyDetails(TourneyDetailType.NOOFPRIZES).getText(), "6");
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyDialogBox.getTourneyDetails(TourneyDetailType.LEVELS).click();
			 tourneyImplPage.verifyLevels(acepointTourneyLevelDetails);
			 
			 
			 tourneyImplPage.getRegisterButton().click();
			 verifyPresent(tourneyImplPage.getRegisterConfirmationPopUp(), "Tourney registration confirmation pop up");
			 tourneyImplPage.getRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getRegisterSuccessPopUp(), "Successfully Registered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Registered");
			 tourneyImplPage.getRegisterSuccessOkButton().click();
			
			 tourneyImplPage.getCancelRegistrationButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterConfirmationPopUp(), "Tourney cancel registration confirmation pop up");
			 tourneyImplPage.getUnRegisterConfirmationYesButton().click();
			 verifyPresent(tourneyImplPage.getUnRegisterSuccessPopUp(), "Successfully Unregistered");
			 if(CustomMethods.isElementPresent(tourneyImplPage.getUnRegisterSuccessPopUp()))
				logger.log(LogStatus.PASS,"Successfully Unregistered");
			 tourneyImplPage.getUnRegisterSuccessOkButton().click();
			
		}

}
