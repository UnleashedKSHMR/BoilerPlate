package com.ace2three.impl.pages;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.locators.AndroidLocators.LobbyPageLocators;
import com.ace2three.locators.AndroidLocators.SignupPageLocators;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.relevantcodes.extentreports.LogStatus;

public class SignupImplPage implements SignupPageLocators,LobbyPageLocators {
	
	WebDriver driver;
	BaseTestSuite basetestsuite = new BaseTestSuite ();
	
	public SignupImplPage (WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver =driver;
		PageFactory.initElements(driver, this);
        //Handling PLP Banners
		try{
			  driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]")).click();
			  BaseTestSuite.logger.log(LogStatus.PASS, "PLP banner displayed and closed");
		}catch(Exception e){
			 
			BaseTestSuite.logger.log(LogStatus.INFO, "No PLP banner displayed");
		}finally{
		
		}
	}
	
	
	@FindBy(xpath= SIGNUP_SUCCESSFUL_BANNER_CLOSE_BUTTON)
	private WebElement signupSuccessfulBannerCloseButton;
	
	public WebElement getSignupSuccessfulBannerCloseButton(){
		return signupSuccessfulBannerCloseButton;
	}
	
	public void verifyPageLoaded() throws IOException{
		if(getUsernamefield().isDisplayed()){
			BaseTestSuite.logger.log(LogStatus.PASS, "Signup page has displayed");
		}else{
			BaseTestSuite.logger.log(LogStatus.FAIL, "Signup page has not displayed" + BaseTestSuite.logger.addScreenCapture(BaseTestSuite.takeScreenShot("")));
		}
		
	}
	public void verifyPostSignUpBanner()
	{
		if(CustomMethods.isElementPresent(getSignupSuccessfulBannerCloseButton()))
		{
			getSignupSuccessfulBannerCloseButton().click();
			System.out.println("Close Clicked");
		}
	}
	public String doSignUp() throws IOException{
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
		Date date = new Date();
		dateFormat.format(date);
		String Username= "test" + dateFormat.format(date);
		
		WebDriverWait wait= new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(signupimplpage.getUsernamefield()));
		signupimplpage.getUsernamefield().sendKeys(Username);
		signupimplpage.getEmailidfield().sendKeys("em"+Username+"@ds.com");
		signupimplpage.getPasswordfield().sendKeys(ReadDataFromProps.props.getProperty("doSignUp.method.password"));
		signupimplpage.getSignupbutton().click();
		// Need to add one more step
		//WebElement ace2threeHeader=driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Ace2Three')]"));
			LobbyImplPage lobbyPage = new LobbyImplPage();
			CustomMethods.waitForElementPresent(lobbyPage.getPlpBannerCloseIcon(), 15);
			lobbyPage.verifyPostLaunchBanners();
			//lobbyPage.verifyLobbyPageDisplayed();
			BaseTestSuite.logger.log(LogStatus.INFO, "Username is: "+ Username);
		return Username;
	}
	
	public String doSignUpWithPhoneNumber() throws IOException{
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
		Date date = new Date();
		dateFormat.format(date);
		String Username= "test" + dateFormat.format(date);
		
		WebDriverWait wait= new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(signupimplpage.getUsernamefield()));
		signupimplpage.getUsernamefield().sendKeys(Username);
		signupimplpage.getmobileNofiled().sendKeys(ReadDataFromProps.props.getProperty("mobile.number"));
		signupimplpage.getPasswordfield().sendKeys("ace2three");
		signupimplpage.getSignupbutton().click();
		// Need to add one more step
		//WebElement ace2threeHeader=driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Ace2Three')]"));
		LobbyImplPage lobbyPage = new LobbyImplPage();
		CustomMethods.waitForElementPresent(lobbyPage.getPlpBannerCloseIcon(), 15);
		lobbyPage.verifyPostLaunchBanners();
		//lobbyPage.verifyLobbyPageDisplayed();
			BaseTestSuite.logger.log(LogStatus.INFO, "Username is: "+ Username);
		return Username;
	}
	
	
	@FindBy(xpath=LOBBY_COUNT)
	private WebElement Lobbycount;
	
	public WebElement getLobbycountDisplay() {
		return Lobbycount;
	}
	
	@FindBy(xpath=ACE2THREE_LOGO)
	private WebElement ace2threelogo;
	
	public WebElement getAce2threelogo(){
		return ace2threelogo;
	}
	
	@FindBy(xpath=MAIN_HEADER)
	private WebElement mainheader;
	
	public WebElement getMainheader(){
		return mainheader;
	}
	
	@FindBy(xpath=SUB_HEADER)
	private WebElement subheader;
	
	public WebElement getSubheader(){
		return subheader;
	}
	
	@FindBy(xpath=USERNAME_FIELD)
	private WebElement usernamefield;
	
	public WebElement getUsernamefield(){
		return usernamefield;
	}
	
	@FindBy(xpath=EMAIL_MOBILE_NO_FIELD)
	private WebElement mobileNofiled;
	
	public WebElement getmobileNofiled(){
		return emailidfield;
	}
	
	@FindBy(xpath=EMAIL_MOBILE_NO_FIELD)
	private WebElement emailidfield;
	
	public WebElement getEmailidfield(){
		return emailidfield;
	}
	
	@FindBy(xpath=PASSWORD_FIELD)
	private WebElement passwordfiled;
	
	public WebElement getPasswordfield(){
		return passwordfiled;
	}
	
	@FindBy(xpath=SIGNUP_BUTTON)
	private WebElement signupbutton;
	
	public WebElement getSignupbutton(){
		return signupbutton;
	}
	
	@FindBy(xpath=SIGNUP_NOTE)
	private WebElement signupnote;
	
	public WebElement getSignupnote(){
		return signupnote;
	}
	
	@FindBy(xpath=LOGIN_LINK_TEXT)
	private WebElement loginlinktext;
	
	public WebElement getLoginlinktext(){
		return loginlinktext;
	}
	

	@FindBy(xpath=LOGIN_LINK)
	private WebElement Loginlink;
	
	public WebElement getLoginlink(){
		return Loginlink;
	}
	
	@FindBy(xpath=ERROR_MESSAGE)
	private WebElement ErrorMessage;
	
	public WebElement getErrorMessage(){
		return ErrorMessage;
	}
	
	@FindBy(xpath=CLICK_TO_LOGIN_BUTTON)
	private WebElement loginClickButton;
	
	public WebElement getLoginClickButton(){
		return loginClickButton;
	}
	
	@FindBy(xpath=SHOW_PASSWORD)
	private WebElement showPassword;
	
	public WebElement getShowPassword(){
		return showPassword;
	}
	
	@FindBy(xpath=LOGIN_SIGNUP_BUTTON)
	private WebElement LoginSignupButton;
	
	public WebElement getLoginSignupButton(){
		return LoginSignupButton;
	}	
}
