package com.ace2three.impl.pages;

import java.awt.Point;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.locators.AndroidLocators.LoginPageLocators;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class LoginImplPage implements LoginPageLocators{

	WebDriver driver;
	public LoginImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver= driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath= RESTRICTED_ACCESS_LOGIN_MESSAGE)
	WebElement restrictedAccessLoginMessage;
	
	public WebElement getRestrictedAccessLoginMessage(){
		return restrictedAccessLoginMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'table_hint_tv')]")
	WebElement tableandPlayerCount;

	public WebElement getTableandPlayerCount(){
	return tableandPlayerCount;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_login_mock')]")
	WebElement loginWithFacebook;
	
	public WebElement getLoginWithFacebook(){
		return loginWithFacebook;
	}
	
	public void clickOnSignUpLink(){
		
		MobileElement el= (MobileElement) driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Sign Up')]"));
		int leftX = el.getLocation().getX();
		int rightX = leftX + el.getSize().getWidth();
		int x= rightX-30;
		System.out.println("x loc: "+x+ " -y loc: "+ el.getCenter().getY());
		((AndroidDriver) driver).tap(1, x, el.getCenter().getY(), 2000);
	}
	
}
