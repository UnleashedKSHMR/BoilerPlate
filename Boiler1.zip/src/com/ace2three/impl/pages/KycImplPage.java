package com.ace2three.impl.pages;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.locators.AndroidLocators.KycScreeenLocators;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.ace2three.utils.business.BusinessMethods;
import com.ace2three.utils.business.BusinessMethods.IdProofList;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class KycImplPage extends MyAccountImplPage implements KycScreeenLocators {
BusinessMethods businessMethods;
BaseTestSuite baseTestSuite;
WebDriver desktopDriver;

	public KycImplPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		businessMethods = new BusinessMethods();
		baseTestSuite= new BaseTestSuite();
	}

	@FindBy(xpath= KYC_EMAIL_FIELD_LOC)
	private WebElement kycEmailField;
	
	
	public WebElement getKycEmailField(){
		return kycEmailField;
	}
	
	@FindBy(xpath= KYC_EMAIL_VALIDATION_INDICATOR)
	private WebElement kycEmailVerifiedIndicator;
	
	public WebElement getKycEmailVerifiedIndicator(){
		return kycEmailVerifiedIndicator;
	}
	
	@FindBy(xpath= KYC_EMAIL_VERIFY_BUTTON)
	private WebElement kycEmailVerifyButton;
	
	public WebElement getKycEmailVerifyButton(){
		return kycEmailVerifyButton;
	}
	
	@FindBy(xpath= KYC_PHONE_NO_FIELD_LOC)
	private WebElement kycPhoneNoField;
	
	public WebElement getKycPhoneNoField(){
		return kycPhoneNoField;
	}
	
	@FindBy(xpath= KYC_PHONE_NO_VALIDATION_INDICATOR)
	private WebElement kycPhoneNoVerifiedIndicator;
	
	public WebElement getKycPhoneNoVerifiedIndicator(){
		return kycPhoneNoVerifiedIndicator;
	}
	
	@FindBy(xpath= KYC_PHONE_NO_VERIFY_BUTTON)
	private WebElement kycPhoneNoVerifyButton;
	
	public WebElement getKycPhoneNoVerifyButton(){
		return kycPhoneNoVerifyButton;
	}
	
	@FindBy(xpath= KYC_PAN_FIELD_LOC)
	private WebElement kycPanField;
	
	public WebElement getKycPanField(){
		return kycPanField;
	}
	
	@FindBy(xpath= KYC_PAN_VALIDATION_INDICATOR)
	private WebElement kycPanVerifiedIndicator;
	
	public WebElement getKycPanVerifiedIndicator(){
		return kycPanVerifiedIndicator;
	}
	
	@FindBy(xpath= KYC_PAN_HELP_BUTTON)
	private WebElement kycPanHelpButton;
	
	public WebElement getKycPanHelpButton(){
		return kycPanHelpButton;
	}
	
	@FindBy(xpath= KYC_PAN_VERIFY_BUTTON)
	private WebElement kycPanUploadButton;
	
	public WebElement getKycPanUploadButton(){
		return kycPanUploadButton;
	}
	
	@FindBy(xpath= KYC_ID_PROOF_FIELD_LOC)
	private WebElement kycIDProofField;
	
	public WebElement getKycIDProofField(){
		return kycIDProofField;
	}
	
	@FindBy(xpath= KYC_ID_PROOF_VALIDATION_INDICATOR)
	private WebElement kycIdProofVerifiedIndicator;
	
	public WebElement getKycIdProofVerifiedIndicator(){
		return kycIdProofVerifiedIndicator;
	}
	
	@FindBy(xpath= KYC_ID_PROOF_VERIFY_BUTTON)
	private WebElement kycIdProofUploadButton;
	
	public WebElement getKycIdProofUploadButton(){
		return kycIdProofUploadButton;
	}
	
	@FindBy(xpath= KYC_EMAIL_WARNING_MESSAGE)
	private WebElement kycEmailWarningMessage;
	
	public WebElement getKycEmailWarningMessage(){
		return kycEmailWarningMessage;
	}
	
	@FindBy(xpath= KYC_PHONE_NO_INVALID_ERROR)
	private WebElement kycPhoneNoInvalidError;
	
	public WebElement getKycPhoneNoInvalidError(){
		return kycPhoneNoInvalidError;
	}
	
	@FindBy(xpath= ID_PROOF_GUIDELINES_POPUP_CONTENT_SECTION)
	private WebElement idProofGuideLinesPopup;
	
	public WebElement getIdProofGuideLinesPopup(){
		return idProofGuideLinesPopup;
	}
	
	@FindBy(xpath= ID_PROOF_GUIDELINES_POPUP_CONTENT_SECTION)
	private WebElement panProofGuideLinesPopup;
	
	public WebElement getPanProofGuideLinesPopup(){
		return panProofGuideLinesPopup;
	}
	
	@FindBy(xpath= ID_PROOF_GUIDELINES_POPUP_HEADER)
	private WebElement idProofGuideLinesPopupHeader;
	
	public WebElement getIdProofGuideLinesPopupHeader(){
		return idProofGuideLinesPopupHeader;
	}
	
	@FindBy(xpath= PAN_PROOF_GUIDELINES_POPUP_HEADER)
	private WebElement panProofGuideLinesPopupHeader;
	
	public WebElement getPanProofGuideLinesPopupHeader(){
		return panProofGuideLinesPopupHeader;
	}
	
	@FindBy(xpath= ID_PROOF_GUIDELINES_POPUP_OK_BUTTON)
	private WebElement idProofGuideLinesPopupOkButton;
	
	public WebElement getIdProofGuideLinesPopupOkButton(){
		return idProofGuideLinesPopupOkButton;
	}
	
	@FindBy(xpath= ID_PROOF_UPLOAD_POPUP_HEADER)
	private WebElement idProofUploadPopUpHeader;
	
	public WebElement getIdProofUploadPopUpHeader(){
		return idProofUploadPopUpHeader;
	}
	
	@FindBy(xpath= ID_PROOF_UPLOAD_POPUP_GUIDELINES_ICON)
	private WebElement idProofUploadPopUpGuidelinesIcon;
	
	public WebElement getIdProofUploadPopUpGuidelinesIcon(){
		return idProofUploadPopUpGuidelinesIcon;
	}
	
	@FindBy(xpath= ID_PROOF_UPLOAD_POPUP_CAMERA_ICON)
	private WebElement idProofUploadPopUpCameraIcon;
	
	public WebElement getIdProofUploadPopUpCameraIcon(){
		return idProofUploadPopUpCameraIcon;
	}
	
	@FindBy(xpath= ID_PROOF_UPLOAD_POPUP_UPLOAD_ICON)
	private WebElement idProofUploadPopUpUploadIcon;
	
	public WebElement getIdProofUploadPopUpUploadIcon(){
		return idProofUploadPopUpUploadIcon;
	}
	
	@FindBy(xpath= ID_PROOF_UPLOAD_POPUP_INSTRUCTIONS_TEXT)
	private WebElement idProofUploadPopUpInstructionsText;
	
	public WebElement getIdProofUploadPopUpInstructionsText(){
		return idProofUploadPopUpInstructionsText;
	}
	
	@FindBy(xpath= ID_PROOF_UPLOAD_POPUP_CLOSE_ICON)
	private WebElement idProofUploadPopUpCloseIcon;
	
	public WebElement getIdProofUploadPopUpCloseIcon(){
		return idProofUploadPopUpCloseIcon;
	}
	
	@FindBy(xpath= CAMERA_SHUTTER_BUTTON)
	private WebElement cameraShutterButton;
	
	public WebElement getCameraShutterButton(){
		return cameraShutterButton;
	}
	
	@FindBy(xpath= ENTER_OTP_POPUP)
	private WebElement enterOtpPopup;
	
	public WebElement getEnterOtpPopup(){
		return enterOtpPopup;
	}
	
	@FindBy(xpath= OTP_ENTRY_FIELD)
	private WebElement otpEntryField;
	
	public WebElement getOtpEntryField(){
		return otpEntryField;
	}
	
	@FindBy(xpath= OTP_RESEND_LINK)
	private WebElement otpResendLink;
	
	public WebElement getOtpResendLink(){
		return otpResendLink;
	}
	
	@FindBy(xpath= OTP_PROGRESS_TIMEBAR)
	private WebElement otpProgressTimeBar;
	
	public WebElement getOtpProgressTimeBar(){
		return otpProgressTimeBar;
	}
	
	@FindBy(xpath= OTP_PROGRESS_TIME)
	private WebElement otpProgressTime;
	
	public WebElement getOtpProgressTime(){
		return otpProgressTime;
	}

	@FindBy(xpath= OTP_INCORRECT_ERROR)
	private WebElement otpIncorrectError;
	
	public WebElement getOtpIncorrectError(){
		return otpIncorrectError;
	}
	
	@FindBy(xpath= OTP_CONFIRM_BUTTON)
	private WebElement otpConfirmButton;
	
	public WebElement getOtpConfirmButton(){
		return otpConfirmButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'kyc_id_attach_text')]")
	private WebElement attachOtherSidePopUpMessage;
	
	public WebElement getAtachOtherSidePopUpMessage(){
		return attachOtherSidePopUpMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvFileOne')]")
	private WebElement attachedFileName;
	
	public WebElement getAttachedFileName(){
		return attachedFileName;
	}
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'iVDeleteFileOne')]")
	private WebElement deleteAttachedFileIcon;
	
	public WebElement getDeleteAttachedFileIcon(){
		return deleteAttachedFileIcon;
	}
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'img_delfile2')]")
	private WebElement deleteSecondAttachedFileIcon;
	
	public WebElement getDeleteSecondAttachedFileIcon(){
		return deleteSecondAttachedFileIcon;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvAttachAnother')]")
	private WebElement attachAnotherSideButton;
	
	public WebElement getAttachAnotherSideButton(){
		return attachAnotherSideButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvNoThanks')]")
	private WebElement attachFileNoThansksButton;
	
	public WebElement getAttachFileNoThansksButton(){
		return attachFileNoThansksButton;
	}
	
	@FindBy(xpath= "//android.widget.CheckBox[contains(@resource-id,'cbAadharCheck')]")
	private WebElement authorizationPopUpMessage;
	
	public WebElement getAuthorizationPopUpMessage(){
		return authorizationPopUpMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvSubmit')]")
	private WebElement authorizationPopUpSubmitButton;
	
	public WebElement getAuthorizationPopUpSubmitButton(){
		return authorizationPopUpSubmitButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvSuccessTitle')]")
	private WebElement idUploadSuccessPopUpHeader;
	
	public WebElement getIdUploadSuccessPopUpHeader(){
		return idUploadSuccessPopUpHeader;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvSuccessTitle')]")
	private WebElement panCardUploadSuccessPopUpHeader;
	
	public WebElement getPanCardUploadSuccessPopUpHeader(){
		return panCardUploadSuccessPopUpHeader;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvMessage')]")
	private WebElement idUploadSuccessMessage;
	
	public WebElement getIdUploadSuccessMessage(){
		return idUploadSuccessMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvMessage')]")
	private WebElement panCardUploadSuccessMessage;
	
	public WebElement getPanCardUploadSuccessMessage(){
		return panCardUploadSuccessMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvOk')]")
	private WebElement idUploadPopupOkButton;
	
	public WebElement getIdUploadPopupOkButton(){
		return idUploadPopupOkButton;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Allow Ace2Three Plus to take pictures and record video?')]")
	private WebElement photoPermissionMessage;
	
	public WebElement getPhotoPermissionMessage(){
		return photoPermissionMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvOk')]")
	private WebElement panUploadPopupOkButton;
	
	public WebElement getPanUploadPopupOkButton(){
		return panUploadPopupOkButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvKYCIdProofApproved')]")
	private WebElement idUploadStatus;
	
	public WebElement getIdUploadStatus(){
		return idUploadStatus;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvKYCPanApproved')]")
	private WebElement panUploadStatus;
	
	public WebElement getPanUploadStatus(){
		return panUploadStatus;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvProceedWithRedeem')]")
	private WebElement toProceedWithRedeemRequestText;
	
	public WebElement getToProceedWithRedeemRequestText(){
		return toProceedWithRedeemRequestText;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement makeYourFirstPurchasePopup;
	
	public WebElement getMakeYourFirstPurchasePopup(){
		return makeYourFirstPurchasePopup;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Buy Real Chips')]")
	private WebElement buyRealChipsButton;
	
	public WebElement getBuyRealChipsButton(){
		return buyRealChipsButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'No Thanks')]")
	private WebElement noThanksButton;
	
	public WebElement getNoThanksButton(){
		return noThanksButton;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'DENY')]")
	private WebElement denyButton;
	
	public WebElement getDenyButton(){
		return denyButton;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'ALLOW')]")
	private WebElement allowButton;
	
	public WebElement getAllowButton(){
		return allowButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvKYCIdProofError')]")
	private WebElement pleaseSelectIdProofErrorMsg;
	
	public WebElement getPleaseSelectIdProofErrorMsg(){
		return pleaseSelectIdProofErrorMsg;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvKYCPanError')]")
	private WebElement pleaseEnterPanNumErrorMsg;
	
	public WebElement getPleaseEnterPanNumErrorMsg(){
		return pleaseEnterPanNumErrorMsg;
	}
	
	@FindBy(xpath= KYC_EMAIL_WARNING_MESSAGE)
	private WebElement activationLinkSentMessage;
	
	public WebElement getActivationLinkSentMessage(){
		return activationLinkSentMessage;
	}
	
	
	
	public void uploadIdProofAadharOneSide(String userName) throws IOException, InterruptedException{
		
		baseTestSuite.verifyPresent(getKycPhoneNoField(), "KYC page");
		getKycIDProofField().click();
		businessMethods.selectIdFromDropDown(IdProofList.AadhaarCard);
		getKycIdProofUploadButton().click();
		baseTestSuite.verifyPresent(getIdProofGuideLinesPopup(),"Id proof guidelines");
		getIdProofGuideLinesPopupOkButton().click();
		
		getIdProofUploadPopUpCameraIcon().click();
		
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		
		//driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'crop_image_menu_crop')]")).click();
		baseTestSuite.verifyPresent(getAtachOtherSidePopUpMessage(),"Attach Other Side popup");
		baseTestSuite.verifyTextPresent(getAtachOtherSidePopUpMessage(),
				ReadDataFromProps.props.getProperty("kyc.page.attach.another.side.popup.message"));
		baseTestSuite.verifyText(getAttachedFileName().getText(),"1. "+userName+"_Aadhaar Card_id_front.jpg");
		baseTestSuite.verifyPresent(getAttachAnotherSideButton(), "Attach Another Side Button");
		baseTestSuite.verifyPresent(getAttachFileNoThansksButton(), "No Thanks Button");
		getAttachAnotherSideButton().click();
		baseTestSuite.verifyPresent(getIdProofUploadPopUpCameraIcon(), "Upload ID Proof popup to upload second image");
		getIdProofUploadPopUpCloseIcon().click();
		getAttachFileNoThansksButton().click();
		baseTestSuite.verifyPresent(getDeleteAttachedFileIcon(), "Delete Icon of first file");
		baseTestSuite.verifyPresent(getAuthorizationPopUpMessage(),"Id card authorization popup");
		baseTestSuite.verifyText(getAuthorizationPopUpMessage().getText(), "By uploading, I authorize Ace2Three to verify my Aadhaar details");
		getAuthorizationPopUpMessage().click();
		baseTestSuite.verifyPresent(getAuthorizationPopUpSubmitButton(), "ID Proof Autorization Submit Button");
		getAuthorizationPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(getIdUploadSuccessPopUpHeader(),30);
		baseTestSuite.verifyPresent(getIdUploadSuccessPopUpHeader(),"ID upload success popup");
		baseTestSuite.verifyTextPresent(getIdUploadSuccessMessage(),ReadDataFromProps.props.getProperty("kyc.page.id.upload.sucess.message"));
		
		getIdUploadPopupOkButton().click();
		baseTestSuite.verifyTextPresent(getIdUploadStatus(),"Pending Approval");
		
	}
	
	public enum IdProofAction{
		Accept,Reject;
	}
	
	public void performActionOnIdProofInAdminSite(String userName,IdProofAction IdProofAction, IdProof idProofType) throws InterruptedException{
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();

		desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		JavascriptExecutor js = (JavascriptExecutor) desktopDriver;  
		//js.executeScript("document.body.style.zoom = '0.9'");
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("RM")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		WebElement kycCue= desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']"));
		js.executeScript("arguments[0].click();", kycCue );
		
		//desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']")).click();
		desktopDriver.findElement(By.cssSelector("input[value='RefreshDetails']")).click();
		desktopDriver.findElement(By.cssSelector("input#searchUserId")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[value='Submit']")).click();
		desktopDriver.findElement(By.cssSelector("span#img"+userName)).click();
		Thread.sleep(3000);
		WebElement we =desktopDriver.findElement(By.cssSelector("input[value='"+IdProofAction+"']"));

		js.executeScript("arguments[0].click();", we);
	
		if(IdProofAction.toString().equalsIgnoreCase("Accept")){
		Thread.sleep(3000);
		desktopDriver.findElement(By.cssSelector("input[id='ID']")).click();
		if(idProofType.toString().equals("Aadhar"))
		{
			new Select(desktopDriver.findElement(By.cssSelector("select[id='idVal']"))).selectByValue("Aadhaar Card");
			desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys("852147"+customeMe.generateRandomNumber(6));
		}
		else if(idProofType.toString().equals("RationCard"))
		{
			new Select(desktopDriver.findElement(By.cssSelector("select[id='idVal']"))).selectByValue("Ration Card");
			desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys("FDU1"+customeMe.generateRandomNumber(8));
		}
		else if (idProofType.toString().equals("VoterID"))
		{
			new Select(desktopDriver.findElement(By.cssSelector("select[id='idVal']"))).selectByValue("Voters Id");
			desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys("as4"+customeMe.generateRandomNumber(6)+"h");
		}
		else if (idProofType.toString().equals("DrivingLicence"))
		{
			new Select(desktopDriver.findElement(By.cssSelector("select[id='idVal']"))).selectByValue("Driver Licence");
			desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys("TS752"+customeMe.generateRandomNumber(6)+"0");
		}
		else if (idProofType.toString().equals("Passport"))
		{
			new Select(desktopDriver.findElement(By.cssSelector("select[id='idVal']"))).selectByValue("Passport");
			desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys("sdfgh4"+customeMe.generateRandomNumber(6)+"45");
		}
		
		
		desktopDriver.findElement(By.cssSelector("textarea[id='comments']")).sendKeys("QA test");
		
		WebElement accept=desktopDriver.findElement(By.cssSelector("input[value='Accept'][type='submit']"));
		js.executeScript("arguments[0].click();", accept);
		
		Thread.sleep(4000);
		
		updateAddressInProfileFromAdmin(userName);
		desktopDriver.close();
		}else{
			
			desktopDriver.switchTo().alert().accept();
			Thread.sleep(4000);
			desktopDriver.close();
		}

	}
	
	public void updateAddressInProfileFromAdmin(String userName) throws InterruptedException{
		
		JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
		executor.executeScript("document.body.style.zoom = '0.9'");
		
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		Thread.sleep(1000);
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
		try{
			desktopDriver.findElement(By.cssSelector("a[href='userProfileDetails.jsp?userid="+userName+"']")).click();
		}catch(Exception e){
			System.out.println("exception 11");
		}
		
		desktopDriver.findElement(By.cssSelector("a[href*='userDetailsUpdate.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("#cAddress[type='checkbox']")).click();
		new Select(desktopDriver.findElement(By.cssSelector("#state"))).selectByValue("Karnataka");
		
		WebElement update=	desktopDriver.findElement(By.cssSelector("input[value='UPDATE']"));
		
		executor.executeScript("arguments[0].click()",update);
		desktopDriver.switchTo().alert().accept();
		WebElement goToProfile=	desktopDriver.findElement(By.cssSelector("input[value='Go Back to Player Profile']"));
		executor.executeScript("arguments[0].click()",goToProfile);
		Thread.sleep(3000);
	}
	
	public enum IdProof{
		Aadhar,RationCard,VoterID,DrivingLicence,Passport ;
	}
	
	public enum GuideLinesCheck
	{
		Ignore,Verify;
	}
	
	public void uploadIdProof(String userName,  IdProof idProofType, GuideLinesCheck glc) throws IOException, InterruptedException
	{
		System.out.println(idProofType);
		baseTestSuite.verifyPresent(getKycPhoneNoField(), "KYC page");
		getKycIDProofField().click();
		if(idProofType.toString().equals("RationCard"))
			businessMethods.selectIdFromDropDown(IdProofList.RationCard);
		else if (idProofType.toString().equals("VoterID"))
			businessMethods.selectIdFromDropDown(IdProofList.VoterID);	
		else if (idProofType.toString().equals("DrivingLicence"))
			businessMethods.selectIdFromDropDown(IdProofList.DrivingLicence);	
		else if (idProofType.toString().equals("Passport"))
			businessMethods.selectIdFromDropDown(IdProofList.Passport);	
		
		getKycIdProofUploadButton().click();
		if(glc.toString().equals("Verify"))
		{
		baseTestSuite.verifyPresent(getIdProofGuideLinesPopup(),"Id proof guidelines");
		getIdProofGuideLinesPopupOkButton().click();
		}
		baseTestSuite.verifyPresent(getIdProofUploadPopUpHeader(), "Upload ID Proof Popup");
		baseTestSuite.verifyPresent(getIdProofUploadPopUpCameraIcon(), "Camera Icon");
		baseTestSuite.verifyPresent(getIdProofUploadPopUpUploadIcon(), "Upload Icon");
		
	
		getIdProofUploadPopUpCameraIcon().click();
		
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		
		//driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'crop_image_menu_crop')]")).click();
		baseTestSuite.verifyPresent(getAtachOtherSidePopUpMessage(),"Attach Other Side popup");
		baseTestSuite.verifyTextPresent(getAtachOtherSidePopUpMessage(),
				ReadDataFromProps.props.getProperty("kyc.page.attach.another.side.popup.message"));
		//baseTestSuite.verifyText(getAttachedFileName().getText(),"1. "+userName+"_Aadhaar Card_id_front.jpg");
		if(idProofType.toString().equals("RationCard"))
			baseTestSuite.verifyText(getAttachedFileName().getText(),"1. "+userName+"_Ration Card_id_front.jpg");
		else if (idProofType.toString().equals("VoterID"))
			baseTestSuite.verifyText(getAttachedFileName().getText(),"1. "+userName+"_Voter ID_id_front.jpg");
		else if (idProofType.toString().equals("DrivingLicence"))
			baseTestSuite.verifyText(getAttachedFileName().getText(),"1. "+userName+"_Driving Licence_id_front.jpg");	
		else if (idProofType.toString().equals("Passport"))
			baseTestSuite.verifyText(getAttachedFileName().getText(),"1. "+userName+"_Passport_id_front.jpg");	
		
		getAttachFileNoThansksButton().click();
		
		getAuthorizationPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(getIdUploadSuccessPopUpHeader(),30);
		baseTestSuite.verifyPresent(getIdUploadSuccessPopUpHeader(),"ID upload success popup");
		baseTestSuite.verifyTextPresent(getIdUploadSuccessMessage(),ReadDataFromProps.props.getProperty("kyc.page.id.upload.sucess.message"));
		
		getIdUploadPopupOkButton().click();
		baseTestSuite.verifyTextPresent(getIdUploadStatus(),"Pending Approval");
	}
	
	public String uploadPan(String userName) throws IOException, InterruptedException
	{
		Random ran = new Random();	
		
		baseTestSuite.verifyPresent(getKycPhoneNoField(), "KYC page");
		getKycPanField().clear();
		baseTestSuite.verifyPresent(getKycPanHelpButton(), "Pan Card question mark");
		String pan=CustomMethods.randomStringGenerator(3)+"py"+(ran.nextInt((9999-1000)+1)+1000)+"e";
		System.out.println(pan);
		getKycPanField().clear();
		MobileElement elePan = (MobileElement)getKycPanField();
		elePan.sendKeys(pan);
		getKycPanUploadButton().click();
		Thread.sleep(2000);
		if(CustomMethods.isElementPresent(getPleaseEnterPanNumErrorMsg()))
		{
			System.out.println("Entering pan second time");
			elePan.clear();
			elePan.sendKeys(pan);
			getKycPanUploadButton().click();
		}
		//getKycPanField().sendKeys(pan);
		
		baseTestSuite.verifyPresent(getPanProofGuideLinesPopup(),"Pan Card proof guidelines");
		getIdProofGuideLinesPopupOkButton().click();
		baseTestSuite.verifyPresent(getPanProofGuideLinesPopupHeader(), "Upload PAN Proof Header");
		baseTestSuite.verifyPresent(getIdProofUploadPopUpCameraIcon(), "Camera Icon");
		baseTestSuite.verifyPresent(getIdProofUploadPopUpUploadIcon(), "Upload Icon");
		getIdProofUploadPopUpCameraIcon().click();	
		if(System.getProperty("deviceName").equals("YHWSHYYT695H9LJV"))
		{
			getCameraShutterButton().click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'done')]")).click();
		
		}
		else if(System.getProperty("deviceName").equals("4d00cbf74f9a411b"))
		{
			MobileElement ele= (MobileElement) driver.findElement(By.xpath("//android.view.View[contains(@index,'0')]"));
			((AndroidDriver) driver).tap(1, ele.getCenter().getX()+800, ele.getCenter().getY(), 2);
			Thread.sleep(2000);
			driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'save')]")).click();
		}
		
		baseTestSuite.verifyText(getAttachedFileName().getText(),"1. "+userName+"_pan_card.jpg");
		getAuthorizationPopUpSubmitButton().click();
		CustomMethods.waitForElementPresent(getIdUploadSuccessPopUpHeader(),30);
		baseTestSuite.verifyPresent(getPanCardUploadSuccessPopUpHeader(),"PAN Card upload success popup");
		baseTestSuite.verifyTextPresent(getPanCardUploadSuccessMessage(),ReadDataFromProps.props.getProperty("kyc.page.pan.upload.success.message"));
		
		getPanUploadPopupOkButton().click();
		baseTestSuite.verifyTextPresent(getPanUploadStatus(),"Pending Approval");
		
		return pan;
	
	}
	
	
	public void approvePan(String userName, IdProofAction IdProofAction, String pan ) throws InterruptedException
	{
		
		updatePanCard(userName, pan); 
		JavascriptExecutor js = (JavascriptExecutor) desktopDriver;  
		//js.executeScript("document.body.style.zoom = '0.9'");
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list){
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("RM")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
		
		WebElement kycCue= desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']"));
		js.executeScript("arguments[0].click();", kycCue );
		
		//desktopDriver.findElement(By.cssSelector("a[href='kycCue.do?method=getKycCueDetailsByAceLevel']")).click();
		desktopDriver.findElement(By.cssSelector("input[value='RefreshDetails']")).click();
		desktopDriver.findElement(By.cssSelector("input#searchUserId")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[value='Submit']")).click();
		desktopDriver.findElement(By.cssSelector("span#img"+userName)).click();
		Thread.sleep(3000);
		WebElement we =desktopDriver.findElement(By.cssSelector("input[value='"+IdProofAction+"']"));

		js.executeScript("arguments[0].click();", we);
	
		if(IdProofAction.toString().equalsIgnoreCase("Accept"))
		{
		Thread.sleep(3000);
		desktopDriver.findElement(By.cssSelector("input[id='PAN']")).click();
		}
		
		desktopDriver.findElement(By.cssSelector("input[id='docId']")).sendKeys(pan);
		desktopDriver.findElement(By.cssSelector("textarea[id='comments']")).sendKeys("QA test");
		
		WebElement accept=desktopDriver.findElement(By.cssSelector("input[value='Accept'][type='submit']"));
		js.executeScript("arguments[0].click();", accept);
		
		Thread.sleep(4000);
		desktopDriver.close();
		
	}
	
	public void updatePanCard(String userName, String pan) throws InterruptedException
	{
		
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
		desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		
		JavascriptExecutor js = (JavascriptExecutor) desktopDriver;  
		js.executeScript("document.body.style.zoom = '0.9'");
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list)
		{
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
	
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
		Thread.sleep(1000);
		desktopDriver.findElement(By.cssSelector("a[href*='PanUpdate.do']")).click();
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		desktopDriver.findElement(By.cssSelector("input[id='panId']")).clear();
		desktopDriver.findElement(By.cssSelector("input[id='panId']")).sendKeys(pan);
		desktopDriver.findElement(By.cssSelector("input[value='Check Duplicity']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='panCheck']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='fName']")).sendKeys(userName+"asddf");
		desktopDriver.findElement(By.cssSelector("input[id='lName']")).sendKeys(userName+"rtgh");
		desktopDriver.findElement(By.cssSelector("img[src='Images/calendar.gif']")).click();
		new Select(desktopDriver.findElement(By.cssSelector("select[class*='ui-datepicker-year']"))).selectByVisibleText("1996");
		new Select(desktopDriver.findElement(By.cssSelector("select[class*='ui-datepicker-month']"))).selectByVisibleText("Mar");
		//WebElement cl = driver.findElement(By.xpath("//table[@class='ui-datepicker-calendar']/thead/following-sibling::tbody/tr[2]/td/a"));
	
	
		Thread.sleep(2000);
		desktopDriver.findElement(By.cssSelector("input[id='comments']")).sendKeys("asdfdasasf");;
		desktopDriver.findElement(By.cssSelector("input[value='Update']")).click();
		desktopDriver.switchTo().alert().accept();
		desktopDriver.switchTo().alert().accept();
	}
	
	public void unverifyMobileNumberFromAdmin(String userName) throws InterruptedException
	{
		
		CustomMethods customeMe=  new CustomMethods();
		desktopDriver=customeMe.launchWebBrowser();
		desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
		
		desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
		desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
		desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
		
		JavascriptExecutor js = (JavascriptExecutor) desktopDriver;  
		js.executeScript("document.body.style.zoom = '0.9'");
		List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
		for(WebElement listedOne:list)
		{
			System.out.println(listedOne.getText());
				if(listedOne.getText().equals("PLAYER")){
					Actions action = new Actions(desktopDriver);
					action.moveToElement(listedOne).build().perform();
				}
		}
	
		desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
		desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(userName);
		desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
		Thread.sleep(1000);
		desktopDriver.findElement(By.cssSelector("input[value='Unverify']")).click();
		for (String handle : desktopDriver.getWindowHandles()) 
		{
			desktopDriver.switchTo().window(handle);
		}
		desktopDriver.findElement(By.cssSelector("input[id='submitId']")).click();
		desktopDriver.switchTo().alert().accept();
		Thread.sleep(2000);
		desktopDriver.close();
		
	}
	
	
}

