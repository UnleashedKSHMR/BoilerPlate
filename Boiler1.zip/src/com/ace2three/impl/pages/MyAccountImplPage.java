package com.ace2three.impl.pages;

import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LobbyImplPage.hamburgerMenuItems;
import com.ace2three.locators.AndroidLocators.MyAccountScreenLocators;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.OCREngine;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MyAccountImplPage implements MyAccountScreenLocators{
	
	BaseTestSuite base= new BaseTestSuite();
	WebDriver driver;
	 private File imgDir;
	 
	public MyAccountImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver= driver;
		PageFactory.initElements(driver, this);
     		
	}
	
	public void launchScreen(){
		
	}
	
	@FindBy(xpath= PASSWORD_PROMPT_POP_UP)
	private WebElement passwordPromtPopUp;
	
	public WebElement getPasswordPromtPopUp(){
		return passwordPromtPopUp;
	}
	@FindBy(xpath= PASSWORD_POP_UP_FIELD)
	private WebElement passwordPopUpField;
	
	public WebElement getPasswordPopUpField(){
		return passwordPopUpField;
	}
	@FindBy(xpath= PASSWORD_POP_UP_SUBMIT_BUTTON)
	private WebElement passwordPopUpSubmitButton;
	
	public WebElement getPasswordPopUpSubmitButton(){
		return passwordPopUpSubmitButton;
	}
	
	@FindBy(xpath= MY_ACCOUNT_BUY_CHIPS)
	private WebElement myAccountBuyChips;
	
	public WebElement getMyAccountBuyChips(){
		return myAccountBuyChips;
	}
	
	@FindBy(xpath= PASSWORD_PROMPT_POP_UP_INVALID_ERROR)
	private WebElement passwordPromtPopUpInvalidError;
	
	public WebElement getPasswordPromtPopUpInvalidError(){
		return passwordPromtPopUpInvalidError;
	}
	
	@FindBy(xpath= MYACCOUNT_SECTION_INFOCUS)
	private WebElement myAccountSection;
	
	public WebElement getMyAccountSection(){
		return myAccountSection;
	}
	
	@FindBy(xpath= MYACCOUNT_SCREEN_RIGHTARROW)
	private WebElement myAccountScreenRightArrow;
	
	public WebElement getMyAccountScreenRightArrow(){
		return myAccountScreenRightArrow;
	}
	
	@FindBy(xpath= MYACCOUNT_SCREEN_LEFTARROW)
	private WebElement myAccountScreenLeftArrow;
	
	public WebElement getMyAccountScreenLeftArrow(){
		return myAccountScreenLeftArrow;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Please verify your email id and phone number')]")
	private WebElement redeemChipsNoPhoneMailAlert;
	
	public WebElement getRedeemChipsNoPhoneMailAlert(){
		return redeemChipsNoPhoneMailAlert;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
	private WebElement redeemChipsNoPhoneMailAlertOkButton;
	
	public WebElement getRedeemChipsNoPhoneMailAlertOkButton(){
		return redeemChipsNoPhoneMailAlertOkButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
	private WebElement redeemChipsNoPhoneMailAlertCancelButton;
	
	public WebElement getRredeemChipsNoPhoneMailAlertCancelButton(){
		return redeemChipsNoPhoneMailAlertCancelButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'No, thanks')]")
	private WebElement redeemChipsNoThanksButton;
	
	public WebElement getRedeemChipsNoThanksButton(){
		return redeemChipsNoThanksButton;
	}
	
	
	
	
	public void verifyMyAccountDetailsScreenDisplayed(){
		
		base.verifyPresent(getMyAccountBuyChips(), "My account details page");
	}
	
	public void launchMyAccountDetailsScreen(){
		if(System.getProperty("testEnvironment").equalsIgnoreCase("production")){
		OCREngine ocr = new OCREngine((AppiumDriver) driver);
		//location of screenshots
        File classpathRoot = new File(System.getProperty("user.dir"));
        imgDir = new File(classpathRoot, "/SourceImages");
        
		LobbyImplPage lobbyPage = new LobbyImplPage();
		
		lobbyPage.getHamburgerMenu().click();

		String MyAccount= imgDir + "/MyAccount.png";
		String AccountDetails= imgDir + "/AccountDetails.png";
		
		
		ocr.waitUntilImageExists(MyAccount, 10);
		ocr.clickByImage(MyAccount);
		ocr.waitUntilImageExists(AccountDetails, 10);
		ocr.clickByImage(AccountDetails);
		
		base.verifyPresent(passwordPromtPopUp, "enter password popup ");
		}else if(System.getProperty("testEnvironment").equalsIgnoreCase("qa")){
			LobbyImplPage lobbyImplPage = new LobbyImplPage();
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"Account Details").click();
			base.verifyPresent(passwordPromtPopUp, "enter password popup ");
		}
		
		
	}
	
	@SuppressWarnings("deprecation")
	public void launchPurchaseLimitsScreen(){
		
		if(System.getProperty("testEnvironment").equalsIgnoreCase("production")){
		OCREngine ocr = new OCREngine((AppiumDriver) driver);
		//location of screenshots
        File classpathRoot = new File(System.getProperty("user.dir"));
        imgDir = new File(classpathRoot, "/SourceImages");
        
		LobbyImplPage lobbyPage = new LobbyImplPage();
		
		lobbyPage.getHamburgerMenu().click();

		String MyAccount= imgDir + "/MyAccount.png";
		String AccountDetails= imgDir + "/AccountDetails.png";
		String PurchaseLimits= imgDir + "/PurchaseLimits.png";
		
		ocr.waitUntilImageExists(MyAccount, 10);
		ocr.clickByImage(MyAccount);
				
		Point2D AccountDetailscoords = ocr.getCoords(ocr.takeScreenshot(), AccountDetails);
		Point2D MyAccountCoords = ocr.getCoords(ocr.takeScreenshot(), MyAccount);
		
		System.out.println((int)AccountDetailscoords.getX()+(int)AccountDetailscoords.getY()+ 
				(int)MyAccountCoords.getX()+ (int)MyAccountCoords.getY());
		
		((AppiumDriver) driver).swipe((int)AccountDetailscoords.getX(),(int)AccountDetailscoords.getY(), 
				(int)MyAccountCoords.getX(), (int)MyAccountCoords.getY(), 3000);
	
		ocr.waitUntilImageExists(PurchaseLimits, 10);
		ocr.clickByImage(PurchaseLimits);
		}else if(System.getProperty("testEnvironment").equalsIgnoreCase("qa")){
			LobbyImplPage lobbyImplPage = new LobbyImplPage();
			lobbyImplPage.getHamburgerMenu().click();
			lobbyImplPage.getHamburgerMenuItem(hamburgerMenuItems.MyAccount,"Purchase Limits").click();
		}
		//base.verifyPresent(passwordPromtPopUp, "enter password popup ");
		
	}
	
	public enum Section {
		AccountDetails,Profile,RedeemChips,KYC,BankAccounts,PurchaseLimits,ChangePassword;
	}

	public void navigateToMyAccountsSection(Section SectionName) {
		
		String SectionCode = null;
			
			switch (SectionName) {
				case AccountDetails:
					SectionCode = "0";
					break;
				case Profile:
					SectionCode = "1";
					break;
				case RedeemChips:
					SectionCode = "2";
					break;
				case KYC:
					SectionCode = "3";
					break;
				case BankAccounts:
					SectionCode = "4";
					break;
				case PurchaseLimits:
					SectionCode = "5";
					break;
				case ChangePassword:
					SectionCode = "6";
					break;
			}
		
	/*	switch (SectionName) {
		case AccountDetails:
			SectionCode = "0";
			break;
		case Profile:
			SectionCode = "1";
			break;
		case KYC:
			SectionCode = "2";
			break;
		case BankAccounts:
			SectionCode = "3";
			break;
		case PurchaseLimits:
			SectionCode = "4";
			break;
		case ChangePassword:
			SectionCode = "5";
			break;
		}*/
		
			
			for(int i=0;i<=8;i++){
				String currentSectionInFocus = getMyAccountSection().getText();
				if(currentSectionInFocus.equalsIgnoreCase(SectionCode)){
					BaseTestSuite.logger.log(LogStatus.PASS, "navigated to "+ SectionName);
					break;
				}else{
					getMyAccountScreenRightArrow().click();
						if(CustomMethods.isElementPresent(getRedeemChipsNoPhoneMailAlert())){
							getRredeemChipsNoPhoneMailAlertCancelButton().click();
						}
						if(CustomMethods.isElementPresent(getRedeemChipsNoThanksButton())){
							getRedeemChipsNoThanksButton().click();
						}
				}

			}
		
	}
}

