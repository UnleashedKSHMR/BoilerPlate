package com.ace2three.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.locators.AndroidLocators.GiftVouchersPageLocators;

public class GiftVouchersImplPage implements GiftVouchersPageLocators {

	public GiftVouchersImplPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Gift Voucher')]")
	private WebElement giftVoucherHeader;
	
	public WebElement getGiftVoucherHeader(){
		return giftVoucherHeader;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Encash Voucher')]")
	private WebElement encashVoucherHeader;
	
	public WebElement getEncashVoucherHeader(){
		return encashVoucherHeader;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'in order to apply voucher code')]")
	private WebElement verifyEmailAndMobileText;
	
	public WebElement getVerifyEmailAndMobileText(){
		return verifyEmailAndMobileText;
	}
	
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'encash_voucher_heading_icon')]")
	private WebElement giftVoucherHeaderIcon;
	
	public WebElement getGiftVoucherHeaderIcon(){
		return giftVoucherHeaderIcon;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'redeem_voucher_encash_msg_tv')]")
	private WebElement giftVoucherEncashMessage;
	
	public WebElement getGiftVoucherEncashMessage(){
		return giftVoucherEncashMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvVoucherResponse')]")
	private WebElement giftVoucherErrorMessage;
	
	public WebElement getGiftVoucherErrorMessage(){
		return giftVoucherErrorMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'redeem_encash_numchips_added_tv')]")
	private WebElement gvLinkedToSpecificPlayerMessage;
	
	public WebElement getGvLinkedToSpecificPlayerMessage(){
		return gvLinkedToSpecificPlayerMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'redeem_voucher_encash_msg_tv')]")
	private WebElement claimYourGiftText;
	
	public WebElement getClaimYourGiftText(){
		return claimYourGiftText;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'etGiftVoucher')]")
	private WebElement giftVoucherCodeInputField;
	
	public WebElement getGiftVoucherCodeInputField(){
		return giftVoucherCodeInputField;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'btnApplyVoucher')]")
	private WebElement giftVoucherCodeApplyButton;
	
	public WebElement getGiftVoucherCodeApplyButton(){
		return giftVoucherCodeApplyButton;
	}
	
	@FindBy(xpath= "//android.widget.LinearLayout[contains(@resource-id,'redeem_voucher_heading_message_ll')]")
	private WebElement verifyEmailPhoneNoMessage;
	
	public WebElement getVerifyEmailPhoneNoMessage(){
		return verifyEmailPhoneNoMessage;
	}

	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'redeem_voucher_email_verify_ll_et')]")
	private WebElement emailInputField;
	
	public WebElement getEmailInputField(){
		return emailInputField;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'redeem_voucher_email_verify_ll_button')]")
	private WebElement emailVerifyButton;
	
	public WebElement getEmailVerifyButton(){
		return emailVerifyButton;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'redeem_voucher_mobile_verify_ll_et')]")
	private WebElement phoneNoinputButton;
	
	public WebElement getPhoneNoinputButton(){
		return phoneNoinputButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'redeem_voucher_mobile_verify_ll_button')]")
	private WebElement phoneNoVerifyButton;
	
	public WebElement getPhoneNoVerifyButton(){
		return phoneNoVerifyButton;
	}
	
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'redeem_voucher_verify_next_btn')]")
	private WebElement giftVoucherRedeemNextButton;
	
	public WebElement getGiftVoucherRedeemNextButton(){
		return giftVoucherRedeemNextButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvVoucherResponse')]")
	private WebElement giftVoucherSuccessMessage;
	
	public WebElement getGiftVoucherSuccessMessage(){
		return giftVoucherSuccessMessage;
	}
	

	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement tourneyRegistrationPopUpText;
	
	public WebElement getTourneyRegistrationPopUpText(){
		return tourneyRegistrationPopUpText;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
	private WebElement tourneyRegistrationButton;
	
	public WebElement getTourneyRegistrationButton(){
		return tourneyRegistrationButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
	private WebElement tourneyCancelButton;
	
	public WebElement getTourneyCancelButton(){
		return tourneyCancelButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement successfulRegisteredTourneyPopUp;
	
	public WebElement getSuccessfulRegisteredTourneyPopUp(){
		return successfulRegisteredTourneyPopUp;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
	private WebElement successfulRegisteredTourneyPopUpOkButton;
	
	public WebElement getSuccessfulRegisteredTourneyPopUpOkButton(){
		return successfulRegisteredTourneyPopUpOkButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'redeem_voucher_email_verify_ll_sent_tv')]")
	private WebElement invalidEmailErrorMessage;
	
	public WebElement getInvalidEmailErrorMessage(){
		return invalidEmailErrorMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'redeem_voucher_email_verify_ll_sent_tv')]")
	private WebElement activationLinkSentMessage;
	
	public WebElement getActivationLinkSentMessage(){
		return activationLinkSentMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'redeem_voucher_mobile_verify_sent_ll_tv')]")
	private WebElement invalidMobileErrorMessage;
	
	public WebElement getInvalidMobileErrorMessage(){
		return invalidMobileErrorMessage;
	}
	
}

