package com.ace2three.impl.pages;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import io.appium.java_client.AppiumDriver;

import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage;
import com.ace2three.app.webview.impl.pages.AddCashWebViewImplPage.paymentMethods;
import com.ace2three.base.BaseTestSuite;
import com.ace2three.base.Beforetest;
import com.ace2three.locators.AndroidLocators;
import com.ace2three.locators.AndroidLocators.LaunchPageLocators;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.ReadDataFromProps;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.StartsActivity;
import io.appium.java_client.remote.MobileCapabilityType;

public class LaunchImplPage extends BaseTestSuite implements AndroidLocators , LaunchPageLocators{

	WebDriver driver;
	
	public LaunchImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver= driver;
		PageFactory.initElements(driver, this);
        
		/*//Handling PLP Banners
		try{
			  driver.findElement(By.xpath("//android.widget.Button[@text='Cancel']")).click();
			      
		}catch(Exception e){
			 
			BaseTestSuite.logger.log(LogStatus.INFO, "No GPS pop up displayed");
		}*/
		
		//Handling Location allow pop up
		/*try{
			  driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'permission_allow_button')]")).click();
			  BaseTestSuite.logger.log(LogStatus.INFO, "Location has allowed"); 
		}catch(Exception e){
			 
			BaseTestSuite.logger.log(LogStatus.INFO, "Location allow pop has not appeared");
		}*/
		
	}
	
	public LaunchImplPage(WebDriver driver, Boolean GPS) {	
		this.driver= driver;
	}
	
	public void launchApp() throws InterruptedException{
		 Activity activity1 = new Activity("air.com.ace2three.mobile.cash", 
				 "com.ace2three.activity.SplashActivity");
			
		((AndroidDriver) driver).startActivity(activity1);
	     Thread.sleep(5000);
	     try{
	    	 
	     WebDriverWait wait = new WebDriverWait(driver, 30);
	     
	     wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//android.widget.ImageView[contains(@resource-id,'app_logo_IV')]")));
	     BaseTestSuite.logger.log(LogStatus.PASS, "APP has successfully launched"); 
	     
	     }catch(Exception e){
	    	 System.out.println(e.toString());
	    	  BaseTestSuite.logger.log(LogStatus.FAIL, "App has failed to luunch within 60 secs"); 
	    	  throw new SkipException("app not opened");
	     }
	     
	}
	
	
	@FindBy(xpath= GPS_POPUP_CLOSE)
	WebElement gpsPopupClose;
	
	public WebElement getGpsPopupCloseButton(){
		return gpsPopupClose;
	}
	
	@FindBy(xpath= GPS_POPUP_OK)
	WebElement gpsPopupOk;
	
	public WebElement getGpsPopupOk(){
		return gpsPopupOk;
	}
	@FindBy(xpath= GPS_POPUP_MESSAGE)
	WebElement gpsPopupMessage;
	
	public WebElement getGpsPopupMessage(){
		return gpsPopupMessage;
	}

@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'error')]")
private WebElement accountDisabledVerificationMessage;

public WebElement getAccountDisabledVerificationMessage(){
return accountDisabledVerificationMessage;
}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Cancel')]")
	WebElement gpsPopupCancelButton;
	
	public WebElement getGpsPopupCancelButton(){
		return gpsPopupCancelButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
	WebElement allowAccessLocationPopUp;
	
	public WebElement getAllowAccessLocationPopUp(){
		return allowAccessLocationPopUp;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'signup_referral_code_tv')]")
	WebElement haveAReferralCodeLink;
	
	public WebElement getHaveAReferralCodeLink(){
		return haveAReferralCodeLink;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'signup_referral_code')]")
	WebElement enterReferralCodeField;
	
	public WebElement getEnterReferralCodeField(){
		return enterReferralCodeField;
	}
	
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'ok')]")
	WebElement allowAccessLocationPopUpOkButton;
	
	public WebElement getAllowAccessLocationPopUpOkButton(){
		return allowAccessLocationPopUpOkButton;
	}
	
	@FindBy(xpath=LOGIN_BUTTON)
	WebElement loginButon;
	
	public WebElement getLoginButon(){
		return loginButon;
	}
	
	@FindBy(xpath=ACE2THREE_LOGO)
	private WebElement ace2threelogo;
	
	public WebElement getace2threelogo(){
		return ace2threelogo;
	}
	
	@FindBy(xpath=USERNAME_FIELD)
	private WebElement usernameField;
	
	public WebElement getUsernameField(){
		return usernameField;
	}
	
	@FindBy(xpath=PASSWORD_FIELD)
	private WebElement passwordField;
	
	public WebElement getpasswordField(){
		return passwordField;
	}
	
	@FindBy(xpath=CLICK_TO_LOGIN_BUTTON)
	private WebElement loginClickButton;
	
	public WebElement getLoginClickButton(){
		return loginClickButton;
	}
	
	@FindBy(xpath=PLP_BANNER_CLOSE)
	private WebElement plpBannerClose;
	
	public WebElement getPlpBannerClose(){
		return plpBannerClose;
	}
	
	@FindBy(xpath=REMEMBER_PASSWORD)
	private WebElement rememberPassword;
	
	public WebElement getRememberPassword(){
		return rememberPassword;
	}
	
	@FindBy(xpath=FORGOT_PASSWORD)
	private WebElement forgotPassword;
	
	public WebElement getForgotPassword(){
		return forgotPassword;
	}
	
	
	@FindBy(xpath=DO_NOT_HAVE_ACCOUNT_LINK)
	private WebElement doNotHaveAccount;
	
	public WebElement getDoNotHaveAccount(){
		return doNotHaveAccount;
	}
	
	@FindBy(xpath=SIGNUP_BUTTON)
	private WebElement signUpButton;
	
	public WebElement getSignUpButton(){
		return signUpButton;
	}
	
	@FindBy(xpath=SECURE_100_PERCENTAGE_LOGO)
	private WebElement secure100PercentageLogo;
	
	public WebElement getSecure100PercentageLogo(){
		return secure100PercentageLogo;
	}
	
	@FindBy(xpath=LEGAL_100_PERCENTAGE_LOGO)
	private WebElement legal100PercentageLogo;
	
	public WebElement getLegal100PercentageLogo(){
		return legal100PercentageLogo;
	}
	
	@FindBy(xpath=SHOW_PASSWORD)
	private WebElement showPassword;
	
	public WebElement getShowPassword(){
		return showPassword;
	}
	
	@FindBy(xpath=PASSWORD_ERROR_MESSAGE)
	private WebElement passwordErrorMessage;
	
	public WebElement getpasswordErrorMessage(){
		return passwordErrorMessage;
	}
	
	@FindBy(css=FORGOT_PASSWORD_HEADER)
	private WebElement forgotPasswordPageHeader;
	
	public WebElement getForgotPasswordPageHeader(){
		return forgotPasswordPageHeader;
	}
	@FindBy(xpath= "//android.widget.RelativeLayout[contains(@resource-id,'upgrade_title_header')]")
	private WebElement upgradePopUpTitleHeader;
	
	public WebElement getUpgradePopUpTitleHeader(){
		return upgradePopUpTitleHeader;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'upgrade_no')]")
	private WebElement upgradeRemaindMeLaterButton;
	
	public WebElement getUpgradeRemaindMeLaterButton(){
		return upgradeRemaindMeLaterButton;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'upgrade_yes')]")
	private WebElement upgradeButton;
	
	public WebElement getUpgradeButton(){
		return upgradeButton;
	}
	@FindBy(xpath=KEEPME_LOGGED)
	private WebElement keepMeLogged;
	
	public WebElement getKeepMeLogged(){
		return keepMeLogged;
	}
	
	@FindBy(xpath=MULTIPLE_INCORRECT_ATTEMPTS_ALERT)
	private WebElement multipleIncorrectAttemptsAlert;
	
	public WebElement getMultipleIncorrectAttemptsAlert(){
		return multipleIncorrectAttemptsAlert;
	}
	
	@FindBy(xpath=CLOSE_MULTIPLE_INCORRECT_ATTEMPTS_ALERT)
	private WebElement closeMultipleIncorrectAttemptsAlert;
	
	public WebElement getCloseMultipleIncorrectAttemptsAlert(){
		return closeMultipleIncorrectAttemptsAlert;
	}
	
	@FindBy(xpath=OTP_SENT_ALERT_MESSAGE)
	private WebElement otpSentAlertMessage;
	
	public WebElement getOtpSentAlertMessage(){
		return otpSentAlertMessage;
	}
	
	@FindBy(xpath=OTP_SENT_ALERT_MESSAGE_OK_BUTTON)
	private WebElement otpSentAlertMessageOkButton;
	
	public WebElement getOtpSentAlertMessageOkButton(){
		return otpSentAlertMessageOkButton;
	}
	
	@FindBy(xpath=OTP_RESENT_LINK)
	private WebElement otpReSentLink;
	
	public WebElement getOtpReSentLink(){
		return otpReSentLink;
	}
	
	@FindBy(xpath=SIGNIN_WITH_DIFFERENT_USERID)
	private WebElement signinWithDifferentUserID;
	
	public WebElement getSigninWithDifferentUserID(){
		return signinWithDifferentUserID;
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'fb_signup_mock')]")
	private WebElement signupWithFacebook;
	
	public WebElement getSignupWithFacebook(){
		return signupWithFacebook;
	}
	 @FindBy(xpath="//android.widget.TextView[contains(@text,'Sorry, Access to Ace2Three is restricted from the location specified in your profile. Know more')]")
	 private WebElement accessRestrictedDueToLocationError;

	 public WebElement getAccessRestrictedDueToLocationError(){
	 return accessRestrictedDueToLocationError;
	 }
	
	public void launchLobbyPage(String userName, String password){
		
		if (CustomMethods.isElementPresent(getLoginButon())) {
			getLoginButon().click();
		}
		getUsernameField().sendKeys(userName);
		getpasswordField().sendKeys(password);
		getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getRegularPlayerPostLoginBuyChipsPop()))
		{
			
			lobbyImplPage.getRegularPlayerPostLoginBuyChipsButton().click();
		//	driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]")).click();
		}
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		}
	
	
	public void launchLobbyPage(String userName, String password, WebDriver driver){
		
		if (CustomMethods.isElementPresent(getLoginButon())) {
			getLoginButon().click();
		}
		getUsernameField().sendKeys(userName);
		getpasswordField().sendKeys(password);
		getLoginClickButton().click();
		LobbyImplPage lobbyImplPage = new LobbyImplPage(driver);
		
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
		
		}
	public void verifyUpgradePopup() throws IOException
	{
		LaunchImplPage launchImplPage = new LaunchImplPage(driver);
		
		if(!CustomMethods.isElementPresent(launchImplPage.getUpgradePopUpTitleHeader())){
			CustomMethods.waitForUpgradePopUpPresent(launchImplPage.getUpgradePopUpTitleHeader(),2);
		}
		
		if(CustomMethods.isElementPresent(launchImplPage.getUpgradePopUpTitleHeader()))
		{
			launchImplPage.getUpgradeRemaindMeLaterButton().click();
		}else{
			
		}
		
	}
	
	public String doSignUpAndConvertToPremium() throws IOException
	{
		BaseTestSuite baseTestSuite = new BaseTestSuite();
		SignupImplPage signupimplpage = new SignupImplPage(driver);
		DateFormat dateFormat = new SimpleDateFormat("HHddMMs");
		Date date = new Date();
		dateFormat.format(date);
		Random ran = new Random();
		
		String Username= "test" + dateFormat.format(date)+ran.nextInt(50);
		
		WebDriverWait wait= new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(signupimplpage.getUsernamefield()));
		signupimplpage.getUsernamefield().sendKeys(Username);
		signupimplpage.getEmailidfield().sendKeys("em"+Username+"@ds.com");
		signupimplpage.getPasswordfield().sendKeys("Ace2three@");
		signupimplpage.getSignupbutton().click();
		// Need to add one more step
		//WebElement ace2threeHeader=driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Ace2Three')]"));
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		CustomMethods.waitForElementPresent(lobbyImplPage.getPlpBannerCloseIcon(), 15);
		lobbyImplPage.verifyPostLaunchBanners();
		//lobbyPage.verifyLobbyPageDisplayed();
		BaseTestSuite.logger.log(LogStatus.INFO, "Username is: "+ Username);
		lobbyImplPage.getAddChipsButton().click();
		AddCashWebViewImplPage addCashWebViewImplPage = new AddCashWebViewImplPage(driver);
		addCashWebViewImplPage.addCash("200", paymentMethods.MobiKwik);
		CustomMethods.waitForElementPresent(lobbyImplPage.getLevelUpAlertMessage());
		baseTestSuite.verifyPresent(lobbyImplPage.getLevelUpAlertMessage(), "level Up alert popup");
		baseTestSuite.verifyTextPresent(lobbyImplPage.getLevelUpAlertMessage(), 
		ReadDataFromProps.props.getProperty("user.first.buy.level.up.message"));
		lobbyImplPage.getLevelUpAlertOkButton().click();
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
		lobbyImplPage.verifyLobbyPageDisplayed();
			
		return Username;
		
	}
	
	public void getLoginDetailsFromAdmin(String userId, WebDriver desktopDriver) throws IOException
	{
		CustomMethods custom = new CustomMethods();
		desktopDriver=custom.launchWebBrowser();
		BaseTestSuite baseTestSuite = new BaseTestSuite();
		
		/*		desktopDriver.manage().window().maximize();*/
				
				desktopDriver.get(ReadDataFromProps.props.getProperty("admin.site.url"));
				desktopDriver.findElement(By.cssSelector("input[id='Username']")).sendKeys(ReadDataFromProps.props.getProperty("user.name"));
				desktopDriver.findElement(By.cssSelector("input[id='Password']")).sendKeys(ReadDataFromProps.props.getProperty("password.input"));
				desktopDriver.findElement(By.cssSelector("table.loginpattern tr td input[id='loginsubmit']")).click();
				JavascriptExecutor executor = (JavascriptExecutor)desktopDriver;
				executor.executeScript("document.body.style.zoom = '0.9'");
				
				List<WebElement>  list =desktopDriver.findElements(By.cssSelector("#cssmenu .has-sub span"));
				for(WebElement listedOne:list){
					System.out.println(listedOne.getText());
						if(listedOne.getText().equals("PLAYER")){
							Actions action = new Actions(desktopDriver);
							action.moveToElement(listedOne).build().perform();
						}
				}
				desktopDriver.findElement(By.cssSelector("a[href='userProfile.jsp']")).click();
				//desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys("nani2");
				desktopDriver.findElement(By.cssSelector("input[id='useridauto']")).sendKeys(userId);
				desktopDriver.findElement(By.cssSelector("input[name='Search']")).click();
				//desktopDriver.findElement(By.cssSelector("a[href='userProfileDetails.jsp?userid=nani2']")).click();
				try{
					desktopDriver.findElement(By.cssSelector("a[href='userProfileDetails.jsp?userid="+userId+"']")).click();
				}catch(Exception e){
					System.out.println("exception 11");
				}

				String beforeHandles = desktopDriver.getWindowHandle();
				desktopDriver.findElement(By.cssSelector("a[href*='loginSummary']")).click();
				Set<String> afterHandles = desktopDriver.getWindowHandles();
				for (String handle : afterHandles) {
					if (!handle.equalsIgnoreCase(beforeHandles)) {
						desktopDriver.switchTo().window(handle);
					}
				}
				System.out.println(desktopDriver
						.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[1]")).getText());
				logger.log(LogStatus.INFO, desktopDriver
						.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[1]")).getText());
				System.out.println(desktopDriver
						.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[3]")).getText());
				logger.log(LogStatus.INFO, desktopDriver
						.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[3]")).getText());
				WebElement stateEle = desktopDriver
						.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[7]"));
				System.out.println(stateEle.getText());
				baseTestSuite.verifyText(stateEle.getText(), "Telangana");
				logger.log(LogStatus.INFO, desktopDriver
						.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[7]")).getText());
				String stateElementText = desktopDriver.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[7]")).getText();
				String loginSourceElement = desktopDriver.findElement(By.xpath("//td[@class='tdpadding' and text()='1']/following-sibling::td[5]")).getText();
				verifyText(loginSourceElement, "APS");
				verifyText(stateElementText, "Telangana");
				desktopDriver.close();
				desktopDriver.switchTo().window(beforeHandles);
				desktopDriver.close();
	}
	
	
	
}
