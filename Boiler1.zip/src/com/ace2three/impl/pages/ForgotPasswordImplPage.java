package com.ace2three.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.locators.AndroidLocators.ForgotPasswordLocators;
import com.ace2three.locators.AndroidLocators.LaunchPageLocators;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ForgotPasswordImplPage implements ForgotPasswordLocators,LaunchPageLocators {
	
	WebDriver driver;

	public ForgotPasswordImplPage(WebDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		this.driver= driver;
	}

	@FindBy(xpath=FORGOT_PASSWORD)
	private WebElement forgotPassword;
	
	public WebElement getForgotPassword(){
		return forgotPassword;
	}
	
	@FindBy(xpath=FORGOT_PASSWORD_WEB_CLOSE_BUTTON)
	private WebElement forgotPasswordMwebCloseButton;
	
	public WebElement getForgotPasswordMwebCloseButton(){
		return forgotPasswordMwebCloseButton;
	}
	@FindBy(xpath=FORGOT_PASSWORD_MWEB_USER_ID_FIELD)
	private WebElement forgotPasswordMwebUserNameField;
	
	public WebElement getForgotPasswordMwebUserNameField(){
		return forgotPasswordMwebUserNameField;
	}
	@FindBy(xpath=FORGOT_PASSWORD_MWEB_EMAIL_OR_MOBILE_NUMBER_FIELD)
	private WebElement forgotPasswordMwebEmailOrMobileNoField;
	
	public WebElement getForgotPasswordMwebEmailOrMobileNoField(){
		return forgotPasswordMwebEmailOrMobileNoField;
	}
	@FindBy(xpath=FORGOT_PASSWORD_MWEB_SUBMIT_BUTTON)
	private WebElement forgotPasswordMwebSubmitButton;
	
	public WebElement getForgotPasswordMwebSubmitButton(){
		return forgotPasswordMwebSubmitButton;
	}
	@FindBy(xpath=FORGOT_PASSWORD_STATUS_FIELD)
	private WebElement forgotPasswordMwebStatusField;
	
	public WebElement getForgotPasswordMwebStatusField(){
		return forgotPasswordMwebStatusField;
	}
	@FindBy(xpath=FORGOT_PASSWORD_ENTER_EMAIL_ID)
	private WebElement forgotPasswordEnterEmailId;
	
	public WebElement getForgotPasswordEnterEmailId(){
		return forgotPasswordEnterEmailId;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'User Id cannot be empty.')]")
	private WebElement fpUserIdCannotBeEmptyStatus;
	
	public WebElement getFpUserIdCannotBeEmptyStatus(){
		return fpUserIdCannotBeEmptyStatus;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'User Id should be between 4 to 12 characters long.')]")
	private WebElement fpUserIdShouldBeBtwStatusField;
	
	public WebElement getFpUserIdShouldBeBtwStatusField(){
		return fpUserIdShouldBeBtwStatusField;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'User Id should start with an alphabet.')]")
	private WebElement fpUserIdShouldStartAlpha;
	
	public WebElement getFpUserIdShouldStartAlpha(){
		return fpUserIdShouldStartAlpha;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'User Id can contain alphabets and numbers only.')]")
	private WebElement fpUserIdContainAlphaAndNumberStatus;
	
	public WebElement getFpUserIdContainAlphaAndNumberStatus(){
		return fpUserIdContainAlphaAndNumberStatus;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'Please enter the correct Email ID')]")
	private WebElement fpEnterCrtUserIdAndEmail;
	
	public WebElement getFpEnterCrtUserIdAndEmail(){
		return fpEnterCrtUserIdAndEmail;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'Please enter the correct Mobile Number')]")
	private WebElement fpEnterCrtUserIdAndMobileNo;
	
	public WebElement getFpEnterCrtUserIdAndMobileNo(){
		return fpEnterCrtUserIdAndMobileNo;
	}
	@FindBy(xpath=FORGOT_PASSWORD_RESEND_OTP_LINK)
	private WebElement forgotPasswordResendOTPLink;
	
	public WebElement getForgotPasswordResendOTPLink(){
		return forgotPasswordResendOTPLink;
	}
	@FindBy(xpath=FORGOT_PASSWORD_STILL_OTP_NOT_RECEIVED_MESSAGE)
	private WebElement forgotPasswordOTPNotReceived;
	
	public WebElement getForgotPasswordOTPNotReceived(){
		return forgotPasswordOTPNotReceived;
	}
	@FindBy(xpath=FORGOT_PASSWORD_CONFIRM_BUTTON)
	private WebElement forgotPasswordConfirmButton;
	
	public WebElement getForgotPasswordConfirmButton(){
		return forgotPasswordConfirmButton;
	}
	@FindBy(xpath=FORGOT_USER_ID_LINK)
	private WebElement forgotUserIdMwebLink;
	
	public WebElement getForgotUserIdMwebLink(){
		return forgotUserIdMwebLink;
	}
	@FindBy(xpath=FORGOT_PASSWORD_ENTER_OTP_FIELD)
	private WebElement enterOTPfield;
	
	public WebElement getEnterOTPfield(){
		return enterOTPfield;
	}
	@FindBy(xpath=FORGOT_PASSWORD_NEW_PASSWORD_FIELD)
	private WebElement newPasswordField;
	
	public WebElement getNewPasswordField(){
		return newPasswordField;
	}
	
	@FindBy(xpath=FORGOT_PASSWORD_CONFIRM_PASSWORD_FIELD)
	private WebElement confirmPasswordField;
	
	public WebElement getConfirmPasswordField(){
		return confirmPasswordField;
	}
	@FindBy(xpath=FORGOT_PASSWORD_RESET_PASSWORD_BUTTON)
	private WebElement resetPasswordButton;
	
	public WebElement getResetPasswordButton(){
		return resetPasswordButton;
	}
	@FindBy(xpath=FORGOT_PASSWORD_MWEB_SUCCESS_STATUS)
	private WebElement pswdChangedSuccessfullyStatusText;
	
	public WebElement getPswdChangedSuccessfullyStatusText(){
		return pswdChangedSuccessfullyStatusText;
	}
	
	
}
