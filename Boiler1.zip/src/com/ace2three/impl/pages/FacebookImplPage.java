package com.ace2three.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FacebookImplPage {

	WebDriver driver;
	public FacebookImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_alert_description')]")
	WebElement linkYourAccountAlert;
	
	public WebElement getLinkYourAccountAlert(){
		return linkYourAccountAlert;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_yes_text')]")
	WebElement yesIamButton;
	
	public WebElement getYesIamButton(){
		return yesIamButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_no_text')]")
	WebElement noIamNotButton;
	
	public WebElement getNoIamNotButton(){
		return noIamNotButton;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_alert_description')]")
	WebElement createUserNameMessage;
	
	public WebElement getCreateUserNameMessage(){
		return createUserNameMessage;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'fb_enter_uname_et')]")
	WebElement createUserNameField;
	
	public WebElement getCreateUserNameField(){
		return createUserNameField;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_yes_text')]")
	WebElement createUserSubmitButton;
	
	public WebElement getCreateUserSubmitButton(){
		return createUserSubmitButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_alert_description')]")
	WebElement successfullyCreatedAccountMessage;
	
	public WebElement getSuccessfullyCreatedAccountMessage(){
		return successfullyCreatedAccountMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Please enter your Email address / Mobile Number')]")
	WebElement enterEmailOrPhoneAlertWhenEmailNotGiven;
	
	public WebElement getEnterEmailOrPhoneAlertWhenEmailNotGiven(){
		return enterEmailOrPhoneAlertWhenEmailNotGiven;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'fb_enter_email_et')]")
	WebElement enterEmailOrPhoneAlertFieldWhenEmailNotGiven;
	
	public WebElement getEnterEmailOrPhoneAlertFieldWhenEmailNotGiven(){
		return enterEmailOrPhoneAlertFieldWhenEmailNotGiven;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_yes_text')]")
	WebElement enterEmailOrPhoneAlertSubmitWhenEmailNotGiven;
	
	public WebElement getEnterEmailOrPhoneAlertSubmitWhenEmailNotGiven(){
		return enterEmailOrPhoneAlertSubmitWhenEmailNotGiven;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_already_text')]")
	WebElement alreadyHaveAccountLinkWhenEmailNotGiven;
	
	public WebElement getAlreadyHaveAccountLinkWhenEmailNotGiven(){
		return alreadyHaveAccountLinkWhenEmailNotGiven;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Enter your Ace2Three credentials to link your facebook and Ace2Three accounts')]")
	WebElement linkFacebookWithAce2threeAlertMessage;
	
	public WebElement getLinkFacebookWithAce2threeAlertMessage(){
		return linkFacebookWithAce2threeAlertMessage;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'fb_enter_uname_et')]")
	WebElement linkFacebookWithAce2threeAlertUserName;
	
	public WebElement getLinkFacebookWithAce2threeAlertUserName(){
		return linkFacebookWithAce2threeAlertUserName;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'fb_enter_password_et')]")
	WebElement linkFacebookWithAce2threeAlertPassword;
	
	public WebElement getLinkFacebookWithAce2threeAlertPassword(){
		return linkFacebookWithAce2threeAlertPassword;
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_yes_text')]")
	WebElement linkFacebookWithAce2threeAlertLoginButton;
	
	public WebElement getLinkFacebookWithAce2threeAlertLoginButton(){
		return linkFacebookWithAce2threeAlertLoginButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'fb_close')]")
	WebElement closeFbDialogBox;
	
	public WebElement getCloseFbDialogBox(){
		return closeFbDialogBox;
	}
	
}
