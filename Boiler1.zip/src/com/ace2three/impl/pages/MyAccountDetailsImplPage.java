package com.ace2three.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.locators.AndroidLocators.MyAccountDetailsPage;
import com.ace2three.locators.AndroidLocators.MyAccountScreenLocators;
import com.ace2three.locators.AndroidLocators.MyProfileScreenLocators;

public class MyAccountDetailsImplPage implements MyAccountDetailsPage{

	public MyAccountDetailsImplPage(WebDriver driver) {
	
		PageFactory.initElements(driver, this);
	}

	public void verifyMyAcountDetailsPageeIsDisplayed(){
		
	//	base.verifyPresent(getMyProfileFirstNameField(), "short Profile details page");
	}
	
	@FindBy(xpath= REDEEM_BUTTON)
	private WebElement redeemButton;
	
	public WebElement getRedeemButton(){
		return redeemButton;
	}
	
	@FindBy(xpath= BUY_CHIPS_BUTTON)
	private WebElement buyChipsButton;
	
	public WebElement getBuyChipsButton(){
		return buyChipsButton;
	}
	
	@FindBy(xpath= ACE_LEVEL_UPGRADE_VALUE)
	private WebElement aceLevelUpgradeValue;
	
	public WebElement getAceLevelUpgradeValue(){
		return aceLevelUpgradeValue;
	}
	
	@FindBy(xpath= ACE_LEVEL_UPGRADE)
	private WebElement aceLevelUpgrade;
	
	public WebElement getAceLevelUpgrade(){
		return aceLevelUpgrade;
	}

	@FindBy(xpath= ACE_LEVEL)
	private WebElement aceLevel;
	
	public WebElement getAceLevel(){
		return aceLevel;
	}

	@FindBy(xpath= ACE_POINTS_BALANCE)
	private WebElement acePointsBalance;
	
	public WebElement getAcePointsBalance(){
		return acePointsBalance;
	}

	@FindBy(xpath= REAL_CHIPS_REDEEMABLE_BALANCE)
	private WebElement realChipsRedeemableBalance;
	
	public WebElement getRealChipsRedeemableBalance(){
		return realChipsRedeemableBalance;
	}

	@FindBy(xpath= REAL_CHIPS_BALANCE)
	private WebElement realChipsBalance;
	
	public WebElement getRealChipsBalance(){
		return realChipsBalance;
	}
	
	@FindBy(xpath= REDEEM_ACE_POINTS_BUTTON)
	private WebElement redeemAcePointsButton;
	
	public WebElement getRedeemAcePointsButton(){
		return redeemAcePointsButton;
	}
	
	@FindBy(xpath= WEB_REDIRECT_ALERT_FOR_REDEEM_YES)
	private WebElement redirectAlertForRedeemYes;
	
	public WebElement getredirectAlertForRedeemYes(){
		return redirectAlertForRedeemYes;
	}
	@FindBy(xpath= THIS_FEATURE_IS_AVAILABLE_ONLY_FOR_PREMIUM_PLAYERS_MESSAGE)
	private WebElement thisFeatureIsOnlyForPremiumPlayer;
	
	public WebElement getThisFeatureIsOnlyForPremiumPlayer(){
		return thisFeatureIsOnlyForPremiumPlayer;
	}
	
	@FindBy(xpath= WEB_REDIRECT_ALERT_FOR_REDEEM_MESSAGE)
	private WebElement redirectAlertForRedeemMessage;
	
	public WebElement getredirectAlertForRedeemMessage(){
		return redirectAlertForRedeemMessage;
	}
	
	@FindBy(xpath= WEB_REDIRECT_ALERT_FOR_REDEEM_NO)
	private WebElement redirectAlertForRedeemNo;
	
	public WebElement getredirectAlertForRedeemNo(){
		return redirectAlertForRedeemNo;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvClickHere')]")
	private WebElement kycLink;
	
	public WebElement getKycLink(){
		return kycLink;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Re-check')]")
	private WebElement reCheckButton;
	
	public WebElement getReCheckButton(){
		return reCheckButton;
	}
	
	@FindBy(xpath= "//android.widget.CheckBox[contains(@resource-id,'agree')]")
	private WebElement acknowledgeCheckBox;
	
	public WebElement getAcknowledgeCheckBox(){
		return acknowledgeCheckBox;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Add Cash')]")
	private WebElement addCashButton;
	
	public WebElement getAddCashButton(){
		return addCashButton;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'p_custom_amount')]")
	private WebElement addAmountField;
	
	public WebElement getAddAmountField(){
		return addAmountField;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Your last used payment mode')]")
	private WebElement lastPaymentMethod;
	
	public WebElement getLastPaymentMethod(){
		return lastPaymentMethod;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'PAY NOW')]")
	private WebElement payNowButton;
	
	public WebElement getPayNowButton(){
		return payNowButton;
	}
	

	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'choosePayment')]")
	private WebElement changePaymentMode;
	
	public WebElement getChangePaymentMode(){
		return changePaymentMode;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Net Banking')]")
	private WebElement netBankingOption;
	
	public WebElement getNetBankingOption(){
		return netBankingOption;
	}
	@FindBy(xpath= "//android.view.View[contains(@text,'AXIS Bank')]")
	private WebElement axisBankOption;
	
	public WebElement getAxisBankOption(){
		return axisBankOption;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Axis PAY')]")
	private WebElement axisPayButton;
	
	public WebElement getAxisPayButton(){
		return axisPayButton;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Congratulations')]")
	private WebElement chipsAddedSuccesMessage;
	
	public WebElement getChipsAddedSuccesMessage(){
		return chipsAddedSuccesMessage;
	}
	
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'closeIv')]")
	private WebElement closeBuyChipsWebview;
	
	public WebElement getCloseBuyChipsWebview(){
		return closeBuyChipsWebview;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement redeemOnlyForPremiumPlayersDialog;
	
	public WebElement getRedeemOnlyForPremiumPlayersDialog(){
		return redeemOnlyForPremiumPlayersDialog;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'No, thanks')]")
	private WebElement redeemOnlyForPremiumPlayersDialogNoThanks;
	
	public WebElement getRedeemOnlyForPremiumPlayersDialogNoThanks(){
		return redeemOnlyForPremiumPlayersDialogNoThanks;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Buy Chips')]")
	private WebElement redeemOnlyForPremiumPlayersDialogBuyChips;
	
	public WebElement getRedeemOnlyForPremiumPlayersDialogBuyChips(){
		return redeemOnlyForPremiumPlayersDialogBuyChips;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'tvClickHere')]")
	private WebElement kycClickHereLink;
	
	public WebElement getKycClickHereLink(){
		return kycClickHereLink;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'myaccount_total_bonuspending_value')]")
	private WebElement bonusPendingValue;
	
	public WebElement getBonusPendingValue(){
		return bonusPendingValue;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'myaccount_claimnow')]")
	private WebElement claimNowLink;
	
	public WebElement getClaimNowLink(){
		return claimNowLink;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement youNeedToBeAPremiumUserPopUp;
	
	public WebElement getYouNeedToBeAPremiumUserPopUp(){
		return youNeedToBeAPremiumUserPopUp;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Buy Now')]")
	private WebElement buyNowButton;
	
	public WebElement getBuyNowButton(){
		return buyNowButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Not now')]")
	private WebElement notNowButton;
	
	public WebElement getNotNowButton(){
		return notNowButton;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'myaccount_et_refcode')]")
	private WebElement enterReferralCodeField;
	
	public WebElement getEnterReferralCodeField(){
		return enterReferralCodeField;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'myaccount_applyrefcode')]")
	private WebElement applyButton;
	
	public WebElement getApplyButton(){
		return applyButton;
	}
	
	/*@FindBy(css= "")
	private WebElement redirectAlertForRedeemNo;
	
	public WebElement getredirectAlertForRedeemNo(){
		return redirectAlertForRedeemNo;
	}*/
	
}
