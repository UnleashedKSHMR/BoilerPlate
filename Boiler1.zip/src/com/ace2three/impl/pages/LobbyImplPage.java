package com.ace2three.impl.pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.locators.AndroidLocators.LobbyPageLocators;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class LobbyImplPage implements LobbyPageLocators{
	BaseTestSuite baseTestSuite = new BaseTestSuite();
	Date date;
	WebDriver driver;
	DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
	public LobbyImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
		//Handling change password pop up
		try{
			  driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'bt_pwd_nw')]")).click();
			  BaseTestSuite.logger.log(LogStatus.PASS, "Change password pop has displayed");
		}catch(Exception e){
			 
			//BaseTestSuite.logger.log(LogStatus.INFO, "Change password pop has not displayed");
		}
		
		//Handling PLP Banners
		try{
			  driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]")).click();
			  BaseTestSuite.logger.log(LogStatus.PASS, "PLP banner displayed and closed");
		}catch(Exception e){
			 
			BaseTestSuite.logger.log(LogStatus.INFO, "No PLP banner displayed");
		}
		
		//Handling pseudo Banners
		try{
			  driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'closeBtn')]")).click();
			  BaseTestSuite.logger.log(LogStatus.PASS, "pseudo banner");
		}catch(Exception e){
			 
			//BaseTestSuite.logger.log(LogStatus.INFO, "No PLP banner displayed");
		}
		try{
			  driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeBtn')]")).click();
			  BaseTestSuite.logger.log(LogStatus.PASS, "sign up banner banner");
		}catch(Exception e){
			 
			//BaseTestSuite.logger.log(LogStatus.INFO, "No PLP banner displayed");
		}
		
	}
	
	
	
	public void verifyPostLaunchBanners(){
		
		//Handling change password pop up
				try{
					  driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'bt_pwd_nw')]")).click();
					  BaseTestSuite.logger.log(LogStatus.PASS, "Change password pop has displayed");
				}catch(Exception e){
					 
					//BaseTestSuite.logger.log(LogStatus.INFO, "Change password pop has not displayed");
				}
				
				//Handling PLP Banners
				try{
					  driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]")).click();
					  BaseTestSuite.logger.log(LogStatus.PASS, "PLP banner displayed and closed");
				}catch(Exception e){
					 
					BaseTestSuite.logger.log(LogStatus.INFO, "No PLP banner displayed");
				}
				
				//Handling pseudo Banners
				try{
					  driver.findElement(By.xpath("//android.widget.TextView[contains(@resource-id,'closeBtn')]")).click();
					  BaseTestSuite.logger.log(LogStatus.PASS, "pseudo banner");
				}catch(Exception e){
					 
					//BaseTestSuite.logger.log(LogStatus.INFO, "No PLP banner displayed");
				}
		
	}
	public LobbyImplPage() {
		this.driver=baseTestSuite.driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="//android.widget.ImageView[contains(@resource-id,'closeIv')]")
	private WebElement plpBannerCloseIcon;
	
	public WebElement getPlpBannerCloseIcon(){
		return plpBannerCloseIcon;
	}
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'closeBtn')]")
	private WebElement psuedoBannerCloseIcon;
	
	public WebElement getPsuedoBannerCloseIcon(){
		return psuedoBannerCloseIcon;
	}
	
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'ok')]")
	private WebElement makeRealPurchaseBuyChipsButton;
	
	public WebElement getMakeRealPurchaseBuyChipsButton(){
		return makeRealPurchaseBuyChipsButton;
	}
	
	@FindBy(xpath=USER_NAME_DISPLAY)
	private WebElement userNameDisplay;
	
	public WebElement getUserNameDisplay(){
		return userNameDisplay;
	}
	
	@FindBy(xpath=HAM_BURGER_MENU)
	private WebElement hamburgerMenu;
	
	public WebElement getHamburgerMenu(){
		return hamburgerMenu;
	}
	
	@FindBy(xpath=UPDATE_PROFILE_WEB_POPUP_HEADER)
	private WebElement updateProfilePopUpHeader;
	
	public WebElement getUpdateProfilePopUpHeader(){
		return updateProfilePopUpHeader;
	}
	
	@FindBy(xpath=UPDATE_PROFILE_WEB_POPUP_CLOSE_BUTTON)
	private WebElement updateProfilePopUpClose;
	
	public WebElement getUpdateProfilePopUpClose(){
		return updateProfilePopUpClose;
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement verifyEmailPhoneNoPopUp;
	
	public WebElement getVerifyEmailPhoneNoPopUp(){
		return verifyEmailPhoneNoPopUp;
	}
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'yes')]")
	private WebElement verifyNowButton;
	
	public WebElement getVerifyNowButton(){
		return verifyNowButton;
	}
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'no')]")
	private WebElement laterButton;
	
	public WebElement getLaterButton(){
		return laterButton;
	}
	@FindBy(xpath=REGULAR_PLAYER_POST_LOGIN_BUY_CHIPS_POP)
	private WebElement regularPlayerPostLoginBuyChipsPop;
	
	public WebElement getRegularPlayerPostLoginBuyChipsPop(){
		return regularPlayerPostLoginBuyChipsPop;
	}
	@FindBy(xpath=REGULAR_PLAYER_POST_LOGIN_BUY_CHIPS_BUTTON)
	private WebElement regularPlayerPostLoginBuyChipsButton;
	
	public WebElement getRegularPlayerPostLoginBuyChipsButton(){
		return regularPlayerPostLoginBuyChipsButton;
	}
	
	@FindBy(xpath=SIGN_UP_BANNER_POP_UP)
	private WebElement signUpBannerPopUpClose;
	
	public WebElement getSignUpBannerPopUpClose(){
		return signUpBannerPopUpClose;
	}
	
	@FindBy(xpath=THANK_YOU_FOR_SIGN_UP_MESSAGE)
	private WebElement thankYouForSignUpMessage;
	
	public WebElement getThankYouForSignUpMessage(){
		return thankYouForSignUpMessage;
	}
	
	@FindBy(xpath=SIGNUP_SUCCESSFUL_BANNER_NO_THANKS)
	private WebElement signUpSuccessBannerNoThanksButton;
	
	public WebElement getSignUpSuccessBannerNoThanksButton(){
		return signUpSuccessBannerNoThanksButton;
	}
	
	@FindBy(xpath=SIGNUP_SUCCESSFUL_BANNER_BUY_CHIPS)
	private WebElement signUpSuccessBuyChipsButton;
	
	public WebElement getSignUpSuccessBuyChipsButton(){
		return signUpSuccessBuyChipsButton;
	}
	
	@FindBy(xpath=HAM_BURGER_MENU_ITEM)
	private WebElement hamBurgerMenuListItem;
	
	public WebElement getHamBurgerMenuListItem(){
		return hamBurgerMenuListItem;
	}
	
	@FindBy(xpath=HOME_TAB_ICON_BOTTOM)
	private WebElement homeTabIcon;
	
	public WebElement getHomeTabIcon(){
		return homeTabIcon;
	}
	
	@FindBy(xpath="//android.widget.ImageView[contains(@resource-id,'gamesIV')]")
	private WebElement gamesTabIcon;
	
	public WebElement getgamesTabIcon(){
		return gamesTabIcon;
	}
	
	@FindBy(xpath="//android.widget.ImageView[contains(@resource-id,'activetablesIV')]")
	private WebElement activeTablesTab;
	
	public WebElement getActiveTablesTab(){
		return activeTablesTab;
	}
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'activegametype1')]")
	private WebElement activeTable1GameType;
	
	public WebElement getActiveTable1(){
		return activeTable1GameType;
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'activegametype1')]/following-sibling::android.widget.TextView")
	private WebElement activeTable1BetAmount;
	
	public WebElement getActiveTable1BetAmount(){
		return activeTable1BetAmount;
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'activegametype3')]")
	private WebElement activeTable2;
	
	public WebElement getActiveTable2(){
		return activeTable2;
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'activegametype1')]/following-sibling::android.widget.TextView")
	private WebElement activeTable2BetAmount;
	
	public WebElement getActiveTable2BetAmount(){
		return activeTable2BetAmount;
	}
	
	@FindBy(xpath=SIGN_OUT_POP_UP_MESSASGE)
	private WebElement logoutAlertPopupMessage;
	
	public WebElement getLogoutAlertPopupMessage(){
		return logoutAlertPopupMessage;
	}
	
	@FindBy(xpath=SIGN_OUT_POP_UP_YES_BUTTON)
	private WebElement logoutAlertPopupYesButton;
	
	public WebElement getLogoutAlertPopupYesButton(){
		return logoutAlertPopupYesButton;
	}
	
	@FindBy(xpath=SIGN_OUT_POP_UP_NO_BUTTON)
	private WebElement logoutAlertPopupNoButton;
	
	public WebElement getLogoutAlertPopupNoButton(){
		return logoutAlertPopupNoButton;
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'real_chips_tv')]")
	private WebElement noOfRealChipsCount;
	
	public WebElement getNoOfRealChipsCount(){
		return noOfRealChipsCount;
	}
	
	@FindBy(xpath="//android.widget.ImageView[contains(@resource-id,'add_chips_iv')]")
	private WebElement addChipsButton;
	
	public WebElement getAddChipsButton(){
		return addChipsButton;
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@resource-id,'statusalert')]")
	private WebElement levelUpAlertMessage;
	
	public WebElement getLevelUpAlertMessage(){
		return levelUpAlertMessage;
	}
	
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'ok')]")
	private WebElement levelUpAlertOkButton;
	
	public WebElement getLevelUpAlertOkButton(){
		return levelUpAlertOkButton;
	}
	
	@FindBy(xpath="//android.widget.Button[contains(@text,'Send OTP')]")
	private WebElement sendOTPButton;
	
	public WebElement getSendOTPButton(){
		return sendOTPButton;
	}
	@FindBy(xpath="//android.widget.EditText[contains(@resource-id,'otp_message_entry')]")
	private WebElement enterOTPField;
	
	public WebElement getEnterOTPField(){
		return enterOTPField;
	}
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'otp_message_button')]")
	private WebElement confirmOTPButton;
	
	public WebElement getConfirmOTPButton(){
		return confirmOTPButton;
	}
	@FindBy(xpath="//android.widget.Button[contains(@text,'Take me to Lobby')]")
	private WebElement takeMeToLobbyButton;
	
	public WebElement getTakeMeToLobbyButton(){
		return takeMeToLobbyButton;
	}
	@FindBy(xpath="//android.widget.Button[contains(@text,'OK')]")
	private WebElement achievedBroonzeLevelOkButton;
	
	public WebElement getAchievedBroonzeLevelOkButton(){
		return achievedBroonzeLevelOkButton;
	}
	
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'negativeBtn')]")
	private WebElement noThanksButton;
	
	public WebElement getNoThanksButton(){
		return noThanksButton;
	}
	
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'bt_pwd_nw')]")
	private WebElement changePasswordNoThanksButton;
	
	public WebElement getChangePasswordNoThanksButton(){
		return changePasswordNoThanksButton;
	}
	@FindBy(xpath="//android.widget.ImageView[contains(@resource-id,'tourneysIV')]")
	private WebElement tourneyButton;
	
	public WebElement getTourneyButton(){
		return tourneyButton;
	}
	
	public void verifyLobbyPageDisplayed(){
		//Handling PLP Banners
				/*try{
					baseTestSuite.driver.findElement(By.xpath("//android.widget.ImageView[contains(@resource-id,'closeIv')]")).click();
					  BaseTestSuite.logger.log(LogStatus.PASS, "PLP banner displayed and closed");
				}catch(Exception e){
					 
					BaseTestSuite.logger.log(LogStatus.INFO, "No PLP banner displayed");
				}finally{
				
				}*/
		
		
		date = new Date();
		baseTestSuite.verifyPresent(getUserNameDisplay(), "Lobby page");
	}
	
	
	public enum hamburgerMenuItems{
		MyAccount,Promotions,GameSettings,AboutUs,Logout;
	}
	
	@SuppressWarnings("deprecation")
	public WebElement getHamburgerMenuItem(hamburgerMenuItems item,String subItem){
			
		String locator="//android.widget.TextView[contains(@text,'%s')]";
		String subItemLoctor= String.format(locator, subItem);
		
		WebElement Element = null ; 
			switch(item){
				case MyAccount:
					driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'My Account')]")).click();
					
					if(("Purchase Limits:Change Password").contains(subItem)){
						Point AccountnAccount = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'My Account')]")).getLocation();
						Point profile = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Profile')]")).getLocation();
						
						System.out.println((int)profile.getX()+(int)profile.getY()+ 
								(int)AccountnAccount.getX()+ (int)AccountnAccount.getY());
						
						((AppiumDriver) driver).swipe((int)profile.getX(),(int)profile.getY(), 
								(int)AccountnAccount.getX(), (int)AccountnAccount.getY(), 3000);
					}
					Element= driver.findElement(By.xpath(subItemLoctor));
						break;
					case Promotions:
						driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Promotions')]")).click();
						Element= driver.findElement(By.xpath(subItemLoctor));
						break;
					case GameSettings:
						Element= driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Game Settings')]"));
						//Element= driver.findElement(By.xpath(subItemLoctor));
						break;
					case AboutUs:
						driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'About Us')]")).click();
						Element= driver.findElement(By.xpath(subItemLoctor));
						break;
					case Logout:
						Element= driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Logout')]"));
						break;
				}
		
			return Element;
	}
	
	public String getActiveTable1BetAmountValue(){
		Character ch = '.';
		String betAmount = getActiveTable1BetAmount().getText();
	    int length = betAmount.length();
	    String amountValue = "";
	    for (int i = 0; i < length; i++) {
	        Character character = betAmount.charAt(i);
	        if (Character.isDigit(character) || character.compareTo(ch)==0) {
	        	amountValue += character;
	        }
	    }
	    System.out.println("result is: " + amountValue);
		return amountValue.trim();
	    
	}
	
}
