package com.ace2three.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.locators.AndroidLocators.KycScreeenLocators;
import com.ace2three.locators.AndroidLocators.MyProfileScreenLocators;
import com.ace2three.utils.CustomMethods;

public class MyProfileImplPage extends MyAccountImplPage implements MyProfileScreenLocators {

	public MyProfileImplPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void verifyProfilePageIsDisplayed(){
		
		base.verifyPresent(getMyProfileFirstNameField(), "short Profile details page");
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Connect with Facebook')]")
	private WebElement connectWithFacebookButton;
	
	public WebElement getConnectWithFacebookButton(){
		return connectWithFacebookButton;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Your Facebook account is successfully linked with your ace2three account')]")
	private WebElement connectWithFbSuccessMessage;
	
	public WebElement getConnectWithFbSuccessMessage(){
		return connectWithFbSuccessMessage;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'OK')]")
	private WebElement connectFromFBSuccessOkButton;
	
	public WebElement getconnectFromFBSuccessOkButton(){
		return connectFromFBSuccessOkButton;
	}

	@FindBy(xpath= PASSWORD_PROMPT_POP_UP)
	private WebElement passwordPromtPopUp;
	
	public WebElement getPasswordPromtPopUp(){
		return passwordPromtPopUp;
	}
	
	@FindBy(xpath= MYPROFILE_FIRST_NAME_LOC)
	private WebElement myProfileFirstNameField;
	
	public WebElement getMyProfileFirstNameField(){
		return myProfileFirstNameField;
	}
	
	@FindBy(xpath= MYPROFILE_LAST_NAME_LOC)
	private WebElement myProfileLastNameField;
	
	public WebElement getMyProfileLastNameField(){
		return myProfileLastNameField;
	}
	
	@FindBy(xpath= MYPROFILE_DOB_FIELD_LOC)
	private WebElement myProfileDOBField;
	
	public WebElement getMyProfileDOBField(){
		return myProfileDOBField;
	}
	
	@FindBy(xpath= MYPROFILE_GENDER_FIELD_LOC)
	private WebElement myProfileGenderField;
	
	public WebElement getMyProfileGenderField(){
		return myProfileGenderField;
	}
	
	@FindBy(xpath= MYPROFILE_STATE_FIELD_LOC)
	private WebElement myProfileStateField;
	
	public WebElement getMyProfileStateField(){
		return myProfileStateField;
	}
	
	@FindBy(xpath= MYPROFILE_CITY_FIELD_LOC)
	private WebElement myProfileCityField;
	
	public WebElement getMyProfileCityField(){
		return myProfileCityField;
	}
	
	@FindBy(xpath= MYPROFILE_SAVE_BUTTON_LOC)
	private WebElement myProfileSaveButtonLoc;
	
	public WebElement getMyProfileSaveButtonLoc(){
		return myProfileSaveButtonLoc;
	}
	
	@FindBy(xpath= MYPROFILE_ERROR_MESSAGE)
	private WebElement myProfileSaveSuccessMessage;
	
	public WebElement getMyProfileSaveSuccessMessage(){
		return myProfileSaveSuccessMessage;
	}
	
	@FindBy(xpath= MYPROFILE_ERROR_MESSAGE)
	private WebElement myProfileErrorMessage;
	
	public WebElement getMyProfileErrorMessage(){
		return myProfileErrorMessage;
	}
	
	@FindBy(xpath= MYPROFILE_CALENDER_OK_BUTTON)
	private WebElement myProfileCalenderOkButton;
	
	public WebElement getMyProfileCalenderOkButton(){
		return myProfileCalenderOkButton;
	}
	

	@FindBy(xpath= MYPROFILE_CALENDER_ICON)
	private WebElement myProfileCalenderIcon;
	
	public WebElement getMyProfileCalenderIcon(){
		return myProfileCalenderIcon;
	}
	
	@FindBy(xpath= MYPROFILE_GENDER_DROP_DOWN_ICON)
	private WebElement myProfileGenderDropDown;
	
	public WebElement getMyProfileGenderDropDown(){
		return myProfileGenderDropDown;
	}
	
	@FindBy(xpath= MYPROFILE_GENDER_DROP_DOWN_FIELD)
	private WebElement myProfileGenderDropDownField;
	
	public WebElement getMyProfileGenderDropDownField(){
		return myProfileGenderDropDownField;
	}
	
	@FindBy(xpath= MYPROFILE_STATE_DROP_DOWN_ICON)
	private WebElement myProfileStateDropDown;
	
	public WebElement getMyProfileStateDropDown(){
		return myProfileStateDropDown;
	}
	
	@FindBy(xpath= MYPROFILE_STATE_DROP_DOWN_FIELD)
	private WebElement myProfileStateDropDownField;
	
	public WebElement getMyProfileStateDropDownField(){
		return myProfileStateDropDownField;
	}
	
	@FindBy(xpath= MYPROFILE_CITY_DROP_DOWN_ICON)
	private WebElement myProfileCityDropDown;
	
	public WebElement getMyProfileCityDropDown(){
		return myProfileCityDropDown;
	}
	
	@FindBy(xpath= MYPROFILE_CITY_DROP_DOWN_FIELD)
	private WebElement myProfileCityDropDownField;
	
	public WebElement getMyProfileCityDropDownField(){
		return myProfileCityDropDownField;
	}
	
	@FindBy(xpath= PROFILE_PIC_EDIT_BUTTON)
	private WebElement myProfilePicEditButton;
	
	public WebElement getMyProfilePicEditButton(){
		return myProfilePicEditButton;
	}
	
	@FindBy(xpath= PROFILE_PIC_EDIT_ALERT_POPUP_MESSAGE)
	private WebElement myProfilePicEditAlertPopupMessage;
	
	public WebElement getMyProfilePicEditAlertPopupMessage(){
		return myProfilePicEditAlertPopupMessage;
	}
	
	@FindBy(xpath= PROFILE_PIC_EDIT_ALERT_POPUP_VERIFYNOW_BUTTON)
	private WebElement myProfilePicEditAlertPopupVerifyNowButton;
	
	public WebElement getMyProfilePicEditAlertPopupVerifyNowButton(){
		return myProfilePicEditAlertPopupVerifyNowButton;
	}
	
	@FindBy(xpath= PROFILE_PIC_EDIT_ALERT_POPUP_LATER_BUTTON)
	private WebElement myProfilePicEditAlertPopupLaterButton;
	
	public WebElement getMyProfilePicEditAlertPopupLaterButton(){
		return myProfilePicEditAlertPopupLaterButton;
	}
	
	@FindBy(xpath= GUIDELINES_FOR_FROFILE_PICTURE_HEADER)
	private WebElement guideLinesForProfilePicture;
	
	public WebElement getGuideLinesForProfilePicture(){
		return guideLinesForProfilePicture;
	}
	
	@FindBy(xpath= GUIDELINES_TEXT_FOR_FROFILE_PICTURE)
	private WebElement guideLinesTextForProfilePicture;
	
	public WebElement getGuideLinesTextForProfilePicture(){
		return guideLinesTextForProfilePicture;
	}
	
	@FindBy(xpath= GUIDELINES_POP_UP_FOR_FROFILE_PICTURE_OK_BUTTON)
	private WebElement guideLinesPopUpForProfilePictureOkButton;
	
	public WebElement getGuideLinesPopUpForProfilePictureOkButton(){
		return guideLinesPopUpForProfilePictureOkButton;
	}
	
	@FindBy(xpath= KycScreeenLocators.ID_PROOF_UPLOAD_POPUP_CAMERA_ICON)
	private WebElement UploadPopUpCameraIcon;
	
	public WebElement getUploadPopUpCameraIcon(){
		return UploadPopUpCameraIcon;
	}
	
	@FindBy(xpath= KycScreeenLocators.ID_PROOF_UPLOAD_POPUP_UPLOAD_ICON)
	private WebElement uploadPopUpUploadIcon;
	
	public WebElement getUploadPopUpUploadIcon(){
		return uploadPopUpUploadIcon;
	}
	
	@FindBy(xpath= KycScreeenLocators.ID_PROOF_UPLOAD_POPUP_INSTRUCTIONS_TEXT)
	private WebElement idProofUploadPopUpInstructionsText;
	
	public WebElement getIdProofUploadPopUpInstructionsText(){
		return idProofUploadPopUpInstructionsText;
	}
	
	@FindBy(xpath= KycScreeenLocators.ID_PROOF_UPLOAD_POPUP_CLOSE_ICON)
	private WebElement uploadPopUpCloseIcon;
	
	public WebElement getUploadPopUpCloseIcon(){
		return uploadPopUpCloseIcon;
	}
	
	@FindBy(xpath= KycScreeenLocators.CAMERA_SHUTTER_BUTTON)
	private WebElement cameraShutterButton;
	
	public WebElement getCameraShutterButton(){
		return cameraShutterButton;
	}
	
	@FindBy(xpath= PROFILE_PIC_UPLOAD_SUCCESS_POPUP_MESSAGE)
	private WebElement profilePicUploadSuccessPopUpMessage;
	
	public WebElement getProfilePicUploadSuccessPopUpMessage(){
		return profilePicUploadSuccessPopUpMessage;
	}
	
	@FindBy(xpath= PROFILE_PIC_UPLOAD_SUCCESS_POPUP_MESSAGE_OK_BUTTON)
	private WebElement profilePicUploadSuccessPopUpMessageOkButton;
	
	public WebElement getProfilePicUploadSuccessPopUpMessageOkButton(){
		return profilePicUploadSuccessPopUpMessageOkButton;
	}
	
	@FindBy(xpath= PROFILE_PIC_APPROVAL_PENDING_STATUS)
	private WebElement profilePicUploadPendingStatus;
	
	public WebElement getProfilePicUploadPendingStatus(){
		return profilePicUploadPendingStatus;
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Disconnect from Facebook')]")
	private WebElement disconnectFromFacebookButton;
	
	public WebElement getDisconnectFromFacebookButton(){
		return disconnectFromFacebookButton;
	}
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Are you sure you want to disconnect your facebook account from Ace2Three')]")
	private WebElement confirmDisconnectDialoxBoxMessage;
	
	public WebElement getConfirmDisconnectDialoxBoxMessage(){
		return confirmDisconnectDialoxBoxMessage;
	}

	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Disconnect')]")
	private WebElement confirmDisconnectDialoxBoxDisconnectButton;
	
	public WebElement getConfirmToDisconnectDialoxBoxDisconnectButton(){
		return confirmDisconnectDialoxBoxDisconnectButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Cancel')]")
	private WebElement confirmDisconnectDialoxBoxCancelButton;
	
	public WebElement getConfirmDisconnectDialoxBoxCancelButton(){
		return confirmDisconnectDialoxBoxCancelButton;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'You have successfully disconnected your facebook account')]")
	private WebElement disconnectedFromFBSuccessMessage;
	
	public WebElement getDisconnectedFromFBSuccessMessage(){
		return disconnectedFromFBSuccessMessage;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'OK')]")
	private WebElement disconnectedFromFBSuccessOkButton;
	
	public WebElement getDisconnectedFromFBSuccessOkButton(){
		return disconnectedFromFBSuccessOkButton;
	}
	
	
	
}

