package com.ace2three.impl.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.business.BusinessMethods;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class GamePlayTableImplPage {

	public static DesiredCapabilities capabilities = new DesiredCapabilities();
	String activity;
	String appPackage;
	
	BusinessMethods businessMethods;
	BaseTestSuite baseTestSuite;
	WebDriver driver;
	

		public GamePlayTableImplPage(WebDriver driver) throws IOException {
			//PageFactory.initElements(driver, this);
			PageFactory.initElements(new AppiumFieldDecorator(driver), this);
			businessMethods = new BusinessMethods();
			baseTestSuite= new BaseTestSuite();
			this.driver= driver;
			CustomMethods.waitForElementPresent(getGameType() , 4);
		}

		@FindBy(xpath= "//*[contains(@resource-id,'pager_title_strip')]//android.widget.TextView[2]")
		private WebElement gameType;
		
		public WebElement getGameType(){
			return gameType;
		}
		
		@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'rightArrow')]")
		private WebElement gameTypeRightArrow;
		
		public WebElement getGameTypeRightArrow(){
			return gameTypeRightArrow;
		}
		
		@FindBy(xpath= "//android.widget.ListView[contains(@resource-id,'lv_subGameCommonFragmentList')]//android.widget.TextView[0]")
		private WebElement betValueList;
		
		public WebElement getBetValueList(){
			return betValueList;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
		private WebElement joinTableYesButton;
		
		public WebElement getJoinTableYesButton(){
			return joinTableYesButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
		private WebElement joinTableNoButton;
		
		public WebElement getJoinTableNoButton(){
			return joinTableNoButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@text,'Please wait while other players join the table')]")
		private WebElement waitOtherPlayerTojoin;
		
		public WebElement getWaitOtherPlayerTojoin(){
			return waitOtherPlayerTojoin;
		}
		//Game Id and bet amount loc's
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'gameidtv')]")
		private WebElement gameTableID;
		
		public WebElement getGameTableID(){
			return gameTableID;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'gametypetv')]")
		private WebElement gameTypeLoc;
		
		public WebElement getGameTypeLoc(){
			return gameTypeLoc;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'bettv')]")
		private WebElement gameBetAmount;
		
		public WebElement getGameBetAmount(){
			return gameBetAmount;
		}
		//end
		//Leave table loc's
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'leave_table_button')]")
		private WebElement leaveTableButton;
		
		public WebElement getLeaveTableButton(){
			return leaveTableButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'gotolobby')]")
		private WebElement leaveToLobby;
		
		public WebElement getLeaveToLobby(){
			return leaveToLobby;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'leavetabletv')]")
		private WebElement leaveTableOption;
		
		public WebElement getLeaveTableOption(){
			return leaveTableOption;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
		private WebElement leaveToLobbyAlertMessage;
		
		public WebElement getLeaveToLobbyAlertMessage(){
			return leaveToLobbyAlertMessage;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
		private WebElement leaveToLobbyAlertOkButton;
		
		public WebElement getLeaveToLobbyAlertOkButton(){
			return leaveToLobbyAlertOkButton;
		}

		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
		private WebElement leaveToLobbyAlertNoButton;
		
		public WebElement getLeaveToLobbyAlertNoButton(){
			return leaveToLobbyAlertNoButton;
		}
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'timertv')]")
		private WebElement leaveToLobbyAlertDontShowThisMessage;
		
		public WebElement getleaveToLobbyAlertDontShowThisMessage(){
			return leaveToLobbyAlertDontShowThisMessage;
		}
		@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'drg_check_iv')]")
		private WebElement leaveToLobbyAlertDontShowThisMessageCheckBox;
		
		public WebElement getLeaveToLobbyAlertDontShowThisMessageCheckBox(){
			return leaveToLobbyAlertDontShowThisMessageCheckBox;
		}
		//Leave table end
		
		// select new table pop up component
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_heading')]")
		private WebElement selectTablePopuUpHeader;
		
		public WebElement getSelectTablePopuUpHeader(){
			return selectTablePopuUpHeader;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_close')]")
		private WebElement selectTablePopuUpCloseButton;
		
		public WebElement getSelectTablePopuUpCloseButton(){
			return selectTablePopuUpCloseButton;
		}

		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_img_two_player')]")
		private WebElement selectTabletwoPlayersOption;
		
		public WebElement getSelectTableTwoPlayersOption(){
			return selectTabletwoPlayersOption;
		}
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_img_six_player')]")
		private WebElement selectTablesixPlayersOption;
		
		public WebElement getSelectTableSixPlayersOption(){
			return selectTablesixPlayersOption;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_tv_gametype')]")
		private WebElement selectTablePopupGameType;
		
		public WebElement getSelectTablePopupGameType(){
			return selectTablePopupGameType;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_tv_bet')]")
		private WebElement selectTablePopupBet;
		
		public WebElement getSelectTablePopupBet(){
			return selectTablePopupBet;
		}
		
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_tv_tolobby')]")
		private WebElement switchTableGoToLobby;
		
		public WebElement getSwitchTableGoToLobby(){
			return switchTableGoToLobby;
		}
			
		@FindBy(xpath= "//android.widget.ListView[contains(@resource-id,'list_game_type')]")
		private WebElement switchTableGameTypeList;
		
		public WebElement getSwitchTableGameTypeList(){
			return switchTableGameTypeList;
		}
		
		@FindBy(xpath= "//android.widget.ListView[contains(@resource-id,'list_bet')]")
		private WebElement switchTableGameBetList;
		
		public WebElement getSwitchTableGameBetList(){
			return switchTableGameBetList;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'ql_img_join')]")
		private WebElement switchTableJoinButton;
		
		public WebElement getSwitchTableJoinButton(){
			return switchTableJoinButton;
		}
		
		///////////// end of switch/Add table
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
		private WebElement noSufficientChipsToPlayAlert;
		
		public WebElement getNoSufficientChipsToPlayAlert(){
			return noSufficientChipsToPlayAlert;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@text,'Buy Real Chips')]")
		private WebElement buyRealChipsButton;
		
		public WebElement getBuyRealChipsButton(){
			return buyRealChipsButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@text,'No Thanks')]")
		private WebElement noSufficientChipsToPlayAlertNoThanks;
		
		public WebElement getNoSufficientChipsToPlayAlertNoThanks(){
			return noSufficientChipsToPlayAlertNoThanks;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'chat_btn')]")
		private WebElement chatOption;
		
		public WebElement getChatOption(){
			return chatOption;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'sort_button')]")
		private WebElement sortButton;
		
		public WebElement getSortButton(){
			return sortButton;
		}
		//Add new table popup
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'game_switch_background')]")
		private WebElement switchTableButton;
		
		public WebElement getSwitchTableButton(){
			return switchTableButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'switch_gametype_tv')]")
		private WebElement switchTableGameType;
		
		public WebElement getSwitchTableGameType(){
			return switchTableGameType;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'switch_betamount_tv')]")
		private WebElement switchTableBetAmount;
		
		public WebElement getSwitchTableBetAmount(){
			return switchTableBetAmount;
		}
		//End switch/add new table
		
		//Player profile loc's
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'settings_text')]")
		private WebElement playerProfileSettingsHeader;
		
		public WebElement getPlayerProfileSettingsHeader(){
			return playerProfileSettingsHeader;
		}
		/*
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'settings_text')]")
		private WebElement playerProfileSettingsHeader;
		
		public WebElement getPlayerProfileSettingsHeader(){
			return playerProfileSettingsHeader;
		}*/
		//end of player profile table
		
		//game related loc's
		@FindBy(xpath= "//android.view.View[1]/android.widget.RelativeLayout[2]//android.widget.TextView[contains(@resource-id,'handTimerTxt1')]")
		private WebElement handTimerPulse;
		
		public WebElement getHandTimerPulse(){
			return handTimerPulse;
		}
		
		@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'openCardId')]")
		private WebElement openCard;
		
		public WebElement getOpenCard(){
			return openCard;
		}
	
		
		@FindBy(xpath= "//android.widget.ImageView[@resource-id='air.com.ace2three.mobile.cash:id/deckCardId' and @index='6']")
		private WebElement deckCard;
		
		public WebElement getDeckCard(){
			return deckCard;
		}
		
		
		@FindBy(xpath= "//android.widget.ImageView[contains(@index,'%s')]")
		private WebElement userCards;
		
		public WebElement getUserCards(){
			return userCards;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'discardButtonId')]")
		private WebElement discardButton;
		
		public WebElement getDiscardButton(){
			return discardButton;
		}
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'showButtonId')]")
		private WebElement showButton;
		
		public WebElement getShowButton(){
			return showButton;
		}
		//end
		
		//Leave table dialog box
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
		private WebElement leaveTableDialogBoxMessage;
		
		public WebElement getLeaveTableDialogBoxMessage(){
			return leaveTableDialogBoxMessage;
		}
		
		//end leave table
		
		//Place show confirmation
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
		private WebElement placeShowConfirmationDialogBoxMessage;
		
		public WebElement getPlaceShowConfirmationDialogBoxMessage(){
			return placeShowConfirmationDialogBoxMessage;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
		private WebElement placeShowConfirmDialogYesButton;
		
		public WebElement getPlaceShowConfirmDialogYesButton(){
			return placeShowConfirmDialogYesButton;
		}

		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
		private WebElement placeShowConfirmDialogNoButton;
		
		public WebElement getPlaceShowConfirmDialogNoButton(){
			return placeShowConfirmDialogNoButton;
		}
		
		@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'DiscardsIv')]")
		private WebElement discardWindowButton;
		
		public WebElement getDiscardWindowButton(){
			return discardWindowButton;
		}
		
		
		
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'discardsclosebtn')]")
		private WebElement discardWindowCloseButton;
		
		public WebElement getDiscardWindowCloseButton(){
			return discardWindowCloseButton;
		}
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'discardsbtn')]")
		private WebElement discardTabButton;
		
		public WebElement getDiscardTabButton(){
			return discardTabButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'lasthandbtn')]")
		private WebElement lastHandTabButton;
		
		public WebElement getLastHandTabButton(){
			return lastHandTabButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'scoreboardbtn')]")
		private WebElement scoreBoardTabButton;
		
		public WebElement getScoreBoardTabButton(){
			return scoreBoardTabButton;
		}
		//Place show confirmation- end
		
		public WebElement getCard(String index){
			String cardLoc= "//android.widget.ImageView[contains(@index,'%s')]";
			String actualCardLoc= String.format(cardLoc, index);
			WebElement element = driver.findElement(By.xpath(actualCardLoc));
			return element;
		}
		
		public enum Game {
			Pool201,Pool101,GunShot,BestO2,BestO3,PointsRummy;
		}
				
		public void navigateToGameType(Game game) {

			String gameCode = null;
				
				switch (game) {
					case PointsRummy:
						gameCode = "0";
						break;
					case Pool201:
						gameCode = "1";
						break;
					case GunShot:
						gameCode = "2";
						break;
					case BestO2:
						gameCode = "3";
						break;
					case BestO3:
						gameCode = "4";
						break;
					case Pool101:
						gameCode = "5";
						break;
				}
				
				for(int i=0;i<=5;i++){
					String currentSectionInFocus = getGameType().getText();
					if(currentSectionInFocus.equalsIgnoreCase(gameCode)){
						BaseTestSuite.logger.log(LogStatus.PASS, "navigated to "+ game.toString());
						break;
					}else{
						getGameTypeRightArrow().click();
					}

				}
		}
		
		public void joinGameTable(String betValue){
			List<WebElement> betList= driver.findElements(By.xpath("//android.widget.ListView[contains(@resource-id,'lv_subGameCommonFragmentList')]/descendant::android.widget.TextView[1]"));
				for(WebElement bet: betList){
					System.out.println(bet.getText()+"Bet text");
					if(bet.getText().equals(betValue)){
						bet.click();
						break;
					}
				}
		}
		
		public enum twoPlayerGameTypes {
		    B02("Bo2"),
		    B03("Bo3"),
		    POINTS_RUMMY("Points Rummy");
		  private String name;
		    twoPlayerGameTypes(String name) {
		        this.name = name;
		    }

		    public String getName() {
		        return this.name;
		    }    
		}
		
		public void selectFromGameTypeListView(twoPlayerGameTypes  playerGameTypes){
			List<WebElement> gameTypes = getSwitchTableGameTypeList().findElements(By.xpath
					("//android.widget.TextView[contains(@resource-id,'text1')]"));
			for(WebElement gameType: gameTypes){
				if(gameType.getText().trim().equalsIgnoreCase(playerGameTypes.getName().trim())){
					gameType.click();
					break;
				}
			}
			
		}
		
		public enum sixPlayerGameTypes {
		    POOL201("201 Pool"),
		    POOL101("101 Pool"),
		    POINTS_RUMMY("Points Rummy"),
		    GUNSHOT("GunShot");
		  private String name;
		  sixPlayerGameTypes(String name) {
		        this.name = name;
		    }

		    public String getName() {
		        return this.name;
		    }    
		}
		
		public void selectFromGameTypeListView(sixPlayerGameTypes  playerGameTypes){
			List<WebElement> gameTypes = getSwitchTableGameTypeList().findElements(By.xpath
					("//android.widget.TextView[contains(@resource-id,'text1')]"));
			for(WebElement gameType: gameTypes){
				if(gameType.getText().trim().equalsIgnoreCase(playerGameTypes.getName().trim())){
					gameType.click();
					break;
				}
			}
			
		}
		
		public String getSwitchTableBetAmountValue(){
			Character ch = '.';
			String betAmount = getSelectTablePopupBet().getText();
		    int length = betAmount.length();
		    String amountValue = "";
		    for (int i = 0; i < length; i++) {
		        Character character = betAmount.charAt(i);
		        if (Character.isDigit(character) || character.compareTo(ch)==0) {
		        	amountValue += character;
		        }
		    }
		    System.out.println("result is: " + amountValue);
			return amountValue.trim();
		    
		}

		public void countCards() throws InterruptedException{
			List<WebElement> cardsCount = driver.findElements(By.xpath("//android.view.ViewGroup[@index='1']/android.widget.ImageView"));
			System.out.println(cardsCount.size()+ ": size");
			for(int i=0; i<=2;i++){
				if(cardsCount.size()==14){
					System.out.println("card has added");
					break;
				}else{
					Thread.sleep(1000);
				}
			}
			if(!(cardsCount.size()==14)){
				baseTestSuite.logger.log(LogStatus.FAIL, "cards not added to player");
			}
		
		}
		
		public int cardsCount() throws InterruptedException{
			Thread.sleep(1000);
			List<WebElement> cardsCount =null;
		
				//((AndroidDriver)driver).getSessionDetails().get(key)
				System.out.println( "here at ccaps :" + ((AndroidDriver)driver).getCapabilities().asMap().get("deviceName"));
				if(((AndroidDriver)driver).getCapabilities().asMap().get("deviceName").toString().contains("emulator")){
					System.out.println( "here at ccaps emu :" + ((AndroidDriver)driver).getCapabilities().asMap().get("deviceName"));
					cardsCount = driver.findElements(By.xpath("//android.view.ViewGroup[2]/android.widget.ImageView"));
				}else{
					System.out.println( "here at ccaps non emu :" + ((AndroidDriver)driver).getCapabilities().asMap().get("deviceName"));
					cardsCount = driver.findElements(By.xpath("//android.view.View[2]/android.widget.ImageView"));
				}
			System.out.println(cardsCount.size() + "this is card size pla1");
			return cardsCount.size();
		}
		
		
		public void tapDeckCardButton(){
			
			new TouchAction((MobileDriver) driver).press(getDeckCard()).waitAction(1000).release().perform();
			}
        
		public void tapDiscardButtton(){
			/*TouchAction action = new TouchAction((AppiumDriver) driver);
			WebElement ele= driver.findElement(By.xpath(""));
			action.tap(ele);*/
			
			new TouchAction((MobileDriver) driver).press(getDiscardButton()).waitAction(1000).release().perform();
			
			}
		
}
