package com.ace2three.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.component.pages.FacebookLoginPages;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;

public class FacebookAppLoginImplPage implements FacebookLoginPages{

	WebDriver driver;
	public FacebookAppLoginImplPage(WebDriver driver) {		
		//This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
		this.driver=driver;
	}

	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'header')]")
	private WebElement facebookLoginPageHeader;
	
	public WebElement getFacebookLoginPageHeader(){
		return facebookLoginPageHeader;
	}  
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'login_username')]")
	private WebElement facebookUserIDField;
	
	public WebElement getFacebookUserIDField(){
		return facebookUserIDField;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'login_password')]")
	private WebElement facebookPasswordField;
	
	public WebElement getFacebookPasswordField(){
		return facebookPasswordField;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'login_login')]")
	private WebElement facebookLoginButton;
	
	public WebElement getFacebookLoginButton(){
		return facebookLoginButton;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Edit This')]")
	private WebElement editPermissionsLink;
	
	public WebElement getEditPermissionsLink(){
		return editPermissionsLink;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Continue')]")
	private WebElement continueWithFacebook;
	
	public WebElement getContinueWithFacebook(){
		return continueWithFacebook;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Info You Provide')]")
	private WebElement editPermissionsPage;
	
	public WebElement getEditPermissionsPage(){
		return editPermissionsPage;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Clear')]")
	private WebElement clearPermissionsButton;
	
	public WebElement getClearPermissionsButton(){
		return clearPermissionsButton;
	}
	
	@FindBy(xpath= "//android.widget.CheckBox[contains(@text,'Public profile')]")
	private WebElement publicProfileCheckBok;
	
	public WebElement getPublicProfileCheckBok(){
		return publicProfileCheckBok;
	}
	
	@FindBy(xpath= "//android.widget.CheckBox[contains(@text,'Friend list')]")
	private WebElement friendsListCheckBox;
	
	public WebElement getFriendsListCheckBox(){
		return friendsListCheckBox;
	}
	
	@FindBy(xpath= "//android.widget.CheckBox[contains(@text,'Email address')]")
	private WebElement emailAddressCheckBox;
	
	public WebElement getEmailAddressCheckBox(){
		return emailAddressCheckBox;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Cancel')]")
	private WebElement cancelButtonInAppLoginPage;
	
	public WebElement getCancelButtonInAppLoginPage(){
		return cancelButtonInAppLoginPage;
	}
	
	
	public void resetFacebookAppOrBrowser(){
		 Activity activity1 = new Activity("com.facebook.katana", 
				 "com.facebook.katana.LoginActivity");
			
		((AndroidDriver) driver).startActivity(activity1);
	     try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	     ((AndroidDriver) driver).resetApp();
	}

	@FindBy(xpath= "//android.view.View[contains(@text,'We could not log you in')]")
	private WebElement ageRestrictionMessage;
	
	@Override
	public WebElement getAgeRestrictionMessage() {
		return ageRestrictionMessage;
	}

	@FindBy(xpath= "//android.widget.Button[contains(@text,'Okay')]")
	private WebElement ageRestrictionOkayButton;
	
	@Override
	public WebElement getAgeRestrictionOkayButton() {
		return ageRestrictionOkayButton;
	}

}
