package com.ace2three.impl.pages;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.GamePlayTableImplPage.Game;
import com.ace2three.utils.business.BusinessMethods;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class GamePlayPlayer2ImplPage {

	
	BusinessMethods businessMethods;
	BaseTestSuite baseTestSuite;
	WebDriver player2Driver;

		public GamePlayPlayer2ImplPage(WebDriver player2Driver) {
			//PageFactory.initElements(player2Driver, this);
			PageFactory.initElements(new AppiumFieldDecorator(player2Driver), this);
			businessMethods = new BusinessMethods();
			baseTestSuite= new BaseTestSuite();
			this.player2Driver=player2Driver;
			player2Driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			System.out.println(System.getProperty("deviceName")+ "asjibahisof111111");
			
		}

		@FindBy(xpath= "//*[contains(@resource-id,'pager_title_strip')]//android.widget.TextView[2]")
		private WebElement gameType;
		
		public WebElement getGameType(){
			return gameType;
		}
		
		@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'rightArrow')]")
		private WebElement gameTypeRightArrow;
		
		public WebElement getGameTypeRightArrow(){
			return gameTypeRightArrow;
		}
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
		private WebElement joinTableYesButton;
		
		public WebElement getJoinTableYesButton(){
			return joinTableYesButton;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
		private WebElement joinTableNoButton;
		
		public WebElement getJoinTableNoButton(){
			return joinTableNoButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@text,'Please wait while other players join the table')]")
		private WebElement waitOtherPlayerTojoin;
		
		public WebElement getWaitOtherPlayerTojoin(){
			return waitOtherPlayerTojoin;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'leave_table_button')]")
		private WebElement leaveTableButton;
		
		public WebElement getLeaveTableButton(){
			return leaveTableButton;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'gotolobby')]")
		private WebElement viewLobby;
		
		public WebElement getViewLobby(){
			return viewLobby;
		}
		
		@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'gotolobby')]")
		private WebElement leaveTable;
		
		public WebElement getLeaveTable(){
			return leaveTable;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'chat_btn')]")
		private WebElement chatOption;
		
		public WebElement getChatOption(){
			return chatOption;
		}
		
		@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'sort_button')]")
		private WebElement sortButton;
		
		public WebElement getSortButton(){
			return sortButton;
		}
		
		//game related loc's
				@FindBy(xpath= "//android.view.View[0]/android.widget.RelativeLayout[contains(@index,'1')]/descendant::android.widget.TextView[contains(@resource-id,'handTimerTxt1')]")
				private WebElement handTimerPulse;
				
				public WebElement getHandTimerPulse(){
					return handTimerPulse;
				}
				
				@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'openCardId')]")
				private WebElement openCard;
				
				public WebElement getOpenCard(){
					return openCard;
				}
				
				@FindBy(xpath= "//android.widget.ImageView[@resource-id='air.com.ace2three.mobile.cash:id/deckCardId' and @index='6']")
				private WebElement deckCard;
				
				public WebElement getDeckCard(){
					return deckCard;
				}
				
				@FindBy(xpath= "//android.widget.ImageView[contains(@index,'%s')]")
				private WebElement userCards;
				
				public WebElement getUserCards(){
					return userCards;
				}
				
				@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'discardButtonId')]")
				private WebElement discardButton;
				
				public WebElement getDiscardButton(){
					return discardButton;
				}
				@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'showButtonId')]")
				private WebElement showButton;
				
				public WebElement getShowButton(){
					return showButton;
				}
				//end
				
				//Place show confirmation
				@FindBy(xpath= "//android.widget.TextView[contains(@resource-id,'statusalert')]")
				private WebElement placeShowConfirmationDialogBoxMessage;
				
				public WebElement getPlaceShowConfirmationDialogBoxMessage(){
					return placeShowConfirmationDialogBoxMessage;
				}
				
				@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'yes')]")
				private WebElement placeShowConfirmDialogYesButton;
				
				public WebElement getPlaceShowConfirmDialogYesButton(){
					return placeShowConfirmDialogYesButton;
				}

				@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'no')]")
				private WebElement placeShowConfirmDialogNoButton;
				
				public WebElement getPlaceShowConfirmDialogNoButton(){
					return placeShowConfirmDialogNoButton;
				}
				
				//Place show confirmation- end
				
				public WebElement getCard(String index){
					String cardLoc= "//android.widget.ImageView[contains(@index,'"+index+"')]";
				//	String actualCardLoc= String.format(cardLoc, index);
					WebElement element = player2Driver.findElement(By.xpath(cardLoc));
					return element;
				}
				
				
		public void navigateToGames() throws InterruptedException{
			Thread.sleep(10000);
			try{
				player2Driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'permission_allow_button')]")).click();
			}catch(Exception e){
				
			}
				LaunchImplPage launchImplPage = new LaunchImplPage(player2Driver);
	            launchImplPage.launchLobbyPage("appium20", "ace2three@", player2Driver);
	            LobbyImplPage lobbyImplPage =new LobbyImplPage(player2Driver);
	            lobbyImplPage.getgamesTabIcon().click();
	  }
		
		public void navigateToGameType(Game game) {

			String gameCode = null;
				
				switch (game) {
					case PointsRummy:
						gameCode = "0";
						break;
					case Pool201:
						gameCode = "1";
						break;
					case GunShot:
						gameCode = "2";
						break;
					case BestO2:
						gameCode = "3";
						break;
					case BestO3:
						gameCode = "4";
						break;
					case Pool101:
						gameCode = "5";
						break;
				}
				
				for(int i=0;i<=5;i++){
					String currentSectionInFocus = getGameType().getText();
					
					if(currentSectionInFocus.equalsIgnoreCase(gameCode)){
						BaseTestSuite.logger.log(LogStatus.PASS, "navigated to "+ game.toString());
						break;
					}else{
						getGameTypeRightArrow().click();
					}

				}
		}
			
		public void joinGameTable(String betValue){
			List<WebElement> betList= player2Driver.findElements(By.xpath("//android.widget.ListView[contains(@resource-id,'lv_subGameCommonFragmentList')]/descendant::android.widget.TextView[1]"));
				for(WebElement bet: betList){
					System.out.println(bet.getText()+"Bet text");
					if(bet.getText().contains(betValue)){
						bet.click();
					}
				}
		}
		
		public static void main(String args[]){
		
			for(int i=1;i<=4;i++){
				for(int j=4;j<=i;j--){
					System.out.print(j);
				}
				System.out.println();
			}
		}
			
		public void countCards() throws InterruptedException{
			List<WebElement> cardsCount = player2Driver.findElements(By.xpath("//android.view.ViewGroup[@index='1']/android.widget.ImageView"));
			System.out.println(cardsCount.size()+ ": size");
			for(int i=0; i<=2;i++){
				if(cardsCount.size()==14){
					System.out.println("card has added");
					break;
				}else{
					Thread.sleep(1000);
				}
			}
			if(!(cardsCount.size()==14)){
				baseTestSuite.logger.log(LogStatus.FAIL, "cards not added to player");
			}
		
		}
		
		public int cardsCount() throws InterruptedException{
			Thread.sleep(1000);
			List<WebElement> cardsCount = player2Driver.findElements(By.xpath("//android.view.ViewGroup[2]//android.widget.ImageView"));
			System.out.println(cardsCount.size() + " this is card size pla1");
			return cardsCount.size();
		}
		
		public void tapOnOpenCard(){
			 new TouchAction((PerformsTouchActions) player2Driver).tap(getOpenCard()).perform();
			 }
		
		public void tapOnDeckCard(){
		     new TouchAction((PerformsTouchActions)player2Driver).tap(getDeckCard()).perform();
		    }
		
	/*	@AfterClass
		public void afterClass(Method method, ITestResult result) throws IOException{
			
			if (!(result.getStatus() == ITestResult.SUCCESS)) {
				baseTestSuite.logger.log(LogStatus.FAIL, result.getThrowable());
				baseTestSuite.logger.log(LogStatus.PASS, "Failed screenshot" + baseTestSuite.logger.addScreenCapture(baseTestSuite.takeScreenShot(method.getName())));
			}
			
		}*/
		
		
		public void tapDeckCardButton(){
			
			new TouchAction((MobileDriver) player2Driver).press(getDeckCard()).waitAction(2000).release().perform();
			}
        
		public void tapDiscardButtton(){
			/*TouchAction action = new TouchAction((AppiumDriver) driver);
			WebElement ele= driver.findElement(By.xpath(""));
			action.tap(ele);*/
			
			new TouchAction((MobileDriver) player2Driver).press(getDiscardButton()).waitAction(2000).release().perform();
			
			}
		
}
