package com.ace2three.utils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ace2three.base.BaseTestSuite;
import com.relevantcodes.extentreports.LogStatus;

public class DataBaseServerConnect extends BaseTestSuite{
	 String databaseURL = "jdbc:oracle:thin:@qadb.headinfotech.local:1521:kingsdev";
     String user = "QA_TEST_DINESHS[ACE2THREE]";
     String password = "D#js87sHSE9";
     Connection connection = null;
     Statement statement = null;
	
	 private void connectDataBase(){
		
	        try {
	            Class.forName("oracle.jdbc.OracleDriver");
	            this.connection = DriverManager.getConnection(databaseURL, user, password);
	            
	        } catch (ClassNotFoundException ex) {
	            System.out.println("Could not find database driver class");
	            logger.log(LogStatus.FATAL, "Could not find database driver class");
	            ex.printStackTrace();
	        } catch (SQLException ex) {
	            System.out.println("An error occurred. Maybe user/password is invalid");
	            logger.log(LogStatus.FATAL, "An error occurred. Maybe user/password is invalid");
	            ex.printStackTrace();
	        }
			
	 }
	 public String selectQuery(String query, String userName) throws InterruptedException, SQLException {

			connectDataBase();
			String result= null;
			if (connection != null) {
				System.out.println("Entered");
			connection.setAutoCommit(false);
			        System.out.println("Connected to the database");
			        // logger.log(LogStatus.PASS, "Connected to the database");
			        //STEP 4: Execute a query
			            System.out.println("Creating statement...");
			            statement = connection.createStatement();
			            
			            try{
			           // query = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE upper(user_id)=upper('"+userName+"')";
			          //  query = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userName+"')";
			        //query="update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('gopidu3876')";
			           	//query="update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
			           	
			          query="select TRANSACTION_ID from (select * from t_zipdial_responses where upper(user_id) = upper('"+userName+"') order by creation_date desc) where rownum = 1";
			     	 
			         //   int rs=  statement.executeUpdate(query);
			           ResultSet rs= statement.executeQuery(query);
			           int i=1;
			           
			           while(rs.next()){
			            System.out.println(rs.getString(i)+ "  : heagdsidls");
			           	result = rs.getString(1);
			           	break;
			           }
			            System.out.println(rs);
			            connection.commit();
			            }catch(Exception e){
			           	e.printStackTrace();
			           	connection.rollback();
			            }
			            System.out.println("Query execution successfull");
			            statement.close();
			        }else{
			        logger.log(LogStatus.FAIL, "Failed to connect to data base");
			        }
			closeConnection();

			return result;
			}
	 private void closeConnection(){
		 if (connection != null) {
	                try {
	                	connection.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
	            }  
	 }
	 
	 public void updateQuery(String query, String userName) throws InterruptedException, SQLException {
		 
		 connectDataBase();
		 if (connection != null) {
			 connection.setAutoCommit(false);
         	 System.out.println("Connected to the database");
         	// logger.log(LogStatus.PASS, "Connected to the database");
         	 //STEP 4: Execute a query
             System.out.println("Creating statement...");
             statement = connection.createStatement();
             try{
            	 //  query = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE upper(user_id)=upper('"+userName+"')";
            	 //  query = "UPDATE ACE2THREE.T_LIMITS_MODIFIED_TRACK SET limit_set_date= sysdate-35 WHERE limit_set_date >= trunc(sysdate)-35 and upper(user_id)=upper('"+userName+"')";
            	 //  query="update T_SOCIAL_USER_ACCT_MASTER set RECORD_STATUS = 'N',DISCONNECT_DATE = sysdate where upper(ace_userid) = uppeR('gopidu3414')";
            	 //  query="update ace2three.game_user_master set phone_number=null,phone_verified='N' where phone_number like'%8463932054'";
            	
             int rs=  statement.executeUpdate(query);
             System.out.println(rs);
             connection.commit();
             }catch(Exception e){
            	 e.printStackTrace();
            	 connection.rollback();
             }
             System.out.println("Query execution successfull");
             statement.close();
         }else{
        	 logger.log(LogStatus.FAIL, "Failed to connect to data base");
         }
		 closeConnection();
	 }
	 
	public static void main(String args[]) throws InterruptedException, SQLException{
		 DataBaseServerConnect baseServerConnect = new DataBaseServerConnect();
				/* baseServerConnect.connectDataBase();
				 String clearDeviceIds = "update game_user_master set phone_verified='N' where user_code in (select bonus_claimed from device_details)";
            	 String deleteDevicesDetails="delete from device_details";
            	 baseServerConnect.updateQuery(clearDeviceIds, "");
            	 baseServerConnect.updateQuery(deleteDevicesDetails, "");*/
		// System.out.println(baseServerConnect.selectQuery(null, "hello011"));
		// baseServerConnect.selectQuery("", "hello011");
		 baseServerConnect.closeConnection();
	}
	
}
