package com.ace2three.utils;

	import java.lang.annotation.Retention;
	import java.lang.annotation.RetentionPolicy;
	import java.lang.annotation.Target;
	import java.lang.annotation.ElementType;
	@Target(value = ElementType.FIELD)
	@Retention(RetentionPolicy.RUNTIME)
	public @interface FindBy {
	
		/**
		 * specify locator in conventional selenium 1 way.
		 * 
		 * @return
		 */
		public String locator();
}
	

