package com.ace2three.utils;

import java.util.Random;

public class GenerateRandomUtils {

	public int generateRandomNumber(int length){
		Random random = new Random();
		int randomNumber=0;
		switch (length){
		case 1:
			randomNumber = random.nextInt(10);
		
		case 2:
			randomNumber = random.nextInt(100);
			
		case 3:
			randomNumber = random.nextInt(1000);
			
		case 4:
			randomNumber = random.nextInt(10000);
			
		case 5:
			randomNumber = random.nextInt(100000);
			
		case 6:
			randomNumber = random.nextInt(1000000);
			
		case 7:
			randomNumber = random.nextInt(10000000);
		case 8:
			randomNumber = random.nextInt(100000000);
		case 9:
			randomNumber = random.nextInt(1000000000);
			
		}
		return randomNumber;
		
		
	}
}
