package com.ace2three.utils;

public class SendMail {

}
