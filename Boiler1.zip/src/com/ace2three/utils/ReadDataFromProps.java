package com.ace2three.utils;

import java.io.FileInputStream;
import java.util.Properties;

import com.ace2three.base.BaseTestSuite;
import com.relevantcodes.extentreports.LogStatus;

public class ReadDataFromProps {
	
	public static Properties props;
	static {
		try {
			FileInputStream fs = new FileInputStream(
					System.getProperty("user.dir")
							+ "\\resource\\data.properties");
			props = new Properties();
			props.load(fs);

		} catch (Exception e) {
			BaseTestSuite.logger.log(LogStatus.FAIL, e.toString());
		}
	}

}
