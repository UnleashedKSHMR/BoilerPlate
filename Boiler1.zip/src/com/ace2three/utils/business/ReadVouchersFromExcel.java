package com.ace2three.utils.business;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class ReadVouchersFromExcel {

	public ArrayList<String> getVouchers() throws IOException {
		String fileLoc = getLatestFilefromDir();
		FileInputStream inp = new FileInputStream(fileLoc);
		HSSFWorkbook xssf = new HSSFWorkbook(inp);
		ArrayList<String> giftVouchers = new ArrayList<String>();
		HSSFSheet sheet = xssf.getSheetAt(0);
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			Row row = sheet.getRow(i);
			if (row != null) {
				Cell cell = row.getCell(1);
				if (cell != null) {
					String cellVal = cell.getStringCellValue();
					/*
					 * String bankCode= cellVal.substring(0, 3); switch
					 * (bankCode){ case "BKID": String bank="Bank Of India";
					 * //WebElement element = driver.findElement(By.xpath(""));
					 * }
					 */
					giftVouchers.add(cellVal);
					System.out.println(cellVal);
				}
			}
		}
		
		System.out.println(sheet.getLastRowNum());
		System.out.println(sheet.getActiveCell());
		
	/*	FileOutputStream  fileout = new FileOutputStream(System.getProperty("user.dir")+"\\resource\\Vouchers.xls");
		xssf.write(fileout);*/
		xssf.close();
	//	fileout.close();
		inp.close();
		return giftVouchers;
		
		
	}
	
	
/*	public void verify(){
	File file = null;
	boolean fileDownloaded = false;
			while (!fileDownloaded) {
				Thread.sleep(2000);
				file = getLatestFilefromDir(path);
				if (file.getName().toString().matches(downloadFile)
						&& file.lastModified() > beforeTime)
					fileDownloaded = true;
				Thread.sleep(1000);
				//FileUtils.moveFileToDirectory(file, destinationDir, true);

			}*/

	public static String getLatestFilefromDir() {
		String home = System.getProperty("user.home");
		File dir = new File(home+"/Downloads/"); 
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}
		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		System.out.println(lastModifiedFile.getName().toString()+ " : last downloaded file");
		String fileLoc= dir+"\\"+lastModifiedFile.getName().toString();
		return fileLoc;
	}
}