package com.ace2three.utils.business;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.utils.CustomMethods;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.functions.ExpectedCondition;

public class BusinessMethods extends BaseTestSuite {

	// public void click on Screen

	public enum IdProofList {

		AadhaarCard, RationCard, VoterID, Passport, DrivingLicence;
	}

	public void selectIdFromDropDown(IdProofList id) {

		List<WebElement> idProofList = driver
				.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'tvSpinnerItem')]"));
		String id1 = null;
		switch (id) {
		case AadhaarCard:
			id1 = "Aadhaar Card";
			break;
		case RationCard:
			id1 = "Ration Card";
			break;
		case VoterID:
			id1 = "Voter ID";
			break;
		case Passport:
			id1 = "Passport";
			break;
		case DrivingLicence:
			id1 = "Driving Licence";
			break;

		}

		for (WebElement idProof : idProofList) {
			String idProofValue = idProof.getText();
			System.out.println("State Values text: " + idProofValue);
			if (idProofValue.equalsIgnoreCase(id1)) {
				idProof.click();
				break;
			}
		}
	}
	
	public boolean checkAutoDetectedOtp(WebElement element) throws IOException{
		
		try {
			WebDriverWait wait = new WebDriverWait(driver, 59);
			wait.until(ExpectedConditions.visibilityOf(element));
			logger.log(LogStatus.INFO, "App auto detected OTP" );
			return true;
		} catch (Exception e) {
			logger.log(LogStatus.INFO, "App didnt auto detected OTP so doing it manually" + 
					logger.addScreenCapture(takeScreenShot("OTP screen")));
			return false;
		}
	}


	public String  getOtpFromMessages() throws InterruptedException{
		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(3000);
		((AndroidDriver) driver).openNotifications();

		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'AM-ACEACT')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 1");
		}
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'New messages')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 2");
		}
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'new messages')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 3");
		}

		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")));
		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();
		
		String MessageLoc= "//android.widget.TextView[contains(@resource-id,'text_view')]";
		List<WebElement> textMessages = driver.findElements(By.xpath(MessageLoc));
		int noOfMesg = textMessages.size();
		System.out.println(noOfMesg);
		String messageText = textMessages.get(noOfMesg - 1).getText();
		String OTP= messageText.substring(0, 7);
		System.out.println("Text Message actual:" + textMessages.get(noOfMesg - 1).getText());
		System.out.println("OTP: " + OTP);
		for (WebElement message : textMessages) {
			System.out.println("Text Message :" + message.getText());
		}
		
		 try {((AndroidDriver) driver).runAppInBackground(1);
		 	} catch (Exception e) {//ignore} 
	        	
	        }
		  return OTP;
	}
	
	public String  getOtpFromMessagesStartingWithHello() throws InterruptedException{
		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(3000);
		((AndroidDriver) driver).openNotifications();
		/*
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")));
*/
		Thread.sleep(5000);
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'AM-ACEACT')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 1");
		}
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'New messages')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 2");
		}
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'new messages')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 3");
		}


		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();
		
		String MessageLoc= "//android.widget.TextView[contains(@resource-id,'text_view')]";
		List<WebElement> textMessages = driver.findElements(By.xpath(MessageLoc));
		int noOfMesg = textMessages.size();
		System.out.println(noOfMesg);
		String messageText = textMessages.get(noOfMesg - 1).getText();
		String[] message = messageText.split(",");
	
		
		String OTP= message[1].toString().trim().substring(0, 6);
		System.out.println("Text Message actual:" + textMessages.get(noOfMesg - 1).getText());
		System.out.println("OTP: " + OTP);
		for (WebElement message1 : textMessages) {
			System.out.println("Text Message :" + message1.getText());
		}
		
		 try {((AndroidDriver) driver).runAppInBackground(1);
		 	} catch (Exception e) {//ignore} 
	        	
	        }
		  return OTP;
		}
	
}
