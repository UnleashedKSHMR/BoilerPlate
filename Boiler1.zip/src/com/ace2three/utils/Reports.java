package com.ace2three.utils;

import com.ace2three.base.BaseTestSuite;
import com.relevantcodes.extentreports.LogStatus;

public class Reports {

	public void log(String status,String info){
		
		switch (status){
		
		case "info": 
			BaseTestSuite.logger.log(LogStatus.INFO, info);
			break;
		
		case "warning": 
			BaseTestSuite.logger.log(LogStatus.WARNING, info);
			break;
			
		case "pass": 
			BaseTestSuite.logger.log(LogStatus.PASS, info);
			break;
			
		case "fail": 
			BaseTestSuite.logger.log(LogStatus.FAIL, info);
			break;
			
			
		}
	}
	
	

}
