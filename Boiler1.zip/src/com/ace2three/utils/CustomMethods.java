package com.ace2three.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.guide.Run;

import com.ace2three.base.BaseTestSuite;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.Connection;

public class CustomMethods extends BaseTestSuite {
	WebDriver desktopWebDriver;
	static AppiumDriver Player2Driver;
	static BaseTestSuite baseTestSuite = new BaseTestSuite();
	private static DesiredCapabilities capabilities = new DesiredCapabilities();
	public void waitForElement(){
		//Stub
	}
	
	public static void selectFromDropDownList(String item){
		baseTestSuite.driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		 // Update profiel,....
       // List<WebElement> Options= element;
		List<WebElement> Options= baseTestSuite.driver.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'tvSpinnerItem')]"));
        for(WebElement Option:Options){
        	String OptionValue= Option.getText();
        	System.out.println("Values text: " + OptionValue);
        		if(OptionValue.equalsIgnoreCase(item)){
        			Option.click();
        			break;
        		}
        }
		
	}
	
	public void click(){
			
		}
	
	
	public void sendKeys(){
		
		//Stub
			
		}

		
	public static boolean isElementPresent(WebElement element) {

		try {
			element.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}

	}
	
	public static void VerifyElementNotEditable(WebElement element, String details) {
		
		if(CustomMethods.isElementPresent(element)){
			logger.log(LogStatus.FAIL, details+ " is editable");
		}else{
			logger.log(LogStatus.PASS, details + " is not editable");
		}
		
	}
	
	public static void VerifyElementNotEditable(WebElement element, String details,String attribute) {
			
			if(element.getAttribute(attribute).equalsIgnoreCase("false")){
				logger.log(LogStatus.PASS, details+ " is not editable");
			}else{
				logger.log(LogStatus.FAIL, details + " is editable");
			}
			
		}

	public static void VerifyElementIsEditable(WebElement element, String details) {
		
		if(CustomMethods.isElementPresent(element)){
			logger.log(LogStatus.PASS, details+ " is editable");
		}else{
			logger.log(LogStatus.FAIL, details + " is not editable");
		}
		
	}
	
	public static void VerifyElementIsEditable(WebElement element, String details,String attribute) {
			
			if(element.getAttribute(attribute).equalsIgnoreCase("true")){
				logger.log(LogStatus.PASS, details+ " is editable");
			}else{
				logger.log(LogStatus.FAIL, details + " is not editable");
			}
			
		}

	
	public static void waitForElementPresent(WebElement element) throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(baseTestSuite.driver, 30);
			wait.until(ExpectedConditions.visibilityOf(element));
				if(System.getProperty("takeScreenshot").equalsIgnoreCase("no")){
				logger.log(LogStatus.PASS, element.getText()+ "element has displayed");
				}else{
					logger.log(LogStatus.PASS, element.getText()+ " element has displayed" + logger.addScreenCapture(takeScreenShot(element.getText())));
				}
		} catch (Exception e) {
			logger.log(LogStatus.FAIL, "unable to locate element after 30 secs" + logger.addScreenCapture(takeScreenShot("Failed")));
		}

	}
	
	public static void waitForElementPresent(WebElement element, int time) throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(baseTestSuite.driver, time);
			wait.until(ExpectedConditions.visibilityOf(element));
				if(System.getProperty("takeScreenshot").equalsIgnoreCase("no")){
				logger.log(LogStatus.PASS, element.getText()+ " element has displayed");
				}else{
					logger.log(LogStatus.PASS, element.getText()+ " element has displayed" + logger.addScreenCapture(takeScreenShot(element.getText())));
				}
		} catch (Exception e) {
			logger.log(LogStatus.FAIL, "unable to locate element after "+time +" secs" + logger.addScreenCapture(takeScreenShot("Failed")));
		}

	}
	
	public static void waitForUpgradePopUpPresent(WebElement element, int time) throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(baseTestSuite.driver, time);
			wait.until(ExpectedConditions.visibilityOf(element));
				if(System.getProperty("takeScreenshot").equalsIgnoreCase("no")){
				logger.log(LogStatus.PASS, element.getText()+ " element has displayed");
				}else{
					logger.log(LogStatus.PASS, element.getText()+ " element has displayed" + logger.addScreenCapture(takeScreenShot(element.getText())));
				}
		} catch (Exception e) {
			logger.log(LogStatus.PASS, "Upgrade pop up not displayed");
		}
	}
	
	
	public WebDriver launchWebBrowser(){
		 System.setProperty("webdriver.chrome.driver" , System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
		 ChromeOptions options = new ChromeOptions();
		 options.addArguments("start-maximized");
		 DesiredCapabilities capabilities = DesiredCapabilities.chrome();    
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		 this.desktopWebDriver = new ChromeDriver(capabilities);
		 desktopWebDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		return desktopWebDriver;
	}
	
	public static int generateRandomNumber(int length){
		
		GenerateRandomUtils random = new GenerateRandomUtils();
		int randonNumber = random.generateRandomNumber(length);
		return randonNumber;
		
	}
	
	public static void disconnectAndReconnect() throws InterruptedException
	{
		BaseTestSuite baseTestSuite = new BaseTestSuite();
		((AndroidDriver) driver).setConnection(Connection.NONE);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());
		logger.log(LogStatus.INFO, "Disconnected Wifi by switching off wifi");
		
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"))));

		baseTestSuite.verifyPresent(
				driver.findElement(By
						.xpath("//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]")),
				"you have been disconnected pop up");
		
		((AndroidDriver) driver).setConnection(Connection.ALL);
		System.out.println("connection none: "+ ((AndroidDriver) driver).getConnection());
		logger.log(LogStatus.INFO, "connected ti Wifi by switching on wifi");
		Thread.sleep(5000);
		try{
			driver.findElement(By.xpath(
					"//android.widget.TextView[contains(@text,'You have been disconnected. Trying to reconnect')]"));
			logger.log(LogStatus.FAIL, "you have been disconnected pop up has not disappeared" + logger.addScreenCapture(takeScreenShot("failure")));
		}catch(Exception e){
			logger.log(LogStatus.PASS, "you have been disconnected pop up has been disappeared");
		}
		
	}
	
	public static void verifyEnabled(WebElement element, String elementName) throws IOException{
		try {
			if(element.getAttribute("enabled").equalsIgnoreCase("true")){
				logger.log(LogStatus.PASS, elementName+ " is enabled");
			}else{
					logger.log(LogStatus.FAIL, elementName+ " is not enabled" + logger.addScreenCapture(takeScreenShot(elementName)));
			}
			
		} catch (Exception e) {
			logger.log(LogStatus.FAIL, "unable to locate element "+elementName + logger.addScreenCapture(takeScreenShot(elementName)));
		}
	}
	
	public static void verifyNotEnabled(WebElement element, String elementName) throws IOException{
		try {
			if(element.getAttribute("enabled").equalsIgnoreCase("false")){
				logger.log(LogStatus.PASS, elementName+ " is not enabled");
			}else{
					logger.log(LogStatus.FAIL, elementName+ " should not be enabled" + logger.addScreenCapture(takeScreenShot(elementName)));
			}
			
		} catch (Exception e) {
			logger.log(LogStatus.FAIL, "unable to locate element "+elementName + logger.addScreenCapture(takeScreenShot(elementName)));
		}
	}
	
	public static void clickCheckBok(WebElement element, String elementName, Boolean check) throws IOException{
		//need to implement this method properlys
		try {
			if(element.getAttribute("checked").equalsIgnoreCase("true")){
				logger.log(LogStatus.PASS, elementName+ " is already checked");
			}else{
				element.click();
					logger.log(LogStatus.FAIL, elementName+ " checked on element");
			}
			
		} catch (Exception e) {
			logger.log(LogStatus.FAIL, "unable to locate element "+elementName + logger.addScreenCapture(takeScreenShot(elementName)));
		}
	}
	
	public static void verifyGuideLinesText(WebElement element,String Expected) throws IOException{
		
		System.out.println("guideLine text is : "+ element.getText());
		String guidelines= element.getText();
		String[] guideLinesEachLines= guidelines.split("\n\n");

		for(String eachLine:guideLinesEachLines){
			System.out.println("lines :"+ eachLine);
		
			baseTestSuite.verifyText(eachLine, Expected);
		}
	}
	
	public WebDriver launchNewSession(){
		
		capabilities.setCapability("deviceName", "emulator-5554");
		capabilities.setCapability("udid", "emulator-5554");
		capabilities.setCapability("platformName", "android");
		capabilities.setCapability("platformVersion", "6.0");
		capabilities.setCapability("appPackage", "air.com.ace2three.mobile.cash");
		capabilities.setCapability("appActivity", "com.ace2three.activity.SplashActivity");
		capabilities.setCapability("unicodeKeyboard", true);
		capabilities.setCapability("resetKeyboard", true);
        capabilities.setCapability("noReset", false);
        capabilities.setCapability("fullReset", false);
        capabilities.setCapability("newCommandTimeout", 60 * 3);
      
        try {
			this.Player2Driver = new AndroidDriver(new URL("http://127.0.0.1:4725/wd/hub/"), capabilities);
						
		} catch (MalformedURLException e) {
			baseTestSuite.extent.addSystemInfo("fail",
					"Either appium is not running or Server port addresses are not matching, Check appium settings");
			baseTestSuite.extent.addSystemInfo("warning", e.toString());
		}
       
		return Player2Driver;
   }
	
	public void resetChromeBrowser(WebDriver driver){

		/*capabilities.setCapability("deviceName", System.getProperty("deviceName"));
		capabilities.setCapability("udid",System.getProperty("udid"));
		capabilities.setCapability("platformName", System.getProperty("platformName"));
		capabilities.setCapability("platformVersion", System.getProperty("platformVersion"));
		capabilities.setCapability(CapabilityType.BROWSER_NAME,"chrome");
		capabilities.setCapability("deviceName","4d00cbf74f9a411b");
		capabilities.setCapability("udid","4d00cbf74f9a411b");
		capabilities.setCapability("platformName", "android");
		capabilities.setCapability("platformVersion","5.0");
		capabilities.setCapability(CapabilityType.BROWSER_NAME,"chrome");
		capabilities.setCapability("unicodeKeyboard", true);
		capabilities.setCapability("resetKeyboard", true);
        capabilities.setCapability("noReset", false);
        capabilities.setCapability("fullReset", false);
        capabilities.setCapability("newCommandTimeout", 60 * 2);
        WebDriver chromeDriver =null;
        try {
		 chromeDriver = new AndroidDriver(new URL("http://127.0.0.1:4725/wd/hub/"), capabilities);
						
		} catch (MalformedURLException e) {
			baseTestSuite.extent.addSystemInfo("fail",
					"Either appium is not running or Server port addresses are not matching, Check appium settings");
			baseTestSuite.extent.addSystemInfo("warning", e.toString());
		}
        
        chromeDriver.get("http://facebook.com");
        ((AndroidDriver)chromeDriver).resetApp();
        chromeDriver.quit();*/
		
		//((AndroidDriver)driver).s
        
	}
	
	public static String randomStringGenerator(int LenthOfString){

	    boolean useLetters = true;
	    boolean useNumbers = false;
	    String generatedString = RandomStringUtils.random(LenthOfString, useLetters, useNumbers);
	    System.out.println(generatedString.toLowerCase());
	    return generatedString.toLowerCase();
	}
	/*public static void main(String args[]){
		System.setProperty("webdriver.chrome.driver" , System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
		 
		 ChromeOptions options = new ChromeOptions();
		 options.addArguments("start-maximized");
		 DesiredCapabilities capabilities = DesiredCapabilities.chrome();    
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		 WebDriver desktopWebDriver = new ChromeDriver(capabilities);
		 desktopWebDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 desktopWebDriver.get("http://facebook.com");
	}*/
	
	public static void installFacebook() throws IOException, InterruptedException{
		String s= null;
		
		//String command = "adb -s "+System.getProperty("udid")+" install D:/Automation/Ace2Three/apk/com.facebook.katana_v152.0.0.42.136-83110613_Android-4.0.3.apk";
		String command = "adb install -r D:/Automation/WS/Ace2Three/apk/facebook.apk";
		System.out.println("installining");
		Process p=Runtime.getRuntime().exec(command);
		BufferedReader stdInput = new BufferedReader(new 
                InputStreamReader(p.getInputStream()));

           BufferedReader stdError = new BufferedReader(new 
                InputStreamReader(p.getErrorStream()));
           
           System.out.println("Here is the standard output of the command:\n");
           while ((s = stdInput.readLine()) != null) {
               System.out.println(s);
           }
           
           // read any errors from the attempted command
           System.out.println("Here is the standard error of the command (if any):\n");
           while ((s = stdError.readLine()) != null) {
               System.out.println(s);
           }
         //  System.exit(0);
		//Thread.sleep(70000);
	}
	public static void installAce2three() throws IOException, InterruptedException{
		String s= null;
		
		//String command = "adb -s "+System.getProperty("udid")+" install D:/Automation/Ace2Three/apk/com.facebook.katana_v152.0.0.42.136-83110613_Android-4.0.3.apk";
		String command = "adb install -r D:/Automation/WS/Ace2Three/apk/ace2threeApk/base.apk";
		System.out.println("installining");
		Process p=Runtime.getRuntime().exec(command);
		BufferedReader stdInput = new BufferedReader(new 
                InputStreamReader(p.getInputStream()));

           BufferedReader stdError = new BufferedReader(new 
                InputStreamReader(p.getErrorStream()));
           
           System.out.println("Here is the standard output of the command:\n");
           while ((s = stdInput.readLine()) != null) {
               System.out.println(s);
           }
           
           // read any errors from the attempted command
           System.out.println("Here is the standard error of the command (if any):\n");
           while ((s = stdError.readLine()) != null) {
               System.out.println(s);
           }
         //  System.exit(0);
		//Thread.sleep(70000);
	}
	
	public static void InstallAPK(String filename){
	    File file = new File("D:/Automation/WS/Ace2Three/apk/facebook.apk"); 
	    if(file.exists()){
	        try {   
	            String command;
	           // filename = StringUtil.insertEscape(filename);
	            command = "adb install -r " + file;
	            Process proc = Runtime.getRuntime().exec(new String[] { "su", "-c", command });
	            proc.waitFor();
	        } catch (Exception e) {
	        e.printStackTrace();
	        }
	     }
	  }
	
	/*public static void InstallAce2threeAPK(String filename){
	    File file = new File("D:/Automation/WS/Ace2Three/apk/ace2threeApk/base.apk"); 
	    if(file.exists()){
	        try {   
	            String command;
	           // filename = StringUtil.insertEscape(filename);
	            command = "adb install -r " + file;
	            Process proc = Runtime.getRuntime().exec(new String[] { "su", "-c", command });
	            proc.waitFor();
	        } catch (Exception e) {
	        e.printStackTrace();
	        }
	     }
	  }*/
	
	
	
	public static void unInstallFacebook() throws IOException{
		String s=null;
		String command = "adb -s "+System.getProperty("udid")+" uninstall com.facebook.katana";
		//String command = "adb -s 4d00cbf74f9a411b uninstall com.facebook.katana";
		Process p = Runtime.getRuntime().exec(command);
		
		BufferedReader stdInput = new BufferedReader(new 
                InputStreamReader(p.getInputStream()));

           BufferedReader stdError = new BufferedReader(new 
                InputStreamReader(p.getErrorStream()));
           
           System.out.println("Here is the standard output of the command:\n");
           while ((s = stdInput.readLine()) != null) {
               System.out.println(s);
           }
           
           // read any errors from the attempted command
           System.out.println("Here is the standard error of the command (if any):\n");
           while ((s = stdError.readLine()) != null) {
               System.out.println(s);
           }
       
	}
	
	public static void unInstallAce2three() throws IOException
	{
		String s=null;
		String command = "adb -s "+System.getProperty("udid")+" uninstall air.com.ace2three.mobile.cash";
		//String command = "adb -s 4d00cbf74f9a411b uninstall com.facebook.katana";
		Process p = Runtime.getRuntime().exec(command);
		
		BufferedReader stdInput = new BufferedReader(new 
                InputStreamReader(p.getInputStream()));

           BufferedReader stdError = new BufferedReader(new 
                InputStreamReader(p.getErrorStream()));
           
           System.out.println("Here is the standard output of the command:\n");
           while ((s = stdInput.readLine()) != null) {
               System.out.println(s);
           }
           
           // read any errors from the attempted command
           System.out.println("Here is the standard error of the command (if any):\n");
           while ((s = stdError.readLine()) != null) {
               System.out.println(s);
           }
		
	}
	
	public static void clearChromeData() throws IOException{
		String s=null;
		String command = "adb shell pm clear com.android.chrome";
		//String command = "adb -s 4d00cbf74f9a411b uninstall com.facebook.katana";
		Process p = Runtime.getRuntime().exec(command);
		
		BufferedReader stdInput = new BufferedReader(new 
                InputStreamReader(p.getInputStream()));

           BufferedReader stdError = new BufferedReader(new 
                InputStreamReader(p.getErrorStream()));
           
           System.out.println("Here is the standard output of the command:\n");
           while ((s = stdInput.readLine()) != null) {
               System.out.println(s);
           }
           
           // read any errors from the attempted command
           System.out.println("Here is the standard error of the command (if any):\n");
           while ((s = stdError.readLine()) != null) {
               System.out.println(s);
           }
		
	}
	
	public static void clearFBData() throws IOException{
		String s=null;
		String command = "adb shell pm clear com.facebook.katana";
		//String command = "adb -s 4d00cbf74f9a411b uninstall com.facebook.katana";
		Process p = Runtime.getRuntime().exec(command);
		
		BufferedReader stdInput = new BufferedReader(new 
                InputStreamReader(p.getInputStream()));

           BufferedReader stdError = new BufferedReader(new 
                InputStreamReader(p.getErrorStream()));
           
           System.out.println("Here is the standard output of the command:\n");
           while ((s = stdInput.readLine()) != null) {
               System.out.println(s);
           }
           
           // read any errors from the attempted command
           System.out.println("Here is the standard error of the command (if any):\n");
           while ((s = stdError.readLine()) != null) {
               System.out.println(s);
           }
		
	}
	
	public static String readOTPFromMobile()
	{
		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
		
		try {((AndroidDriver) driver).runAppInBackground(5);
        } catch (Exception e) {//ignore} 
        	
        }
		((AndroidDriver) driver).openNotifications();

		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'AM-ACEACT')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 1");
		}
		try {
			driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'New messages')]")).click();
		} catch (Exception e) {
			System.out.println("into exception 2");
		}

		driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'ACEACT')]")).click();

		List<WebElement> textMessages = driver
				.findElements(By.xpath("//android.widget.TextView[contains(@resource-id,'text_view')]"));
		int noOfMesg = textMessages.size();
		String messageText;
		/*if(noOfMesg==1)
			messageText = textMessages.get(0).getText();
			else
			messageText = textMessages.get(noOfMesg - 1).getText();*/
		messageText = textMessages.get(noOfMesg - 1).getText();
		System.out.println("Text Message actual:" + messageText);
		
		 /* for(int i=1;i==noOfMesg;i++){
		  System.out.println("telhasf "+textMessages.get(i).getText()); }*/
		 
		//messageText = textMessages.get(noOfMesg - 1).getText();
		String splitMessage[] =messageText.split(" ");
		String OTP= splitMessage[0].substring(0, 6);
		System.out.println("Text Message actual:" + textMessages.get(noOfMesg - 1).getText());
		System.out.println("OTP: " + OTP);
		for (WebElement message : textMessages) {
			System.out.println("Text Message :" + message.getText());
		}
		
		System.out.println(OTP);
		
		return OTP;
	}
	
	/*public static void installFacebook() throws IOException, InterruptedException{
		
		//String command = "adb -s "+System.getProperty("udid")+" install D:/Automation/Ace2Three/apk/com.facebook.katana_v152.0.0.42.136-83110613_Android-4.0.3.apk";
		String command = "adb -s 4d00cbf74f9a411b install D:/Automation/Ace2Three/apk/com.facebook.katana_v152.0.0.42.136-83110613_Android-4.0.3.apk";
		Process child = Runtime.getRuntime().exec(command);
		Thread.sleep(30000);
	}
	
	public static void unInstallFacebook() throws IOException{
		
		//String command = "adb -s "+System.getProperty("udid")+" uninstall com.facebook.katana";
		String command = "adb -s 4d00cbf74f9a411b uninstall com.facebook.katana";
		Process child = Runtime.getRuntime().exec(command);
		
	}*/
	

}
