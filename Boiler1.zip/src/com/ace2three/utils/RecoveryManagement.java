package com.ace2three.utils;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;

public class RecoveryManagement {
	BaseTestSuite base= new BaseTestSuite();
	WebDriver driver;
	public RecoveryManagement(WebDriver driver){
			//This initElements method will create all WebElements
			this.driver= driver;
			PageFactory.initElements(driver, this);
	     		
		}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'button2')]")
	private WebElement textMessageCancelButton;
	
	public WebElement getTextMessageCancelButton(){
		return textMessageCancelButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'button1')]")
	private WebElement textMessageCancelButton1;
	
	public WebElement getTextMessageCancelButton1(){
		return textMessageCancelButton1;
	}
	
	public void handleTextMessageAlert(){
		if(CustomMethods.isElementPresent(getTextMessageCancelButton1())){
			getTextMessageCancelButton1().click();
		}
		
		if(CustomMethods.isElementPresent(getTextMessageCancelButton())){
			getTextMessageCancelButton().click();
		}
		
	}
}
