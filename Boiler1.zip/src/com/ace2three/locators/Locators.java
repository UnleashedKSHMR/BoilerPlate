
package com.ace2three.locators;

public interface Locators {
	
	public interface WebHomePageLocators{
		
		final String SIGNUP_USERID_FIELD ="#registrationform input[id='username']";
		final String SIGNUP_PASSWORD_FIELD ="#registrationform input[id='password']";
		final String SIGNUP_EMAIL_PHONENUMBER_FIELD ="#registrationform input[id='email']";
		final String SIGNUP_PLAY_SUBMIT_FIELD ="#registrationform input[id='submit_btn']";
		
	}

}
