
package com.ace2three.locators;

public interface AndroidLocators {

		public interface LaunchPageLocators{
			
			final String GPS_POPUP_CLOSE ="//android.widget.Button[@text='Cancel']"; 
			final String GPS_POPUP_OK ="//android.widget.Button[@text='OK']";
			final String GPS_POPUP_MESSAGE ="//android.widget.TextView[contains(@resource-id,'message')]";
			
			final String LOGIN_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvLogin')]";
			final String ACE2THREE_LOGO ="//android.widget.ImageView[contains(@resource-id,'air.com.ace2three.mobile.cash:id/login_app_logo_IV')]";
			final String USERNAME_FIELD ="//android.widget.EditText[contains(@resource-id,'nicknameTV')]";
			final String PASSWORD_FIELD ="//android.widget.EditText[contains(@resource-id,'pwdTV')]";
			final String CLICK_TO_LOGIN_BUTTON ="//android.widget.Button[@text='Login']";
			final String PLP_BANNER_CLOSE ="//android.widget.ImageView[contains(@resource-id,'closeIv')]";
			final String REMEMBER_PASSWORD ="//android.widget.ImageView[contains(@resource-id,'remember_iv')]";
			final String FORGOT_PASSWORD ="//android.widget.TextView[contains(@text,'Forgot User ID/Password')]";
			final String DO_NOT_HAVE_ACCOUNT_LINK ="//android.widget.TextView[contains(@resource-id,'dont_have_acc')]";
			final String SIGNUP_BUTTON ="//*[contains(@text,'Sign Up')]";
			final String SECURE_100_PERCENTAGE_LOGO ="//android.widget.ImageView[contains(@resource-id,'login_secure_label_image')]";
			final String LEGAL_100_PERCENTAGE_LOGO ="//android.widget.ImageView[contains(@resource-id,'login_legal_label_image')]";
			
			final String SHOW_PASSWORD ="//android.widget.ImageView[contains(@resource-id,'password_show_click')]";
			final String PASSWORD_ERROR_MESSAGE ="//android.widget.TextView[contains(@resource-id,'error')]";
			final String FORGOT_PASSWORD_HEADER =".header .msub_t";
			final String KEEPME_LOGGED ="//android.widget.ImageView[contains(@resource-id,'remember_iv')]";
			final String MULTIPLE_INCORRECT_ATTEMPTS_ALERT ="//android.widget.TextView[contains(@resource-id,'statusalert')]";
			final String CLOSE_MULTIPLE_INCORRECT_ATTEMPTS_ALERT ="//android.widget.TextView[contains(@resource-id,'tvClose')]";
			final String OTP_SENT_ALERT_MESSAGE ="//android.widget.TextView[contains(@text,'OTP has been sent to your registered mobile and email id')]";
			final String OTP_SENT_ALERT_MESSAGE_OK_BUTTON ="//android.widget.Button[contains(@resource-id,'ok')]";
			final String OTP_RESENT_LINK ="//android.widget.TextView[contains(@resource-id,'resendOtpTv')]";
			final String SIGNIN_WITH_DIFFERENT_USERID ="//android.widget.TextView[contains(@resource-id,'sign_up_with_diff_acc_tv')]";
			}
		
		public interface ForgotPasswordLocators
		{
			final String FORGOT_USER_ID_LINK="//android.view.View[contains(@text,'Forgot User Id ?')]";
			final String FORGOT_PASSWORD_WEB_CLOSE_BUTTON="//android.widget.ImageView[contains(@resource-id,'closeIv')]";
			final String FORGOT_PASSWORD_MWEB_USER_ID_FIELD="//android.widget.EditText[contains(@resource-id,'useridfp')]";
			final String FORGOT_PASSWORD_MWEB_EMAIL_OR_MOBILE_NUMBER_FIELD="//android.widget.EditText[contains(@resource-id,'emailidfp')]";
			final String FORGOT_PASSWORD_MWEB_SUBMIT_BUTTON="//android.widget.Button[contains(@text,'SUBMIT')]";
			final String FORGOT_PASSWORD_STATUS_FIELD="//android.view.View[contains(@text,'Please enter valid')]";
			final String FORGOT_PASSWORD_RESEND_OTP_LINK="//android.view.View[contains(@text,'Resend OTP')]";
			final String FORGOT_PASSWORD_CONFIRM_BUTTON="//android.widget.Button[contains(@text,'Confirm')]";
			final String FORGOT_PASSWORD_STILL_OTP_NOT_RECEIVED_MESSAGE="//android.view.View[contains(@text,'Still did not receive OTP')]";
			final String FORGOT_PASSWORD_ENTER_EMAIL_ID="//android.view.View[contains(@text,'Please enter Email')]";
			final String FORGOT_PASSWORD_ENTER_OTP_FIELD="//android.widget.EditText[contains(@resource-id,'otpValue')]";
			final String FORGOT_PASSWORD_NEW_PASSWORD_FIELD="//android.widget.EditText[contains(@resource-id,'resetpassword')]";
			final String FORGOT_PASSWORD_CONFIRM_PASSWORD_FIELD="//android.widget.EditText[contains(@resource-id,'confirmpassword')]";
			final String FORGOT_PASSWORD_RESET_PASSWORD_BUTTON="//android.widget.Button[contains(@resource-id,'mPasswordReset_submit')]";
			final String FORGOT_PASSWORD_MWEB_SUCCESS_STATUS="//android.view.View[contains(@text,'Your password has been changed successfully')]";
		}
		
		public interface LoginPageLocators{
			final String RESTRICTED_ACCESS_LOGIN_MESSAGE ="//android.widget.TextView[contains(@text,'Access to Ace2Three is restricted from the location specified in your profile. Know more')]";
			final String KNOW_MORE_LINK ="//android.widget.TextView[contains(@text,'Access to Ace2Three is restricted from the location specified in your profile. Know more')]";
			
		}
		
		public interface LobbyPageLocators{
			final String USER_NAME_DISPLAY ="//android.widget.TextView[contains(@resource-id,'user_name_tv')]";
			final String HAM_BURGER_MENU ="//android.widget.ImageView[contains(@resource-id,'lobbysettingsIV')]";
			final String UPDATE_PROFILE_WEB_POPUP_HEADER ="//android.widget.ImageView[contains(@resource-id,'lobbysettingsIV')]";
			final String UPDATE_PROFILE_WEB_POPUP_CLOSE_BUTTON ="//android.widget.ImageView[contains(@resource-id,'closeIv')]";
			final String SIGN_UP_BANNER_POP_UP ="//android.widget.ImageView[contains(@resource-id,'closeBtn')]";
			final String THANK_YOU_FOR_SIGN_UP_MESSAGE ="//android.widget.ImageView[contains(@text,'Thank you for Signing up')]";
			final String SIGNUP_SUCCESSFUL_BANNER_NO_THANKS ="//android.widget.Button[contains(@resource-id,'negativeBtn')]";
			final String SIGNUP_SUCCESSFUL_BANNER_BUY_CHIPS ="//android.widget.Button[contains(@resource-id,'positiveBtn')]";
			final String HAM_BURGER_MENU_ITEM ="//android.widget.TextView[contains(@text,'%s')]";
			final String HOME_TAB_ICON_BOTTOM ="//android.widget.ImageView[contains(@resource-id,'homeIV')]";
			final String SIGN_OUT_POP_UP_MESSASGE ="//android.widget.TextView[contains(@resource-id,'statusalert')]";
			final String SIGN_OUT_POP_UP_YES_BUTTON ="//android.widget.Button[contains(@resource-id,'yes')]";
			final String SIGN_OUT_POP_UP_NO_BUTTON ="//android.widget.Button[contains(@resource-id,'no')]";
			final String SIGNUP_SUCCESSFUL_BANNER_CLOSE_BUTTON="//android.widget.ImageView[contains(@resource-id,'closeBtn')]";
			final String REGULAR_PLAYER_POST_LOGIN_BUY_CHIPS_POP="//android.widget.RelativeLayout[contains(@resource-id,'title_header')]";
			final String REGULAR_PLAYER_POST_LOGIN_BUY_CHIPS_BUTTON="//android.widget.Button[contains(@text,'Buy chips')]";
		}
		public interface SignupPageLocators{
			
			final String LOBBY_COUNT ="//android.widget.TextView[contains(@resource-id,'table_hint_tv')]";
			final String ACE2THREE_LOGO ="//android.widget.ImageView[contains(@resource-id,'login_app_logo_IV')]";
			final String MAIN_HEADER="//android.widget.TextView[contains(@text,'PLAY RUMMY ONLINE')]";
			final String SUB_HEADER="//android.widget.TextView[@text='ANYWHERE ANYTIME..']";
			final String USERNAME_FIELD="//android.widget.EditText[contains(@resource-id,'signup_nicknameTV')]";
			//final String EMAIL_ID_FIELD="//android.widget.EditText[@text='Email ID or Mobile No)']";
			final String EMAIL_MOBILE_NO_FIELD="//android.widget.EditText[contains(@resource-id,'signup_emailTV')]";
			final String PASSWORD_FIELD="//android.widget.EditText[contains(@resource-id,'signup_pwdTV')]";
			final String SIGNUP_BUTTON="//android.widget.Button[contains(@text,'Sign Up')]";
			final String SIGNUP_NOTE="//android.widget.TextView[contains(@text,'*By signing up, I verify I am above 18 years and agree to T&C')]";
			final String LOGIN_LINK_TEXT="//android.widget.TextView[contains(@text,'Already have an account')]";
			final String LOGIN_LINK="//android.widget.TextView[contains(@resource-id,'tvLogin')]";
			final String ERROR_MESSAGE="//android.widget.TextView[contains(@resource-id,'reg_error')]";
			final String CLICK_TO_LOGIN_BUTTON="//android.widget.Button[contains(@text='Login')]";
			final String SHOW_PASSWORD="//android.widget.ImageView[contains(@resource-id,'show_password_click')]";
			final String LOGIN_SIGNUP_BUTTON ="//android.widget.Button[contains(@text,'Sign up')]";
			
		}
		public interface GameSettingsLocators{
			
			final String GAMES_SETTINGS_POPUP_HEADER ="//android.widget.TextView[contains(@text,'Game Settings')]";
			final String SOUND_ON_OFF_OPTION ="//android.widget.ImageView[contains(@resource-id,'sound_on_off_iv')]";
			final String VIBRATION_ON_OFF_OPTION ="//android.widget.ImageView[contains(@resource-id,'vibration_on_off_iv')]";
			final String PROFILE_ON_OFF_OPTION ="//android.widget.ImageView[contains(@resource-id,'profile_on_off_iv')]";
			final String GAME_SETTINGS_CLOSE ="//android.widget.TextView[contains(@text,'Game Settings')]/following-sibling::android.widget.ImageView";
			
			
		}
		
		public interface MyAccountScreenLocators{
			
			final String PASSWORD_PROMPT_POP_UP ="//android.widget.TextView[contains(@text,'Enter Password')]";
			final String PASSWORD_POP_UP_FIELD ="//android.widget.RelativeLayout[contains(@resource-id,'password_field')]/android.widget.EditText";
			final String PASSWORD_POP_UP_SUBMIT_BUTTON ="//android.widget.Button[contains(@resource-id,'password_submit')]";
			final String MY_ACCOUNT_BUY_CHIPS ="//android.widget.Button[contains(@resource-id,'myaccount_buych_button')]";
			final String PASSWORD_PROMPT_POP_UP_INVALID_ERROR ="//android.widget.TextView[contains(@resource-id,'password_error')]";
			final String MYACCOUNT_SECTION_INFOCUS ="//android.view.View[contains(@resource-id,'ptsProfile')]/android.widget.TextView[2]";
			final String MYACCOUNT_SCREEN_RIGHTARROW ="//android.widget.ImageView[contains(@resource-id,'ivRightArrow')]";
			final String MYACCOUNT_SCREEN_LEFTARROW ="//android.widget.ImageView[contains(@resource-id,'ivLeftArrow')]";
			
		}
		public interface MyProfileScreenLocators{
			
			final String MYPROFILE_PIC_IMAGE_LOC ="//android.widget.ImageView[contains(@resource-id,'profilePicImageView')]";
			final String MYPROFILE_FIRST_NAME_LOC ="//android.widget.EditText[contains(@resource-id,'etFirstName')]";
			final String MYPROFILE_LAST_NAME_LOC ="//android.widget.EditText[contains(@resource-id,'etLastName')]";
			final String MYPROFILE_DOB_FIELD_LOC ="//android.widget.TextView[contains(@resource-id,'tvProfileDOB')]";
			final String MYPROFILE_GENDER_FIELD_LOC ="//android.widget.TextView[contains(@resource-id,'tvProfileGender')]";
			final String MYPROFILE_STATE_FIELD_LOC ="//android.widget.TextView[contains(@resource-id,'tvProfileState')]";
			final String MYPROFILE_CITY_FIELD_LOC ="//android.widget.TextView[contains(@resource-id,'tvProfileCity')]";
			final String MYPROFILE_SAVE_BUTTON_LOC ="//android.widget.TextView[contains(@resource-id,'tvSaveDetails')]";
			final String MYPROFILE_ERROR_MESSAGE ="//android.widget.TextView[contains(@resource-id,'tvSavePersonalDetailsError')]";
			final String MYPROFILE_CALENDER_OK_BUTTON ="//android.widget.Button[contains(@text,'OK')]";
			final String MYPROFILE_CALENDER_ICON ="//android.widget.ImageView[contains(@resource-id,'ivCalendar')]";
			final String MYPROFILE_GENDER_DROP_DOWN_ICON ="//android.widget.ImageView[contains(@resource-id,'ivGenderDropDown')]";
			final String MYPROFILE_GENDER_DROP_DOWN_FIELD ="//android.widget.TextView[contains(@resource-id,'tvProfileGender')]";
			final String MYPROFILE_STATE_DROP_DOWN_ICON ="//android.widget.ImageView[contains(@resource-id,'ivStateDropDown')]";
			final String MYPROFILE_STATE_DROP_DOWN_FIELD ="//android.widget.TextView[contains(@resource-id,'tvProfileState')]";
			final String MYPROFILE_CITY_DROP_DOWN_ICON ="//android.widget.ImageView[contains(@resource-id,'ivCityDropDown')]";
			final String MYPROFILE_CITY_DROP_DOWN_FIELD ="//android.widget.TextView[contains(@resource-id,'tvProfileCity')]";
			final String PROFILE_PIC_EDIT_BUTTON ="//android.widget.LinearLayout[contains(@resource-id,'llEditPic')]";
			final String PROFILE_PIC_EDIT_ALERT_POPUP_MESSAGE ="//android.widget.TextView[contains(@text,'Please verify your E-mail ID and Mobile Number')]";
			final String PROFILE_PIC_EDIT_ALERT_POPUP_VERIFYNOW_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvVerifyNow')]";
			final String PROFILE_PIC_EDIT_ALERT_POPUP_LATER_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvOk')]";
			final String GUIDELINES_FOR_FROFILE_PICTURE_HEADER ="//android.widget.TextView[contains(@text,'Guidelines for Profile Picture')]";
			final String GUIDELINES_TEXT_FOR_FROFILE_PICTURE ="//android.widget.TextView[@resource-id='air.com.ace2three.mobile.cash:id/tvGuidelines']";
			final String GUIDELINES_POP_UP_FOR_FROFILE_PICTURE_OK_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvOk')]";
			final String PROFILE_PIC_UPLOAD_SUCCESS_POPUP_MESSAGE ="//android.widget.TextView[contains(@resource-id,'tvMessage')]";
			final String PROFILE_PIC_UPLOAD_SUCCESS_POPUP_MESSAGE_OK_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvOk')]";
			final String PROFILE_PIC_APPROVAL_PENDING_STATUS ="//android.widget.TextView[contains(@resource-id,'tvPicStatusMsg')]";
			
			
		}
		public interface KycScreeenLocators{
			
			final String KYC_EMAIL_FIELD_LOC ="//android.widget.EditText[contains(@resource-id,'etKYCEmail')]";
			final String KYC_EMAIL_VALIDATION_INDICATOR ="//android.widget.ImageView[contains(@resource-id,'ivKYCEmailValidate')]";
			final String KYC_EMAIL_VERIFY_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvKYCEmailVerify')]";
			final String KYC_PHONE_NO_FIELD_LOC ="//android.widget.EditText[contains(@resource-id,'etKYCMobile')]";
			final String KYC_PHONE_NO_VALIDATION_INDICATOR ="//android.widget.ImageView[contains(@resource-id,'ivKYCMobileValidate')]";
			final String KYC_PHONE_NO_VERIFY_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvKYCMobileVerify')]";
			final String KYC_PAN_FIELD_LOC ="//android.widget.EditText[contains(@resource-id,'tvKYCPan')]";
			final String KYC_PAN_VALIDATION_INDICATOR ="//android.widget.ImageView[contains(@resource-id,'ivKYCPanValidate')]";
			final String KYC_PAN_VERIFY_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvKYCPanUpload')]";
			final String KYC_PAN_HELP_BUTTON ="//android.widget.ImageView[contains(@resource-id,'ivKYCPanHelp')]";
			final String KYC_ID_PROOF_FIELD_LOC ="//android.widget.TextView[contains(@resource-id,'tvKYCIdProof')]";
			final String KYC_ID_PROOF_VALIDATION_INDICATOR ="//android.widget.ImageView[contains(@resource-id,'ivKYCIdProofValidate')]";
			final String KYC_ID_PROOF_VERIFY_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvKYCIdProofUpload')]";
			final String KYC_EMAIL_WARNING_MESSAGE ="//android.widget.TextView[contains(@resource-id,'tvKYCEmailError')]";
			final String KYC_PHONE_NO_INVALID_ERROR ="//android.widget.TextView[contains(@resource-id,'tvKYCMobileError')]";
			final String ID_PROOF_GUIDELINES_POPUP_CONTENT_SECTION ="//android.widget.ScrollView[contains(@resource-id,'scrollView')]/android.widget.TextView[contains(@resource-id,'tvGuidelines')]";
			final String ID_PROOF_GUIDELINES_POPUP_HEADER ="//android.widget.TextView[contains(@resource-id,'tvGuidelinesTitle')]";
			final String PAN_PROOF_GUIDELINES_POPUP_HEADER ="//android.widget.TextView[contains(@resource-id,'tvUploadFileTitle')]";
			final String ID_PROOF_GUIDELINES_POPUP_OK_BUTTON ="//android.widget.TextView[contains(@resource-id,'tvOk')]";
			final String ID_PROOF_UPLOAD_POPUP_HEADER ="//android.widget.TextView[contains(@resource-id,'tvUploadFileTitle')]";
			final String ID_PROOF_UPLOAD_POPUP_GUIDELINES_ICON ="//android.widget.TextView[contains(@resource-id,'ivInfo')]";
			final String ID_PROOF_UPLOAD_POPUP_CAMERA_ICON ="//android.widget.ImageView[contains(@resource-id,'ivCamera')]";
			final String ID_PROOF_UPLOAD_POPUP_UPLOAD_ICON ="//android.widget.ImageView[contains(@resource-id,'ivGallery')]";
			final String ID_PROOF_UPLOAD_POPUP_INSTRUCTIONS_TEXT ="//android.widget.TextView[contains(@resource-id,'tvInstruction')]";
			final String ID_PROOF_UPLOAD_POPUP_CLOSE_ICON ="//android.widget.TextView[contains(@resource-id,'tvClose')]";
			final String CAMERA_SHUTTER_BUTTON ="//android.widget.ImageView[contains(@resource-id,'shutter_button')]";
			final String ENTER_OTP_POPUP ="//android.widget.RelativeLayout[contains(@resource-id,'VerifymobRL')]/android.widget.RelativeLayout[contains(@resource-id,'otp_parent_layout')]";
			final String OTP_ENTRY_FIELD ="//android.widget.EditText[contains(@resource-id,'otp_message_entry')]";
			final String OTP_RESEND_LINK ="//android.widget.TextView[contains(@resource-id,'otp_message_resend')]";
			final String OTP_PROGRESS_TIMEBAR ="//android.widget.ProgressBar[contains(@resource-id,'otp_progress_timer_bar')]";
			final String OTP_PROGRESS_TIME ="//android.widget.TextView[contains(@resource-id,'otp_progress_timer')]";
			final String OTP_INCORRECT_ERROR ="//android.widget.TextView[contains(@resource-id,'otp_error_message')]";
			final String OTP_CONFIRM_BUTTON ="//android.widget.Button[contains(@resource-id,'otp_message_button')]";
			
		}

			public interface GiftVouchersPageLocators{
			
		
			}
			
			public interface MyAccountDetailsPage{
				final String REDEEM_BUTTON ="//android.widget.Button[contains(@resource-id,'myaccount_redeem_button')]";
				final String BUY_CHIPS_BUTTON ="//android.widget.Button[contains(@resource-id,'myaccount_buych_button')]";
				final String REDEEM_ACE_POINTS_BUTTON ="//android.widget.Button[contains(@resource-id,'myaccount_redeem_acepoints_button')]";
				final String REAL_CHIPS_BALANCE ="//android.widget.TextView(@resource-id,'myaccount_total_realchips_value')]";
				final String REAL_CHIPS_REDEEMABLE_BALANCE ="//android.widget.TextView[contains(@resource-id,'myaccount_total_redeembalance_value')]";
				final String ACE_POINTS_BALANCE ="//android.widget.TextView[contains(@resource-id,'myaccount_acepointsbalance_value')]";
				final String ACE_LEVEL ="//android.widget.TextView[contains(@resource-id,'myaccount_acelevel_value')]";
				final String ACE_LEVEL_UPGRADE ="//android.widget.TextView[contains(@resource-id,'myaccount_upradeal_field')]";
				final String ACE_LEVEL_UPGRADE_VALUE ="//android.widget.TextView[contains(@resource-id,'myaccount_upradeal_value')]";
				final String WEB_REDIRECT_ALERT_FOR_REDEEM_YES ="//android.widget.Button[contains(@resource-id,'yes')]";
				final String WEB_REDIRECT_ALERT_FOR_REDEEM_NO ="//android.widget.Button[contains(@resource-id,'no')]";
				final String WEB_REDIRECT_ALERT_FOR_REDEEM_MESSAGE ="//android.widget.TextView[contains(@resource-id,'statusalert')]";
				final String THIS_FEATURE_IS_AVAILABLE_ONLY_FOR_PREMIUM_PLAYERS_MESSAGE="//android.widget.TextView[contains(@resource-id,'statusalert')]";
				
			}//android.widget.TextView[contains(@resource-id,'statusalert')]
			
			public interface ChangePasswordPageLocators{
				
				final String HAMBURGER_MENU_CHANGE_PASSWORD="//android.widget.TextView[contains(@text,'Change Password')]";
				final String CURRENT_PASSWORD_FIELD="//android.widget.EditText[contains(@resource-id,'etCurrentPassword')]";
				final String CURRENT_PASSWORD_SHOW_BUTTON="//android.widget.TextView[contains(@resource-id,'tvShowCurrentPassword')]";
				final String NEW_PASSWORD_FIELD="//android.widget.EditText[contains(@resource-id,'etNewPassword')]";
				final String NEW_PASSWORD_SHOW_BUTTON="//android.widget.TextView[contains(@resource-id,'tvShowNewPassword')]";
				final String CONFIRM_PASSWORD_FIELD="//android.widget.EditText[contains(@resource-id,'etConfirmPassword')]";
				final String CONFIRM_PASSWORD_SHOW_BUTTON="//android.widget.TextView[contains(@resource-id,'tvShowConfirmPassword')]";
				final String CHANGE_PASSWORD_SUBMIT_BUTTON="//android.widget.TextView[contains(@resource-id,'tvSubmitChangePassword')]";
				final String PASSWORD_GUIDELINES_OK_BUTTON="//android.widget.TextView[contains(@resource-id,'okay_button')]";
				final String CHANGE_PASSWORD_GUIDELINES_TEXT="//android.widget.TextView[contains(@resource-id,'tv_guidelines')]";
				final String PASSWORD_GUIDELINES_HEADER="//android.widget.TextView[contains(@resource-id,'tv_guidelines_title')]";
				final String CHANGE_PASSWORD_ERROR_STATUS_FIELD="//android.widget.TextView[contains(@resource-id,'tvErrorChangePassword')]";
				final String PASSWORD_CHANGED_SUCCESSFULLY_TEXT="//android.widget.TextView[contains(@resource-id,'statusalert')]";
				final String PASSWORD_CHANGED_SUCCESSFULLY_OK_BUTTON="//android.widget.Button[contains(@resource-id,'yes')]";
				final String CHANGE_YOUR_PASSWORD_POP_UP="//android.widget.TextView[contains(@resource-id,'header_title_tv')]";
				final String CHANGE_NOW_BUTTON="//android.widget.Button[contains(@resource-id,'bt_pwd_ok')]";
				final String CHANGE_YOUR_PASSWORD_POP_TEXT="//android.widget.TextView[contains(@resource-id,'otp_tv_msg')]";
				final String NOT_NOW_BUTTON="//android.widget.Button[contains(@resource-id,'bt_pwd_nw')]";
				final String CHANGE_YOUR_PASSWORD_POP_UP_CLOSE_BUTTON="//android.widget.TextView[contains(@resource-id,'tvClose')]";
				final String CHANGE_PASSWORD_WINDOW_HEADER="//android.widget.TextView[contains(@resource-id,'tvDialogTitle')]";
				final String YOUR_PSWD_HAS_BEEN_CHANGED_MSG_AT_LOGIN_SCREEN="//android.widget.TextView[contains(@resource-id,'error')]";
			
			}
			
			public interface AchievementsPageLocators{
				
				final String ACHIEVEMENTS_HEADER="//android.widget.TextView[contains(@resource-id,'achievementsHeadingTextView')]";
				final String MAKE_YOUR_FIRST_PURCHASE="//android.widget.TextView[contains(@text,'Make your first purchase')]";
				final String Buy_CHIPS_BUTTON = "//android.widget.TextView[contains(@resource-id,'buyChipsTextView')]";
				final String TRICKY_THREE_HEADER="//android.widget.TextView[contains(@text,'Tricky Three')]";
				final String RUMMY_PRO_HEADER="//android.widget.TextView[contains(@text,'Rummy Pro')]";
				final String FANTASTIC_FIVE_HEADER="//android.widget.TextView[contains(@text,'Fantastic Five')]";
				final String POOL_101_MASTER_HEADER="//android.widget.TextView[contains(@text,'101 Master')]";
				final String POOL_201_MASTER_HEADER="//android.widget.TextView[contains(@text,'Pool Master')]";
				final String STAKES_MASTER_HEADER="//android.widget.TextView[contains(@text,'Stakes Master')]";
				
			}
			
			
}


