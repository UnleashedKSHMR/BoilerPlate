
package com.ace2three.locators;

public interface IOSLocators {

}
