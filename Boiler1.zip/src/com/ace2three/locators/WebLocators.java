package com.ace2three.locators;

public interface WebLocators {

	public interface AdminLoginPage{
		final String ADMIN_USER_NAME ="input[id='Username']";
		final String ADMIN_PASSWORD_FIELD ="input[id='Password']";
		final String ADMIN_SUBMIT_BUTTON ="table.loginpattern tr td input[id='loginsubmit']";
		final String TOURNEY_TAB ="//*[@text='TOURNEYS']";
		
		
	}
	public interface EnforceStrongPassword{
		final String ENFORCE_STRONG_PASSWORD="input[id='openPopUp']";
		final String CONTACT_MODE="select[id='contactmode']";
		final String PRO_ACTIVE="option[value='pro-active']";
		final String INTERACTION_CHANNEL="select[id='ContactChannel']";
		final String COMMENT="textarea[id='commentForPasswordChange']";
		final String SUBMIT="input[value='Submit']";
	}
	
}
