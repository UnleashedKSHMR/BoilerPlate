package com.ace2three.app.webview.impl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;

public class RedeemAcePointsWebImplPage {

	public RedeemAcePointsWebImplPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'AcePoints')]")
	private WebElement redeemAcePointsHeader;
	
	public WebElement getRedeemAcePointsHeader(){
		return redeemAcePointsHeader;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'REDEEM WITH PURCHASE')]")
	private WebElement redeemAcePointsPurchaseButton;
	
	public WebElement getRedeemAcePointsPurchaseButton(){
		return redeemAcePointsPurchaseButton;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@resource-id,'balanceInfo')]")
	private WebElement inSufficientMessage;
	
	public WebElement getInSufficientMessage(){
		return inSufficientMessage;
	}
}
