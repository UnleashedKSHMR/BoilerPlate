package com.ace2three.app.webview.impl.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.impl.pages.MyAccountDetailsImplPage;
import com.ace2three.utils.CustomMethods;

public class AddCashWebViewImplPage {
	WebDriver driver;
	
	public AddCashWebViewImplPage(WebDriver driver) throws IOException {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		CustomMethods.waitForElementPresent(getAddCashPageHeader() , 30);
	}
	
	@FindBy(xpath= "//android.widget.ImageView[contains(@resource-id,'closeIv')]")
	private WebElement addCashWebViewClose;
	
	public WebElement getAddCashWebViewClose(){
		return addCashWebViewClose;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Add Cash')]")
	private WebElement addCashPageHeader;
	
	public WebElement getAddCashPageHeader(){
		return addCashPageHeader;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'PAY %s')]")
	private WebElement addCashPayButton;
	
	public WebElement getAddCashPayButton(){
		return addCashPayButton;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'p_custom_amount')]")
	private WebElement customAmountField;
	
	public WebElement getCustomAmountField(){
		return customAmountField;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'choosePayment')]")
	private WebElement changePaymentMode;
	
	public WebElement getChangePaymentMode(){
		return changePaymentMode;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Wallets')]")
	private WebElement walletsPaymentMode;
	
	public WebElement getWalletsPaymentMode(){
		return walletsPaymentMode;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Bank MobiKwik')]")
	private WebElement mobikwikOption;
	
	public WebElement getMobikwikOption(){
		return mobikwikOption;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Mobikiwik PAY')]")
	private WebElement mobikwikPayButton;
	
	public WebElement getMobikwikPayButton(){
		return mobikwikPayButton;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Mobikiwik Cancel')]")
	private WebElement mobikwikCancelButton;
	
	public WebElement getMobikwikCancelButton(){
		return mobikwikCancelButton;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'CHANGE PASSWORD')]")
	private WebElement changePasswordButton;
	
	public WebElement getChangePasswordButton(){
		return changePasswordButton;
	}
	@FindBy(xpath="//android.widget.EditText[contains(@resource-id,'currentPass')]")
	private WebElement currentPasswordfield;
	
	public WebElement getCurrentPasswordfield(){
		return currentPasswordfield;
	}
	@FindBy(xpath="//android.widget.EditText[contains(@resource-id,'newPass')]")
	private WebElement newPasswordfield;
	
	public WebElement getNewPasswordfield(){
		return newPasswordfield;
	}
	
	@FindBy(xpath="//android.widget.EditText[contains(@resource-id,'newPass1')]")
	private WebElement confirmPasswordfield;
	
	public WebElement getConfirmPasswordfield(){
		return confirmPasswordfield;
	}
	
	@FindBy(xpath="//android.widget.Button[contains(@resource-id,'submit_chngPwd')]")
	private WebElement submitButton;
	
	public WebElement getSubmitButton(){
		return submitButton;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'Change Password')]")
	private WebElement changePasswordHeader;
	
	public WebElement getChangePasswordHeader(){
		return changePasswordHeader;
	}
	@FindBy(xpath="//android.view.View[contains(@text,'Mobikwik')]")
	private WebElement lastUsedPaymentMode;
	
	public WebElement getLastUsedPaymentMode(){
		return lastUsedPaymentMode;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'PAY NOW')]")
	private WebElement payNowButton;
	
	public WebElement getPayNowButton(){
		return payNowButton;
	}
	
	public void addCash(String amount){
		
		String payButtonLocator="//android.view.View[contains(@text,'PAY %s')]";
		String payButtonLocatorActual= String.format(payButtonLocator, amount);
		driver.findElement(By.xpath(payButtonLocatorActual)).click();
		MyAccountDetailsImplPage MyAccountpage = new MyAccountDetailsImplPage(driver);
		
		MyAccountpage.getNetBankingOption().click();
		MyAccountpage.getAxisBankOption().click();
		MyAccountpage.getPayNowButton().click();
		MyAccountpage.getAxisPayButton().click();
		
	}

	public enum paymentMethods{
		AxisBank,MobiKwik;
	}
	public void addCash(String amount, paymentMethods paymentMode) throws IOException{
			
		if(CustomMethods.isElementPresent(getCustomAmountField())){
			getCustomAmountField().clear();
			getCustomAmountField().sendKeys(amount);
			if(getLastUsedPaymentMode().getText().contains("Mobikwik"))
			{
				getPayNowButton().click();
				CustomMethods.waitForElementPresent(getMobikwikPayButton(),30);
				getMobikwikPayButton().click();
				return ;
			}
			//getChangePaymentMode().click();
		}else{
			String payButtonLocator="//android.view.View[contains(@text,'PAY %s')]";
			String payButtonLocatorActual= String.format(payButtonLocator, amount);
			CustomMethods.waitForElementPresent(driver.findElement(By.xpath(payButtonLocatorActual)),30);
			driver.findElement(By.xpath(payButtonLocatorActual)).click();
		}
		
		MyAccountDetailsImplPage MyAccountpage = new MyAccountDetailsImplPage(driver);
		if(paymentMode.toString().equalsIgnoreCase("AxisBank")){
			MyAccountpage.getNetBankingOption().click();
			MyAccountpage.getAxisBankOption().click();
			MyAccountpage.getPayNowButton().click();
			MyAccountpage.getAxisPayButton().click();
		}else if(paymentMode.toString().equalsIgnoreCase("MobiKwik")){
			if(CustomMethods.isElementPresent(getChangePaymentMode()))
			getChangePaymentMode().click();
			driver.getPageSource();
			CustomMethods.waitForElementPresent(getWalletsPaymentMode(),30);
			getWalletsPaymentMode().click();
			driver.getPageSource();
			CustomMethods.waitForElementPresent(getMobikwikOption(),30);
			getMobikwikOption().click();
			MyAccountpage.getPayNowButton().click();
			CustomMethods.waitForElementPresent(getMobikwikPayButton(),30);
			getMobikwikPayButton().click();
		}

			
	}

}
