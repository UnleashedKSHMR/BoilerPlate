package com.ace2three.app.webview.impl.pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.utils.CustomMethods;

public class ForgotPasswordWebViewImplPage {

	
	WebDriver driver;
	public ForgotPasswordWebViewImplPage(WebDriver driver) throws IOException {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		CustomMethods.waitForElementPresent(getForgotPasswordHeader() , 7);
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Forgot Password')]")
	private WebElement forgotPasswordHeader;
	
	public WebElement getForgotPasswordHeader(){
		return forgotPasswordHeader;
	}
	
}
