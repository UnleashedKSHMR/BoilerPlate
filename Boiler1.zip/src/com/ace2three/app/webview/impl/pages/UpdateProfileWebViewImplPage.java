package com.ace2three.app.webview.impl.pages;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ace2three.base.BaseTestSuite;
import com.ace2three.impl.pages.LobbyImplPage;
import com.ace2three.utils.CustomMethods;
import com.ace2three.utils.DataBaseServerConnect;
import com.ace2three.utils.business.BusinessMethods;

public class UpdateProfileWebViewImplPage {

WebDriver driver;
	
	public UpdateProfileWebViewImplPage(WebDriver driver) throws IOException {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		CustomMethods.waitForElementPresent(getPhoneNumberField() , 3);
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'mobile')]")
	private WebElement phoneNumberField;
	
	public WebElement getPhoneNumberField(){
		return phoneNumberField;
	}
	
	@FindBy(xpath= "//android.view.View[@index='5']")
	private WebElement phoneNumberVerifyButton;
	
	public WebElement getPhoneNumberVerifyButton(){
		return phoneNumberVerifyButton;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'OTP Sent')]")
	private WebElement otpSentAlertMessage;
	
	public WebElement getOtpSentAlertMessage(){
		return otpSentAlertMessage;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'mobileOTP')]")
	private WebElement otpEnterField;
	
	public WebElement getOtpEnterField(){
		return otpEnterField;
	}
	
	@FindBy(xpath= "//android.view.View[@index='7']/android.view.View[contains(@text,'Verify')]")
	private WebElement otpVerifyLink;
	
	public WebElement getOtpVerifyLink(){
		return otpVerifyLink;
	}
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'firstName')]")
	private WebElement firstNameEditText;
	
	public WebElement getFirstNameEditText(){
		return firstNameEditText;
	}
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'lastName')]")
	private WebElement lastNameEditText;
	
	public WebElement getLastNameEditText(){
		return lastNameEditText;
	}
	@FindBy(xpath= "//android.widget.EditText[contains(@resource-id,'mobile')]")
	private WebElement mobileNumberEditText;
	
	public WebElement getMobileNumberEditText(){
		return mobileNumberEditText;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'shortprofile_mobilesubmit')]")
	private WebElement shortProfileContinueButton;
	
	public WebElement getShortProfileContinueButton(){
		return shortProfileContinueButton;
	}
	
	
	
	
	public void verifyPhoneNumberFromShortProfilePage(String phoneNumber,String username) throws InterruptedException, SQLException{
		getPhoneNumberField().sendKeys(phoneNumber);
		getPhoneNumberVerifyButton().click();
		BaseTestSuite baseTestSuite = new BaseTestSuite();
		baseTestSuite.verifyPresent(getOtpSentAlertMessage(), "OTP sent message");
		
		DataBaseServerConnect dataBaseServerConnect = new DataBaseServerConnect();
		String OTP =dataBaseServerConnect.selectQuery(null, username);
		getOtpEnterField().sendKeys(OTP);
		getOtpVerifyLink().click();
		
	}
	public void selectFromDropDownListOfShortProfile(String item){
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		 // Update profiel,....
       // List<WebElement> Options= element;
		List<WebElement> Options= driver.findElements(By.xpath("//android.widget.CheckedTextView[contains(@resource-id,'text1')]"));
        for(WebElement Option:Options){
        	String OptionValue= Option.getText();
        	System.out.println("Values text: " + OptionValue);
        		if(OptionValue.equalsIgnoreCase(item)){
        			Option.click();
        			break;
        		}
        }
		
	}
	
	public void updateShortProfile() throws IOException, InterruptedException
	{
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		
		getFirstNameEditText().sendKeys(CustomMethods.randomStringGenerator(5));
		getLastNameEditText().sendKeys(CustomMethods.randomStringGenerator(5));
		Random ran = new Random();
		String year=199+""+ran.nextInt(9);
		/*int mob= ran.nextInt(Integer.SIZE - 1) + 123456789;
		System.out.println(8+""+mob);
		*/
		
		getMobileNumberEditText().sendKeys(86523+""+CustomMethods.generateRandomNumber(5));
		
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'yeardropdown')]")).click();
		selectFromDropDownListOfShortProfile("199"+(ran.nextInt(9-4)+4));
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'monthdropdown')]")).click();
		selectFromDropDownListOfShortProfile("Mar");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'daydropdown')]")).click();
		selectFromDropDownListOfShortProfile("04");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'state')]")).click();
		selectFromDropDownListOfShortProfile("Andhra Pradesh");
		
		
		getShortProfileContinueButton().click();
		Thread.sleep(2000);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
	}
	
	public void updateShortProfileWithoutStateAndMobileNo() throws IOException, InterruptedException
	{
		LobbyImplPage lobbyImplPage = new LobbyImplPage();
		CustomMethods.waitForElementPresent(getFirstNameEditText(), 30);
		getFirstNameEditText().sendKeys(CustomMethods.randomStringGenerator(5));
		getLastNameEditText().sendKeys(CustomMethods.randomStringGenerator(5));
		Random ran = new Random();
		String year=199+""+ran.nextInt(9);
		/*int mob= ran.nextInt(Integer.SIZE - 1) + 123456789;
		System.out.println(8+""+mob);
		*/
		
		//getMobileNumberEditText().sendKeys(86523+""+CustomMethods.generateRandomNumber(5));
		
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'yeardropdown')]")).click();
		selectFromDropDownListOfShortProfile("199"+(ran.nextInt(9-4)+4));
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'monthdropdown')]")).click();
		selectFromDropDownListOfShortProfile("Mar");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'daydropdown')]")).click();
		selectFromDropDownListOfShortProfile("04");
		Thread.sleep(1000);
	//	driver.findElement(By.xpath("//android.widget.Spinner[contains(@resource-id,'state')]")).click();
	//	selectFromDropDownListOfShortProfile("Andhra Pradesh");
		
		
		getShortProfileContinueButton().click();
		Thread.sleep(2000);
		if(CustomMethods.isElementPresent(lobbyImplPage.getUpdateProfilePopUpClose()))
			lobbyImplPage.getUpdateProfilePopUpClose().click();
	}
}
