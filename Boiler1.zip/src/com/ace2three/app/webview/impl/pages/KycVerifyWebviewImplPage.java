package com.ace2three.app.webview.impl.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;

	public class KycVerifyWebviewImplPage {

	public KycVerifyWebviewImplPage(AndroidDriver driver) {

		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'If you are not a player from')]")
	private WebElement kyc;
	
	public WebElement getKycEmailField(){
		return kyc;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Verify KYC')]")
	private WebElement verifyKyc;
	
	public WebElement getVerifyKyc(){
		return verifyKyc;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'OK')]")
	private WebElement locationAlertOkButton;
	
	public WebElement getLocationAlertOkButton(){
		return locationAlertOkButton;
	}
	@FindBy(xpath= "//android.widget.CheckedTextView[contains(@text,'Aadhaar Card')]")
	private WebElement aadharCardRadioButton;
	
	public WebElement getAadharCardRadioButton(){
		return aadharCardRadioButton;
	}
	@FindBy(xpath= "//android.widget.Button[contains(@text,'No thanks')]")
	private WebElement attachAnotherNoThanksButton;
	
	public WebElement getAttachAnotherNoThanksButton(){
		return attachAnotherNoThanksButton;
	}
	@FindBy(xpath= "//android.widget.Spinner[contains(@text,'Select ID Proof')]")
	private WebElement selectIdProofDropDownList;
	
	public WebElement getSelectIdProofDropDownList(){
		return selectIdProofDropDownList;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'Not now')]")
	private WebElement locationAlertNotNowButton;
	
	public WebElement getlocationAlertNotNowButton(){
		return locationAlertNotNowButton;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Login to Update KYC.')]")
	private WebElement loginToUpdateKycHeader;
	
	public WebElement getLoginToUpdateKycHeader(){
		return loginToUpdateKycHeader;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@text,'User name')]")
	private WebElement userId;
	
	public WebElement getUserId(){
		return userId;
	}
	
	@FindBy(xpath= "//android.widget.EditText[contains(@text,'Password')]")
	private WebElement passwordField;
	
	public WebElement getPasswordField(){
		return passwordField;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@text,'LOGIN')]")
	private WebElement loginButton;
	
	public WebElement getLoginButton(){
		return loginButton;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'Add New Proof')]")
	private WebElement addAnotherFile;
	
	public WebElement getAddAnotherFile(){
		return addAnotherFile;
	}
	
	@FindBy(xpath= "//android.widget.Image[contains(@text,'Camera')]")
	private WebElement cameraIcon;
	
	public WebElement getCameraIcon(){
		return cameraIcon;
	}
	
	@FindBy(xpath= "//android.widget.TextView[contains(@text,'Camera')]")
	private WebElement cameraOption;
	
	public WebElement getCameraOption(){
		return cameraOption;
	}
	
	@FindBy(xpath= "//android.widget.CheckBox[contains(@resource-id,'terms')]")
	private WebElement termsCheckBok;
	
	public WebElement getTermsCheckBok(){
		return termsCheckBok;
	}
	
	@FindBy(xpath= "//android.widget.Button[contains(@resource-id,'mkycSubmit')]")
	private WebElement submitButton;
	
	public WebElement getSubmitButton(){
		return submitButton;
	}
	
	@FindBy(xpath= "//android.view.View[contains(@text,'1 file uploaded')]")
	private WebElement oneFileUploaded;
	
	public WebElement getOneFileUploaded(){
		return oneFileUploaded;
	}
	
}
